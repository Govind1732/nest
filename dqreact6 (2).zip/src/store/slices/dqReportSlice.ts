import { createSlice, createAsyncThunk, type PayloadAction } from "@reduxjs/toolkit"

// Define initial filter options
const initialFilterOptions = {
  platforms: ["GCP", "TeraData", "AWS", "Azure"],
  lobs: ["Network Performance", "Customer Experience", "Billing", "Operations"],
  productTypes: ["5G Home", "Wireless", "Fios", "Enterprise"],
  productAreas: ["East", "West", "Central", "National"],
  productNames: ["Product A", "Product B", "Product C", "Product D"],
  businessPrograms: ["Program 1", "Program 2", "Program 3", "Program 4"],
}

// Define initial state
interface DQReportState {
  dashboardView: boolean
  dataProductsView: boolean
  tableLevelAssetsView: boolean
  selectedLabel: string | null
  enterpriseData: any[]
  dqTrendData: any
  productTypeWiseData: any[]
  lobWiseData: any[]
  isLoading: boolean
  error: string | null
  startDate: string
  endDate: string
  filterOptions: typeof initialFilterOptions
  filterValues: any
}

const initialState: DQReportState = {
  dashboardView: true,
  dataProductsView: false,
  tableLevelAssetsView: false,
  selectedLabel: null,
  enterpriseData: [],
  dqTrendData: { trend_line: [] },
  productTypeWiseData: [],
  lobWiseData: [],
  isLoading: false,
  error: null,
  startDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().split("T")[0], // 7 days ago
  endDate: new Date().toISOString().split("T")[0], // today
  filterOptions: initialFilterOptions,
  filterValues: {},
}

// Async thunk for fetching DQ report data
export const fetchDQReportData = createAsyncThunk("dqReport/fetchData", async (_, { rejectWithValue }) => {
  try {
    // In a real app, these would be API calls
    // For demo purposes, we'll simulate responses
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Mock enterprise data
    const enterpriseData = [
      {
        no_of_assets: 1043,
        TBL_COMPLETENESS: 91.5,
        TBL_TIMELINESS: 100.0,
        TBL_UNIQUENESS: 90.8,
        tbl_conformity: 95.3,
        tbl_validity: 91.6,
        tbl_consistency: 98.8,
        OVERALL_DQ_SCORE: 94.7,
      },
    ]

    // Mock LOB-wise data
    const lobWiseData = [
      { lob_name: "Network Performance", lob_dq_score: 94.2, no_of_assets: 412 },
      { lob_name: "Customer Experience", lob_dq_score: 89.7, no_of_assets: 287 },
      { lob_name: "Billing", lob_dq_score: 92.5, no_of_assets: 156 },
      { lob_name: "Operations", lob_dq_score: 96.3, no_of_assets: 188 },
    ]

    // Mock DQ trend data
    const dqTrendData = {
      trend_line: Array(7)
        .fill(0)
        .map((_, i) => {
          const date = new Date()
          date.setDate(date.getDate() - (6 - i))
          return {
            run_date: date.toISOString().split("T")[0],
            trend_score: Math.floor(Math.random() * 10) + 90, // Random score between 90-100
          }
        }),
    }

    // Mock product type wise data
    const productTypeWiseData = [
      {
        product_type: "5G Home",
        no_of_assets: 412,
        TBL_COMPLETENESS: 92.5,
        TBL_TIMELINESS: 98.7,
        TBL_UNIQUENESS: 91.2,
        tbl_conformity: 94.8,
        tbl_validity: 90.3,
        tbl_consistency: 97.1,
        OVERALL_DQ_SCORE: 94.1,
      },
      {
        product_type: "Wireless",
        no_of_assets: 287,
        TBL_COMPLETENESS: 89.3,
        TBL_TIMELINESS: 97.5,
        TBL_UNIQUENESS: 88.9,
        tbl_conformity: 92.1,
        tbl_validity: 87.6,
        tbl_consistency: 95.4,
        OVERALL_DQ_SCORE: 91.8,
      },
      {
        product_type: "Fios",
        no_of_assets: 156,
        TBL_COMPLETENESS: 94.7,
        TBL_TIMELINESS: 99.2,
        TBL_UNIQUENESS: 93.5,
        tbl_conformity: 96.3,
        tbl_validity: 92.8,
        tbl_consistency: 98.6,
        OVERALL_DQ_SCORE: 95.9,
      },
      {
        product_type: "Enterprise",
        no_of_assets: 188,
        TBL_COMPLETENESS: 90.8,
        TBL_TIMELINESS: 98.1,
        TBL_UNIQUENESS: 90.2,
        tbl_conformity: 93.7,
        tbl_validity: 89.5,
        tbl_consistency: 96.9,
        OVERALL_DQ_SCORE: 93.2,
      },
    ]

    return {
      enterpriseData,
      lobWiseData,
      dqTrendData,
      productTypeWiseData,
    }
  } catch (error) {
    return rejectWithValue("Failed to fetch DQ report data")
  }
})

// Async thunk for applying filters
export const applyFilters = createAsyncThunk("dqReport/applyFilters", async (filters: any, { rejectWithValue }) => {
  try {
    // In a real app, this would be an API call with the filters
    // For demo purposes, we'll simulate a response
    await new Promise((resolve) => setTimeout(resolve, 1500))

    // Mock filtered data - in a real app, this would come from the API
    // For demo, we'll just return slightly modified data
    const enterpriseData = [
      {
        no_of_assets: Math.floor(Math.random() * 500) + 500,
        TBL_COMPLETENESS: Math.floor(Math.random() * 10) + 85,
        TBL_TIMELINESS: Math.floor(Math.random() * 10) + 90,
        TBL_UNIQUENESS: Math.floor(Math.random() * 10) + 85,
        tbl_conformity: Math.floor(Math.random() * 10) + 85,
        tbl_validity: Math.floor(Math.random() * 10) + 85,
        tbl_consistency: Math.floor(Math.random() * 10) + 90,
        OVERALL_DQ_SCORE: Math.floor(Math.random() * 10) + 85,
      },
    ]

    // Mock LOB-wise data
    const lobWiseData = [
      {
        lob_name: "Network Performance",
        lob_dq_score: Math.floor(Math.random() * 10) + 85,
        no_of_assets: Math.floor(Math.random() * 200) + 200,
      },
      {
        lob_name: "Customer Experience",
        lob_dq_score: Math.floor(Math.random() * 10) + 85,
        no_of_assets: Math.floor(Math.random() * 200) + 100,
      },
      {
        lob_name: "Billing",
        lob_dq_score: Math.floor(Math.random() * 10) + 85,
        no_of_assets: Math.floor(Math.random() * 100) + 100,
      },
      {
        lob_name: "Operations",
        lob_dq_score: Math.floor(Math.random() * 10) + 85,
        no_of_assets: Math.floor(Math.random() * 100) + 100,
      },
    ]

    // Mock DQ trend data
    const dqTrendData = {
      trend_line: Array(7)
        .fill(0)
        .map((_, i) => {
          const date = new Date(filters.startDate)
          date.setDate(date.getDate() + i)
          return {
            run_date: date.toISOString().split("T")[0],
            trend_score: Math.floor(Math.random() * 15) + 85, // Random score between 85-100
          }
        }),
    }

    // Mock product type wise data
    const productTypeWiseData = [
        {
          product_type: "5G Home",
          no_of_assets: Math.floor(Math.random() * 200) + 200,
          TBL_COMPLETENESS: Math.floor(Math.random() * 10) + 85,
          TBL_TIMELINESS: Math.floor(Math.random() * 10) + 90,
          TBL_UNIQUENESS: Math.floor(Math.random() * 10) + 85,
          tbl_conformity: Math.floor(Math.random() * 10) + 85,
          tbl_validity: Math.floor(Math.random() * 10) + 85,
          tbl_consistency: Math.floor(Math.random() * 10) + 90,
          OVERALL_DQ_SCORE: Math.floor(Math.random() * 10) + 85,
        },
        {
          product_type: "Wireless",
          no_of_assets: Math.floor(Math.random() * 200) + 100,
          TBL_COMPLETENESS: Math.floor(Math.random() * 10) + 85,
          TBL_TIMELINESS: Math.floor(Math.random() * 10) + 90,
          TBL_UNIQUENESS: Math.floor(Math.random() * 10) + 85,
          tbl_conformity: Math.floor(Math.random() * 10) + 85,
          tbl_validity: Math.floor(Math.random() * 10) + 85,
          tbl_consistency: Math.floor(Math.random() * 10) + 90,
          OVERALL_DQ_SCORE: Math.floor(Math.random() * 10) + 85,
        },
        {
          product_type: "Fios",
          no_of_assets: Math.floor(Math.random() * 100) + 100,
          TBL_COMPLETENESS: Math.floor(Math.random() * 10) + 85,
          TBL_TIMELINESS: Math.floor(Math.random() * 10) + 90,
          TBL_UNIQUENESS: Math.floor(Math.random() * 10) + 85,
          tbl_conformity: Math.floor(Math.random() * 10) + 85,
          tbl_validity: Math.floor(Math.random() * 10) + 85,
          tbl_consistency: Math.floor(Math.random() * 10) + 90,
          OVERALL_DQ_SCORE: Math.floor(Math.random() * 10) + 85,
        },
        {
          product_type: "Enterprise",
          no_of_assets: Math.floor(Math.random() * 100) + 100,
          TBL_COMPLETENESS: Math.floor(Math.random() * 10) + 85,\
          TBL_TIMELINESS: Math.floor  * 100) + 100,
          TBL_COMPLETENESS: Math.floor(Math.random() * 10) + 85,
          TBL_TIMELINESS: Math.floor(Math.random() * 10) + 90,
          TBL_UNIQUENESS: Math.floor(Math.random() * 10) + 85,
          tbl_conformity: Math.floor(Math.random() * 10) + 85,
          tbl_validity: Math.floor(Math.random() * 10) + 85,
          tbl_consistency: Math.floor(Math.random() * 10) + 90,
          OVERALL_DQ_SCORE: Math.floor(Math.random() * 10) + 85,
        },
      ]

    return {
      enterpriseData,
      lobWiseData,
      dqTrendData,
      productTypeWiseData,
      startDate: filters.startDate.toISOString().split("T")[0],
      endDate: filters.endDate.toISOString().split("T")[0],
    }
  } catch (error) {
    return rejectWithValue("Failed to apply filters")
  }
})

// Create the slice
const dqReportSlice = createSlice({
  name: "dqReport",
  initialState,
  reducers: {
    setDashboardView: (state, action: PayloadAction<boolean>) => {
      state.dashboardView = action.payload
    },
    setDataProductsView: (state, action: PayloadAction<boolean>) => {
      state.dataProductsView = action.payload
    },
    setTableLevelAssetsView: (state, action: PayloadAction<boolean>) => {
      state.tableLevelAssetsView = action.payload
    },
    setSelectedLabel: (state, action: PayloadAction<string | null>) => {
      state.selectedLabel = action.payload
    },
    resetFilters: (state) => {
      state.filterValues = {}
      state.startDate = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().split("T")[0]
      state.endDate = new Date().toISOString().split("T")[0]
    },
  },
  extraReducers: (builder) => {
    builder
      // Fetch DQ report data
      .addCase(fetchDQReportData.pending, (state) => {
        state.isLoading = true
        state.error = null
      })
      .addCase(fetchDQReportData.fulfilled, (state, action) => {
        state.isLoading = false
        state.enterpriseData = action.payload.enterpriseData
        state.lobWiseData = action.payload.lobWiseData
        state.dqTrendData = action.payload.dqTrendData
        state.productTypeWiseData = action.payload.productTypeWiseData
      })
      .addCase(fetchDQReportData.rejected, (state, action) => {
        state.isLoading = false
        state.error = action.payload as string
      })

      // Apply filters
      .addCase(applyFilters.pending, (state) => {
        state.isLoading = true
        state.error = null
      })
      .addCase(applyFilters.fulfilled, (state, action) => {
        state.isLoading = false
        state.enterpriseData = action.payload.enterpriseData
        state.lobWiseData = action.payload.lobWiseData
        state.dqTrendData = action.payload.dqTrendData
        state.productTypeWiseData = action.payload.productTypeWiseData
        state.startDate = action.payload.startDate
        state.endDate = action.payload.endDate
        state.filterValues = action.meta.arg
      })
      .addCase(applyFilters.rejected, (state, action) => {
        state.isLoading = false
        state.error = action.payload as string
      })
  },
})

export const { setDashboardView, setDataProductsView, setTableLevelAssetsView, setSelectedLabel, resetFilters } =
  dqReportSlice.actions

export default dqReportSlice.reducer
