import { createSlice, type PayloadAction } from "@reduxjs/toolkit"

interface ActiveProduct {
  productId: string
  L2_productId: string
  tableName: string
}

interface DQDomainLevelReportState {
  activeProduct: ActiveProduct
  showAllColumns: boolean
  dashboardView: boolean
  selectedTable: string
  columnsData: any[]
  last7days: string[]
}

const initialState: DQDomainLevelReportState = {
  activeProduct: {
    productId: "",
    L2_productId: "",
    tableName: "",
  },
  showAllColumns: false,
  dashboardView: true,
  selectedTable: "",
  columnsData: [],
  last7days: [],
}

export const dqDomainLevelReportSlice = createSlice({
  name: "dqDomainLevelReport",
  initialState,
  reducers: {
    setActiveProduct: (state, action: PayloadAction<ActiveProduct>) => {
      state.activeProduct = action.payload
    },
    setShowAllColumns: (state, action: PayloadAction<boolean>) => {
      state.showAllColumns = action.payload
    },
    setDashboardView: (state, action: PayloadAction<boolean>) => {
      state.dashboardView = action.payload
    },
    setSelectedTable: (state, action: PayloadAction<string>) => {
      state.selectedTable = action.payload
    },
    setColumnsData: (state, action: PayloadAction<any[]>) => {
      state.columnsData = action.payload
    },
    setLast7days: (state, action: PayloadAction<string[]>) => {
      state.last7days = action.payload
    },
  },
})

export const { setActiveProduct, setShowAllColumns, setDashboardView, setSelectedTable, setColumnsData, setLast7days } =
  dqDomainLevelReportSlice.actions

export default dqDomainLevelReportSlice.reducer
