// DataProfile slice for Redux
import { createSlice, type PayloadAction } from "@reduxjs/toolkit"

interface DataProfileState {
  environment: string
  dbName: string
  tableName: string
}

const initialState: DataProfileState = {
  environment: "TeraData",
  dbName: "",
  tableName: "",
}

const dataProfileSlice = createSlice({
  name: "dataProfile",
  initialState,
  reducers: {
    setEnvironment: (state, action: PayloadAction<string>) => {
      state.environment = action.payload
    },
    setDbName: (state, action: PayloadAction<string>) => {
      state.dbName = action.payload
    },
    setTableName: (state, action: PayloadAction<string>) => {
      state.tableName = action.payload
    },
    clearState: (state) => {
      state.environment = "TeraData"
      state.dbName = ""
      state.tableName = ""
    },
  },
})

export const { setEnvironment, setDbName, setTableName, clearState } = dataProfileSlice.actions

export default dataProfileSlice.reducer
