import { createSlice, createAsyncThunk } from "@reduxjs/toolkit"

interface AutoProfileState {
  dbName: string
  tableName: string
  file: File | null
  isUploading: boolean
  isLoading: boolean
  error: string | null
  tableData: any[]
}

const initialState: AutoProfileState = {
  dbName: "",
  tableName: "",
  file: null,
  isUploading: false,
  isLoading: false,
  error: null,
  tableData: [],
}

export const submitAutoProfileRequest = createAsyncThunk(
  "autoProfile/submitRequest",
  async (payload: { file: File }, thunkAPI) => {
    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1500))
      return { message: "Auto profile request submitted successfully" }
    } catch (error: any) {
      return thunkAPI.rejectWithValue(error.message)
    }
  },
)

const autoProfileSlice = createSlice({
  name: "autoProfile",
  initialState,
  reducers: {
    setDbName: (state, action) => {
      state.dbName = action.payload
    },
    setTableName: (state, action) => {
      state.tableName = action.payload
    },
    setFile: (state, action) => {
      state.file = action.payload
    },
    setIsUploading: (state, action) => {
      state.isUploading = action.payload
    },
    clearState: (state) => {
      state.dbName = ""
      state.tableName = ""
      state.file = null
      state.isUploading = false
      state.isLoading = false
      state.error = null
      state.tableData = []
    },
    setTableData: (state, action) => {
      state.tableData = action.payload
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(submitAutoProfileRequest.pending, (state) => {
        state.isLoading = true
        state.error = null
      })
      .addCase(submitAutoProfileRequest.fulfilled, (state) => {
        state.isLoading = false
        state.isUploading = false
        state.error = null
      })
      .addCase(submitAutoProfileRequest.rejected, (state, action) => {
        state.isLoading = false
        state.error = action.payload
        state.isUploading = false
      })
  },
})

export const { setDbName, setTableName, setFile, setIsUploading, clearState, setTableData } = autoProfileSlice.actions

export default autoProfileSlice.reducer
