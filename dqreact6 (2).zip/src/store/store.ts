import { configureStore } from "@reduxjs/toolkit"
import { setupListeners } from "@reduxjs/toolkit/query"
import { api } from "@/services/api"
import appReducer from "@/store/slices/app-slice"
import dqReportReducer from "@/store/slices/dq-report-slice"
import dqDomainLevelReportReducer from "@/store/slices/dq-domain-level-report-slice"
import autoProfileReducer from "@/store/slices/auto-profile-slice"
import ruleProfileDTRanReducer from "@/store/slices/rule-profile-dtran-slice"
import ruleProfileOneCorpReducer from "@/store/slices/rule-profile-onecorp-slice"
import ruleProfileMLEReducer from "@/store/slices/rule-profile-mle-slice"
import dataProfileReducer from "@/store/slices/data-profile-slice"
import customProfileReducer from "@/store/slices/custom-profile-slice"
import dqMetricsAPIReducer from "@/store/slices/dq-metrics-api-slice"
import etlPipelineIntegrationAPIReducer from "@/store/slices/etl-pipeline-integration-api-slice"

export const store = configureStore({
  reducer: {
    [api.reducerPath]: api.reducer,
    app: appReducer,
    dqReport: dqReportReducer,
    dqDomainLevelReport: dqDomainLevelReportReducer,
    autoProfile: autoProfileReducer,
    ruleProfileDTRan: ruleProfileDTRanReducer,
    ruleProfileOneCorp: ruleProfileOneCorpReducer,
    ruleProfileMLE: ruleProfileMLEReducer,
    dataProfile: dataProfileReducer,
    customProfile: customProfileReducer,
    dqMetricsAPI: dqMetricsAPIReducer,
    etlPipelineIntegrationAPI: etlPipelineIntegrationAPIReducer,
  },
  middleware: (getDefaultMiddleware) => getDefaultMiddleware().concat(api.middleware),
})

setupListeners(store.dispatch)

export type RootState = ReturnType<typeof store.getState>
export type AppDispatch = typeof store.dispatch
