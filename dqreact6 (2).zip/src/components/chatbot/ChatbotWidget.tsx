"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { MessageSquare, X, Send, Loader2, ChevronDown, ChevronUp } from "lucide-react"
import { useTranslation } from "react-i18next"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Avatar } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"

interface Message {
  id: string
  content: string
  role: "user" | "assistant"
  timestamp: Date
}

export function ChatbotWidget() {
  const { t } = useTranslation()
  const [isOpen, setIsOpen] = useState(false)
  const [isMinimized, setIsMinimized] = useState(false)
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      content: t("chatbot.welcomeMessage"),
      role: "assistant",
      timestamp: new Date(),
    },
  ])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  // Scroll to bottom of messages
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" })
    }
  }, [messages])

  // Focus input when chat opens
  useEffect(() => {
    if (isOpen && !isMinimized && inputRef.current) {
      inputRef.current.focus()
    }
  }, [isOpen, isMinimized])

  const toggleChat = () => {
    setIsOpen(!isOpen)
    if (isMinimized) setIsMinimized(false)
  }

  const toggleMinimize = () => {
    setIsMinimized(!isMinimized)
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInput(e.target.value)
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && input.trim()) {
      handleSendMessage()
    }
  }

  const handleSendMessage = async () => {
    if (!input.trim()) return

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      content: input.trim(),
      role: "user",
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)

    try {
      // In a real app, this would be an API call to a chatbot service
      // For demo purposes, we'll simulate a response after a delay
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Process the user's query
      const response = processUserQuery(userMessage.content)

      // Add assistant message
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: response,
        role: "assistant",
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, assistantMessage])
    } catch (error) {
      console.error("Failed to get chatbot response:", error)

      // Add error message
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: t("chatbot.errorMessage"),
        role: "assistant",
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, errorMessage])
    } finally {
      setIsLoading(false)
    }
  }

  // Simple function to process user queries
  // In a real app, this would be replaced with an actual AI service call
  const processUserQuery = (query: string): string => {
    const lowerQuery = query.toLowerCase()

    // Data quality related queries
    if (lowerQuery.includes("data quality") || lowerQuery.includes("dq")) {
      if (lowerQuery.includes("definition") || lowerQuery.includes("what is")) {
        return t("chatbot.responses.dqDefinition")
      }
      if (lowerQuery.includes("metric") || lowerQuery.includes("measure")) {
        return t("chatbot.responses.dqMetrics")
      }
      if (lowerQuery.includes("report")) {
        return t("chatbot.responses.dqReports")
      }
    }

    // Navigation related queries
    if (lowerQuery.includes("find") || lowerQuery.includes("where is") || lowerQuery.includes("how to access")) {
      if (lowerQuery.includes("profile") || lowerQuery.includes("profiling")) {
        return t("chatbot.responses.findProfiling")
      }
      if (lowerQuery.includes("report")) {
        return t("chatbot.responses.findReports")
      }
      if (lowerQuery.includes("validation")) {
        return t("chatbot.responses.findValidation")
      }
      if (lowerQuery.includes("api") || lowerQuery.includes("integration")) {
        return t("chatbot.responses.findAPI")
      }
    }

    // Feature related queries
    if (lowerQuery.includes("how to") || lowerQuery.includes("how do i")) {
      if (lowerQuery.includes("upload") || lowerQuery.includes("submit")) {
        return t("chatbot.responses.howToUpload")
      }
      if (lowerQuery.includes("filter") || lowerQuery.includes("search")) {
        return t("chatbot.responses.howToFilter")
      }
      if (lowerQuery.includes("download") || lowerQuery.includes("export")) {
        return t("chatbot.responses.howToDownload")
      }
    }

    // Default response for unrecognized queries
    return t("chatbot.responses.default")
  }

  return (
    <>
      {/* Chat toggle button */}
      <motion.div
        className="fixed bottom-4 right-4 z-50"
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: "spring", stiffness: 260, damping: 20 }}
      >
        <Button
          onClick={toggleChat}
          className="h-12 w-12 rounded-full shadow-lg"
          aria-label={isOpen ? t("chatbot.close") : t("chatbot.open")}
        >
          {isOpen ? <X className="h-5 w-5" /> : <MessageSquare className="h-5 w-5" />}
        </Button>
      </motion.div>

      {/* Chat window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            className="fixed bottom-20 right-4 z-50 w-80 md:w-96"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 20, opacity: 0 }}
            transition={{ type: "spring", stiffness: 260, damping: 20 }}
          >
            <Card className="shadow-xl border-primary/10">
              <CardHeader className="p-3 border-b flex flex-row items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Avatar className="h-8 w-8 bg-primary">
                    <MessageSquare className="h-4 w-4 text-white" />
                  </Avatar>
                  <div>
                    <h3 className="text-sm font-medium">{t("chatbot.title")}</h3>
                    <p className="text-xs text-muted-foreground">{t("chatbot.subtitle")}</p>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={toggleMinimize}
                  aria-label={isMinimized ? t("chatbot.expand") : t("chatbot.minimize")}
                >
                  {isMinimized ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                </Button>
              </CardHeader>

              <AnimatePresence>
                {!isMinimized && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                  >
                    <CardContent className="p-0">
                      <div className="h-80 overflow-y-auto p-4 space-y-4">
                        {messages.map((message) => (
                          <div
                            key={message.id}
                            className={cn(
                              "flex flex-col max-w-[80%] rounded-lg p-3",
                              message.role === "user" ? "ml-auto bg-primary text-primary-foreground" : "bg-muted",
                            )}
                          >
                            <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                            <span className="text-xs opacity-70 mt-1 self-end">
                              {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                            </span>
                          </div>
                        ))}
                        {isLoading && (
                          <div className="flex flex-col max-w-[80%] rounded-lg p-3 bg-muted">
                            <div className="flex items-center space-x-2">
                              <Loader2 className="h-4 w-4 animate-spin" />
                              <p className="text-sm">{t("chatbot.thinking")}</p>
                            </div>
                          </div>
                        )}
                        <div ref={messagesEndRef} />
                      </div>
                    </CardContent>

                    <CardFooter className="p-3 border-t">
                      <div className="flex w-full items-center space-x-2">
                        <Input
                          ref={inputRef}
                          type="text"
                          placeholder={t("chatbot.inputPlaceholder")}
                          value={input}
                          onChange={handleInputChange}
                          onKeyDown={handleKeyDown}
                          disabled={isLoading}
                          className="flex-1"
                        />
                        <Button
                          size="icon"
                          onClick={handleSendMessage}
                          disabled={!input.trim() || isLoading}
                          aria-label={t("chatbot.send")}
                        >
                          <Send className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardFooter>
                  </motion.div>
                )}
              </AnimatePresence>

              {isMinimized && (
                <div className="p-2">
                  <Badge variant="outline" className="w-full justify-center py-1">
                    {messages.length - 1} {t("chatbot.messages")}
                  </Badge>
                </div>
              )}
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
