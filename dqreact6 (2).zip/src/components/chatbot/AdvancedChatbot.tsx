"use client"

import type React from "react"

import { useState, useRef, useEffect, useCallback } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  MessageSquare,
  X,
  Send,
  Loader2,
  ChevronDown,
  ChevronUp,
  Sparkles,
  Paperclip,
  Maximize2,
  Minimize2,
} from "lucide-react"
import { useTranslation } from "react-i18next"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Avatar } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { cn } from "@/lib/utils"
import { useAIChat } from "@/hooks/useAIChat"
import { useLocation } from "react-router-dom"
import { useAuth } from "@/modules/auth/hooks/useAuth"

interface Message {
  id: string
  content: string
  role: "user" | "assistant"
  timestamp: Date
  attachments?: string[]
  contextInfo?: {
    page?: string
    action?: string
    userRole?: string
  }
}

export function AdvancedChatbot() {
  const { t } = useTranslation()
  const location = useLocation()
  const { user } = useAuth()
  const [isOpen, setIsOpen] = useState(false)
  const [isMinimized, setIsMinimized] = useState(false)
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState("")
  const [attachments, setAttachments] = useState<string[]>([])
  const [suggestedQuestions, setSuggestedQuestions] = useState<string[]>([])
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const { processMessage, isProcessing, generateSuggestedQuestions } = useAIChat()

  // Initialize chatbot with welcome message
  useEffect(() => {
    if (messages.length === 0) {
      const welcomeMessage: Message = {
        id: "1",
        content: t("chatbot.welcomeMessage"),
        role: "assistant",
        timestamp: new Date(),
      }
      setMessages([welcomeMessage])

      // Generate initial suggested questions based on current page
      generateInitialSuggestions()
    }
  }, [])

  // Generate context-aware suggested questions
  const generateInitialSuggestions = useCallback(async () => {
    const currentPath = location.pathname
    const userRole = user?.role || "Guest"

    const questions = await generateSuggestedQuestions(currentPath, userRole)
    setSuggestedQuestions(questions)
  }, [location.pathname, user?.role, generateSuggestedQuestions])

  // Update suggested questions when page changes
  useEffect(() => {
    if (isOpen) {
      generateInitialSuggestions()
    }
  }, [location.pathname, isOpen, generateInitialSuggestions])

  // Scroll to bottom of messages
  useEffect(() => {
    if (messagesEndRef.current && isOpen && !isMinimized) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" })
    }
  }, [messages, isOpen, isMinimized])

  // Focus input when chat opens
  useEffect(() => {
    if (isOpen && !isMinimized && inputRef.current) {
      inputRef.current.focus()
    }
  }, [isOpen, isMinimized])

  const toggleChat = () => {
    setIsOpen(!isOpen)
    if (isMinimized) setIsMinimized(false)
    if (isFullscreen) setIsFullscreen(false)
  }

  const toggleMinimize = () => {
    setIsMinimized(!isMinimized)
  }

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen)
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInput(e.target.value)
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && input.trim()) {
      handleSendMessage()
    }
  }

  const handleFileUpload = () => {
    fileInputRef.current?.click()
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const newAttachments = Array.from(e.target.files).map((file) => file.name)
      setAttachments([...attachments, ...newAttachments])
    }
  }

  const handleRemoveAttachment = (attachment: string) => {
    setAttachments(attachments.filter((a) => a !== attachment))
  }

  const handleSuggestedQuestionClick = (question: string) => {
    setInput(question)
    handleSendMessage(question)
  }

  const handleSendMessage = async (overrideMessage?: string) => {
    const messageText = overrideMessage || input
    if (!messageText.trim() && attachments.length === 0) return

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      content: messageText.trim(),
      role: "user",
      timestamp: new Date(),
      attachments: attachments.length > 0 ? [...attachments] : undefined,
      contextInfo: {
        page: location.pathname,
        userRole: user?.role,
      },
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setAttachments([])

    try {
      // Process the user's query with context
      const response = await processMessage(messageText, messages, {
        currentPath: location.pathname,
        userRole: user?.role,
        attachments: userMessage.attachments,
      })

      // Add assistant message
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: response.text,
        role: "assistant",
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, assistantMessage])

      // Generate new suggested questions based on the conversation
      const newSuggestions = await generateSuggestedQuestions(location.pathname, user?.role || "Guest", [
        ...messages,
        userMessage,
        assistantMessage,
      ])
      setSuggestedQuestions(newSuggestions)
    } catch (error) {
      console.error("Failed to get chatbot response:", error)

      // Add error message
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: t("chatbot.errorMessage"),
        role: "assistant",
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, errorMessage])
    }
  }

  return (
    <>
      {/* Chat toggle button */}
      <motion.div
        className="fixed bottom-4 right-4 z-50"
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: "spring", stiffness: 260, damping: 20 }}
      >
        <Button
          onClick={toggleChat}
          className="h-12 w-12 rounded-full shadow-lg"
          aria-label={isOpen ? t("chatbot.close") : t("chatbot.open")}
        >
          {isOpen ? <X className="h-5 w-5" /> : <MessageSquare className="h-5 w-5" />}
        </Button>
      </motion.div>

      {/* Chat window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            className={cn(
              "fixed z-50",
              isFullscreen ? "inset-4 md:inset-8 lg:inset-16" : "bottom-20 right-4 w-80 md:w-96",
            )}
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 20, opacity: 0 }}
            transition={{ type: "spring", stiffness: 260, damping: 20 }}
          >
            <Card className="shadow-xl border-primary/10 h-full flex flex-col">
              <CardHeader className="p-3 border-b flex flex-row items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Avatar className="h-8 w-8 bg-primary">
                    <Sparkles className="h-4 w-4 text-white" />
                  </Avatar>
                  <div>
                    <h3 className="text-sm font-medium">{t("chatbot.advancedTitle")}</h3>
                    <p className="text-xs text-muted-foreground">{t("chatbot.advancedSubtitle")}</p>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={toggleMinimize}
                          className="h-7 w-7"
                          aria-label={isMinimized ? t("chatbot.expand") : t("chatbot.minimize")}
                        >
                          {isMinimized ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>{isMinimized ? t("chatbot.expand") : t("chatbot.minimize")}</TooltipContent>
                    </Tooltip>
                  </TooltipProvider>

                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={toggleFullscreen}
                          className="h-7 w-7"
                          aria-label={isFullscreen ? t("chatbot.exitFullscreen") : t("chatbot.fullscreen")}
                        >
                          {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        {isFullscreen ? t("chatbot.exitFullscreen") : t("chatbot.fullscreen")}
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>

                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={toggleChat}
                          className="h-7 w-7"
                          aria-label={t("chatbot.close")}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>{t("chatbot.close")}</TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
              </CardHeader>

              <AnimatePresence>
                {!isMinimized && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="flex flex-col flex-1"
                  >
                    <CardContent className="p-0 flex-1 overflow-hidden flex flex-col">
                      <div className="flex-1 overflow-y-auto p-4 space-y-4">
                        {messages.map((message) => (
                          <div
                            key={message.id}
                            className={cn(
                              "flex flex-col max-w-[80%] rounded-lg p-3",
                              message.role === "user" ? "ml-auto bg-primary text-primary-foreground" : "bg-muted",
                            )}
                          >
                            <p className="text-sm whitespace-pre-wrap">{message.content}</p>

                            {message.attachments && message.attachments.length > 0 && (
                              <div className="mt-2 space-y-1">
                                {message.attachments.map((attachment, index) => (
                                  <div
                                    key={index}
                                    className={cn(
                                      "text-xs flex items-center gap-1 p-1 rounded",
                                      message.role === "user"
                                        ? "bg-primary-foreground/20 text-primary-foreground"
                                        : "bg-background/50",
                                    )}
                                  >
                                    <Paperclip className="h-3 w-3" />
                                    <span className="truncate">{attachment}</span>
                                  </div>
                                ))}
                              </div>
                            )}

                            <span className="text-xs opacity-70 mt-1 self-end">
                              {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                            </span>
                          </div>
                        ))}

                        {isProcessing && (
                          <div className="flex flex-col max-w-[80%] rounded-lg p-3 bg-muted">
                            <div className="flex items-center space-x-2">
                              <Loader2 className="h-4 w-4 animate-spin" />
                              <p className="text-sm">{t("chatbot.thinking")}</p>
                            </div>
                          </div>
                        )}

                        <div ref={messagesEndRef} />
                      </div>

                      {/* Suggested questions */}
                      {suggestedQuestions.length > 0 && (
                        <div className="p-2 border-t">
                          <p className="text-xs text-muted-foreground mb-2">{t("chatbot.suggested")}</p>
                          <div className="flex flex-wrap gap-2">
                            {suggestedQuestions.map((question, index) => (
                              <Button
                                key={index}
                                variant="outline"
                                size="sm"
                                className="text-xs py-1 h-auto"
                                onClick={() => handleSuggestedQuestionClick(question)}
                              >
                                {question}
                              </Button>
                            ))}
                          </div>
                        </div>
                      )}
                    </CardContent>

                    <CardFooter className="p-3 border-t">
                      {attachments.length > 0 && (
                        <div className="mb-2 flex flex-wrap gap-1 w-full">
                          {attachments.map((attachment, index) => (
                            <Badge key={index} variant="secondary" className="flex items-center gap-1 text-xs">
                              <Paperclip className="h-3 w-3" />
                              <span className="max-w-[100px] truncate">{attachment}</span>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-4 w-4 ml-1 p-0"
                                onClick={() => handleRemoveAttachment(attachment)}
                              >
                                <X className="h-3 w-3" />
                              </Button>
                            </Badge>
                          ))}
                        </div>
                      )}

                      <div className="flex w-full items-center space-x-2">
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="outline"
                                size="icon"
                                className="h-8 w-8 flex-shrink-0"
                                onClick={handleFileUpload}
                                aria-label={t("chatbot.attachFile")}
                              >
                                <Paperclip className="h-4 w-4" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>{t("chatbot.attachFile")}</TooltipContent>
                          </Tooltip>
                        </TooltipProvider>

                        <Input
                          ref={inputRef}
                          type="text"
                          placeholder={t("chatbot.advancedInputPlaceholder")}
                          value={input}
                          onChange={handleInputChange}
                          onKeyDown={handleKeyDown}
                          disabled={isProcessing}
                          className="flex-1"
                        />

                        <Button
                          size="icon"
                          onClick={() => handleSendMessage()}
                          disabled={(!input.trim() && attachments.length === 0) || isProcessing}
                          aria-label={t("chatbot.send")}
                          className="h-8 w-8 flex-shrink-0"
                        >
                          <Send className="h-4 w-4" />
                        </Button>

                        <input type="file" ref={fileInputRef} className="hidden" onChange={handleFileChange} multiple />
                      </div>
                    </CardFooter>
                  </motion.div>
                )}
              </AnimatePresence>

              {isMinimized && (
                <div className="p-2">
                  <Badge variant="outline" className="w-full justify-center py-1">
                    {messages.length - 1} {t("chatbot.messages")}
                  </Badge>
                </div>
              )}
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
