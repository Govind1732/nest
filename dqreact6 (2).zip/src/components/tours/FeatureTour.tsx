"use client"

import { useState, useEffect } from "react"
import { useLocation } from "react-router-dom"
import { useTranslation } from "react-i18next"
import { GuidedTour, type TourStep } from "@/components/ui/guided-tour"
import { useGuidedTour } from "@/hooks/useGuidedTour"
import { Button } from "@/components/ui/button"
import { HelpCircle } from "lucide-react"
import { ROUTES } from "@/config/constants"

export function FeatureTour() {
  const { t } = useTranslation()
  const location = useLocation()
  const [tourSteps, setTourSteps] = useState<TourStep[]>([])
  const [tourId, setTourId] = useState<string>("")

  // Determine which tour to show based on current route
  useEffect(() => {
    const currentPath = location.pathname
    let newTourId = ""
    let steps: TourStep[] = []

    // Match route to tour
    if (currentPath === ROUTES.HOME || currentPath === ROUTES.DQ_REPORT) {
      newTourId = "home-tour"
      steps = getHomeTourSteps()
    } else if (currentPath.includes("/profiling/")) {
      newTourId = "profiling-tour"
      steps = getProfilingTourSteps()
    } else if (currentPath === ROUTES.DATA_QUALITY_VALIDATION) {
      newTourId = "validation-tour"
      steps = getValidationTourSteps()
    } else if (currentPath === ROUTES.DQ_DOMAIN_LEVEL_REPORT) {
      newTourId = "reports-tour"
      steps = getReportsTourSteps()
    } else if (currentPath === ROUTES.ADMIN) {
      newTourId = "admin-tour"
      steps = getAdminTourSteps()
    }

    setTourId(newTourId)
    setTourSteps(steps)
  }, [location.pathname, t])

  const {
    isOpen,
    startTour,
    closeTour,
    completeTour,
    currentStep,
    setCurrentStep,
    hasCompletedTour,
    resetTourCompletion,
  } = useGuidedTour({
    tourId,
    steps: tourSteps,
    autoStart: false,
  })

  // Get tour steps for Home/DQ Report page
  const getHomeTourSteps = (): TourStep[] => {
    return [
      {
        target: ".dq-dashboard-header",
        title: t("tours.home.welcome.title"),
        content: t("tours.home.welcome.content"),
        placement: "bottom",
      },
      {
        target: ".dq-overall-score",
        title: t("tours.home.overallScore.title"),
        content: t("tours.home.overallScore.content"),
        placement: "right",
      },
      {
        target: ".dq-metrics-cards",
        title: t("tours.home.metrics.title"),
        content: t("tours.home.metrics.content"),
        placement: "bottom",
      },
      {
        target: ".dq-charts-container",
        title: t("tours.home.charts.title"),
        content: t("tours.home.charts.content"),
        placement: "top",
      },
      {
        target: ".dq-filters-section",
        title: t("tours.home.filters.title"),
        content: t("tours.home.filters.content"),
        placement: "top",
      },
    ]
  }

  // Get tour steps for Profiling pages
  const getProfilingTourSteps = (): TourStep[] => {
    return [
      {
        target: ".profiling-header",
        title: t("tours.profiling.welcome.title"),
        content: t("tours.profiling.welcome.content"),
        placement: "bottom",
      },
      {
        target: ".profiling-upload-area",
        title: t("tours.profiling.uploadArea.title"),
        content: t("tours.profiling.uploadArea.content"),
        placement: "right",
      },
      {
        target: ".profiling-submit-button",
        title: t("tours.profiling.submitButton.title"),
        content: t("tours.profiling.submitButton.content"),
        placement: "top",
      },
      {
        target: ".profiling-view-edit-tab",
        title: t("tours.profiling.viewEdit.title"),
        content: t("tours.profiling.viewEdit.content"),
        placement: "bottom",
      },
    ]
  }

  // Get tour steps for Validation page
  const getValidationTourSteps = (): TourStep[] => {
    return [
      {
        target: ".validation-header",
        title: t("tours.validation.welcome.title"),
        content: t("tours.validation.welcome.content"),
        placement: "bottom",
      },
      {
        target: ".validation-tabs",
        title: t("tours.validation.tabs.title"),
        content: t("tours.validation.tabs.content"),
        placement: "bottom",
      },
      {
        target: ".validation-steps-indicator",
        title: t("tours.validation.steps.title"),
        content: t("tours.validation.steps.content"),
        placement: "right",
      },
      {
        target: ".validation-source-section",
        title: t("tours.validation.sourceSelection.title"),
        content: t("tours.validation.sourceSelection.content"),
        placement: "bottom",
      },
    ]
  }

  // Get tour steps for Reports page
  const getReportsTourSteps = (): TourStep[] => {
    return [
      {
        target: ".domain-report-header",
        title: t("tours.reports.welcome.title"),
        content: t("tours.reports.welcome.content"),
        placement: "bottom",
      },
      {
        target: ".domain-list-container",
        title: t("tours.reports.domainList.title"),
        content: t("tours.reports.domainList.content"),
        placement: "right",
      },
      {
        target: ".domain-score-cards",
        title: t("tours.reports.scoreCards.title"),
        content: t("tours.reports.scoreCards.content"),
        placement: "bottom",
      },
      {
        target: ".domain-charts-container",
        title: t("tours.reports.charts.title"),
        content: t("tours.reports.charts.content"),
        placement: "top",
      },
      {
        target: ".domain-download-button",
        title: t("tours.reports.download.title"),
        content: t("tours.reports.download.content"),
        placement: "left",
      },
    ]
  }

  // Get tour steps for Admin page
  const getAdminTourSteps = (): TourStep[] => {
    return [
      {
        target: ".admin-header",
        title: t("tours.admin.welcome.title"),
        content: t("tours.admin.welcome.content"),
        placement: "bottom",
      },
      {
        target: ".admin-stats-cards",
        title: t("tours.admin.stats.title"),
        content: t("tours.admin.stats.content"),
        placement: "bottom",
      },
      {
        target: ".admin-role-requests-tab",
        title: t("tours.admin.roleRequests.title"),
        content: t("tours.admin.roleRequests.content"),
        placement: "right",
      },
      {
        target: ".admin-user-management-tab",
        title: t("tours.admin.userManagement.title"),
        content: t("tours.admin.userManagement.content"),
        placement: "right",
      },
      {
        target: ".admin-approval-buttons",
        title: t("tours.admin.approvalButtons.title"),
        content: t("tours.admin.approvalButtons.content"),
        placement: "top",
      },
    ]
  }

  // Only show the tour button if we have steps for the current page
  if (tourSteps.length === 0) {
    return null
  }

  return (
    <>
      {/* Tour trigger button */}
      <div className="fixed bottom-4 left-4 z-40">
        <Button
          onClick={hasCompletedTour ? resetTourCompletion : startTour}
          variant="outline"
          className="rounded-full shadow-md flex items-center gap-2"
        >
          <HelpCircle className="h-4 w-4" />
          {hasCompletedTour ? t("guidedTour.restartTour") : t("guidedTour.startTour")}
        </Button>
      </div>

      {/* Guided tour component */}
      <GuidedTour
        steps={tourSteps}
        isOpen={isOpen}
        onClose={closeTour}
        onComplete={completeTour}
        currentStepIndex={currentStep}
        onStepChange={setCurrentStep}
      />
    </>
  )
}
