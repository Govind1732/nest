"use client"

import { useMemo } from "react"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell } from "recharts"
import { useTranslation } from "react-i18next"

interface DataPoint {
  name: string
  value: number
  [key: string]: any
}

interface AdvancedBarChartProps {
  data: DataPoint[]
  xKey?: string
  yKey?: string
  barKey?: string
  width?: number | string
  height?: number | string
  horizontal?: boolean
  showGrid?: boolean
  showLegend?: boolean
  showTooltip?: boolean
  colorBy?: "value" | "category"
  colors?: string[]
  barSize?: number
  margin?: { top?: number; right?: number; bottom?: number; left?: number }
  tickFormatter?: (value: any) => string
  tooltipFormatter?: (value: any, name: string, props: any) => [string, string]
  animationDuration?: number
  className?: string
}

export function AdvancedBarChart({
  data,
  xKey = "name",
  yKey = "value",
  barKey = "value",
  width = "100%",
  height = 300,
  horizontal = false,
  showGrid = true,
  showLegend = false,
  showTooltip = true,
  colorBy = "value",
  colors = ["#008331", "#bc9f0a", "#b95319"], // Success, Warning, Error
  barSize = 20,
  margin = { top: 20, right: 30, bottom: 50, left: 30 },
  tickFormatter,
  tooltipFormatter,
  animationDuration = 1000,
  className,
}: AdvancedBarChartProps) {
  const { t } = useTranslation()

  const getColorByValue = (value: number) => {
    if (value >= 90) return colors[0] // Success
    if (value >= 80) return colors[1] // Warning
    return colors[2] // Error
  }

  const defaultTickFormatter = (value: number) => `${value}%`

  const defaultTooltipFormatter = (value: number) => [`${value}%`, t("reports.dqReport.metrics.value")]

  const formattedData = useMemo(() => {
    return data.map((item) => ({
      ...item,
      color: colorBy === "value" ? getColorByValue(item[yKey]) : undefined,
    }))
  }, [data, yKey, colorBy])

  return (
    <div className={className} style={{ width, height }}>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={formattedData} layout={horizontal ? "vertical" : "horizontal"} margin={margin}>
          {showGrid && <CartesianGrid strokeDasharray="3 3" />}

          {horizontal ? (
            <>
              <XAxis type="number" domain={[0, 100]} tickFormatter={tickFormatter || defaultTickFormatter} />
              <YAxis type="category" dataKey={xKey} width={120} />
            </>
          ) : (
            <>
              <XAxis dataKey={xKey} />
              <YAxis domain={[0, 100]} tickFormatter={tickFormatter || defaultTickFormatter} />
            </>
          )}

          {showTooltip && (
            <Tooltip formatter={tooltipFormatter || defaultTooltipFormatter} cursor={{ fill: "rgba(0, 0, 0, 0.1)" }} />
          )}

          {showLegend && <Legend />}

          <Bar dataKey={barKey} barSize={barSize} animationDuration={animationDuration} animationEasing="ease-in-out">
            {formattedData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color || colors[index % colors.length]} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}
