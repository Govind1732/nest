"use client"

import { useRef, useState, useEffect } from "react"

interface LineChartProps {
  data: Array<{ date: string; value: number }>
  height?: number
  width?: number
  className?: string
  lineColor?: string
  areaColor?: string
  showDots?: boolean
  showLabels?: boolean
  showGrid?: boolean
  showTooltip?: boolean
}

export function LineChart({
  data,
  height = 200,
  width,
  className,
  lineColor = "hsl(var(--primary))",
  areaColor = "hsl(var(--primary) / 0.2)",
  showDots = true,
  showLabels = true,
  showGrid = false,
  showTooltip = true,
}: LineChartProps) {
  const svgRef = useRef<SVGSVGElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const [containerWidth, setContainerWidth] = useState(0)
  const [hoveredPoint, setHoveredPoint] = useState<{ x: number; y: number; value: number; date: string } | null>(null)
  
  // Sort data by date
  const sortedData = [...data].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
  
  // Calculate min and max values
  const minValue = Math.min(...sortedData.map(d => d.value))
  const maxValue = Math.max(...sortedData.map(d => d.value))
  
  // Update container width on resize
  useEffect(() => {
    if (!containerRef.current) return
    
    const updateWidth = () => {
      if (containerRef.current) {
        setContainerWidth(containerRef.current.clientWidth)
      }
    }
    
    updateWidth()
    window.addEventListener('resize', updateWidth)
    return () => window.removeEventListener('resize', updateWidth)
  }, [])

  // Use container width if width is not provided
  const chartWidth =

\
