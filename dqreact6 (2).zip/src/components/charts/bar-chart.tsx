"use client"

import { useRef, useState } from "react"
import { motion } from "framer-motion"
import { cn } from "@/lib/utils"

interface BarChartProps {
  data: Array<{ name: string; value: number; color?: string }>
  height?: number
  className?: string
  showLabels?: boolean
  showValues?: boolean
  maxValue?: number
  horizontal?: boolean
  onClick?: (item: { name: string; value: number }) => void
}

export function BarChart({
  data,
  height = 200,
  className,
  showLabels = true,
  showValues = true,
  maxValue,
  horizontal = false,
  onClick,
}: BarChartProps) {
  const chartRef = useRef<HTMLDivElement>(null)
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null)
  const calculatedMaxValue = maxValue || Math.max(...data.map((item) => item.value), 0)

  // Default colors from the theme
  const defaultColors = [
    "hsl(var(--chart-1))",
    "hsl(var(--chart-2))",
    "hsl(var(--chart-3))",
    "hsl(var(--chart-4))",
    "hsl(var(--chart-5))",
  ]

  // Get color based on value
  const getColorByValue = (value: number) => {
    if (value >= 90) return "hsl(var(--success))"
    if (value >= 80) return "hsl(var(--warning))"
    return "hsl(var(--error))"
  }

  if (horizontal) {
    return (
      <div className={cn("w-full", className)} ref={chartRef}>
        <div className="space-y-2">
          {data.map((item, index) => {
            const barWidth = (item.value / calculatedMaxValue) * 100
            const barColor = item.color || getColorByValue(item.value) || defaultColors[index % defaultColors.length]

            return (
              <div
                key={item.name}
                className="flex items-center gap-2"
                onMouseEnter={() => setHoveredIndex(index)}
                onMouseLeave={() => setHoveredIndex(null)}
                onClick={() => onClick?.(item)}
              >
                {showLabels && <div className="w-32 truncate text-sm">{item.name}</div>}
                <div className="flex-1 h-8 bg-muted rounded-md overflow-hidden">
                  <motion.div
                    className="h-full rounded-md"
                    style={{ backgroundColor: barColor }}
                    initial={{ width: 0 }}
                    animate={{ width: `${barWidth}%` }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    whileHover={{ opacity: 0.9 }}
                    whileTap={{ scale: 0.98 }}
                  />
                </div>
                {showValues && (
                  <motion.div
                    className="w-12 text-right text-sm font-medium"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.5 + index * 0.1 }}
                  >
                    {item.value}%
                  </motion.div>
                )}
              </div>
            )
          })}
        </div>
      </div>
    )
  }

  return (
    <div className={cn("w-full", className)} ref={chartRef}>
      <div className="flex items-end h-full space-x-2">
        {data.map((item, index) => {
          const barHeight = (item.value / calculatedMaxValue) * height
          const barColor = item.color || getColorByValue(item.value) || defaultColors[index % defaultColors.length]
          const isHovered = hoveredIndex === index

          return (
            <div
              key={item.name}
              className="flex flex-col items-center flex-1"
              onMouseEnter={() => setHoveredIndex(index)}
              onMouseLeave={() => setHoveredIndex(null)}
              onClick={() => onClick?.(item)}
            >
              <div className="w-full relative" style={{ height: `${height}px` }}>
                <motion.div
                  className={cn(
                    "absolute bottom-0 w-full rounded-t-sm cursor-pointer transition-all",
                    onClick && "hover:opacity-80",
                  )}
                  style={{ backgroundColor: barColor }}
                  initial={{ height: 0 }}
                  animate={{
                    height: `${barHeight}px`,
                    scale: isHovered ? 1.05 : 1,
                  }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                />
              </div>
              {showValues && (
                <motion.div
                  className="text-xs font-medium mt-1"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.5 + index * 0.1 }}
                >
                  {item.value}%
                </motion.div>
              )}
              {showLabels && (
                <motion.div
                  className="text-xs text-muted-foreground mt-1 truncate w-full text-center"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.7 + index * 0.1 }}
                >
                  {item.name}
                </motion.div>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}
