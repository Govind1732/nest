"use client"

import { useRef, useEffect } from "react"
import { Chart, type ChartConfiguration, registerables } from "chart.js"
import { cn } from "@/lib/utils"
import { formatPercentage } from "@/lib/formatters"

Chart.register(...registerables)

interface LineChartProps {
  data: {
    labels: string[]
    datasets: {
      label: string
      data: number[]
      borderColor?: string
      backgroundColor?: string
    }[]
  }
  height?: number
  className?: string
  showLegend?: boolean
}

export function LineChart({ data, height = 300, className, showLegend = false }: LineChartProps) {
  const chartRef = useRef<HTMLCanvasElement>(null)
  const chartInstance = useRef<Chart | null>(null)

  useEffect(() => {
    if (!chartRef.current) return

    // Destroy existing chart
    if (chartInstance.current) {
      chartInstance.current.destroy()
    }

    const ctx = chartRef.current.getContext("2d")
    if (!ctx) return

    const defaultColors = [
      "rgba(0, 131, 49, 1)",
      "rgba(188, 159, 10, 1)",
      "rgba(185, 83, 25, 1)",
      "rgba(59, 130, 246, 1)",
      "rgba(139, 92, 246, 1)",
    ]

    const defaultBackgroundColors = [
      "rgba(0, 131, 49, 0.1)",
      "rgba(188, 159, 10, 0.1)",
      "rgba(185, 83, 25, 0.1)",
      "rgba(59, 130, 246, 0.1)",
      "rgba(139, 92, 246, 0.1)",
    ]

    const enhancedDatasets = data.datasets.map((dataset, index) => ({
      ...dataset,
      borderColor: dataset.borderColor || defaultColors[index % defaultColors.length],
      backgroundColor: dataset.backgroundColor || defaultBackgroundColors[index % defaultBackgroundColors.length],
      tension: 0.3,
      fill: true,
      pointRadius: 3,
      pointHoverRadius: 5,
      pointBackgroundColor: dataset.borderColor || defaultColors[index % defaultColors.length],
    }))

    const config: ChartConfiguration = {
      type: "line",
      data: {
        labels: data.labels,
        datasets: enhancedDatasets,
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: showLegend,
            position: "top",
            labels: {
              usePointStyle: true,
              padding: 20,
              font: {
                size: 12,
              },
            },
          },
          tooltip: {
            mode: "index",
            intersect: false,
            callbacks: {
              label: (context) => {
                return `${context.dataset.label}: ${formatPercentage(context.parsed.y)}`
              },
            },
          },
        },
        scales: {
          x: {
            grid: {
              display: false,
            },
            ticks: {
              font: {
                size: 11,
              },
            },
          },
          y: {
            beginAtZero: true,
            grid: {
              display: true,
              drawBorder: false,
            },
            ticks: {
              font: {
                size: 11,
              },
              callback: (value) => {
                return `${value}%`
              },
            },
          },
        },
      },
    }

    chartInstance.current = new Chart(ctx, config)

    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy()
      }
    }
  }, [data, showLegend])

  return (
    <div className={cn("w-full", className)} style={{ height }}>
      <canvas ref={chartRef} />
    </div>
  )
}
