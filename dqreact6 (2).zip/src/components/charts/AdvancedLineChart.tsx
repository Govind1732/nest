"use client"

import { useMemo } from "react"
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ReferenceLine,
} from "recharts"
import { useTranslation } from "react-i18next"

interface DataPoint {
  [key: string]: any
}

interface DataSet {
  name: string
  data: number[]
  color?: string
}

interface AdvancedLineChartProps {
  data: DataPoint[]
  dataSets: DataSet[]
  xKey: string
  width?: number | string
  height?: number | string
  showGrid?: boolean
  showLegend?: boolean
  showTooltip?: boolean
  colors?: string[]
  margin?: { top?: number; right?: number; bottom?: number; left?: number }
  tickFormatter?: (value: any) => string
  tooltipFormatter?: (value: any, name: string, props: any) => [string, string]
  animationDuration?: number
  showArea?: boolean
  targetLine?: number
  className?: string
  dotSize?: number
  activeDotSize?: number
  strokeWidth?: number
}

export function AdvancedLineChart({
  data,
  dataSets,
  xKey,
  width = "100%",
  height = 300,
  showGrid = true,
  showLegend = true,
  showTooltip = true,
  colors = ["#008331", "#bc9f0a", "#b95319", "#0284c7", "#7c3aed"],
  margin = { top: 20, right: 30, bottom: 50, left: 30 },
  tickFormatter,
  tooltipFormatter,
  animationDuration = 1000,
  showArea = false,
  targetLine,
  className,
  dotSize = 3,
  activeDotSize = 6,
  strokeWidth = 2,
}: AdvancedLineChartProps) {
  const { t } = useTranslation()

  const defaultTickFormatter = (value: number) => `${value}%`

  const defaultTooltipFormatter = (value: number, name: string) => [
    `${value}%`,
    t(`reports.dqReport.metrics.${name.toLowerCase()}`, name),
  ]

  const getLineColor = (index: number, dataset: DataSet) => {
    return dataset.color || colors[index % colors.length]
  }

  const formattedData = useMemo(() => {
    // Transform data if needed
    return data
  }, [data])

  return (
    <div className={className} style={{ width, height }}>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={formattedData} margin={margin}>
          {showGrid && <CartesianGrid strokeDasharray="3 3" />}

          <XAxis dataKey={xKey} padding={{ left: 10, right: 10 }} />

          <YAxis domain={[0, "dataMax"]} tickFormatter={tickFormatter || defaultTickFormatter} />

          {showTooltip && (
            <Tooltip formatter={tooltipFormatter || defaultTooltipFormatter} cursor={{ strokeDasharray: "3 3" }} />
          )}

          {showLegend && <Legend wrapperStyle={{ paddingTop: 20 }} verticalAlign="top" align="right" />}

          {targetLine !== undefined && (
            <ReferenceLine
              y={targetLine}
              stroke="#888"
              strokeDasharray="3 3"
              label={{ value: `Target: ${targetLine}%`, position: "left" }}
            />
          )}

          {dataSets.map((dataset, index) => (
            <Line
              key={dataset.name}
              type="monotone"
              dataKey={dataset.name}
              name={dataset.name}
              stroke={getLineColor(index, dataset)}
              strokeWidth={strokeWidth}
              dot={{ r: dotSize }}
              activeDot={{ r: activeDotSize }}
              fill={showArea ? `${getLineColor(index, dataset)}20` : "none"}
              animationDuration={animationDuration}
              animationEasing="ease-in-out"
              isAnimationActive={true}
            />
          ))}
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}
