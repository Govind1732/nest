"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { ChevronDown, ChevronRight } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { cn } from "@/lib/utils"
import { SIDEBAR_ITEMS } from "@/config/navigation"
import { getIconByName } from "@/lib/icons"

export function Sidebar({ isOpen }: { isOpen: boolean }) {
  const pathname = usePathname()
  const [openMenus, setOpenMenus] = useState<Record<string, boolean>>({})

  // Initialize open state based on current path
  useEffect(() => {
    const newOpenMenus: Record<string, boolean> = {}

    SIDEBAR_ITEMS.forEach((item) => {
      if (item.submenu) {
        const isSubmenuActive = item.submenu.some(
          (subItem) => pathname === subItem.href || pathname.startsWith(subItem.href + "/"),
        )
        if (isSubmenuActive) {
          newOpenMenus[item.title] = true
        }
      }
    })

    setOpenMenus(newOpenMenus)
  }, [pathname])

  const toggleMenu = (title: string) => {
    setOpenMenus((prev) => ({
      ...prev,
      [title]: !prev[title],
    }))
  }

  return (
    <motion.aside
      className={cn(
        "h-screen sticky top-0 bg-sidebar border-r border-border/40 overflow-y-auto",
        isOpen ? "w-64" : "w-16",
      )}
      initial={false}
      animate={{ width: isOpen ? 256 : 64 }}
      transition={{ duration: 0.3, ease: "easeInOut" }}
    >
      <div className="py-4">
        <nav className="space-y-1">
          {SIDEBAR_ITEMS.map((item) => (
            <div key={item.title} className="px-3">
              {item.submenu ? (
                <div>
                  <button
                    onClick={() => toggleMenu(item.title)}
                    className={cn(
                      "flex items-center w-full px-3 py-2 text-sm rounded-md transition-colors",
                      "hover:bg-muted/50",
                      openMenus[item.title] ? "bg-muted/50" : "",
                    )}
                  >
                    {item.icon && <span className="mr-2">{getIconByName(item.icon)}</span>}
                    {isOpen && (
                      <>
                        <span className="flex-1 text-left">{item.title}</span>
                        {openMenus[item.title] ? (
                          <ChevronDown className="h-4 w-4" />
                        ) : (
                          <ChevronRight className="h-4 w-4" />
                        )}
                      </>
                    )}
                  </button>

                  <AnimatePresence initial={false}>
                    {openMenus[item.title] && isOpen && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.3 }}
                        className="overflow-hidden"
                      >
                        <div className="pl-9 pr-3 py-1 space-y-1">
                          {item.submenu.map((subItem) => (
                            <Link
                              key={subItem.href}
                              href={subItem.href}
                              className={cn(
                                "block px-3 py-2 text-sm rounded-md transition-colors",
                                "hover:bg-muted/50",
                                pathname === subItem.href
                                  ? "bg-muted/50 text-primary font-medium"
                                  : "text-muted-foreground",
                              )}
                            >
                              {subItem.title}
                            </Link>
                          ))}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ) : (
                <Link
                  href={item.href}
                  className={cn(
                    "flex items-center px-3 py-2 text-sm rounded-md transition-colors",
                    "hover:bg-muted/50",
                    pathname === item.href ? "bg-muted/50 text-primary font-medium" : "text-muted-foreground",
                  )}
                >
                  {item.icon && <span className="mr-2">{getIconByName(item.icon)}</span>}
                  {isOpen && <span>{item.title}</span>}
                </Link>
              )}
            </div>
          ))}
        </nav>
      </div>
    </motion.aside>
  )
}
