"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Link, useLocation } from "react-router-dom"
import {
  Home,
  Database,
  CheckCircle,
  Webhook,
  BarChart,
  FileText,
  ShieldCheck,
  ChevronDown,
  ChevronRight,
} from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { cn } from "@/lib/utils"
import { SIDEBAR_ITEMS } from "@/config/constants"

const iconMap: Record<string, React.ReactNode> = {
  Home: <Home className="h-4 w-4" />,
  Database: <Database className="h-4 w-4" />,
  CheckCircle: <CheckCircle className="h-4 w-4" />,
  Webhook: <Webhook className="h-4 w-4" />,
  BarChart: <BarChart className="h-4 w-4" />,
  FileText: <FileText className="h-4 w-4" />,
  ShieldCheck: <ShieldCheck className="h-4 w-4" />,
}

export function Sidebar() {
  const location = useLocation()
  const [openMenus, setOpenMenus] = useState<Record<string, boolean>>({})
  const [isCollapsed, setIsCollapsed] = useState(false)

  // Initialize open state based on current path
  useEffect(() => {
    const newOpenMenus: Record<string, boolean> = {}

    SIDEBAR_ITEMS.forEach((item) => {
      if (item.submenu) {
        const isSubmenuActive = item.submenu.some(
          (subItem) => location.pathname === subItem.href || location.pathname.startsWith(subItem.href + "/"),
        )
        if (isSubmenuActive) {
          newOpenMenus[item.title] = true
        }
      }
    })

    setOpenMenus(newOpenMenus)
  }, [location.pathname])

  const toggleMenu = (title: string) => {
    setOpenMenus((prev) => ({
      ...prev,
      [title]: !prev[title],
    }))
  }

  return (
    <motion.aside
      className={cn(
        "h-screen sticky top-0 bg-sidebar border-r border-border/40 overflow-y-auto",
        isCollapsed ? "w-16" : "w-64",
      )}
      initial={false}
      animate={{ width: isCollapsed ? 64 : 256 }}
      transition={{ duration: 0.3, ease: "easeInOut" }}
    >
      <div className="py-4">
        <div className="px-3 mb-4 flex justify-end">
          <button onClick={() => setIsCollapsed(!isCollapsed)} className="p-1 rounded-md hover:bg-muted">
            {isCollapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
          </button>
        </div>
        <nav className="space-y-1">
          {SIDEBAR_ITEMS.map((item) => (
            <div key={item.title} className="px-3">
              {item.submenu ? (
                <div>
                  <button
                    onClick={() => toggleMenu(item.title)}
                    className={cn(
                      "flex items-center w-full px-3 py-2 text-sm rounded-md transition-colors",
                      "hover:bg-muted/50",
                      openMenus[item.title] ? "bg-muted/50" : "",
                    )}
                  >
                    {item.icon && <span className="mr-2">{iconMap[item.icon]}</span>}
                    {!isCollapsed && (
                      <>
                        <span className="flex-1 text-left">{item.title}</span>
                        {openMenus[item.title] ? (
                          <ChevronDown className="h-4 w-4" />
                        ) : (
                          <ChevronRight className="h-4 w-4" />
                        )}
                      </>
                    )}
                  </button>

                  <AnimatePresence initial={false}>
                    {openMenus[item.title] && !isCollapsed && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.3 }}
                        className="overflow-hidden"
                      >
                        <div className="pl-9 pr-3 py-1 space-y-1">
                          {item.submenu.map((subItem) => (
                            <Link
                              key={subItem.href}
                              to={subItem.href}
                              className={cn(
                                "block px-3 py-2 text-sm rounded-md transition-colors",
                                "hover:bg-muted/50",
                                location.pathname === subItem.href
                                  ? "bg-muted/50 text-primary font-medium"
                                  : "text-muted-foreground",
                              )}
                            >
                              {subItem.title}
                            </Link>
                          ))}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ) : (
                <Link
                  to={item.href}
                  className={cn(
                    "flex items-center px-3 py-2 text-sm rounded-md transition-colors",
                    "hover:bg-muted/50",
                    location.pathname === item.href ? "bg-muted/50 text-primary font-medium" : "text-muted-foreground",
                  )}
                >
                  {item.icon && <span className="mr-2">{iconMap[item.icon]}</span>}
                  {!isCollapsed && <span>{item.title}</span>}
                </Link>
              )}
            </div>
          ))}
        </nav>
      </div>
    </motion.aside>
  )
}

function ChevronLeft(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="m15 18-6-6 6-6" />
    </svg>
  )
}
