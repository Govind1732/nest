"use client"

import { useState } from "react"
import { Link, useLocation } from "react-router-dom"
import { Menu, HelpCircle } from "lucide-react"
import { motion } from "framer-motion"
import { useTranslation } from "react-i18next"
import { cn } from "@/lib/utils"
import { NAVBAR_ITEMS } from "@/config/constants"
import { Button } from "@/components/ui/button"
import { ThemeToggle } from "@/components/ui/theme-toggle"
import { LanguageToggle } from "@/components/ui/language-toggle"
import { useAuth } from "@/modules/auth/hooks/useAuth"

export function Navbar() {
  const location = useLocation()
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const { user } = useAuth()
  const { t } = useTranslation()

  return (
    <motion.header
      className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60"
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.3 }}
      role="banner"
    >
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <Link to="/" className="flex items-center gap-2" aria-label="Home">
            <motion.img
              src="/Verizon_GlowV_RGB.svg"
              alt="LensX Logo"
              className="h-8 w-8"
              whileHover={{ scale: 1.1 }}
              transition={{ type: "spring", stiffness: 400, damping: 10 }}
            />
            <div className="flex flex-col">
              <span className="text-xl font-bold tracking-tight">{t("app.name").split(" - ")[0]}</span>
              <span className="text-xs text-muted-foreground">{t("app.name").split(" - ")[1]}</span>
            </div>
          </Link>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-6" aria-label="Main navigation">
          {NAVBAR_ITEMS.map((item) => (
            <Link
              key={item.href}
              to={item.href}
              className={cn(
                "text-sm font-medium transition-colors hover:text-primary relative",
                location.pathname === item.href ? "text-primary" : "text-muted-foreground",
              )}
              aria-current={location.pathname === item.href ? "page" : undefined}
            >
              {t(`common.navigation.${item.title.toLowerCase().replace(/\s+/g, "")}`)}
              {location.pathname === item.href && (
                <motion.div
                  className="absolute -bottom-[17px] left-0 right-0 h-[2px] bg-primary"
                  layoutId="navbar-indicator"
                  transition={{ type: "spring", stiffness: 300, damping: 30 }}
                />
              )}
            </Link>
          ))}
          <div className="flex items-center gap-2">
            <LanguageToggle />
            <ThemeToggle />
            <Button variant="ghost" size="icon">
              <HelpCircle className="h-5 w-5" />
              <span className="sr-only">{t("common.navigation.help")}</span>
            </Button>
            {user && (
              <div className="ml-4 flex items-center gap-2">
                <div
                  className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-medium"
                  aria-hidden="true"
                >
                  {user.name.charAt(0)}
                </div>
                <div className="hidden lg:block">
                  <div className="text-sm font-medium">{user.name}</div>
                  <div className="text-xs text-muted-foreground">{user.role}</div>
                </div>
              </div>
            )}
          </div>
        </nav>

        {/* Mobile Menu Button */}
        <div className="flex items-center gap-2 md:hidden">
          <LanguageToggle />
          <ThemeToggle />
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            aria-expanded={isMobileMenuOpen}
            aria-controls="mobile-menu"
          >
            <Menu className="h-5 w-5" />
            <span className="sr-only">{t("common.actions.menu")}</span>
          </Button>
        </div>

        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <motion.div
            id="mobile-menu"
            className="absolute top-16 left-0 right-0 bg-background border-b border-border/40 md:hidden"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            role="navigation"
            aria-label="Mobile navigation"
          >
            <nav className="container py-4 flex flex-col gap-2">
              {NAVBAR_ITEMS.map((item) => (
                <Link
                  key={item.href}
                  to={item.href}
                  className={cn(
                    "px-4 py-2 text-sm font-medium rounded-md transition-colors hover:bg-muted",
                    location.pathname === item.href ? "bg-muted text-primary" : "text-muted-foreground",
                  )}
                  onClick={() => setIsMobileMenuOpen(false)}
                  aria-current={location.pathname === item.href ? "page" : undefined}
                >
                  {t(`common.navigation.${item.title.toLowerCase().replace(/\s+/g, "")}`)}
                </Link>
              ))}
              <Link
                to="/help"
                className="px-4 py-2 text-sm font-medium rounded-md transition-colors hover:bg-muted flex items-center gap-2"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                <HelpCircle className="h-4 w-4" />
                <span>{t("common.navigation.help")}</span>
              </Link>
              {user && (
                <div className="px-4 py-2 border-t mt-2 pt-4">
                  <div className="flex items-center gap-2">
                    <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-medium">
                      {user.name.charAt(0)}
                    </div>
                    <div>
                      <div className="text-sm font-medium">{user.name}</div>
                      <div className="text-xs text-muted-foreground">{user.role}</div>
                    </div>
                  </div>
                </div>
              )}
            </nav>
          </motion.div>
        )}
      </div>
    </motion.header>
  )
}
