"use client"

import { useState, useEffect, useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { useTranslation } from "react-i18next"
import { X, ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"

export interface TourStep {
  target: string
  title: string
  content: string
  placement?: "top" | "right" | "bottom" | "left"
  spotlightPadding?: number
}

interface GuidedTourProps {
  steps: TourStep[]
  isOpen: boolean
  onClose: () => void
  onComplete: () => void
  currentStepIndex?: number
  onStepChange?: (index: number) => void
}

export function GuidedTour({
  steps,
  isOpen,
  onClose,
  onComplete,
  currentStepIndex = 0,
  onStepChange,
}: GuidedTourProps) {
  const { t } = useTranslation()
  const [currentStep, setCurrentStep] = useState(currentStepIndex)
  const [targetElement, setTargetElement] = useState<HTMLElement | null>(null)
  const [tooltipPosition, setTooltipPosition] = useState({ top: 0, left: 0 })
  const tooltipRef = useRef<HTMLDivElement>(null)

  // Update current step if controlled externally
  useEffect(() => {
    setCurrentStep(currentStepIndex)
  }, [currentStepIndex])

  // Find target element and calculate position
  useEffect(() => {
    if (!isOpen) return

    const step = steps[currentStep]
    if (!step) return

    const element = document.querySelector(step.target) as HTMLElement
    if (!element) {
      console.warn(`Target element not found: ${step.target}`)
      return
    }

    setTargetElement(element)

    // Calculate position
    const updatePosition = () => {
      if (!element || !tooltipRef.current) return

      const elementRect = element.getBoundingClientRect()
      const tooltipRect = tooltipRef.current.getBoundingClientRect()
      const padding = step.spotlightPadding || 8

      let top = 0
      let left = 0

      switch (step.placement) {
        case "top":
          top = elementRect.top - tooltipRect.height - padding
          left = elementRect.left + elementRect.width / 2 - tooltipRect.width / 2
          break
        case "right":
          top = elementRect.top + elementRect.height / 2 - tooltipRect.height / 2
          left = elementRect.right + padding
          break
        case "bottom":
          top = elementRect.bottom + padding
          left = elementRect.left + elementRect.width / 2 - tooltipRect.width / 2
          break
        case "left":
          top = elementRect.top + elementRect.height / 2 - tooltipRect.height / 2
          left = elementRect.left - tooltipRect.width - padding
          break
        default:
          // Default to bottom
          top = elementRect.bottom + padding
          left = elementRect.left + elementRect.width / 2 - tooltipRect.width / 2
      }

      // Ensure tooltip stays within viewport
      const viewportWidth = window.innerWidth
      const viewportHeight = window.innerHeight

      if (left < 20) left = 20
      if (left + tooltipRect.width > viewportWidth - 20) left = viewportWidth - tooltipRect.width - 20
      if (top < 20) top = 20
      if (top + tooltipRect.height > viewportHeight - 20) top = viewportHeight - tooltipRect.height - 20

      setTooltipPosition({ top, left })

      // Scroll element into view if needed
      if (
        elementRect.top < 0 ||
        elementRect.left < 0 ||
        elementRect.bottom > viewportHeight ||
        elementRect.right > viewportWidth
      ) {
        element.scrollIntoView({
          behavior: "smooth",
          block: "center",
          inline: "center",
        })
      }
    }

    // Initial position calculation
    updatePosition()

    // Recalculate on resize
    window.addEventListener("resize", updatePosition)

    // Cleanup
    return () => {
      window.removeEventListener("resize", updatePosition)
    }
  }, [isOpen, currentStep, steps])

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      const nextStep = currentStep + 1
      setCurrentStep(nextStep)
      if (onStepChange) onStepChange(nextStep)
    } else {
      handleComplete()
    }
  }

  const handlePrev = () => {
    if (currentStep > 0) {
      const prevStep = currentStep - 1
      setCurrentStep(prevStep)
      if (onStepChange) onStepChange(prevStep)
    }
  }

  const handleComplete = () => {
    onComplete()
  }

  const handleClose = () => {
    onClose()
  }

  if (!isOpen || !steps.length) return null

  const currentTourStep = steps[currentStep]
  if (!currentTourStep) return null

  return (
    <div className="fixed inset-0 z-[100] overflow-hidden" data-testid="guided-tour">
      {/* Overlay with spotlight */}
      <div className="absolute inset-0 bg-black/50" onClick={handleClose} />

      {targetElement && (
        <div
          className="absolute bg-transparent pointer-events-none"
          style={{
            top: targetElement.getBoundingClientRect().top - (currentTourStep.spotlightPadding || 8),
            left: targetElement.getBoundingClientRect().left - (currentTourStep.spotlightPadding || 8),
            width: targetElement.getBoundingClientRect().width + (currentTourStep.spotlightPadding || 8) * 2,
            height: targetElement.getBoundingClientRect().height + (currentTourStep.spotlightPadding || 8) * 2,
            boxShadow: "0 0 0 9999px rgba(0, 0, 0, 0.75)",
            borderRadius: "4px",
          }}
        />
      )}

      {/* Tooltip */}
      <AnimatePresence>
        <motion.div
          ref={tooltipRef}
          className="absolute z-[101]"
          style={{
            top: tooltipPosition.top,
            left: tooltipPosition.left,
          }}
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.9 }}
          transition={{ duration: 0.2 }}
        >
          <Card className="w-[300px] shadow-lg">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">{currentTourStep.title}</CardTitle>
                <Button variant="ghost" size="icon" onClick={handleClose} className="h-6 w-6">
                  <X className="h-4 w-4" />
                  <span className="sr-only">{t("guidedTour.close")}</span>
                </Button>
              </div>
            </CardHeader>
            <CardContent className="text-sm">{currentTourStep.content}</CardContent>
            <CardFooter className="flex justify-between pt-2">
              <div className="flex items-center text-xs text-muted-foreground">
                {currentStep + 1} / {steps.length}
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handlePrev}
                  disabled={currentStep === 0}
                  className={cn("h-8 px-2", currentStep === 0 && "opacity-50 cursor-not-allowed")}
                >
                  <ChevronLeft className="h-4 w-4 mr-1" />
                  {t("guidedTour.prev")}
                </Button>
                <Button variant="default" size="sm" onClick={handleNext} className="h-8 px-2">
                  {currentStep < steps.length - 1 ? t("guidedTour.next") : t("guidedTour.finish")}
                  {currentStep < steps.length - 1 && <ChevronRight className="h-4 w-4 ml-1" />}
                </Button>
              </div>
            </CardFooter>
          </Card>
        </motion.div>
      </AnimatePresence>
    </div>
  )
}
