"use client"

import { useState, useEffect } from "react"
import type { TourStep } from "@/components/ui/guided-tour"

interface UseGuidedTourOptions {
  tourId: string
  steps: TourStep[]
  autoStart?: boolean
  onComplete?: () => void
}

export function useGuidedTour({ tourId, steps, autoStart = false, onComplete }: UseGuidedTourOptions) {
  const [isOpen, setIsOpen] = useState(false)
  const [currentStep, setCurrentStep] = useState(0)
  const [hasCompletedTour, setHasCompletedTour] = useState(false)

  // Check if tour has been completed before
  useEffect(() => {
    const completedTours = JSON.parse(localStorage.getItem("completedTours") || "{}")
    if (completedTours[tourId]) {
      setHasCompletedTour(true)
    }

    // Auto start if enabled and tour not completed
    if (autoStart && !completedTours[tourId]) {
      setIsOpen(true)
    }
  }, [tourId, autoStart])

  const startTour = () => {
    setCurrentStep(0)
    setIsOpen(true)
  }

  const closeTour = () => {
    setIsOpen(false)
  }

  const completeTour = () => {
    setIsOpen(false)
    setHasCompletedTour(true)

    // Save completion status to localStorage
    const completedTours = JSON.parse(localStorage.getItem("completedTours") || "{}")
    completedTours[tourId] = true
    localStorage.setItem("completedTours", JSON.stringify(completedTours))

    if (onComplete) {
      onComplete()
    }
  }

  const resetTourCompletion = () => {
    setHasCompletedTour(false)

    // Remove from completed tours
    const completedTours = JSON.parse(localStorage.getItem("completedTours") || "{}")
    delete completedTours[tourId]
    localStorage.setItem("completedTours", JSON.stringify(completedTours))
  }

  return {
    isOpen,
    currentStep,
    hasCompletedTour,
    startTour,
    closeTour,
    completeTour,
    setCurrentStep,
    resetTourCompletion,
  }
}
