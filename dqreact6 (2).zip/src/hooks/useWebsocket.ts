"use client"

import { useState, useEffect, useRef, useCallback } from "react"
import { io, type Socket } from "socket.io-client"

interface UseWebSocketOptions {
  url: string
  events: Record<string, (data: any) => void>
  autoConnect?: boolean
  reconnectionAttempts?: number
  reconnectionDelay?: number
}

export function useWebSocket({
  url,
  events,
  autoConnect = true,
  reconnectionAttempts = 5,
  reconnectionDelay = 5000,
}: UseWebSocketOptions) {
  const [isConnected, setIsConnected] = useState(false)
  const [error, setError] = useState<Error | null>(null)
  const socketRef = useRef<Socket | null>(null)
  const reconnectAttemptsRef = useRef(0)

  const connect = useCallback(() => {
    // Close existing connection if any
    if (socketRef.current) {
      socketRef.current.close()
    }

    // Initialize socket
    socketRef.current = io(url, {
      transports: ["websocket"],
      autoConnect,
      reconnection: true,
      reconnectionAttempts,
      reconnectionDelay,
    })

    // Handle connection events
    socketRef.current.on("connect", () => {
      setIsConnected(true)
      setError(null)
      reconnectAttemptsRef.current = 0
    })

    socketRef.current.on("disconnect", () => {
      setIsConnected(false)
    })

    socketRef.current.on("connect_error", (err) => {
      setError(err)
      reconnectAttemptsRef.current += 1

      if (reconnectAttemptsRef.current >= reconnectionAttempts) {
        socketRef.current?.disconnect()
      }
    })

    // Register custom event handlers
    Object.entries(events).forEach(([event, handler]) => {
      socketRef.current?.on(event, handler)
    })

    return () => {
      // Clean up event listeners
      socketRef.current?.off("connect")
      socketRef.current?.off("disconnect")
      socketRef.current?.off("connect_error")

      Object.keys(events).forEach((event) => {
        socketRef.current?.off(event)
      })

      // Close connection
      socketRef.current?.close()
      socketRef.current = null
    }
  }, [url, events, autoConnect, reconnectionAttempts, reconnectionDelay])

  useEffect(() => {
    return connect()
  }, [connect])

  const disconnect = useCallback(() => {
    socketRef.current?.disconnect()
  }, [])

  const emit = useCallback((event: string, data?: any) => {
    if (!socketRef.current) {
      setError(new Error("Socket not connected"))
      return
    }

    socketRef.current.emit(event, data)
  }, [])

  return {
    isConnected,
    error,
    socket: socketRef.current,
    connect,
    disconnect,
    emit,
  }
}
