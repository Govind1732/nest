import { rest } from "msw"
import { API_BASE_URL } from "@/config/constants"

export const handlers = [
  // Auth endpoints
  rest.get(`${API_BASE_URL}/auth/me`, (req, res, ctx) => {
    return res(
      ctx.json({
        id: "user-1",
        name: "John Doe",
        email: "john.doe@verizon.com",
        role: "Admin",
        projects: ["DTRan", "OneCorp", "MLE"],
      }),
    )
  }),

  rest.post(`${API_BASE_URL}/auth/login`, (req, res, ctx) => {
    return res(
      ctx.json({
        user: {
          id: "user-1",
          name: "John Doe",
          email: "john.doe@verizon.com",
          role: "Admin",
          projects: ["DTRan", "OneCorp", "MLE"],
        },
        token: "mock-jwt-token",
      }),
    )
  }),

  // DQ Reports endpoints
  rest.get(`${API_BASE_URL}/reports/dq-domain-level`, (req, res, ctx) => {
    return res(
      ctx.json({
        dateRange: "03/22/2025 - 03/28/2025",
        dqScore: 93.4,
        dqMetrics: {
          completeness: 92.9,
          timeliness: 100.0,
          uniqueness: 90.8,
          conformity: 89.8,
          validity: 90.5,
          consistency: 98.8,
        },
        products: [
          {
            name: "Journey Data Product",
            score: 93.4,
            subItems: [
              { name: "Customer Interaction", score: 91.8 },
              { name: "Customer Product Order", score: 93.5 },
            ],
          },
          // Other products...
        ],
        dqScoreTables: {
          labels: [
            "jnl_cntm_po_updates_1",
            "jnl_cntm_po_updates_2",
            // More labels...
          ],
          values: [81.7, 84.3, 89.7, 90.5, 92.0, 92.2, 92.4, 92.4],
        },
        dqScoreTrend: {
          labels: ["03/22", "03/23", "03/24", "03/25", "03/26", "03/27", "03/28", "03/29"],
          datasets: [
            {
              label: "DQ Score",
              data: [92.4, 92.8, 93.9, 93.4, 93.1, 93.7, 93.8, 97.2],
            },
          ],
        },
      }),
    )
  }),

  // Profile endpoints
  rest.post(`${API_BASE_URL}/profiling/data-profile/check-connectivity`, (req, res, ctx) => {
    return res(
      ctx.json({
        success: true,
        message: "Connection successful",
      }),
    )
  }),

  // More API handlers...
]
