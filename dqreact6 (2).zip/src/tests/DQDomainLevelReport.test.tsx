import { render, screen, fireEvent, waitFor } from "@testing-library/react"
import { Provider } from "react-redux"
import { configureStore } from "@reduxjs/toolkit"
import { DQDomainLevelReport } from "@/modules/reports/components/DQDomainLevelReport/DQDomainLevelReport"
import dqDomainLevelReportReducer from "@/store/slices/dqDomainLevelReportSlice"
import { api } from "@/services/api"
import { rest } from "msw"
import { setupServer } from "msw/node"

// Mock data
const mockProductData = [
  {
    product_id: "Test Product",
    dq_score: {
      completeness: 95,
      uniqueness: 88,
      timeliness: 92,
      consistency: 85,
      validity: 90,
      conformity: 94,
    },
    barChart_allTables: [
      {
        tableName: "Table 1",
        overall_DQ_Score: 92,
        columns: [],
      },
    ],
    lineChart: {
      "2023-01-01": 90,
      "2023-01-02": 92,
      "2023-01-03": 91,
    },
  },
]

const mockL2Data = [
  {
    product_id: "Test Product",
    level2_data: [
      {
        level2_name: "L2 Product",
        dq_score: {
          completeness: 94,
          uniqueness: 87,
          timeliness: 91,
          consistency: 84,
          validity: 89,
          conformity: 93,
        },
        barChart_allTables: [
          {
            tableName: "L2 Table 1",
            overall_DQ_Score: 91,
            columns: [],
          },
        ],
        lineChart: {
          "2023-01-01": 89,
          "2023-01-02": 91,
          "2023-01-03": 90,
        },
      },
    ],
  },
]

// Setup MSW server
const server = setupServer(
  rest.get("https://localhost:3000/dataQuality/api/product-data", (req, res, ctx) => {
    return res(ctx.json(mockProductData))
  }),
  rest.get("https://localhost:3000/dataQuality/api/l2-product-data", (req, res, ctx) => {
    return res(ctx.json(mockL2Data))
  }),
  rest.post("https://localhost:3000/dataQuality/api/top-bottom-five-scores", (req, res, ctx) => {
    return res(
      ctx.json({
        top_5_scores: [
          { table: "Table 1", score: 95 },
          { table: "Table 2", score: 93 },
        ],
        bottom_5_scores: [
          { table: "Table 3", score: 85 },
          { table: "Table 4", score: 82 },
        ],
      }),
    )
  }),
)

// Setup store for testing
const setupStore = () => {
  return configureStore({
    reducer: {
      [api.reducerPath]: api.reducer,
      dqDomainLevelReport: dqDomainLevelReportReducer,
    },
    middleware: (getDefaultMiddleware) => getDefaultMiddleware().concat(api.middleware),
  })
}

// Setup before tests
beforeAll(() => server.listen())
afterEach(() => server.resetHandlers())
afterAll(() => server.close())

// Mock html2canvas and jsPDF
jest.mock("html2canvas", () => ({
  __esModule: true,
  default: jest.fn().mockResolvedValue({
    toDataURL: jest.fn().mockReturnValue("data:image/png;base64,mockImageData"),
  }),
}))

jest.mock("jspdf", () => {
  const mockJsPDF = {
    addImage: jest.fn(),
    save: jest.fn(),
    internal: {
      pageSize: {
        getWidth: jest.fn().mockReturnValue(210),
        getHeight: jest.fn().mockReturnValue(297),
      },
    },
    getImageProperties: jest.fn().mockReturnValue({ width: 100, height: 100 }),
  }
  return {
    __esModule: true,
    default: jest.fn(() => mockJsPDF),
  }
})

describe("DQDomainLevelReport Component", () => {
  test("renders the component with loading state", async () => {
    const store = setupStore()

    render(
      <Provider store={store}>
        <DQDomainLevelReport />
      </Provider>,
    )

    // Check for loading indicators
    expect(screen.getByText(/DQ Domain Level Report/i)).toBeInTheDocument()

    // Wait for data to load
    await waitFor(() => {
      expect(screen.queryByText(/No Data Available/i)).not.toBeInTheDocument()
    })
  })

  test("displays product data when loaded", async () => {
    const store = setupStore()
    store.dispatch({
      type: "dqDomainLevelReport/setActiveProduct",
      payload: { productId: "Test Product", L2_productId: "", tableName: "" },
    })

    render(
      <Provider store={store}>
        <DQDomainLevelReport />
      </Provider>,
    )

    // Wait for data to load
    await waitFor(() => {
      expect(screen.getByText(/Test Product/i)).toBeInTheDocument()
      expect(screen.getByText(/DQ Score Tables/i)).toBeInTheDocument()
      expect(screen.getByText(/DQ Score Trend/i)).toBeInTheDocument()
    })
  })

  test("handles PDF download", async () => {
    const store = setupStore()
    store.dispatch({
      type: "dqDomainLevelReport/setActiveProduct",
      payload: { productId: "Test Product", L2_productId: "", tableName: "" },
    })

    render(
      <Provider store={store}>
        <DQDomainLevelReport />
      </Provider>,
    )

    // Wait for data to load
    await waitFor(() => {
      expect(screen.getByText(/Download PDF/i)).toBeInTheDocument()
    })

    // Click download button
    fireEvent.click(screen.getByText(/Download PDF/i))

    // Verify html2canvas was called
    await waitFor(() => {
      expect(jest.mock("html2canvas")).toHaveBeenCalled()
    })
  })
})
