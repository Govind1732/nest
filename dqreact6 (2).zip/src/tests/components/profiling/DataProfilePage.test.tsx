import { render, screen, fireEvent, waitFor } from "@testing-library/react"
import { Provider } from "react-redux"
import { store } from "@/store/store"
import { BrowserRouter } from "react-router-dom"
import DataProfilePage from "@/modules/profiling/pages/DataProfilePage"

describe("DataProfilePage", () => {
  const setup = () => {
    return render(
      <Provider store={store}>
        <BrowserRouter>
          <DataProfilePage />
        </BrowserRouter>
      </Provider>,
    )
  }

  test("renders Data Profile page", () => {
    setup()
    expect(screen.getByText(/Data Profile/i)).toBeInTheDocument()
    expect(screen.getByText(/Submit Request/i)).toBeInTheDocument()
    expect(screen.getByText(/Download Reports/i)).toBeInTheDocument()
  })

  test("allows environment selection", () => {
    setup()
    const environmentSelect = screen.getByRole("combobox", { name: /Environment/i })
    expect(environmentSelect).toBeInTheDocument()
  })

  test("allows db name selection", () => {
    setup()
    const dbNameSelect = screen.getByRole("combobox", { name: /DB Name/i })
    expect(dbNameSelect).toBeInTheDocument()
  })

  test("allows table name selection", () => {
    setup()
    const tableNameSelect = screen.getByRole("combobox", { name: /Table Name/i })
    expect(tableNameSelect).toBeInTheDocument()
  })

  test("submits the form", async () => {
    setup()
    const submitButton = screen.getByRole("button", { name: /Check For Connectivity/i })
    fireEvent.click(submitButton)
    await waitFor(() => {
      expect(screen.getByText(/Connection successful/i)).toBeInTheDocument()
    })
  })
})
