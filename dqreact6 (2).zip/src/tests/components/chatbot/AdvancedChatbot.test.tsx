"use client"

import { render, screen, fireEvent, waitFor } from "@testing-library/react"
import { AdvancedChatbot } from "@/components/chatbot/AdvancedChatbot"
import { useAIChat } from "@/hooks/useAIChat"
import { useLocation } from "react-router-dom"
import { useAuth } from "@/modules/auth/hooks/useAuth"

// Mock the hooks
jest.mock("@/hooks/useAIChat", () => ({
  useAIChat: jest.fn(),
}))

jest.mock("react-router-dom", () => ({
  useLocation: jest.fn(),
}))

jest.mock("@/modules/auth/hooks/useAuth", () => ({
  useAuth: jest.fn(),
}))

// Mock translations
jest.mock("react-i18next", () => ({
  useTranslation: () => {
    return {
      t: (str: string) => str,
      i18n: {
        changeLanguage: () => new Promise(() => {}),
      },
    }
  },
}))

describe("AdvancedChatbot", () => {
  // Setup default mocks
  beforeEach(() => {
    // Mock useAIChat
    ;(useAIChat as jest.Mock).mockReturnValue({
      processMessage: jest.fn().mockResolvedValue({ text: "AI response" }),
      isProcessing: false,
      generateSuggestedQuestions: jest
        .fn()
        .mockResolvedValue(["What is data quality?", "How do I upload a file?", "Where can I find my reports?"]),
    })

    // Mock useLocation
    ;(useLocation as jest.Mock).mockReturnValue({
      pathname: "/dq-report",
    })

    // Mock useAuth
    ;(useAuth as jest.Mock).mockReturnValue({
      user: {
        id: "user-1",
        name: "Test User",
        role: "DQ User",
      },
    })
  })

  afterEach(() => {
    jest.clearAllMocks()
  })

  test("renders chatbot toggle button", () => {
    render(<AdvancedChatbot />)

    const toggleButton = screen.getByRole("button", { name: /chatbot.open/i })
    expect(toggleButton).toBeInTheDocument()
  })

  test("opens chatbot when toggle button is clicked", async () => {
    render(<AdvancedChatbot />)

    const toggleButton = screen.getByRole("button", { name: /chatbot.open/i })
    fireEvent.click(toggleButton)

    await waitFor(() => {
      expect(screen.getByText(/chatbot.advancedTitle/i)).toBeInTheDocument()
    })
  })

  test("displays welcome message when opened", async () => {
    render(<AdvancedChatbot />)

    const toggleButton = screen.getByRole("button", { name: /chatbot.open/i })
    fireEvent.click(toggleButton)

    await waitFor(() => {
      expect(screen.getByText(/chatbot.welcomeMessage/i)).toBeInTheDocument()
    })
  })

  test("allows sending a message and receives AI response", async () => {
    const mockProcessMessage = jest.fn().mockResolvedValue({ text: "AI response" })
    ;(useAIChat as jest.Mock).mockReturnValue({
      processMessage: mockProcessMessage,
      isProcessing: false,
      generateSuggestedQuestions: jest.fn().mockResolvedValue([]),
    })

    render(<AdvancedChatbot />)

    // Open chatbot
    const toggleButton = screen.getByRole("button", { name: /chatbot.open/i })
    fireEvent.click(toggleButton)

    // Type a message
    const input = await screen.findByPlaceholderText(/chatbot.advancedInputPlaceholder/i)
    fireEvent.change(input, { target: { value: "What is data quality?" } })

    // Send the message
    const sendButton = screen.getByRole("button", { name: /chatbot.send/i })
    fireEvent.click(sendButton)

    // Check if user message appears
    await waitFor(() => {
      expect(screen.getByText("What is data quality?")).toBeInTheDocument()
    })

    // Check if AI responds
    await waitFor(() => {
      expect(screen.getByText("AI response")).toBeInTheDocument()
    })

    // Verify processMessage was called with correct arguments
    expect(mockProcessMessage).toHaveBeenCalledWith(
      "What is data quality?",
      expect.any(Array),
      expect.objectContaining({
        currentPath: "/dq-report",
        userRole: "DQ User",
      }),
    )
  })

  test("displays suggested questions and allows clicking them", async () => {
    const mockProcessMessage = jest.fn().mockResolvedValue({ text: "AI response" })
    ;(useAIChat as jest.Mock).mockReturnValue({
      processMessage: mockProcessMessage,
      isProcessing: false,
      generateSuggestedQuestions: jest.fn().mockResolvedValue(["What is data quality?", "How do I upload a file?"]),
    })

    render(<AdvancedChatbot />)

    // Open chatbot
    const toggleButton = screen.getByRole("button", { name: /chatbot.open/i })
    fireEvent.click(toggleButton)

    // Wait for suggested questions to appear
    await waitFor(() => {
      expect(screen.getByText("What is data quality?")).toBeInTheDocument()
      expect(screen.getByText("How do I upload a file?")).toBeInTheDocument()
    })

    // Click a suggested question
    fireEvent.click(screen.getByText("What is data quality?"))

    // Verify processMessage was called with the suggested question
    await waitFor(() => {
      expect(mockProcessMessage).toHaveBeenCalledWith(
        "What is data quality?",
        expect.any(Array),
        expect.objectContaining({
          currentPath: "/dq-report",
          userRole: "DQ User",
        }),
      )
    })
  })

  test("supports file attachments", async () => {
    const mockProcessMessage = jest.fn().mockResolvedValue({ text: "AI response about attachments" })
    ;(useAIChat as jest.Mock).mockReturnValue({
      processMessage: mockProcessMessage,
      isProcessing: false,
      generateSuggestedQuestions: jest.fn().mockResolvedValue([]),
    })

    render(<AdvancedChatbot />)

    // Open chatbot
    const toggleButton = screen.getByRole("button", { name: /chatbot.open/i })
    fireEvent.click(toggleButton)

    // Click attachment button
    const attachButton = screen.getByRole("button", { name: /chatbot.attachFile/i })

    // Mock file input change
    const fileInput = document.querySelector('input[type="file"]')
    if (fileInput) {
      const file = new File(["dummy content"], "test.csv", { type: "text/csv" })
      Object.defineProperty(fileInput, "files", {
        value: [file],
      })
      fireEvent.change(fileInput)
    }

    // Send message with attachment
    const sendButton = screen.getByRole("button", { name: /chatbot.send/i })
    fireEvent.click(sendButton)

    // Verify processMessage was called with attachment info
    await waitFor(() => {
      expect(mockProcessMessage).toHaveBeenCalledWith(
        "",
        expect.any(Array),
        expect.objectContaining({
          attachments: ["test.csv"],
        }),
      )
    })

    // Check if AI responds about attachments
    await waitFor(() => {
      expect(screen.getByText("AI response about attachments")).toBeInTheDocument()
    })
  })

  test("toggles fullscreen mode", async () => {
    render(<AdvancedChatbot />)

    // Open chatbot
    const toggleButton = screen.getByRole("button", { name: /chatbot.open/i })
    fireEvent.click(toggleButton)

    // Find and click fullscreen button
    const fullscreenButton = await screen.findByRole("button", { name: /chatbot.fullscreen/i })
    fireEvent.click(fullscreenButton)

    // Check if fullscreen class is applied (this is a simplified check)
    const chatWindow = document.querySelector(".fixed.z-50")
    expect(chatWindow).toHaveClass("inset-4")

    // Click again to exit fullscreen
    const exitFullscreenButton = await screen.findByRole("button", { name: /chatbot.exitFullscreen/i })
    fireEvent.click(exitFullscreenButton)

    // Check if fullscreen class is removed
    await waitFor(() => {
      const chatWindow = document.querySelector(".fixed.z-50")
      expect(chatWindow).not.toHaveClass("inset-4")
    })
  })

  test("shows loading state while processing message", async () => {
    // Mock processing state
    ;(useAIChat as jest.Mock).mockReturnValue({
      processMessage: jest.fn().mockImplementation(() => {
        return new Promise((resolve) => {
          setTimeout(() => resolve({ text: "AI response" }), 500)
        })
      }),
      isProcessing: true,
      generateSuggestedQuestions: jest.fn().mockResolvedValue([]),
    })

    render(<AdvancedChatbot />)

    // Open chatbot
    const toggleButton = screen.getByRole("button", { name: /chatbot.open/i })
    fireEvent.click(toggleButton)

    // Type and send a message
    const input = await screen.findByPlaceholderText(/chatbot.advancedInputPlaceholder/i)
    fireEvent.change(input, { target: { value: "Test message" } })
    const sendButton = screen.getByRole("button", { name: /chatbot.send/i })
    fireEvent.click(sendButton)

    // Check for loading indicator
    expect(screen.getByText(/chatbot.thinking/i)).toBeInTheDocument()
  })
})
