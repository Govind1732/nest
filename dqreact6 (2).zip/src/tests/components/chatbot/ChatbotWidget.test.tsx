import type React from "react"
import { render, screen, fireEvent, waitFor } from "@testing-library/react"
import { ChatbotWidget } from "@/components/chatbot/ChatbotWidget"

// Mock translations
jest.mock("react-i18next", () => ({
  // this mock makes sure any components using the translate hook can use it without a warning being shown
  useTranslation: () => {
    return {
      t: (str: string) => str,
      i18n: {
        changeLanguage: () => new Promise(() => {}),
      },
    }
  },
  I18nextProvider: ({ children }: { children: React.ReactNode }) => children,
}))

describe("ChatbotWidget", () => {
  beforeEach(() => {
    // Reset DOM
    document.body.innerHTML = ""
  })

  test("renders chatbot toggle button", () => {
    render(<ChatbotWidget />)

    const toggleButton = screen.getByRole("button", { name: /chatbot.open/i })
    expect(toggleButton).toBeInTheDocument()
  })

  test("opens chatbot when toggle button is clicked", async () => {
    render(<ChatbotWidget />)

    const toggleButton = screen.getByRole("button", { name: /chatbot.open/i })
    fireEvent.click(toggleButton)

    await waitFor(() => {
      expect(screen.getByText(/chatbot.title/i)).toBeInTheDocument()
    })
  })

  test("displays welcome message when opened", async () => {
    render(<ChatbotWidget />)

    const toggleButton = screen.getByRole("button", { name: /chatbot.open/i })
    fireEvent.click(toggleButton)

    await waitFor(() => {
      expect(screen.getByText(/chatbot.welcomeMessage/i)).toBeInTheDocument()
    })
  })

  test("allows sending a message", async () => {
    render(<ChatbotWidget />)

    // Open chatbot
    const toggleButton = screen.getByRole("button", { name: /chatbot.open/i })
    fireEvent.click(toggleButton)

    // Type a message
    const input = await screen.findByPlaceholderText(/chatbot.inputPlaceholder/i)
    fireEvent.change(input, { target: { value: "What is data quality?" } })

    // Send the message
    const sendButton = screen.getByRole("button", { name: /chatbot.send/i })
    fireEvent.click(sendButton)

    // Check if user message appears
    await waitFor(() => {
      expect(screen.getByText("What is data quality?")).toBeInTheDocument()
    })

    // Check if bot responds
    await waitFor(
      () => {
        // The exact response will depend on the processUserQuery implementation
        expect(screen.getAllByText(/chatbot.responses/i).length).toBeGreaterThan(0)
      },
      { timeout: 2000 },
    )
  })

  test("can be minimized", async () => {
    render(<ChatbotWidget />)

    // Open chatbot
    const toggleButton = screen.getByRole("button", { name: /chatbot.open/i })
    fireEvent.click(toggleButton)

    // Find and click minimize button
    const minimizeButton = await screen.findByRole("button", { name: /chatbot.minimize/i })
    fireEvent.click(minimizeButton)

    // Check if minimized state shows message count
    await waitFor(() => {
      expect(screen.getByText(/chatbot.messages/i)).toBeInTheDocument()
    })
  })

  test("can be closed", async () => {
    render(<ChatbotWidget />)

    // Open chatbot
    const toggleButton = screen.getByRole("button", { name: /chatbot.open/i })
    fireEvent.click(toggleButton)

    // Wait for chatbot to open
    await screen.findByText(/chatbot.title/i)

    // Click the toggle button again to close
    fireEvent.click(toggleButton)

    // Check if chatbot is closed
    await waitFor(() => {
      expect(screen.queryByText(/chatbot.title/i)).not.toBeInTheDocument()
    })
  })
})
