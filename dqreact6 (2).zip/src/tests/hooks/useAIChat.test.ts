import { renderHook, act } from "@testing-library/react-hooks"
import { useAIChat } from "@/hooks/useAIChat"
import { ROUTES } from "@/config/constants"
import { expect } from "@jest/globals"

// Mock translations
jest.mock("react-i18next", () => ({
  useTranslation: () => {
    return {
      t: (str: string) => str,
      i18n: {
        changeLanguage: () => new Promise(() => {}),
      },
    }
  },
}))

describe("useAIChat", () => {
  beforeEach(() => {
    jest.useFakeTimers()
  })

  afterEach(() => {
    jest.useRealTimers()
  })

  test("processMessage returns a response based on intent and entities", async () => {
    const { result } = renderHook(() => useAIChat())

    // Mock message and context
    const message = "What is data quality?"
    const conversationHistory = [
      {
        id: "1",
        content: "chatbot.welcomeMessage",
        role: "assistant",
        timestamp: new Date(),
      },
    ]
    const context = {
      currentPath: "/dq-report",
      userRole: "DQ User",
    }

    // Call processMessage
    let response
    await act(async () => {
      response = await result.current.processMessage(message, conversationHistory, context)
      jest.advanceTimersByTime(1000) // Advance timers for the simulated delay
    })

    // Verify response
    expect(response).toBeDefined()
    expect(response.text).toBe("chatbot.responses.definition.dataQuality")
    expect(response.intent).toBe("definition")
  })

  test("processMessage handles different intents correctly", async () => {
    const { result } = renderHook(() => useAIChat())
    const conversationHistory = []
    const context = { currentPath: "/" }

    // Test different intents
    const testCases = [
      { message: "Hello", expectedIntent: "greeting" },
      { message: "How do I upload a file?", expectedIntent: "howto" },
      { message: "Where can I find reports?", expectedIntent: "location" },
      { message: "Why is data quality important?", expectedIntent: "reason" },
      { message: "When will my report be ready?", expectedIntent: "time" },
      { message: "Who should I contact for help?", expectedIntent: "person" },
      { message: "Thank you for your help", expectedIntent: "gratitude" },
    ]

    for (const testCase of testCases) {
      let response
      await act(async () => {
        response = await result.current.processMessage(testCase.message, conversationHistory, context)
        jest.advanceTimersByTime(1000)
      })

      expect(response.intent).toBe(testCase.expectedIntent)
    }
  })

  test("processMessage extracts entities correctly", async () => {
    const { result } = renderHook(() => useAIChat())
    const conversationHistory = []
    const context = { currentPath: "/" }

    // Test entity extraction
    let response
    await act(async () => {
      response = await result.current.processMessage(
        "What is completeness in data quality?",
        conversationHistory,
        context,
      )
      jest.advanceTimersByTime(1000)
    })

    // The response should be about completeness specifically
    expect(response.text).toBe("chatbot.responses.definition.completeness")
  })

  test("generateSuggestedQuestions returns context-aware questions", async () => {
    const { result } = renderHook(() => useAIChat())

    // Test different paths
    const testCases = [
      {
        path: ROUTES.DQ_REPORT,
        role: "DQ User",
        expectedQuestions: [
          "chatbot.suggestions.dqReport1",
          "chatbot.suggestions.dqReport2",
          "chatbot.suggestions.dqReport3",
        ],
      },
      {
        path: ROUTES.AUTO_PROFILE,
        role: "DQ User",
        expectedQuestions: [
          "chatbot.suggestions.profile1",
          "chatbot.suggestions.profile2",
          "chatbot.suggestions.profile3",
        ],
      },
      {
        path: ROUTES.DATA_QUALITY_VALIDATION,
        role: "DQ User",
        expectedQuestions: [
          "chatbot.suggestions.validation1",
          "chatbot.suggestions.validation2",
          "chatbot.suggestions.validation3",
        ],
      },
      {
        path: ROUTES.ADMIN,
        role: "Admin",
        expectedQuestions: ["chatbot.suggestions.admin1", "chatbot.suggestions.admin2", "chatbot.suggestions.admin3"],
      },
      {
        path: "/unknown-path",
        role: "DQ User",
        expectedQuestions: [
          "chatbot.suggestions.default1",
          "chatbot.suggestions.default2",
          "chatbot.suggestions.default3",
        ],
      },
    ]

    for (const testCase of testCases) {
      let questions
      await act(async () => {
        questions = await result.current.generateSuggestedQuestions(testCase.path, testCase.role)
      })

      expect(questions).toEqual(testCase.expectedQuestions)
    }
  })

  test("isProcessing state changes during message processing", async () => {
    const { result } = renderHook(() => useAIChat())

    // Initial state should be false
    expect(result.current.isProcessing).toBe(false)

    // Start processing a message
    let processPromise
    act(() => {
      processPromise = result.current.processMessage("Test message", [], { currentPath: "/" })
      // Should be true during processing
      expect(result.current.isProcessing).toBe(true)
    })

    // Advance timers to complete processing
    await act(async () => {
      jest.advanceTimersByTime(1000)
      await processPromise
    })

    // Should be false after processing completes
    expect(result.current.isProcessing).toBe(false)
  })

  test("processMessage handles context information correctly", async () => {
    const { result } = renderHook(() => useAIChat())

    // Test with page context
    let response
    await act(async () => {
      response = await result.current.processMessage("What can I do here?", [], { currentPath: ROUTES.DQ_REPORT })
      jest.advanceTimersByTime(1000)
    })

    // Should return contextual response for DQ_REPORT
    expect(response.text).toBe("chatbot.responses.contextual.dq_report")

    // Test with attachment context
    await act(async () => {
      response = await result.current.processMessage("", [], {
        currentPath: "/",
        attachments: ["test.csv", "data.xlsx"],
      })
      jest.advanceTimersByTime(1000)
    })

    // Should return response about attachments
    expect(response.text).toBe("chatbot.responses.attachments")
  })
})
