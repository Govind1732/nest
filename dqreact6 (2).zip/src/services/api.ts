import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react"

// Define base API
export const api = createApi({
  reducerPath: "api",
  baseQuery: fetchBaseQuery({ baseUrl: "/api" }),
  tagTypes: [
    "DQReport",
    "DQDomainLevelReport",
    "AutoProfile",
    "RuleProfile",
    "DataProfile",
    "CustomProfile",
    "DQMetricsAPI",
    "ETLPipelineIntegration",
  ],
  endpoints: (builder) => ({
    // DQ Report endpoints
    getDQReportData: builder.query({
      query: () => "dq-report",
      providesTags: ["DQReport"],
    }),
    applyDQReportFilters: builder.mutation({
      query: (filters) => ({
        url: "dq-report/filter",
        method: "POST",
        body: filters,
      }),
      invalidatesTags: ["DQReport"],
    }),
    
    // DQ Domain Level Report endpoints
    getProductData: builder.query({
      query: () => "product-data",
      providesTags: ["DQDomainLevelReport"],
    }),
    getL2ProductData: builder.query({
      query: () => "l2-product-data",
      providesTags: ["DQDomainLevelReport"],
    }),
    postTopBottomFiveScores: builder.mutation({
      query: (data) => ({
        url: "top-bottom-five-scores",
        method: "POST",
        body: data,
      }),
    }),
    
    // Auto Profile endpoints
    submitAutoProfileRequest: builder.mutation({
      query: (data) => ({
        url: "auto-profile",
        method: "POST",
        body: data,
      }),
      invalidatesTags: ["AutoProfile"],
    }),
    
    // Rule Profile endpoints
    submitRuleProfileRequest: builder.mutation({
      query: (data) => ({
        url: "rule-profile",
        method: "POST",
        body: data,
      }),
      invalidatesTags: ["RuleProfile"],
    }),
    
    // Data Profile endpoints
    submitDataProfileRequest: builder.mutation({
      query: (data) => ({
        url: "data-profile",
        method: "POST",
        body: data,
      }),
      invalidatesTags: ["DataProfile"],
    }),
    
    // Custom Profile endpoints
    submitCustomProfileRequest: builder.mutation({
      query: (data) => ({\
        url: "
