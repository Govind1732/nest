"use client"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { motion } from "framer-motion"
import { Download } from "lucide-react"
import { PageContainer, PageHeader } from "@/components/layout/PageContainer"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { RoleGuard } from "@/modules/auth/components/RoleGuard"
import { useDispatch, useSelector } from "react-redux"
import { setEnvironment, setDbName, setTableName, clearState } from "@/store/slices/dataProfileSlice"

type FormValues = {}

export default function DataProfilePage() {
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("submit")
  const dispatch = useDispatch()
  const { environment, dbName, tableName } = useSelector((state: any) => state.dataProfile)

  const form = useForm<FormValues>({
    // resolver: zodResolver(dataProfileSchema),
    defaultValues: {
      environment: "TeraData",
      dbName: "",
      tableName: "",
    },
  })

  const onSubmit = async () => {
    // Handle form submission
    toast({
      title: "Connection successful",
      description: "Your data profile request has been submitted",
    })
  }

  const handleReset = () => {
    dispatch(clearState())
  }

  return (
    <PageContainer>
      <PageHeader
        title="Data Profile"
        breadcrumbs={[{ label: "Profiling", href: "/profiling" }, { label: "Data Profile" }]}
      />

      <RoleGuard requiredRole="DQ User" projectId="DTRan">
        <Tabs defaultValue="submit" onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="submit">Submit Request</TabsTrigger>
            <TabsTrigger value="download">Download Reports</TabsTrigger>
          </TabsList>

          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
          >
            <Card>
              <CardContent className="p-6">
                {activeTab === "submit" && (
                  <div className="max-w-2xl mx-auto">
                    <Form {...form}>
                      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                        <FormField
                          control={form.control}
                          name="environment"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Environment</FormLabel>
                              <Select
                                onValueChange={(value) => dispatch(setEnvironment(value))}
                                defaultValue={environment}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select environment" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="TeraData">TeraData</SelectItem>
                                  <SelectItem value="GCP">GCP</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="dbName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>DB Name</FormLabel>
                              <Select onValueChange={(value) => dispatch(setDbName(value))} defaultValue={dbName}>
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select DB Name" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="db1">Database 1</SelectItem>
                                  <SelectItem value="db2">Database 2</SelectItem>
                                  <SelectItem value="db3">Database 3</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="tableName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Table Name</FormLabel>
                              <Select onValueChange={(value) => dispatch(setTableName(value))} defaultValue={tableName}>
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select Table Name" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="table1">Table 1</SelectItem>
                                  <SelectItem value="table2">Table 2</SelectItem>
                                  <SelectItem value="table3">Table 3</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <div className="flex justify-center">
                          <Button type="submit">Check For Connectivity</Button>
                        </div>
                      </form>
                    </Form>
                  </div>
                )}

                {activeTab === "download" && (
                  <div className="flex flex-col items-center justify-center p-8">
                    <p className="text-center text-muted-foreground mb-6">Select a report to download</p>
                    <Button className="w-full" onClick={() => {}}>
                      <Download className="mr-2 h-4 w-4" />
                      Download Report
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </Tabs>
      </RoleGuard>
    </PageContainer>
  )
}
