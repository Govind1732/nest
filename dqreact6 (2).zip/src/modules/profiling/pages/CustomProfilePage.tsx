const CustomProfilePage = () => {
  return (
    <div>
      <h1>Custom Profile Page</h1>
      <p>This is a custom profile page.</p>
    </div>
  )
}

export default CustomProfilePage
