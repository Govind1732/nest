"use client"

import type React from "react"

import { useState } from "react"
import { motion } from "framer-motion"
import { Upload } from "lucide-react"
import { PageContainer, PageHeader } from "@/components/layout/PageContainer"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"

export default function DataQualityValidationPage() {
  const [activeTab, setActiveTab] = useState("multiple")
  const [environment, setEnvironment] = useState("")
  const [dbName, setDbName] = useState("")
  const [tableName, setTableName] = useState("")
  const [step, setStep] = useState(1)
  const [file, setFile] = useState<File | null>(null)
  const [isUploading, setIsUploading] = useState(false)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setFile(e.target.files[0])
    }
  }

  const handleCheckConnectivity = () => {
    console.log("Checking connectivity for:", { environment, dbName, tableName })
    // Simulate successful connection check
    setTimeout(() => {
      setStep(2)
    }, 1000)
  }

  const handleReset = () => {
    setEnvironment("")
    setDbName("")
    setTableName("")
    setStep(1)
    setFile(null)
  }

  const handleSubmit = () => {
    if (activeTab === "multiple" && file) {
      setIsUploading(true)
      // Simulate upload
      setTimeout(() => {
        setIsUploading(false)
        setFile(null)
        // Show success message
      }, 1500)
    }
  }

  return (
    <PageContainer>
      <PageHeader
        title="DataQuality Validation"
        breadcrumbs={[{ label: "Profiling", href: "/profiling" }, { label: "DataQuality Validation" }]}
      />

      <Tabs defaultValue="multiple" onValueChange={setActiveTab}>
        <TabsList className="mb-6">
          <TabsTrigger value="multiple">Submit Multiple Requests</TabsTrigger>
          <TabsTrigger value="single">Submit Single Request</TabsTrigger>
          <TabsTrigger value="view">View/Edit Request</TabsTrigger>
        </TabsList>

        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
        >
          <Card>
            <CardContent className="p-6">
              {activeTab === "multiple" && (
                <div>
                  <div className="flex flex-col items-center justify-center p-8 border-2 border-dashed rounded-lg">
                    <Upload className="h-12 w-12 text-muted-foreground mb-4" />
                    <p className="text-center mb-4">Upload Excel file for multiple requests</p>

                    <Input
                      type="file"
                      className="hidden"
                      id="file-upload"
                      accept=".csv,.xlsx,.xls"
                      onChange={handleFileChange}
                    />

                    {file ? (
                      <div className="flex items-center gap-2 p-2 border rounded-md w-full max-w-md">
                        <div className="flex-1 truncate">{file.name}</div>
                      </div>
                    ) : (
                      <Button asChild>
                        <label htmlFor="file-upload">Choose File</label>
                      </Button>
                    )}
                  </div>

                  <div className="flex justify-center gap-4 mt-6">
                    <Button variant="outline" onClick={handleReset}>
                      Reset
                    </Button>
                    <Button onClick={handleSubmit} disabled={!file || isUploading}>
                      {isUploading ? "Uploading..." : "Submit"}
                    </Button>
                  </div>
                </div>
              )}

              {activeTab === "single" && (
                <div>
                  <div className="flex mb-6">
                    <div className="flex flex-col items-center mr-8">
                      <div
                        className={`flex items-center justify-center w-8 h-8 rounded-full ${step >= 1 ? "bg-primary text-white" : "bg-muted text-muted-foreground"}`}
                      >
                        1
                      </div>
                      <span className="text-sm mt-2">Source</span>
                      <span className="text-xs text-muted-foreground">Step 1</span>
                    </div>
                    <div className="flex-1 pt-4">
                      <div className={`h-0.5 ${step >= 2 ? "bg-primary" : "bg-muted"}`}></div>
                    </div>
                    <div className="flex flex-col items-center mr-8">
                      <div
                        className={`flex items-center justify-center w-8 h-8 rounded-full ${step >= 2 ? "bg-primary text-white" : "bg-muted text-muted-foreground"}`}
                      >
                        2
                      </div>
                      <span className="text-sm mt-2">Taxonomy</span>
                      <span className="text-xs text-muted-foreground">Step 2</span>
                    </div>
                    <div className="flex-1 pt-4">
                      <div className={`h-0.5 ${step >= 3 ? "bg-primary" : "bg-muted"}`}></div>
                    </div>
                    <div className="flex flex-col items-center">
                      <div
                        className={`flex items-center justify-center w-8 h-8 rounded-full ${step >= 3 ? "bg-primary text-white" : "bg-muted text-muted-foreground"}`}
                      >
                        3
                      </div>
                      <span className="text-sm mt-2">Meta</span>
                      <span className="text-xs text-muted-foreground">Step 3</span>
                    </div>
                  </div>

                  <h3 className="text-xl font-semibold mb-6">Select source</h3>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                    <div>
                      <label htmlFor="environment" className="block text-sm font-medium mb-1">
                        Environment
                      </label>
                      <Select value={environment} onValueChange={setEnvironment}>
                        <SelectTrigger id="environment">
                          <SelectValue placeholder="Environment" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="env1">Environment 1</SelectItem>
                          <SelectItem value="env2">Environment 2</SelectItem>
                          <SelectItem value="env3">Environment 3</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <label htmlFor="dbName" className="block text-sm font-medium mb-1">
                        DB Name
                      </label>
                      <Select value={dbName} onValueChange={setDbName}>
                        <SelectTrigger id="dbName">
                          <SelectValue placeholder="DB Name" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="db1">Database 1</SelectItem>
                          <SelectItem value="db2">Database 2</SelectItem>
                          <SelectItem value="db3">Database 3</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <label htmlFor="tableName" className="block text-sm font-medium mb-1">
                        Table Name
                      </label>
                      <Select value={tableName} onValueChange={setTableName}>
                        <SelectTrigger id="tableName">
                          <SelectValue placeholder="Table Name" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="table1">Table 1</SelectItem>
                          <SelectItem value="table2">Table 2</SelectItem>
                          <SelectItem value="table3">Table 3</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="flex justify-center gap-4">
                    <Button variant="outline" onClick={handleReset}>
                      Reset
                    </Button>
                    <Button onClick={handleCheckConnectivity}>Check Connectivity</Button>
                  </div>
                </div>
              )}

              {activeTab === "view" && (
                <div>
                  <p className="text-center text-muted-foreground">View and edit existing validation requests</p>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </Tabs>
    </PageContainer>
  )
}
