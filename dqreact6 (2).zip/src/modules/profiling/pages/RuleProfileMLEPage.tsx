"use client"

import type React from "react"

import { useState } from "react"
import { motion } from "framer-motion"
import { Pencil, Trash, Upload } from "lucide-react"
import { PageContainer, PageHeader } from "@/components/layout/PageContainer"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DataTable } from "@/components/ui/data-table"
import { useToast } from "@/hooks/use-toast"
import { RoleGuard } from "@/modules/auth/components/RoleGuard"
import { useDispatch, useSelector } from "react-redux"
import { setFile, setIsUploading, clearState, setLoading, setError } from "@/store/slices/ruleProfileMLESlice"

type FormValues = {}

export default function RuleProfileMLEPage() {
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("submit")
  const dispatch = useDispatch()
  const { file, isUploading, tableData, isLoading, error } = useSelector((state: any) => state.ruleProfileMLE)

  // Mock data for the table
  const columns = [
    { accessorKey: "id", header: "#" },
    { accessorKey: "sourceTable", header: "Source Table" },
    { accessorKey: "startDate", header: "Start Date" },
    { accessorKey: "endDate", header: "End Date" },
    {
      id: "actions",
      header: "Actions",
      cell: ({ row }: any) => (
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon">
            <Pencil className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon">
            <Trash className="h-4 w-4" />
          </Button>
        </div>
      ),
    },
  ]

  const data = [
    {
      id: "1",
      sourceTable: "mle_table_1",
      startDate: "2025-03-14",
      endDate: "2025-04-17",
    },
  ]

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      dispatch(setFile(e.target.files[0]))
    }
  }

  const handleSubmitFile = async () => {
    if (!file) return

    try {
      dispatch(setIsUploading(true))
      dispatch(setLoading(true))

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1500))

      toast({
        title: "Upload successful",
        description: "Your file has been uploaded successfully",
      })

      dispatch(setFile(null))
      dispatch(setLoading(false))
    } catch (e: any) {
      console.error("Upload failed:", e)
      toast({
        variant: "destructive",
        title: "Upload failed",
        description: "There was an error uploading your file",
      })
      dispatch(setError(e.message))
      dispatch(setLoading(false))
    } finally {
      dispatch(setIsUploading(false))
    }
  }

  const handleReset = () => {
    dispatch(clearState())
  }

  return (
    <PageContainer>
      <PageHeader
        title="Rule Profile - MLE"
        breadcrumbs={[
          { label: "Profiling", href: "/profiling" },
          { label: "Rule Profile", href: "/profiling/rule-profile" },
          { label: "MLE" },
        ]}
      />

      <RoleGuard requiredRole="DQ User" projectId="DTRan">
        <Tabs defaultValue="submit" onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="submit">Submit Multiple Requests</TabsTrigger>
            <TabsTrigger value="view">View/Edit Request</TabsTrigger>
          </TabsList>

          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
          >
            <Card>
              <CardContent className="p-6">
                {activeTab === "submit" && (
                  <div>
                    <div className="flex flex-col items-center justify-center p-8 border-2 border-dashed rounded-lg">
                      <Upload className="h-12 w-12 text-muted-foreground mb-4" />
                      <p className="text-center mb-4">Upload Excel file for multiple requests</p>

                      <Input
                        type="file"
                        className="hidden"
                        id="file-upload"
                        accept=".csv,.xlsx,.xls"
                        onChange={handleFileChange}
                      />

                      {file ? (
                        <div className="flex items-center gap-2 p-2 border rounded-md w-full max-w-md">
                          <div className="flex-1 truncate">{file.name}</div>
                        </div>
                      ) : (
                        <Button asChild>
                          <label htmlFor="file-upload">Choose File</label>
                        </Button>
                      )}
                    </div>

                    <div className="flex justify-center gap-4 mt-6">
                      <Button variant="outline" onClick={handleReset}>
                        Reset
                      </Button>
                      <Button onClick={handleSubmitFile} disabled={!file || isUploading}>
                        {isUploading ? "Uploading..." : "Submit"}
                      </Button>
                    </div>
                  </div>
                )}

                {activeTab === "view" && (
                  <div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                      <div>
                        <label htmlFor="database" className="block text-sm font-medium mb-1">
                          Database
                        </label>
                        <Input id="database" placeholder="Enter database name" />
                      </div>
                      <div>
                        <label htmlFor="tableName" className="block text-sm font-medium mb-1">
                          Table Name
                        </label>
                        <Input id="tableName" placeholder="Enter table name" />
                      </div>
                    </div>

                    <div className="flex justify-end mb-6">
                      <Button>Submit</Button>
                    </div>

                    <DataTable columns={columns} data={tableData} />
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </Tabs>
      </RoleGuard>
    </PageContainer>
  )
}
