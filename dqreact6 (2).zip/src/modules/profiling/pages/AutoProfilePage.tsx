"use client"

import type React from "react"
import { useState, useRef } from "react"
import { Upload, Copy, Eye, Download } from "lucide-react"
import { PageHeader } from "@/components/layout/PageContainer"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DataTable } from "@/components/ui/data-table"
import { useToast } from "@/hooks/use-toast"
import { useDispatch, useSelector } from "react-redux"
import {
  setDbName,
  setTableName,
  setFile,
  setIsUploading,
  clearState,
  submitAutoProfileRequest,
  setTableData,
} from "@/store/slices/autoProfileSlice"

export function AutoProfilePage() {
  const [activeTab, setActiveTab] = useState("submit")
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()
  const dispatch = useDispatch()
  const { dbName, tableName, file, isUploading, isLoading, tableData } = useSelector((state: any) => state.autoProfile)

  // Mock data for the table
  const columns = [
    { accessorKey: "prfl_tbl_id", header: "PRFL_TBL_ID" },
    { accessorKey: "data_lob", header: "DATA_LOB" },
    { accessorKey: "data_bus_elem", header: "DATA_BUS_ELEM" },
    { accessorKey: "data_dmn", header: "DATA_DMN" },
    { accessorKey: "data_sub_dmn", header: "DATA_SUB_DMN" },
    { accessorKey: "data_src", header: "DATA_SRC" },
    { accessorKey: "db_name", header: "DB_NAME" },
    { accessorKey: "src_tbl", header: "SRC_TBL" },
    { accessorKey: "incr_dt_col", header: "INCR_DT_COL" },
    { accessorKey: "unq_index_cols", header: "UNQ_INDEX_COLS" },
    { accessorKey: "audit_ts", header: "AUDIT_TS" },
  ]

  const mockData = [
    {
      prfl_tbl_id: "2357",
      data_lob: "Network Performance",
      data_bus_elem: "5g_home_CURATED",
      data_dmn: "5g_home",
      data_sub_dmn: "5g_home_CURATED_UAT",
      data_src: "GCP",
      db_name: "vz-it-pr-gudv-dtwndo-0.aid_5g_home_ready_tbls",
      src_tbl: "dpu_performance_kpi_5min_norm",
      incr_dt_col: "trans_dt",
      unq_index_cols: "trans_dt.event_time",
      audit_ts: "Daily",
    },
  ]

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      dispatch(setFile(e.target.files[0]))
    }
  }

  const handleSubmit = () => {
    if (activeTab === "submit" && file) {
      dispatch(setIsUploading(true))
      dispatch(submitAutoProfileRequest({ file: file as File }))
        .then(() => {
          toast({
            title: "Success",
            description: "Auto profile request submitted successfully",
          })
          dispatch(setFile(null))
        })
        .catch(() => {
          toast({
            variant: "destructive",
            title: "Error",
            description: "Failed to submit auto profile request",
          })
        })
        .finally(() => {
          dispatch(setIsUploading(false))
        })
    } else if (activeTab === "view" && dbName && tableName) {
      dispatch(setTableData(mockData))
    }
  }

  const handleReset = () => {
    dispatch(clearState())
  }

  return (
    <div>
      <PageHeader
        title="Auto Profile"
        breadcrumbs={[{ label: "Profiling", href: "/profiling" }, { label: "Auto Profile" }]}
      />

      <Tabs defaultValue="submit" onValueChange={setActiveTab}>
        <TabsList className="mb-6">
          <TabsTrigger value="submit">Submit Multiple Requests</TabsTrigger>
          <TabsTrigger value="view">View/Edit Request</TabsTrigger>
        </TabsList>

        <TabsContent value="submit">
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col items-center justify-center p-8 border-2 border-dashed rounded-lg">
                <Upload className="h-12 w-12 text-muted-foreground mb-4" />
                <p className="text-center mb-4">Click or drag file to upload</p>

                <Input
                  type="file"
                  className="hidden"
                  id="file-upload"
                  accept=".csv,.xlsx,.xls"
                  onChange={handleFileChange}
                  ref={fileInputRef}
                />

                {file ? (
                  <div className="flex items-center gap-2 p-2 border rounded-md w-full max-w-md">
                    <div className="flex-1 truncate">{file.name}</div>
                    <Button variant="ghost" size="icon">
                      <Copy className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon">
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon">
                      <Download className="h-4 w-4" />
                    </Button>
                  </div>
                ) : (
                  <Button asChild>
                    <label htmlFor="file-upload">Choose File</label>
                  </Button>
                )}
              </div>

              <div className="flex justify-center gap-4 mt-6">
                <Button variant="outline" onClick={handleReset}>
                  Reset
                </Button>
                <Button onClick={handleSubmit} disabled={!file || isUploading}>
                  {isUploading ? "Uploading..." : "Submit"}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="view">
          <Card>
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div>
                  <label htmlFor="database" className="block text-sm font-medium mb-1">
                    Database
                  </label>
                  <Input
                    id="database"
                    value={dbName}
                    onChange={(e) => dispatch(setDbName(e.target.value))}
                    placeholder="vz-it-pr-gudv-dtwndo-0.aid_5g_home_ready_tbls"
                  />
                </div>
                <div>
                  <label htmlFor="tableName" className="block text-sm font-medium mb-1">
                    Table Name
                  </label>
                  <Input
                    id="tableName"
                    value={tableName}
                    onChange={(e) => dispatch(setTableName(e.target.value))}
                    placeholder="dpu_performance_kpi_5min_norm"
                  />
                </div>
              </div>

              <div className="flex justify-end mb-6">
                <Button onClick={handleSubmit}>Submit</Button>
              </div>

              {dbName && tableName && <DataTable columns={columns} data={tableData} />}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
