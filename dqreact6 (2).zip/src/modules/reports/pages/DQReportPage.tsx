"use client"

import { useState, useEffect } from "react"
import { useDispatch, useSelector } from "react-redux"
import { motion } from "framer-motion"
import { CheckCircle, Clock, Fingerprint, AlignJustify, Shield, LayoutGrid, Download, RefreshCw } from "lucide-react"
import { PageHeader } from "@/components/layout/PageContainer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { CircleProgress } from "@/components/charts/CircleProgress"
import { ScoreCard } from "@/components/charts/ScoreCard"
import { Skeleton } from "@/components/ui/skeleton"
import { useToast } from "@/hooks/use-toast"
import { AdvancedBarChart } from "@/components/charts/AdvancedBarChart"
import { AdvancedLineChart } from "@/components/charts/AdvancedLineChart"
import { LiveDataChart } from "@/modules/reports/components/LiveDataChart"
import { DQReportFilters } from "@/modules/reports/components/DQReport/DQReportFilters"
import { DQReportDataProducts } from "@/modules/reports/components/DQReport/DQReportDataProducts"
import { FilteredReportTable } from "@/modules/reports/components/DQReport/FilteredReportTable"
import {
  setDashboardView,
  setDataProductsView,
  setTableLevelAssetsView,
  setSelectedLabel,
  fetchDQReportData,
  applyFilters,
} from "@/store/slices/dqReportSlice"
import html2canvas from "html2canvas"
import jsPDF from "jspdf"
import type { RootState } from "@/store/store"

export function DQReportPage() {
  const dispatch = useDispatch()
  const { toast } = useToast()
  const [isExporting, setIsExporting] = useState(false)

  // Get state from Redux store
  const {
    dashboardView,
    dataProductsView,
    tableLevelAssetsView,
    selectedLabel,
    enterpriseData,
    dqTrendData,
    productTypeWiseData,
    isLoading,
    startDate,
    endDate,
    filterValues,
    error,
  } = useSelector((state: RootState) => state.dqReport)

  // Fetch initial data
  useEffect(() => {
    dispatch(fetchDQReportData() as any)
  }, [dispatch])

  // Handle errors
  useEffect(() => {
    if (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error,
      })
    }
  }, [error, toast])

  const handleDownloadPDF = async () => {
    setIsExporting(true)

    try {
      const element = document.getElementById("dq-report-content")
      if (!element) return

      const icons = element.querySelectorAll(".pdf-icon")
      icons.forEach((icon) => (icon.style.display = "none"))

      const canvas = await html2canvas(element, { scale: 2 })
      const imgData = canvas.toDataURL("image/png")

      const pdf = new jsPDF({
        orientation: "l", // landscape
        unit: "mm",
        format: "a4",
      })

      // Define margins
      const margin = 2 // in mm
      const pdfWidth = pdf.internal.pageSize.getWidth() - 2 * margin
      const pdfHeight = pdf.internal.pageSize.getHeight() - 2 * margin

      // Adjust image dimensions to maintain aspect ratio
      const imgProps = pdf.getImageProperties(imgData)
      const imgWidth = imgProps.width
      const imgHeight = imgProps.height
      let finalImgWidth, finalImgHeight

      // Calculate final image dimensions based on aspect ratio
      if (imgWidth / imgHeight > pdfWidth / pdfHeight) {
        finalImgWidth = pdfWidth
        finalImgHeight = (imgHeight * pdfWidth) / imgWidth
      } else {
        finalImgHeight = pdfHeight
        finalImgWidth = (imgWidth * pdfHeight) / imgHeight
      }

      // Calculate position to center the image
      const imgX = margin + (pdfWidth - finalImgWidth) / 2
      const imgY = margin + (pdfHeight - finalImgHeight) / 2

      pdf.addImage(imgData, "PNG", imgX, imgY, finalImgWidth, finalImgHeight)
      pdf.save("DQ Report.pdf")

      toast({
        title: "Success",
        description: "Report downloaded successfully",
      })
    } catch (error) {
      console.error("PDF export error:", error)
      toast({
        variant: "destructive",
        title: "Export Failed",
        description: "Failed to export the report to PDF",
      })
    } finally {
      // Restore hidden elements
      const element = document.getElementById("dq-report-content")
      if (element) {
        const icons = element.querySelectorAll(".pdf-icon")
        icons.forEach((icon) => (icon.style.display = ""))
      }
      setIsExporting(false)
    }
  }

  const handleRefresh = async () => {
    dispatch(fetchDQReportData() as any)
    toast({
      title: "Refreshed",
      description: "Report data has been refreshed",
    })
  }

  const handleFilterApply = (filters: any) => {
    dispatch(applyFilters(filters) as any)
  }

  const handleViewDataProducts = () => {
    dispatch(setDashboardView(false))
    dispatch(setDataProductsView(true))
    dispatch(setTableLevelAssetsView(false))
  }

  const handleViewDashboard = () => {
    dispatch(setDashboardView(true))
    dispatch(setDataProductsView(false))
    dispatch(setTableLevelAssetsView(false))
  }

  // Prepare chart data
  const barChartData =
    productTypeWiseData?.map((item: any) => ({
      name: item.product_type,
      value: Number.parseFloat(item.OVERALL_DQ_SCORE),
    })) || []

  const lineChartData =
    dqTrendData?.trend_line?.map((item: any) => ({
      name: formatDate(item.run_date),
      value: Number.parseFloat(item.trend_score),
    })) || []

  // Helper function to format date
  function formatDate(dateString: string) {
    const [year, month, day] = dateString.split("-")
    return `${month}/${day}`
  }

  // Calculate enterprise score
  const calculateEnterpriseScore = () => {
    if (!enterpriseData || enterpriseData.length === 0) return 0

    const metrics = [
      "TBL_COMPLETENESS",
      "TBL_TIMELINESS",
      "TBL_UNIQUENESS",
      "tbl_conformity",
      "tbl_validity",
      "tbl_consistency",
    ]

    let sum = 0
    let count = 0

    metrics.forEach((metric) => {
      if (enterpriseData[0][metric]) {
        sum += Number.parseFloat(enterpriseData[0][metric])
        count++
      }
    })

    return count > 0 ? sum / count : 0
  }

  const enterpriseScore = calculateEnterpriseScore()

  return (
    <div>
      <PageHeader
        title="DQ Report"
        description="Overview of data quality metrics across the organization"
        actions={
          <Button variant="outline" onClick={handleRefresh} disabled={isLoading}>
            <RefreshCw className={`mr-2 h-4 w-4 ${isLoading ? "animate-spin" : ""}`} />
            Refresh
          </Button>
        }
      />

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Filters sidebar */}
        <div className="md:col-span-1">
          <DQReportFilters onApplyFilters={handleFilterApply} />
        </div>

        {/* Main content */}
        <div id="dq-report-content" className="md:col-span-3">
          {/* Navigation header */}
          <div className="flex justify-between items-center mb-4 p-4 bg-white rounded-lg shadow-sm">
            <div className="flex items-center space-x-2">
              <span className={`cursor-pointer ${dashboardView ? "font-bold" : ""}`} onClick={handleViewDashboard}>
                DQ Reports
              </span>

              {(dataProductsView || tableLevelAssetsView) && (
                <>
                  <span>/</span>
                  <span
                    className={`cursor-pointer ${dataProductsView ? "font-bold" : ""}`}
                    onClick={handleViewDataProducts}
                  >
                    All Data Products
                  </span>
                </>
              )}

              {tableLevelAssetsView && (
                <>
                  <span>/</span>
                  <span className="font-bold">Table Level Assets</span>
                </>
              )}
            </div>

            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="flex items-center">
                  <span className="inline-block w-3 h-3 rounded-full bg-green-600 mr-1"></span>
                  <span className="text-xs">90-100%</span>
                </div>
                <div className="flex items-center">
                  <span className="inline-block w-3 h-3 rounded-full bg-orange-500 mr-1"></span>
                  <span className="text-xs">80-89%</span>
                </div>
                <div className="flex items-center">
                  <span className="inline-block w-3 h-3 rounded-full bg-red-500 mr-1"></span>
                  <span className="text-xs">0-79%</span>
                </div>
              </div>

              <div className="pdf-icon">
                <Button variant="outline" size="sm" onClick={handleDownloadPDF} disabled={isExporting}>
                  <Download className="mr-2 h-4 w-4" />
                  {isExporting ? "Exporting..." : "Download PDF"}
                </Button>
              </div>
            </div>
          </div>

          {/* Dashboard View */}
          {dashboardView && (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
              {/* Enterprise Score and Metrics */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-7 gap-4 mb-8">
                <Card className="col-span-1 md:col-span-2 lg:col-span-1">
                  <CardContent className="p-6">
                    <div className="flex flex-col items-center">
                      {isLoading ? (
                        <div className="flex flex-col items-center w-full">
                          <Skeleton className="h-[150px] w-[150px] rounded-full" />
                          <Skeleton className="h-6 w-24 mt-2" />
                        </div>
                      ) : (
                        <CircleProgress
                          value={enterpriseScore}
                          size={150}
                          label="Enterprise"
                          sublabel={`CDA - ${enterpriseData?.[0]?.no_of_assets || 0}`}
                        />
                      )}
                    </div>
                  </CardContent>
                </Card>

                {isLoading
                  ? Array(6)
                      .fill(0)
                      .map((_, i) => (
                        <Card key={i} className="col-span-1">
                          <CardContent className="p-6">
                            <div className="flex flex-col items-center">
                              <Skeleton className="h-12 w-12 rounded-full mb-4" />
                              <Skeleton className="h-4 w-32 mb-2" />
                              <Skeleton className="h-6 w-20" />
                            </div>
                          </CardContent>
                        </Card>
                      ))
                  : enterpriseData &&
                    enterpriseData.length > 0 && (
                      <>
                        <ScoreCard
                          title="Completeness"
                          value={Number.parseFloat(enterpriseData[0].TBL_COMPLETENESS || 0)}
                          icon={<CheckCircle className="h-5 w-5" />}
                        />
                        <ScoreCard
                          title="Timeliness"
                          value={Number.parseFloat(enterpriseData[0].TBL_TIMELINESS || 0)}
                          icon={<Clock className="h-5 w-5" />}
                        />
                        <ScoreCard
                          title="Uniqueness"
                          value={Number.parseFloat(enterpriseData[0].TBL_UNIQUENESS || 0)}
                          icon={<Fingerprint className="h-5 w-5" />}
                        />
                        <ScoreCard
                          title="Conformity"
                          value={Number.parseFloat(enterpriseData[0].tbl_conformity || 0)}
                          icon={<AlignJustify className="h-5 w-5" />}
                        />
                        <ScoreCard
                          title="Validity"
                          value={Number.parseFloat(enterpriseData[0].tbl_validity || 0)}
                          icon={<Shield className="h-5 w-5" />}
                        />
                        <ScoreCard
                          title="Consistency"
                          value={Number.parseFloat(enterpriseData[0].tbl_consistency || 0)}
                          icon={<LayoutGrid className="h-5 w-5" />}
                        />
                      </>
                    )}
              </div>

              {/* Charts */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                <Card>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-center">
                      <CardTitle>DQ Score Tables</CardTitle>
                      <Button variant="link" onClick={handleViewDataProducts} className="text-sm p-0 h-auto">
                        All Data Products
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-0">
                    {isLoading ? (
                      <Skeleton className="h-[300px] w-full" />
                    ) : barChartData.length > 0 ? (
                      <AdvancedBarChart
                        data={barChartData}
                        height={300}
                        horizontal={true}
                        colorBy="value"
                        onClick={(item) => {
                          dispatch(setSelectedLabel(item.name === selectedLabel ? null : item.name))
                        }}
                      />
                    ) : (
                      <div className="flex justify-center items-center h-[300px]">
                        <p className="text-muted-foreground">No data available</p>
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>DQ Score Trend</CardTitle>
                  </CardHeader>
                  <CardContent className="pt-0">
                    {isLoading ? (
                      <Skeleton className="h-[300px] w-full" />
                    ) : lineChartData.length > 0 ? (
                      <AdvancedLineChart
                        data={lineChartData}
                        dataSets={[{ name: "DQ Score", data: lineChartData.map((item) => item.value) }]}
                        xKey="name"
                        height={300}
                        showArea={true}
                        targetLine={90}
                      />
                    ) : (
                      <div className="flex justify-center items-center h-[300px]">
                        <p className="text-muted-foreground">No data available</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>

              {/* Live Data Chart */}
              <Card className="mb-8">
                <CardHeader>
                  <CardTitle>Real-time Metrics</CardTitle>
                </CardHeader>
                <CardContent>
                  <LiveDataChart
                    title="Real-time DQ Metrics"
                    endpoint="dq-metrics/live"
                    dataSets={["completeness", "validity", "conformity"]}
                    colors={["#008331", "#0284c7", "#bc9f0a"]}
                  />
                </CardContent>
              </Card>

              {/* Filtered Table */}
              {selectedLabel && (
                <Card className="mb-8">
                  <CardHeader>
                    <CardTitle>
                      Data Quality for {selectedLabel} ({startDate} to {endDate})
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <FilteredReportTable
                      productTypeWiseData={productTypeWiseData}
                      label={selectedLabel}
                      startDate={startDate}
                      endDate={endDate}
                    />
                  </CardContent>
                </Card>
              )}
            </motion.div>
          )}

          {/* Data Products View */}
          {(dataProductsView || tableLevelAssetsView) && (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
              <DQReportDataProducts productTypeWiseData={productTypeWiseData} startDate={startDate} endDate={endDate} />
            </motion.div>
          )}
        </div>
      </div>
    </div>
  )
}
