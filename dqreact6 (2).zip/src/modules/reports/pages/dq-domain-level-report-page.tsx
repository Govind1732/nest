import { DQDomainLevelReport } from "../components/dq-domain-level-report/dq-domain-level-report"

export function DQDomainLevelReportPage() {
  return (
    <div className="h-screen">
      <DQDomainLevelReport />
    </div>
  )
}
