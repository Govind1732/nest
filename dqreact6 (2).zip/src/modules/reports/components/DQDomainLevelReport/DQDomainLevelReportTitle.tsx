"use client"

import { useEffect, useState } from "react"
import { useDispatch } from "react-redux"
import { setLast7days } from "@/store/slices/dqDomainLevelReportSlice"
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink } from "@/components/ui/breadcrumb"

export function DQDomainLevelReportTitle() {
  const [reportDates, setReportDates] = useState({
    todayDate: "",
    startDate: "",
    endDate: "",
  })

  const dispatch = useDispatch()

  useEffect(() => {
    const today = new Date()
    const dates = []
    const mmDates = []

    for (let i = 1; i <= 7; i++) {
      const date = new Date(today)
      date.setDate(today.getDate() - i)
      dates.push(date.toISOString().split("T")[0].replace(/-/g, "/"))
      mmDates.push(
        `${String(date.getMonth() + 1).padStart(2, "0")}/${String(date.getDate()).padStart(2, "0")}/${date.getFullYear()}`,
      )
    }

    dispatch(setLast7days(dates))
    setReportDates({
      todayDate: today.toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" }),
      startDate: mmDates[mmDates.length - 1],
      endDate: mmDates[0],
    })
  }, [dispatch])

  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center gap-4">
        <h2 className="text-2xl font-bold">DQ Domain Level Report</h2>
        <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
        <div>
          {reportDates.startDate} - {reportDates.endDate}
        </div>
      </div>
      <Breadcrumb>
        <BreadcrumbItem>
          <BreadcrumbLink href="/reporting">Reporting</BreadcrumbLink>
        </BreadcrumbItem>
        <BreadcrumbItem>
          <BreadcrumbLink href="/reporting/dq-domain-level-report">DQ Domain Level Report</BreadcrumbLink>
        </BreadcrumbItem>
      </Breadcrumb>
    </div>
  )
}
