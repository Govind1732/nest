"use client"

import { useSelector, useDispatch } from "react-redux"
import { Download } from "lucide-react"
import html2canvas from "html2canvas"
import jsPDF from "jspdf"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

import { DQDomainLevelReportTitle } from "./DQDomainLevelReportTitle"
import { DQDomainLevelReportSidebar } from "./DQDomainLevelReportSidebar"
import { DQDomainLevelReportPillars } from "./DQDomainLevelReportPillars"
import { DQDomainLevelColumns } from "./DQDomainLevelColumns"
import { DQBarchart } from "./DQBarchart"
import { DQLinechart } from "./DQLinechart"
import { Legend } from "./Legend"

import { useGetProductDataQuery, useGetL2ProductDataQuery } from "@/services/api"
import { setDashboardView, setShowAllColumns, setActiveProduct } from "@/store/slices/dqDomainLevelReportSlice"

export function DQDomainLevelReport() {
  const { data: productData = [], isLoading: productIdDataLoading } = useGetProductDataQuery()
  const { data: l2Data = [], isLoading: l2DataLoading } = useGetL2ProductDataQuery()

  const activeProduct = useSelector((state) => state.dqDomainLevelReport.activeProduct)
  const dashboardView = useSelector((state) => state.dqDomainLevelReport.dashboardView)
  const showAllColumns = useSelector((state) => state.dqDomainLevelReport.showAllColumns)
  const dispatch = useDispatch()

  const handleDownloadPDF = () => {
    const element = document.getElementById("dq-report-content")
    const sidebar = document.getElementById("dq-report-sidebar")
    if (!element) return

    // Hide the sidebar
    if (sidebar) {
      sidebar.style.display = "none"
    }

    const icons = element.querySelectorAll(".pdf-icon")
    icons.forEach((icon) => (icon.style.display = "none"))

    html2canvas(element, { scale: 2 }).then((canvas) => {
      const imgData = canvas.toDataURL("image/png")
      const pdf = new jsPDF({
        orientation: "l", // landscape
        unit: "mm",
        format: "a4",
      })

      // Define margins
      const margin = 2 // in mm
      const pdfWidth = pdf.internal.pageSize.getWidth() - 2 * margin
      const pdfHeight = pdf.internal.pageSize.getHeight() - 2 * margin

      // Adjust image dimensions to maintain aspect ratio
      const imgProps = pdf.getImageProperties(imgData)
      const imgWidth = imgProps.width
      const imgHeight = imgProps.height
      let finalImgWidth, finalImgHeight

      // Calculate final image dimensions based on aspect ratio
      if (imgWidth / imgHeight > pdfWidth / pdfHeight) {
        finalImgWidth = pdfWidth
        finalImgHeight = (imgHeight * pdfWidth) / imgWidth
      } else {
        finalImgHeight = pdfHeight
        finalImgWidth = (imgWidth * pdfHeight) / imgHeight
      }

      // Calculate position to center the image
      const imgX = margin + (pdfWidth - finalImgWidth) / 2
      const imgY = margin + (pdfHeight - finalImgHeight) / 2

      pdf.addImage(imgData, "PNG", imgX, imgY, finalImgWidth, finalImgHeight)
      pdf.save("DQ Domain Level Report.pdf")

      // Restore hidden elements after PDF generation
      icons.forEach((icon) => (icon.style.display = ""))
      if (sidebar) {
        sidebar.style.display = ""
      }
    })
  }

  return (
    <div className="h-full bg-white">
      <div className="h-[10%] px-6 py-4 flex items-center justify-between sticky top-0 z-10 bg-white border-b">
        <DQDomainLevelReportTitle />
      </div>
      <div className="h-[90%] flex">
        <div id="dq-report-sidebar" className="w-1/5 h-full border-r bg-white overflow-y-auto">
          <DQDomainLevelReportSidebar />
        </div>
        <div id="dq-report-content" className="w-4/5 h-full overflow-y-auto">
          <div className="h-[7%] flex justify-between items-center px-4 py-2 border-b">
            <div>
              <span className="product-title">
                {activeProduct.productId && (
                  <span
                    onClick={() => {
                      dispatch(setDashboardView(true))
                      dispatch(
                        setActiveProduct({
                          productId: activeProduct.productId,
                          L2_productId: "",
                          tableName: "",
                        }),
                      )
                    }}
                    className="cursor-pointer"
                  >
                    {activeProduct.productId && !activeProduct.L2_productId && !activeProduct.tableName ? (
                      <span className="text-xl font-bold">{activeProduct.productId}</span>
                    ) : (
                      <span>{activeProduct.productId}</span>
                    )}
                  </span>
                )}
                {activeProduct.L2_productId && (
                  <span
                    onClick={() => {
                      dispatch(setDashboardView(true))
                      dispatch(setShowAllColumns(false))
                      dispatch(
                        setActiveProduct({
                          productId: activeProduct.productId,
                          L2_productId: activeProduct.L2_productId,
                          tableName: "",
                        }),
                      )
                    }}
                    className="cursor-pointer"
                  >
                    {activeProduct.tableName ? (
                      <span> / {activeProduct.L2_productId}</span>
                    ) : (
                      <span className="text-lg font-bold"> / {activeProduct.L2_productId}</span>
                    )}
                  </span>
                )}
                {activeProduct.tableName && <span className="text-lg font-bold"> / {activeProduct.tableName}</span>}
              </span>
            </div>
            <div className="flex items-center gap-4">
              <Legend />
              <div className="pdf-icon flex items-center cursor-pointer" onClick={handleDownloadPDF}>
                <Download className="h-5 w-5 mr-1" />
                <Button variant="link" className="p-0">
                  Download PDF
                </Button>
              </div>
            </div>
          </div>

          {/* Dashboard View */}
          <div className={`h-[93%] overflow-y-auto ${dashboardView ? "block" : "hidden"}`}>
            <div className="p-4">
              <DQDomainLevelReportPillars />
            </div>

            {/* Product Level Charts */}
            {activeProduct.productId && !activeProduct.L2_productId && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 h-[500px] md:h-[400px]">
                <Card className="h-full">
                  <CardHeader>
                    <CardTitle className="text-center">DQ Score Tables</CardTitle>
                  </CardHeader>
                  <CardContent className="h-[calc(100%-60px)]">
                    {productIdDataLoading || l2DataLoading ? (
                      <div className="flex items-center justify-center h-full">
                        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
                      </div>
                    ) : productData.filter((product) => product.product_id === activeProduct.productId)[0]
                        ?.barChart_allTables?.length > 0 ? (
                      <DQBarchart
                        bargraphData={
                          productData.filter((product) => product.product_id === activeProduct.productId)[0]
                            ?.barChart_allTables
                        }
                      />
                    ) : (
                      <div className="flex justify-center items-center h-full">
                        <p className="text-lg font-bold">No Data Available</p>
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Card className="h-full">
                  <CardHeader>
                    <CardTitle className="text-center">DQ Score Trend</CardTitle>
                  </CardHeader>
                  <CardContent className="h-[calc(100%-60px)]">
                    {productIdDataLoading || l2DataLoading ? (
                      <div className="flex items-center justify-center h-full">
                        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
                      </div>
                    ) : productData.filter((product) => product.product_id === activeProduct.productId)[0]
                        ?.lineChart ? (
                      <DQLinechart
                        linechartData={
                          productData.filter((product) => product.product_id === activeProduct.productId)[0]?.lineChart
                        }
                      />
                    ) : (
                      <div className="flex justify-center items-center h-full">
                        <p className="text-lg font-bold">No Data Available</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            )}

            {/* L2 Product Level Charts */}
            {activeProduct.productId && activeProduct.L2_productId && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 h-[500px] md:h-[400px]">
                <Card className="h-full">
                  <CardHeader>
                    <CardTitle className="text-center">DQ Score Tables</CardTitle>
                  </CardHeader>
                  <CardContent className="h-[calc(100%-60px)]">
                    {productIdDataLoading || l2DataLoading ? (
                      <div className="flex items-center justify-center h-full">
                        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
                      </div>
                    ) : l2Data
                        .filter((product) => product.product_id === activeProduct.productId)[0]
                        ?.level2_data.filter((level2) => level2.level2_name === activeProduct.L2_productId)[0]
                        ?.barChart_allTables?.length > 0 ? (
                      <DQBarchart
                        bargraphData={
                          l2Data
                            .filter((product) => product.product_id === activeProduct.productId)[0]
                            ?.level2_data.filter((level2) => level2.level2_name === activeProduct.L2_productId)[0]
                            ?.barChart_allTables
                        }
                      />
                    ) : (
                      <div className="flex justify-center items-center h-full">
                        <p className="text-lg font-bold">No Data Available</p>
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Card className="h-full">
                  <CardHeader>
                    <CardTitle className="text-center">DQ Score Trend</CardTitle>
                  </CardHeader>
                  <CardContent className="h-[calc(100%-60px)]">
                    {productIdDataLoading || l2DataLoading ? (
                      <div className="flex items-center justify-center h-full">
                        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
                      </div>
                    ) : l2Data
                        .filter((product) => product.product_id === activeProduct.productId)[0]
                        ?.level2_data.filter((level2) => level2.level2_name === activeProduct.L2_productId)[0]
                        ?.lineChart ? (
                      <DQLinechart
                        linechartData={
                          l2Data
                            .filter((product) => product.product_id === activeProduct.productId)[0]
                            ?.level2_data.filter((level2) => level2.level2_name === activeProduct.L2_productId)[0]
                            ?.lineChart
                        }
                      />
                    ) : (
                      <div className="flex justify-center items-center h-full">
                        <p className="text-lg font-bold">No Data Available</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            )}
          </div>

          {/* Columns View */}
          <div className={`p-4 ${showAllColumns ? "flex" : "hidden"} justify-center items-start`}>
            <DQDomainLevelColumns />
          </div>
        </div>
      </div>
    </div>
  )
}
