import { truncateDecimal } from "@/lib/utils"

interface TopBottomScore {
  table: string
  score: number
}

interface TopBottomScores {
  top_5_scores: TopBottomScore[]
  bottom_5_scores: TopBottomScore[]
}

interface DQDomainLevelModalProps {
  topBottomScores: TopBottomScores
  isTopBottomScoresLoading: boolean
  isTopBottomScoresError: boolean
  selectedPillar: string
}

export function DQDomainLevelModal({
  topBottomScores,
  isTopBottomScoresLoading,
  isTopBottomScoresError,
  selectedPillar,
}: DQDomainLevelModalProps) {
  const getScoreColor = (score: number) => {
    if (score > 90) {
      return {
        bg: "bg-green-100",
        text: "text-green-700",
      }
    } else if (score > 80) {
      return {
        bg: "bg-orange-100",
        text: "text-orange-700",
      }
    } else {
      return {
        bg: "bg-red-100",
        text: "text-red-700",
      }
    }
  }

  const hasNon100Scores =
    topBottomScores?.top_5_scores &&
    topBottomScores?.bottom_5_scores &&
    [
      ...topBottomScores.top_5_scores.map((item) => item.score),
      ...topBottomScores.bottom_5_scores.map((item) => item.score),
    ].some((score) => score !== 100)

  if (isTopBottomScoresLoading) {
    return (
      <div className="flex justify-center items-center h-40">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
      </div>
    )
  }

  if (isTopBottomScoresError) {
    return (
      <div className="text-red-500 p-4">
        <p>There was an error loading the scores. Please try again later.</p>
      </div>
    )
  }

  if (!hasNon100Scores) {
    return (
      <div className="text-center p-4">
        <p className="text-green-700 font-bold">All tables scored 100% in {selectedPillar}.</p>
      </div>
    )
  }

  return (
    <div className="flex flex-col md:flex-row justify-center gap-4 p-2">
      {/* Top 5 Scores */}
      <div className="w-full md:w-1/2">
        <div className="rounded-md overflow-hidden">
          <div className="bg-green-100 text-green-800 py-2 text-center font-medium">Top 5 Scores</div>
          <div className="divide-y">
            {topBottomScores.top_5_scores.map((item, index) => {
              const { bg, text } = getScoreColor(item.score)
              return (
                <div key={index} className="flex justify-between items-center p-2">
                  <span className="truncate max-w-[70%]">{item.table}</span>
                  <span className={`${bg} ${text} px-2 py-1 rounded-full text-sm`}>
                    {truncateDecimal(item.score, 1)}%
                  </span>
                </div>
              )
            })}
          </div>
        </div>
      </div>

      {/* Bottom 5 Scores */}
      {topBottomScores.bottom_5_scores.filter((item) => item.score !== 100).length > 0 && (
        <div className="w-full md:w-1/2">
          <div className="rounded-md overflow-hidden">
            <div className="bg-orange-100 text-orange-800 py-2 text-center font-medium">Low 5 Scores</div>
            <div className="divide-y">
              {topBottomScores.bottom_5_scores
                .filter((item) => item.score !== 100)
                .map((item, index) => {
                  const { bg, text } = getScoreColor(item.score)
                  return (
                    <div key={index} className="flex justify-between items-center p-2">
                      <span className="truncate max-w-[70%]">{item.table}</span>
                      <span className={`${bg} ${text} px-2 py-1 rounded-full text-sm`}>
                        {truncateDecimal(item.score, 1)}%
                      </span>
                    </div>
                  )
                })}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
