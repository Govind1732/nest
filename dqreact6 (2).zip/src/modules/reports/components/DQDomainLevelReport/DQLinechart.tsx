"use client"

import { useRef, useEffect } from "react"
import Chart from "chart.js/auto"
import { truncateDecimal, colors } from "@/lib/utils"

interface DQLinechartProps {
  linechartData: Record<string, number>
}

export function DQLinechart({ linechartData }: DQLinechartProps) {
  const chartRef = useRef<HTMLCanvasElement>(null)

  const formatDate = (dateString: string) => {
    const [year, month, day] = dateString.split("-")
    return `${month}/${day}`
  }

  const getLineBackgroundColor = (value: number) => {
    if (value > 90) return colors.strokeColorHigh
    if (value > 80 && value <= 90) return colors.strokeColorMedium
    return colors.strokeColorLow
  }

  const getXLineAxisConfig = () => ({
    display: true,
    grid: { display: false, color: "#D8DADA" },
    ticks: {
      font: { size: 14 },
      color: "#6F7171",
    },
    border: { color: "#000" },
  })

  const getYLineAxisConfig = () => ({
    display: true,
    grid: { display: false },
    beginAtZero: true,
    min: 0,
    max: 100,
    ticks: {
      stepSize: 20,
      font: { size: 14 },
      color: "#6F7171",
      callback: (value: number) => (value === 0 ? "" : `${value}%`),
    },
    border: { color: "#000" },
  })

  useEffect(() => {
    if (!chartRef.current || !linechartData) return

    const ctx = chartRef.current.getContext("2d")
    if (!ctx) return

    const chartConfig = {
      type: "line",
      data: {
        labels: Object.keys(linechartData).map((date) => formatDate(date)),
        datasets: [
          {
            fill: false,
            tension: 0,
            data: Object.values(linechartData).map((value) => truncateDecimal(value, 1)),
            backgroundColor: (context: any) => getLineBackgroundColor(context.raw),
            borderColor: "#000",
            pointRadius: 5,
            pointHoverRadius: 10,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            bodyFont: { size: 15 },
            padding: 10,
            boxPadding: 10,
          },
        },
        scales: {
          x: getXLineAxisConfig(),
          y: getYLineAxisConfig(),
        },
        layout: {
          padding: {
            right: 50,
            top: 20,
          },
        },
      },
      plugins: [
        {
          id: "datalabels",
          afterDatasetsDraw: (chart: any) => {
            const ctx = chart.ctx
            chart.data.datasets.forEach((_dataset: any, i: number) => {
              const meta = chart.getDatasetMeta(i)
              meta.data.forEach((point: any, index: number) => {
                const value = truncateDecimal(chart.data.datasets[i].data[index], 1)
                ctx.fillStyle = "#000"
                ctx.font = "15px Arial"
                ctx.fillText(value + "%", point.x - 12, point.y + 20)
              })
            })
          },
        },
      ],
    }

    const myChart = new Chart(ctx, chartConfig as any)

    return () => myChart.destroy()
  }, [linechartData])

  return (
    <div className="w-full h-full flex justify-center items-center">
      <canvas ref={chartRef} className="w-full h-full"></canvas>
    </div>
  )
}
