"use client"

import { useState, useEffect } from "react"
import { useGetProductDataQuery, useGetL2ProductDataQuery } from "@/services/api"
import { usePostTopBottomFiveScoresMutation } from "@/services/api"
import { useSelector } from "react-redux"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Skeleton } from "@/components/ui/skeleton"
import { truncateDecimal } from "@/lib/utils"
import { DQDomainLevelModal } from "./DQDomainLevelModal"

// Import icons
import { CheckCircle, Medal, Clock, Grid, Shield, ThumbsUp } from "lucide-react"

export function DQDomainLevelReportPillars() {
  const { data: productData = [], isLoading: productIdDataLoading } = useGetProductDataQuery()
  const { data: l2Data = [], isLoading: l2DataLoading } = useGetL2ProductDataQuery()
  const [postTopBottomFiveScores, { isLoading: isTopBottomScoresLoading, isError: isTopBottomScoresError }] =
    usePostTopBottomFiveScoresMutation()
  const activeProduct = useSelector((state) => state.dqDomainLevelReport.activeProduct)
  const [showModal, setShowModal] = useState(false)
  const [selectedPillar, setSelectedPillar] = useState("")
  const [topBottomScores, setTopBottomScores] = useState({})

  const metricIcons = {
    completeness: <CheckCircle className="h-8 w-8" />,
    uniqueness: <Medal className="h-8 w-8" />,
    timeliness: <Clock className="h-8 w-8" />,
    consistency: <Grid className="h-8 w-8" />,
    validity: <Shield className="h-8 w-8" />,
    conformity: <ThumbsUp className="h-8 w-8" />,
  }

  const calculateAverageScore = () => {
    const scores = l2Data
      ?.find((product) => product.product_id === activeProduct?.productId)
      ?.level2_data?.find((level2) => level2.level2_name === activeProduct?.L2_productId)?.dq_score

    if (!scores) return 0

    const values = Object.values(scores).filter((value) => value !== null)
    const sum = values.reduce((acc, val) => acc + val, 0)
    return truncateDecimal(sum / values.length, 1)
  }

  let activeProduct_overall_score = 0
  if (activeProduct?.productId && !activeProduct?.L2_productId && productData?.length > 0) {
    const product_id_obj = productData.filter((product) => {
      return product?.product_id === activeProduct?.productId
    })
    activeProduct_overall_score = truncateDecimal(
      Object.values(product_id_obj[0]?.["dq_score"]).reduce((a, b) => Number.parseFloat(a) + Number.parseFloat(b), 0) /
        Object.keys(product_id_obj[0]?.["dq_score"]).length,
      1,
    )
  } else if (activeProduct?.productId && activeProduct?.L2_productId && l2Data?.length > 0) {
    activeProduct_overall_score = calculateAverageScore()
  } else {
    activeProduct_overall_score = 0
  }

  // Radial Bar Chart
  useEffect(() => {
    const radialBar = document.getElementById("radialBar")
    if (radialBar) {
      const color =
        activeProduct_overall_score > 90
          ? "var(--color-success)"
          : activeProduct_overall_score > 80
            ? "var(--color-warning)"
            : "var(--color-error)"
      radialBar.style.background = `conic-gradient(${color} ${activeProduct_overall_score}%, #f6f6f6 ${activeProduct_overall_score}%)`
      const span = radialBar.querySelector("span")
      if (span) {
        span.innerText = `${activeProduct_overall_score}%`
        span.style.color = color
      }
    }
  }, [activeProduct_overall_score])

  const handlePostTopBottomFiveScores = async (score_type) => {
    setSelectedPillar(score_type.charAt(0).toUpperCase() + score_type.slice(1))
    const inputData = {
      product_name: activeProduct.productId || "",
      score_type: "tbl_" + score_type.toString().toLowerCase(),
      level_2_name: activeProduct.L2_productId || "",
    }
    setShowModal(true)
    try {
      const response = await postTopBottomFiveScores(inputData).unwrap()
      setTopBottomScores(response)
    } catch (error) {
      console.error("Failed to post data:", error)
    }
  }

  const getScoreColor = (score) => {
    if (score > 90) {
      return {
        bg: "bg-green-100",
        text: "text-green-700",
      }
    } else if (score > 80) {
      return {
        bg: "bg-orange-100",
        text: "text-orange-700",
      }
    } else {
      return {
        bg: "bg-red-100",
        text: "text-red-700",
      }
    }
  }

  return (
    <>
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{selectedPillar}</DialogTitle>
          </DialogHeader>
          <DQDomainLevelModal
            topBottomScores={topBottomScores}
            isTopBottomScoresLoading={isTopBottomScoresLoading}
            isTopBottomScoresError={isTopBottomScoresError}
            selectedPillar={selectedPillar}
          />
        </DialogContent>
      </Dialog>

      {activeProduct.productId && !activeProduct.L2_productId && (
        <>
          {productIdDataLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-7 gap-4">
              {[...Array(7)].map((_, index) => (
                <Skeleton key={index} className="h-[200px] rounded-md" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-7 gap-4">
              <div className="bg-white rounded-xl shadow-md p-4 min-h-[180px] flex flex-col items-center justify-between transition-all hover:translate-y-[-4px] hover:scale-[1.02] hover:shadow-lg">
                <div className="flex flex-col items-center gap-4">
                  <div id="radialBar" className="relative w-28 h-28 rounded-full flex items-center justify-center">
                    <span className="relative z-10 text-xl font-bold"></span>
                    <div className="absolute inset-0 m-auto w-20 h-20 bg-gray-100 rounded-full shadow-inner"></div>
                  </div>
                  <p className="text-lg font-bold">Overall Score</p>
                </div>
              </div>

              {productData.length > 0 &&
                Object.entries(
                  productData.filter((product) => product.product_id === activeProduct.productId)[0]?.dq_score,
                )?.map(([key, value]) => {
                  const scoreValue = Number.parseFloat(value as string)
                  const { bg, text } = getScoreColor(scoreValue)

                  return (
                    <div
                      key={key}
                      className={`${bg} rounded-xl shadow-md p-4 min-h-[180px] flex flex-col items-center justify-between transition-all hover:translate-y-[-4px] hover:scale-[1.02] hover:shadow-lg cursor-pointer`}
                      onClick={() => handlePostTopBottomFiveScores(key)}
                    >
                      <div className="bg-white p-3 rounded-full shadow">{metricIcons[key]}</div>
                      <div className="flex flex-col items-center gap-2.5">
                        <p className={`text-lg font-bold ${text}`}>{truncateDecimal(scoreValue, 1)}</p>
                        <p className="text-lg font-bold text-black">{key.charAt(0).toUpperCase() + key.slice(1)}</p>
                      </div>
                    </div>
                  )
                })}
            </div>
          )}
        </>
      )}

      {activeProduct.productId && activeProduct.L2_productId && (
        <>
          {l2DataLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-7 gap-4">
              {[...Array(7)].map((_, index) => (
                <Skeleton key={index} className="h-[200px] rounded-md" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-7 gap-4">
              <div className="bg-white rounded-xl shadow-md p-4 min-h-[180px] flex flex-col items-center justify-between transition-all hover:translate-y-[-4px] hover:scale-[1.02] hover:shadow-lg">
                <div className="flex flex-col items-center gap-4">
                  <div id="radialBar" className="relative w-28 h-28 rounded-full flex items-center justify-center">
                    <span className="relative z-10 text-xl font-bold"></span>
                    <div className="absolute inset-0 m-auto w-20 h-20 bg-gray-100 rounded-full shadow-inner"></div>
                  </div>
                  <p className="text-lg font-bold">Overall Score</p>
                </div>
              </div>

              {activeProduct.productId &&
                activeProduct.L2_productId &&
                l2Data.length > 0 &&
                l2Data
                  .filter((product) => product.product_id === activeProduct.productId)[0]
                  ?.level2_data.filter((l2Item) => l2Item.level2_name === activeProduct.L2_productId)[0]?.dq_score &&
                Object.entries(
                  l2Data
                    .filter((product) => product.product_id === activeProduct.productId)[0]
                    ?.level2_data.filter((l2Item) => l2Item.level2_name === activeProduct.L2_productId)[0]?.dq_score,
                )
                  .map(([key, value]) => {
                    if (value === null) return null

                    const scoreValue = Number.parseFloat(value as string)
                    const { bg, text } = getScoreColor(scoreValue)

                    return (
                      <div
                        key={key}
                        className={`${bg} rounded-xl shadow-md p-4 min-h-[180px] flex flex-col items-center justify-between transition-all hover:translate-y-[-4px] hover:scale-[1.02] hover:shadow-lg cursor-pointer`}
                        onClick={() => handlePostTopBottomFiveScores(key)}
                      >
                        <div className="bg-white p-3 rounded-full shadow">{metricIcons[key]}</div>
                        <div className="flex flex-col items-center gap-2.5">
                          <p className={`text-lg font-bold ${text}`}>{truncateDecimal(scoreValue, 1)}</p>
                          <p className="text-lg font-bold text-black">{key.charAt(0).toUpperCase() + key.slice(1)}</p>
                        </div>
                      </div>
                    )
                  })
                  .filter(Boolean)}
            </div>
          )}
        </>
      )}
    </>
  )
}
