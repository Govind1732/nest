// Auth service for API calls
import { api } from "@/store/api"
import type { User } from "@/types/common.types"

export const authApi = api.injectEndpoints({
  endpoints: (builder) => ({
    getCurrentUser: builder.query<User, void>({
      query: () => "/auth/me",
      providesTags: ["User"],
    }),
    login: builder.mutation<{ user: User; token: string }, { email: string; password: string }>({
      query: (credentials) => ({
        url: "/auth/login",
        method: "POST",
        body: credentials,
      }),
      invalidatesTags: ["User"],
    }),
    logout: builder.mutation<void, void>({
      query: () => ({
        url: "/auth/logout",
        method: "POST",
      }),
      invalidatesTags: ["User"],
    }),
    requestRoleUpgrade: builder.mutation<void, { projectId: string; reason: string }>({
      query: (data) => ({
        url: "/auth/request-role-upgrade",
        method: "POST",
        body: data,
      }),
    }),
  }),
})

export const { useGetCurrentUserQuery, useLoginMutation, useLogoutMutation, useRequestRoleUpgradeMutation } = authApi
