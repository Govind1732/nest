"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { PageContainer, PageHeader } from "@/components/layout/PageContainer"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function DQFalloutSubscriptionPage() {
  const [dbName, setDbName] = useState("")
  const [tableName, setTableName] = useState("")
  const [emailId, setEmailId] = useState("")
  const [environment, setEnvironment] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const handleReset = () => {
    setDbName("")
    setTableName("")
    setEmailId("")
    setEnvironment("")
  }

  const handleSubscribe = () => {
    setIsLoading(true)
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false)
      // Show success message
    }, 1500)
  }

  return (
    <PageContainer>
      <PageHeader
        title="DQ Fallout Subscription"
        breadcrumbs={[{ label: "API Integration", href: "/api-integration" }, { label: "DQ Fallout Subscription" }]}
      />

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
        <Card>
          <CardContent className="p-6">
            <div className="max-w-2xl mx-auto">
              <div className="space-y-6">
                <div className="space-y-2">
                  <label htmlFor="environment" className="block text-sm font-medium">
                    Environment
                  </label>
                  <Select value={environment} onValueChange={setEnvironment}>
                    <SelectTrigger id="environment">
                      <SelectValue placeholder="Select environment" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="td">TD</SelectItem>
                      <SelectItem value="gcp">GCP</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label htmlFor="dbName" className="block text-sm font-medium">
                    DB Name
                  </label>
                  <Input
                    id="dbName"
                    value={dbName}
                    onChange={(e) => setDbName(e.target.value)}
                    placeholder="Enter database name"
                    className="w-full"
                  />
                </div>

                <div className="space-y-2">
                  <label htmlFor="tableName" className="block text-sm font-medium">
                    Table Name
                  </label>
                  <Input
                    id="tableName"
                    value={tableName}
                    onChange={(e) => setTableName(e.target.value)}
                    placeholder="Enter table name"
                    className="w-full"
                  />
                </div>

                <div className="space-y-2">
                  <label htmlFor="emailId" className="block text-sm font-medium">
                    Email Id
                  </label>
                  <Input
                    id="emailId"
                    type="email"
                    value={emailId}
                    onChange={(e) => setEmailId(e.target.value)}
                    placeholder="Enter your email"
                    className="w-full"
                  />
                </div>

                <div className="flex justify-center gap-4 pt-4">
                  <Button variant="outline" onClick={handleReset}>
                    Reset
                  </Button>
                  <Button onClick={handleSubscribe} disabled={isLoading}>
                    {isLoading ? "Processing..." : "Subscribe"}
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </PageContainer>
  )
}
