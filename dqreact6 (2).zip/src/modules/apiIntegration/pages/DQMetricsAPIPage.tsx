"use client"

import { useState, useEffect } from "react"
import { Typography, TextField, Button, Grid, Paper, CircularProgress, Alert, Snackbar } from "@mui/material"
import { CopyToClipboard } from "react-copy-to-clipboard"
import FileCopyIcon from "@mui/icons-material/FileCopy"
import CheckCircleIcon from "@mui/icons-material/CheckCircle"
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter"
import { dracula } from "react-syntax-highlighter/dist/esm/styles/prism"

const DQMetricsAPIPage = () => {
  const [dqType, setDqType] = useState("")
  const [date, setDate] = useState("")
  const [timeDimension, setTimeDimension] = useState("")
  const [apiEndpoint, setApiEndpoint] = useState("")
  const [generatedQuery, setGeneratedQuery] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [successMessage, setSuccessMessage] = useState("")
  const [openSnackbar, setOpenSnackbar] = useState(false)

  useEffect(() => {
    if (dqType && date && timeDimension) {
      generateQuery()
    }
  }, [dqType, date, timeDimension])

  const generateQuery = async () => {
    setIsLoading(true)
    setError("")
    setGeneratedQuery("")

    // Construct the API endpoint based on the input parameters
    const endpoint = `/api/dq-metrics?dq_type=${dqType}&date=${date}&time_dimension=${timeDimension}`

    setApiEndpoint(endpoint)

    try {
      // Simulate API call delay
      await new Promise((resolve) => setTimeout(resolve, 500))

      // Simulate API response
      const mockApiResponse = {
        query: `
       SELECT
           date,
           time_dimension,
           dq_type,
           metric_value
       FROM
           dq_metrics_table
       WHERE
           date = '${date}'
           AND time_dimension = '${timeDimension}'
           AND dq_type = '${dqType}';
       `,
      }

      setGeneratedQuery(mockApiResponse.query)
    } catch (err) {
      setError("Failed to generate query. Please check your inputs.")
      console.error(err)
    } finally {
      setIsLoading(false)
    }
  }

  const handleCopyClick = () => {
    setSuccessMessage("Query copied to clipboard!")
    setOpenSnackbar(true)
  }

  const handleCloseSnackbar = (event, reason) => {
    if (reason === "clickaway") {
      return
    }
    setOpenSnackbar(false)
  }

  return (
    <Grid container spacing={3} justifyContent="center" alignItems="flex-start" style={{ padding: "20px" }}>
      <Grid item xs={12} md={8}>
        <Typography variant="h4" gutterBottom>
          DQ Metrics API Query Generator
        </Typography>
        <Paper elevation={3} style={{ padding: "20px" }}>
          <Grid container spacing={2} alignItems="center">
            <Grid item xs={12}>
              <Typography variant="subtitle1">
                Enter the parameters to generate the API query for fetching Data Quality Metrics.
              </Typography>
            </Grid>
            <Grid item xs={12} sm={4}>
              <TextField
                fullWidth
                label="DQ Type"
                variant="outlined"
                value={dqType}
                onChange={(e) => setDqType(e.target.value)}
                placeholder="e.g., completeness"
              />
            </Grid>
            <Grid item xs={12} sm={4}>
              <TextField
                fullWidth
                label="Date"
                variant="outlined"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                placeholder="YYYY-MM-DD"
              />
            </Grid>
            <Grid item xs={12} sm={4}>
              <TextField
                fullWidth
                label="Time Dimension"
                variant="outlined"
                value={timeDimension}
                onChange={(e) => setTimeDimension(e.target.value)}
                placeholder="e.g., daily"
              />
            </Grid>
            <Grid item xs={12}>
              <Button variant="contained" color="primary" onClick={generateQuery} disabled={isLoading}>
                {isLoading ? <CircularProgress size={24} color="inherit" /> : "Generate Query"}
              </Button>
            </Grid>
          </Grid>
        </Paper>
        {error && (
          <Alert severity="error" style={{ marginTop: "20px" }}>
            {error}
          </Alert>
        )}
        {apiEndpoint && (
          <Paper elevation={3} style={{ padding: "20px", marginTop: "20px" }}>
            <Typography variant="h6" gutterBottom>
              API Endpoint:
            </Typography>
            <TextField
              fullWidth
              variant="outlined"
              value={apiEndpoint}
              InputProps={{
                readOnly: true,
                endAdornment: (
                  <CopyToClipboard text={apiEndpoint} onCopy={handleCopyClick}>
                    <Button>
                      <FileCopyIcon />
                    </Button>
                  </CopyToClipboard>
                ),
              }}
            />
          </Paper>
        )}
        {generatedQuery && (
          <Paper elevation={3} style={{ padding: "20px", marginTop: "20px" }}>
            <Typography variant="h6" gutterBottom>
              Generated Query:
            </Typography>
            <SyntaxHighlighter language="sql" style={dracula}>
              {generatedQuery}
            </SyntaxHighlighter>
            <CopyToClipboard text={generatedQuery} onCopy={handleCopyClick}>
              <Button variant="contained" color="primary" style={{ marginTop: "10px" }}>
                Copy Query
              </Button>
            </CopyToClipboard>
          </Paper>
        )}
      </Grid>
      <Snackbar
        open={openSnackbar}
        autoHideDuration={3000}
        onClose={handleCloseSnackbar}
        message={
          <Typography>
            <CheckCircleIcon style={{ marginRight: "5px", verticalAlign: "middle" }} />
            {successMessage}
          </Typography>
        }
        anchorOrigin={{ vertical: "bottom", horizontal: "left" }}
      />
    </Grid>
  )
}

export default DQMetricsAPIPage
