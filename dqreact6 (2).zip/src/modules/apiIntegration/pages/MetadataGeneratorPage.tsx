"use client"

import type React from "react"

import { useState } from "react"
import { motion } from "framer-motion"
import { PageContainer, PageHeader } from "@/components/layout/PageContainer"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Upload, Copy, Eye, Download } from "lucide-react"

export default function MetadataGeneratorPage() {
  const [emailId, setEmailId] = useState("")
  const [file, setFile] = useState<File | null>(null)
  const [isUploading, setIsUploading] = useState(false)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setFile(e.target.files[0])
    }
  }

  const handleReset = () => {
    setEmailId("")
    setFile(null)
  }

  const handleGenerate = () => {
    setIsUploading(true)
    // Simulate API call
    setTimeout(() => {
      setIsUploading(false)
      // Show success message
    }, 1500)
  }

  return (
    <PageContainer>
      <PageHeader
        title="Metadata Generator"
        breadcrumbs={[{ label: "API Integration", href: "/api-integration" }, { label: "Metadata Generator" }]}
      />

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
        <Card>
          <CardContent className="p-6">
            <div className="max-w-2xl mx-auto">
              <div className="space-y-6">
                <div className="space-y-2">
                  <label htmlFor="emailId" className="block text-sm font-medium">
                    Email Id
                  </label>
                  <Input
                    id="emailId"
                    type="email"
                    value={emailId}
                    onChange={(e) => setEmailId(e.target.value)}
                    placeholder="Enter your email"
                    className="w-full"
                  />
                </div>

                <div className="space-y-2">
                  <label htmlFor="file-upload" className="block text-sm font-medium">
                    Upload Excel File
                  </label>
                  <div className="flex flex-col items-center justify-center p-6 border-2 border-dashed rounded-lg">
                    <Upload className="h-12 w-12 text-muted-foreground mb-4" />
                    <p className="text-center mb-4">Click or drag file to upload</p>

                    <Input
                      type="file"
                      className="hidden"
                      id="file-upload"
                      accept=".csv,.xlsx,.xls"
                      onChange={handleFileChange}
                    />

                    {file ? (
                      <div className="flex items-center gap-2 p-2 border rounded-md w-full max-w-md">
                        <div className="flex-1 truncate">{file.name}</div>
                        <Button variant="ghost" size="icon">
                          <Copy className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon">
                          <Download className="h-4 w-4" />
                        </Button>
                      </div>
                    ) : (
                      <Button asChild>
                        <label htmlFor="file-upload">Choose File</label>
                      </Button>
                    )}
                  </div>
                </div>

                <div className="flex justify-center gap-4 pt-4">
                  <Button variant="outline" onClick={handleReset}>
                    Reset
                  </Button>
                  <Button onClick={handleGenerate} disabled={!file || !emailId || isUploading}>
                    {isUploading ? "Generating..." : "Generate"}
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </PageContainer>
  )
}
