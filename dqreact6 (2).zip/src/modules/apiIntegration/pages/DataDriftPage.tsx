"use client"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import type { z } from "zod"
import { motion } from "framer-motion"
import { PageContainer, PageHeader } from "@/components/layout/PageContainer"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { dataDriftSchema } from "@/lib/schema"
import { RoleGuard } from "@/modules/auth/components/RoleGuard"

type FormValues = z.infer<typeof dataDriftSchema>

export default function DataDriftPage() {
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("same")
  const [isLoading, setIsLoading] = useState(false)

  const form = useForm<FormValues>({
    resolver: zodResolver(dataDriftSchema),
    defaultValues: {
      environment: "TeraData",
      dbName: "",
      tableName: "",
    },
  })

  const onSubmit = async (values: FormValues) => {
    try {
      setIsLoading(true)

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1500))

      toast({
        title: "Connection successful",
        description: "Data drift analysis has been initiated",
      })

      form.reset()
    } catch (error) {
      console.error("Connection check failed:", error)
      toast({
        variant: "destructive",
        title: "Connection failed",
        description: "There was an error checking connectivity",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <PageContainer>
      <PageHeader
        title="Data Drift"
        breadcrumbs={[{ label: "API Integration", href: "/api-integration" }, { label: "Data Drift" }]}
      />

      <RoleGuard requiredRole="DQ User">
        <Tabs defaultValue="same" onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="same">Same environment</TabsTrigger>
            <TabsTrigger value="different">Different environment</TabsTrigger>
          </TabsList>

          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
          >
            <Card>
              <CardContent className="p-6">
                <div className="max-w-2xl mx-auto">
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                      <FormField
                        control={form.control}
                        name="environment"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Environment</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select environment" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="TeraData">TeraData</SelectItem>
                                <SelectItem value="GCP">GCP</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="dbName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>
                              DB Name <span className="text-red-500">*</span>
                            </FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select DB Name" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="db1">Database 1</SelectItem>
                                <SelectItem value="db2">Database 2</SelectItem>
                                <SelectItem value="db3">Database 3</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="tableName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>
                              Table Name <span className="text-red-500">*</span>
                            </FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select Table Name" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="table1">Table 1</SelectItem>
                                <SelectItem value="table2">Table 2</SelectItem>
                                <SelectItem value="table3">Table 3</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {activeTab === "different" && (
                        <>
                          <FormField
                            control={form.control}
                            name="targetEnvironment"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Target Environment</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select Target Environment" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="TeraData">TeraData</SelectItem>
                                    <SelectItem value="GCP">GCP</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name="targetDbName"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Target DB Name</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select Target DB Name" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="db1">Database 1</SelectItem>
                                    <SelectItem value="db2">Database 2</SelectItem>
                                    <SelectItem value="db3">Database 3</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name="targetTableName"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Target Table Name</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select Target Table Name" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="table1">Table 1</SelectItem>
                                    <SelectItem value="table2">Table 2</SelectItem>
                                    <SelectItem value="table3">Table 3</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </>
                      )}

                      <div className="flex justify-center gap-4 pt-4">
                        <Button type="button" variant="outline" onClick={() => form.reset()}>
                          Reset
                        </Button>
                        <Button type="submit" disabled={isLoading}>
                          {isLoading ? "Checking..." : "Check For Connectivity"}
                        </Button>
                      </div>
                    </form>
                  </Form>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </Tabs>
      </RoleGuard>
    </PageContainer>
  )
}
