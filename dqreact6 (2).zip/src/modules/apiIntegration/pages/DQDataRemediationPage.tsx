"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { PageContainer, PageHeader } from "@/components/layout/PageContainer"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function DQDataRemediationPage() {
  const [environment, setEnvironment] = useState("")
  const [dbName, setDbName] = useState("")
  const [tableName, setTableName] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const handleCheckConnectivity = () => {
    setIsLoading(true)
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false)
      // Show success message
    }, 1500)
  }

  const handleReset = () => {
    setEnvironment("")
    setDbName("")
    setTableName("")
  }

  return (
    <PageContainer>
      <PageHeader
        title="DQ Data Remediation"
        breadcrumbs={[{ label: "API Integration", href: "/api-integration" }, { label: "DQ Data Remediation" }]}
      />

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
        <Card>
          <CardContent className="p-6">
            <div className="max-w-2xl mx-auto">
              <div className="space-y-6">
                <div className="space-y-2">
                  <label htmlFor="environment" className="block text-sm font-medium">
                    Environment
                  </label>
                  <Select value={environment} onValueChange={setEnvironment}>
                    <SelectTrigger id="environment">
                      <SelectValue placeholder="Select environment" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="td">TD</SelectItem>
                      <SelectItem value="gcp">GCP</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label htmlFor="dbName" className="block text-sm font-medium">
                    DB Name
                  </label>
                  <Select value={dbName} onValueChange={setDbName}>
                    <SelectTrigger id="dbName">
                      <SelectValue placeholder="Select DB Name" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="db1">Database 1</SelectItem>
                      <SelectItem value="db2">Database 2</SelectItem>
                      <SelectItem value="db3">Database 3</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label htmlFor="tableName" className="block text-sm font-medium">
                    Table Name
                  </label>
                  <Select value={tableName} onValueChange={setTableName}>
                    <SelectTrigger id="tableName">
                      <SelectValue placeholder="Select Table Name" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="table1">Table 1</SelectItem>
                      <SelectItem value="table2">Table 2</SelectItem>
                      <SelectItem value="table3">Table 3</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex justify-center gap-4 pt-4">
                  <Button variant="outline" onClick={handleReset}>
                    Reset
                  </Button>
                  <Button onClick={handleCheckConnectivity} disabled={isLoading}>
                    {isLoading ? "Checking..." : "Check For Connectivity"}
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </PageContainer>
  )
}
