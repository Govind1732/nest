import { AdminPage } from "@/modules/admin/pages/admin-page"
import { AppLayout } from "@/components/layout/app-layout"

export default function Admin() {
  return (
    <AppLayout>
      <AdminPage />
    </AppLayout>
  )
}
