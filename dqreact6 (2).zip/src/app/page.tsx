import { DQReportPage } from "@/modules/reports/pages/dq-report-page"
import { AppLayout } from "@/components/layout/app-layout"

export default function Home() {
  return (
    <AppLayout>
      <DQReportPage />
    </AppLayout>
  )
}
