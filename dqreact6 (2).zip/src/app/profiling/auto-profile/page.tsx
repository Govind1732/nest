import { AutoProfilePage } from "@/modules/profiling/pages/auto-profile-page"
import { AppLayout } from "@/components/layout/app-layout"

export default function AutoProfile() {
  return (
    <AppLayout>
      <AutoProfilePage />
    </AppLayout>
  )
}
