import { CustomProfilePage } from "@/modules/profiling/pages/custom-profile-page"
import { AppLayout } from "@/components/layout/app-layout"

export default function CustomProfile() {
  return (
    <AppLayout>
      <CustomProfilePage />
    </AppLayout>
  )
}
