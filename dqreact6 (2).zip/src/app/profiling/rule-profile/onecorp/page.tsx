import { RuleProfileOneCorpPage } from "@/modules/profiling/pages/rule-profile-onecorp-page"
import { AppLayout } from "@/components/layout/app-layout"

export default function RuleProfileOneCorp() {
  return (
    <AppLayout>
      <RuleProfileOneCorpPage />
    </AppLayout>
  )
}
