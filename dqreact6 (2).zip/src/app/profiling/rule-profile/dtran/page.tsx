import { RuleProfileDTRanPage } from "@/modules/profiling/pages/rule-profile-dtran-page"
import { AppLayout } from "@/components/layout/app-layout"

export default function RuleProfileDTRan() {
  return (
    <AppLayout>
      <RuleProfileDTRanPage />
    </AppLayout>
  )
}
