import { RuleProfileMLEPage } from "@/modules/profiling/pages/rule-profile-mle-page"
import { AppLayout } from "@/components/layout/app-layout"

export default function RuleProfileMLE() {
  return (
    <AppLayout>
      <RuleProfileMLEPage />
    </AppLayout>
  )
}
