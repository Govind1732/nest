import { DataProfilePage } from "@/modules/profiling/pages/data-profile-page"
import { AppLayout } from "@/components/layout/app-layout"

export default function DataProfile() {
  return (
    <AppLayout>
      <DataProfilePage />
    </AppLayout>
  )
}
