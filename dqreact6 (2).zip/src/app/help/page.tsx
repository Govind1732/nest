import { HelpPage } from "@/modules/help/pages/help-page"
import { AppLayout } from "@/components/layout/app-layout"

export default function Help() {
  return (
    <AppLayout>
      <HelpPage />
    </AppLayout>
  )
}
