import { MetadataGeneratorPage } from "@/modules/api-integration/pages/metadata-generator-page"
import { AppLayout } from "@/components/layout/app-layout"

export default function MetadataGenerator() {
  return (
    <AppLayout>
      <MetadataGeneratorPage />
    </AppLayout>
  )
}
