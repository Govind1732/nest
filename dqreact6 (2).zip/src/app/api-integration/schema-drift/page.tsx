import { SchemaDriftPage } from "@/modules/api-integration/pages/schema-drift-page"
import { AppLayout } from "@/components/layout/app-layout"

export default function SchemaDrift() {
  return (
    <AppLayout>
      <SchemaDriftPage />
    </AppLayout>
  )
}
