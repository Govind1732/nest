import { DQDataRemediationPage } from "@/modules/api-integration/pages/dq-data-remediation-page"
import { AppLayout } from "@/components/layout/app-layout"

export default function DQDataRemediation() {
  return (
    <AppLayout>
      <DQDataRemediationPage />
    </AppLayout>
  )
}
