import { DQMetricsAPIPage } from "@/modules/api-integration/pages/dq-metrics-api-page"
import { AppLayout } from "@/components/layout/app-layout"

export default function DQMetricsAPI() {
  return (
    <AppLayout>
      <DQMetricsAPIPage />
    </AppLayout>
  )
}
