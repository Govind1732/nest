import { ETLPipelineIntegrationPage } from "@/modules/api-integration/pages/etl-pipeline-integration-page"
import { AppLayout } from "@/components/layout/app-layout"

export default function ETLPipelineIntegration() {
  return (
    <AppLayout>
      <ETLPipelineIntegrationPage />
    </AppLayout>
  )
}
