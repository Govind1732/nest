import { DataDriftPage } from "@/modules/api-integration/pages/data-drift-page"
import { AppLayout } from "@/components/layout/app-layout"

export default function DataDrift() {
  return (
    <AppLayout>
      <DataDriftPage />
    </AppLayout>
  )
}
