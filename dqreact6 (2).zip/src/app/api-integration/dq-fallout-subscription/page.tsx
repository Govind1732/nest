import { DQFalloutSubscriptionPage } from "@/modules/api-integration/pages/dq-fallout-subscription-page"
import { AppLayout } from "@/components/layout/app-layout"

export default function DQFalloutSubscription() {
  return (
    <AppLayout>
      <DQFalloutSubscriptionPage />
    </AppLayout>
  )
}
