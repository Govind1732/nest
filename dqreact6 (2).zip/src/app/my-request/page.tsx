import { MyRequestPage } from "@/modules/my-requests/pages/my-request-page"
import { AppLayout } from "@/components/layout/app-layout"

export default function MyRequest() {
  return (
    <AppLayout>
      <MyRequestPage />
    </AppLayout>
  )
}
