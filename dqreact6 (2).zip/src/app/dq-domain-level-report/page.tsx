import { DQDomainLevelReportPage } from "@/modules/reports/pages/dq-domain-level-report-page"
import { AppLayout } from "@/components/layout/app-layout"

export default function DQDomainLevelReport() {
  return (
    <AppLayout>
      <DQDomainLevelReportPage />
    </AppLayout>
  )
}
