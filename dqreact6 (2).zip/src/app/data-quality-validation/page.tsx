import { DataQualityValidationPage } from "@/modules/profiling/pages/data-quality-validation-page"
import { AppLayout } from "@/components/layout/app-layout"

export default function DataQualityValidation() {
  return (
    <AppLayout>
      <DataQualityValidationPage />
    </AppLayout>
  )
}
