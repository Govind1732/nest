import type { Metadata } from "next"
import { PageContainer } from "@/components/layout/PageContainer"
import { DQReportPage } from "@/modules/reports/pages/DQReportPage"

export const metadata: Metadata = {
  title: "DQ Report - LensX",
  description: "Data Quality Reports Dashboard",
}

export default function DQReport() {
  return (
    <PageContainer>
      <DQReportPage />
    </PageContainer>
  )
}
