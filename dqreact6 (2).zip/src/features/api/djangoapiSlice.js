import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react"

export const djangoApi = createApi({
  reducerPath: "djangoApi",
  baseQuery: fetchBaseQuery({ baseUrl: "http://localhost:8000/" }),
  endpoints: (builder) => ({
    getPosts: builder.query({
      query: () => "posts/",
    }),
    getPost: builder.query({
      query: (id) => `posts/${id}/`,
    }),
    createPost: builder.mutation({
      query: (newPost) => ({
        url: "posts/",
        method: "POST",
        body: newPost,
      }),
    }),
    updatePost: builder.mutation({
      query: (updatedPost) => ({
        url: `posts/${updatedPost.id}/`,
        method: "PUT",
        body: updatedPost,
      }),
    }),
    deletePost: builder.mutation({
      query: (id) => ({
        url: `posts/${id}/`,
        method: "DELETE",
      }),
    }),
    getComments: builder.query({
      query: (postId) => `posts/${postId}/comments/`,
    }),
    createComment: builder.mutation({
      query: ({ postId, newComment }) => ({
        url: `posts/${postId}/comments/`,
        method: "POST",
        body: newComment,
      }),
    }),
    updateComment: builder.mutation({
      query: ({ postId, updatedComment }) => ({
        url: `posts/${postId}/comments/${updatedComment.id}/`,
        method: "PUT",
        body: updatedComment,
      }),
    }),
    deleteComment: builder.mutation({
      query: ({ postId, commentId }) => ({
        url: `posts/${postId}/comments/${commentId}/`,
        method: "DELETE",
      }),
    }),
  }),
})

export const {
  useGetPostsQuery,
  useGetPostQuery,
  useCreatePostMutation,
  useUpdatePostMutation,
  useDeletePostMutation,
  useGetCommentsQuery,
  useCreateCommentMutation,
  useUpdateCommentMutation,
  useDeleteCommentMutation,
} = djangoApi
