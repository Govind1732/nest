import { DQReportPage } from "@/modules/reports/pages/DQReportPage"

export default function Home() {
  return <DQReportPage />
}
