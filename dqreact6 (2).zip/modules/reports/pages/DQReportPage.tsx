"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { CheckCircle, Clock, Fingerprint, FileCheck, ShieldCheck, Layers } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ScoreCard } from "@/components/charts/ScoreCard"
import { CircleProgress } from "@/components/charts/CircleProgress"
import { BarChart } from "@/components/charts/BarChart"
import { LineChart } from "@/components/charts/LineChart"
import { DQReportFilters } from "@/modules/reports/components/DQReport/DQReportFilters"
import { FilteredReportTable } from "@/modules/reports/components/DQReport/FilteredReportTable"

// Mock data
const mockDQScores = [
  { name: "Conformity", value: 87, icon: FileCheck, color: "hsl(var(--chart-1))" },
  { name: "Completeness", value: 92, icon: CheckCircle, color: "hsl(var(--chart-2))" },
  { name: "Timeliness", value: 78, icon: Clock, color: "hsl(var(--chart-3))" },
  { name: "Uniqueness", value: 95, icon: Fingerprint, color: "hsl(var(--chart-4))" },
  { name: "Validity", value: 83, icon: ShieldCheck, color: "hsl(var(--chart-5))" },
  { name: "Consistency", value: 89, icon: Layers, color: "hsl(var(--primary))" },
]

const mockBarChartData = mockDQScores.map((item) => ({ name: item.name, value: item.value, color: item.color }))

const mockLineChartData = [
  { date: "2023-04-01", value: 82 },
  { date: "2023-04-02", value: 84 },
  { date: "2023-04-03", value: 85 },
  { date: "2023-04-04", value: 83 },
  { date: "2023-04-05", value: 86 },
  { date: "2023-04-06", value: 88 },
  { date: "2023-04-07", value: 87 },
]

export function DQReportPage() {
  const [activeTab, setActiveTab] = useState("overview")
  const enterpriseScore = Math.round(mockDQScores.reduce((acc, item) => acc + item.value, 0) / mockDQScores.length)

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4">
        <motion.h1
          className="text-3xl font-bold tracking-tight"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          Data Quality Report
        </motion.h1>
        <motion.p
          className="text-muted-foreground"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.5 }}
        >
          Monitor and analyze data quality metrics across your organization.
        </motion.p>
      </div>

      <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="details">Detailed Reports</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {mockDQScores.map((score, index) => (
              <motion.div
                key={score.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * index, duration: 0.5 }}
              >
                <ScoreCard title={score.name} value={score.value} icon={score.icon} color={score.color} />
              </motion.div>
            ))}
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Enterprise Score</CardTitle>
                <CardDescription>Overall data quality score</CardDescription>
              </CardHeader>
              <CardContent className="flex justify-center">
                <CircleProgress value={enterpriseScore} size={180} label="Enterprise Score" />
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>DQ Score Trend</CardTitle>
                <CardDescription>Last 7 days</CardDescription>
              </CardHeader>
              <CardContent>
                <LineChart data={mockLineChartData} height={180} width={400} className="mx-auto" />
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>DQ Score Comparison</CardTitle>
              <CardDescription>By quality dimension</CardDescription>
            </CardHeader>
            <CardContent>
              <BarChart data={mockBarChartData} height={250} className="w-full" />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="details">
          <Card>
            <CardHeader>
              <CardTitle>Detailed Reports</CardTitle>
              <CardDescription>Filter and view detailed data quality reports</CardDescription>
            </CardHeader>
            <CardContent>
              <DQReportFilters />
              <div className="mt-6">
                <FilteredReportTable />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
