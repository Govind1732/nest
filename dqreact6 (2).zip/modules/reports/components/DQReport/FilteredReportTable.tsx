"use client"

import { useState } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { MoreHorizontal, Download, Eye } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"

// Mock data
const mockReports = [
  {
    id: "1",
    name: "Customer Data",
    platform: "Teradata",
    lob: "Consumer",
    productType: "Wireless",
    score: 92,
    status: "Passed",
  },
  {
    id: "2",
    name: "Billing Records",
    platform: "GCP",
    lob: "Business",
    productType: "Wireline",
    score: 78,
    status: "Warning",
  },
  {
    id: "3",
    name: "Network Performance",
    platform: "AWS",
    lob: "Enterprise",
    productType: "IoT",
    score: 65,
    status: "Failed",
  },
  {
    id: "4",
    name: "Service Activation",
    platform: "Teradata",
    lob: "Consumer",
    productType: "Wireless",
    score: 88,
    status: "Passed",
  },
  {
    id: "5",
    name: "Device Inventory",
    platform: "GCP",
    lob: "Business",
    productType: "IoT",
    score: 81,
    status: "Passed",
  },
]

export function FilteredReportTable() {
  const [reports] = useState(mockReports)

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Passed":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
      case "Warning":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
      case "Failed":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300"
    }
  }

  const getScoreColor = (score: number) => {
    if (score >= 85) return "text-green-600 dark:text-green-400"
    if (score >= 70) return "text-yellow-600 dark:text-yellow-400"
    return "text-red-600 dark:text-red-400"
  }

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Report Name</TableHead>
            <TableHead>Platform</TableHead>
            <TableHead>LOB</TableHead>
            <TableHead>Product Type</TableHead>
            <TableHead>DQ Score</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {reports.map((report) => (
            <TableRow key={report.id}>
              <TableCell className="font-medium">{report.name}</TableCell>
              <TableCell>{report.platform}</TableCell>
              <TableCell>{report.lob}</TableCell>
              <TableCell>{report.productType}</TableCell>
              <TableCell className={cn("font-medium", getScoreColor(report.score))}>{report.score}%</TableCell>
              <TableCell>
                <Badge className={getStatusColor(report.status)} variant="outline">
                  {report.status}
                </Badge>
              </TableCell>
              <TableCell className="text-right">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon">
                      <MoreHorizontal className="h-4 w-4" />
                      <span className="sr-only">Open menu</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem className="flex items-center">
                      <Eye className="mr-2 h-4 w-4" />
                      View Details
                    </DropdownMenuItem>
                    <DropdownMenuItem className="flex items-center">
                      <Download className="mr-2 h-4 w-4" />
                      Download Report
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}
