"use client"

import type React from "react"

import { useState } from "react"
import { motion } from "framer-motion"
import { Search } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export function DQReportFilters() {
  const [platform, setPlatform] = useState("")
  const [lob, setLob] = useState("")
  const [productType, setProductType] = useState("")
  const [productArea, setProductArea] = useState("")
  const [searchTerm, setSearchTerm] = useState("")

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    // Implement search functionality
    console.log("Search with filters:", { platform, lob, productType, productArea, searchTerm })
  }

  const handleReset = () => {
    setPlatform("")
    setLob("")
    setProductType("")
    setProductArea("")
    setSearchTerm("")
  }

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
      <form onSubmit={handleSearch} className="space-y-4">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Select value={platform} onValueChange={setPlatform}>
            <SelectTrigger>
              <SelectValue placeholder="Platform" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Platforms</SelectItem>
              <SelectItem value="td">Teradata</SelectItem>
              <SelectItem value="gcp">Google Cloud Platform</SelectItem>
              <SelectItem value="aws">AWS</SelectItem>
            </SelectContent>
          </Select>

          <Select value={lob} onValueChange={setLob}>
            <SelectTrigger>
              <SelectValue placeholder="Line of Business" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All LOBs</SelectItem>
              <SelectItem value="consumer">Consumer</SelectItem>
              <SelectItem value="business">Business</SelectItem>
              <SelectItem value="enterprise">Enterprise</SelectItem>
            </SelectContent>
          </Select>

          <Select value={productType} onValueChange={setProductType}>
            <SelectTrigger>
              <SelectValue placeholder="Product Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="wireless">Wireless</SelectItem>
              <SelectItem value="wireline">Wireline</SelectItem>
              <SelectItem value="iot">IoT</SelectItem>
            </SelectContent>
          </Select>

          <Select value={productArea} onValueChange={setProductArea}>
            <SelectTrigger>
              <SelectValue placeholder="Product Area" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Areas</SelectItem>
              <SelectItem value="mobility">Mobility</SelectItem>
              <SelectItem value="broadband">Broadband</SelectItem>
              <SelectItem value="voice">Voice</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search by product name or business program..."
              className="pl-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <Button type="submit">Search</Button>
          <Button type="button" variant="outline" onClick={handleReset}>
            Reset
          </Button>
        </div>
      </form>
    </motion.div>
  )
}
