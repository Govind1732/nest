"use client"

import { useState } from "react"
import Link from "next/link"
import { Menu, HelpCircle } from "lucide-react"
import { motion } from "framer-motion"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ThemeToggle } from "@/components/ui/theme-toggle"

const NAVBAR_ITEMS = [
  { title: "Data Validation", href: "/data-quality-validation" },
  { title: "DQ Domain Level Report", href: "/dq-domain-level-report" },
  { title: "DQ Report", href: "/" },
  { title: "My Request", href: "/my-request" },
  { title: "Help", href: "/help" },
]

export function Navbar({
  toggleSidebar,
  isSidebarOpen,
}: {
  toggleSidebar: () => void
  isSidebarOpen: boolean
}) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  return (
    <motion.header
      className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60"
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.3 }}
      role="banner"
    >
      <div className="flex h-16 items-center justify-between px-4">
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleSidebar}
            className="mr-2"
            aria-label={isSidebarOpen ? "Close sidebar" : "Open sidebar"}
          >
            <Menu className="h-5 w-5" />
          </Button>
          <Link href="/" className="flex items-center gap-2" aria-label="Home">
            <motion.div
              className="h-8 w-8 bg-primary rounded-full flex items-center justify-center text-primary-foreground font-bold"
              whileHover={{ scale: 1.1 }}
              transition={{ type: "spring", stiffness: 400, damping: 10 }}
            >
              L
            </motion.div>
            <div className="flex flex-col">
              <span className="text-xl font-bold tracking-tight">LensX</span>
              <span className="text-xs text-muted-foreground">Data Quality & Validation</span>
            </div>
          </Link>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-6" aria-label="Main navigation">
          {NAVBAR_ITEMS.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "text-sm font-medium transition-colors hover:text-primary relative",
                location.pathname === item.href ? "text-primary" : "text-muted-foreground",
              )}
              aria-current={location.pathname === item.href ? "page" : undefined}
            >
              {item.title}
              {location.pathname === item.href && (
                <motion.div
                  className="absolute -bottom-[17px] left-0 right-0 h-[2px] bg-primary"
                  layoutId="navbar-indicator"
                  transition={{ type: "spring", stiffness: 300, damping: 30 }}
                />
              )}
            </Link>
          ))}
          <div className="flex items-center gap-2">
            <ThemeToggle />
            <Button variant="ghost" size="icon">
              <HelpCircle className="h-5 w-5" />
              <span className="sr-only">Help</span>
            </Button>
          </div>
        </nav>

        {/* Mobile Menu Button */}
        <div className="flex items-center gap-2 md:hidden">
          <ThemeToggle />
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            aria-expanded={isMobileMenuOpen}
            aria-controls="mobile-menu"
          >
            <Menu className="h-5 w-5" />
            <span className="sr-only">Menu</span>
          </Button>
        </div>

        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <motion.div
            id="mobile-menu"
            className="absolute top-16 left-0 right-0 bg-background border-b border-border/40 md:hidden"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            role="navigation"
            aria-label="Mobile navigation"
          >
            <nav className="container py-4 flex flex-col gap-2">
              {NAVBAR_ITEMS.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "px-4 py-2 text-sm font-medium rounded-md transition-colors hover:bg-muted",
                    location.pathname === item.href ? "bg-muted text-primary" : "text-muted-foreground",
                  )}
                  onClick={() => setIsMobileMenuOpen(false)}
                  aria-current={location.pathname === item.href ? "page" : undefined}
                >
                  {item.title}
                </Link>
              ))}
              <Link
                href="/help"
                className="px-4 py-2 text-sm font-medium rounded-md transition-colors hover:bg-muted flex items-center gap-2"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                <HelpCircle className="h-4 w-4" />
                <span>Help</span>
              </Link>
            </nav>
          </motion.div>
        )}
      </div>
    </motion.header>
  )
}
