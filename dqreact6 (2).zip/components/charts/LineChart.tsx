"use client"

import { useRef } from "react"
import { motion } from "framer-motion"
import { cn } from "@/lib/utils"

interface LineChartProps {
  data: Array<{ date: string; value: number }>
  height?: number
  width?: number
  className?: string
  lineColor?: string
  areaColor?: string
  showDots?: boolean
  showLabels?: boolean
}

export function LineChart({
  data,
  height = 200,
  width = 500,
  className,
  lineColor = "hsl(var(--primary))",
  areaColor = "hsl(var(--primary) / 0.2)",
  showDots = true,
  showLabels = true,
}: LineChartProps) {
  const svgRef = useRef<SVGSVGElement>(null)
  
  // Sort data by date
  const sortedData = [...data].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
  
  // Calculate min and max values
  const minValue = Math.min(...sortedData.map(d => d.value))
  const maxValue = Math.max(...sortedData.map(d => d.value))
  
  // Calculate points for the path
  const points = sortedData.map((d, i) => {
    const x = (i / (sortedData.length - 1)) * width
    const y = height - ((d.value - minValue) / (maxValue - minValue)) * height
    return { x, y, value: d.value, date: d.date }
  })
  
  // Create the path string
  const linePath = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ')
  
  // Create the area path (for fill)
  const areaPath = `${linePath} L ${width} ${height} L 0 ${height} Z`

  return (
    <div className={cn("relative", className)}>
      <svg ref={svgRef} width={width} height={height} className="overflow-visible">
        {/* Area fill */}
        <motion.path
            className="overflow-visible">
        {/* Area fill */}
        <motion.path
          d={areaPath}
          fill={areaColor}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1 }}
        />
        
        {/* Line */}
        <motion.path
          d={linePath}
          fill="none"
          stroke={lineColor}
          strokeWidth={2}
          strokeLinecap="round"
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 1.5, ease: "easeInOut" }}
        />
        
        {/* Dots */}
        {showDots && points.map((point, i) => (
          <motion.circle
            key={i}
            cx={point.x}
            cy={point.y}
            r={4}
            fill="white"
            stroke={lineColor}
            strokeWidth={2}
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 1.5 + (i * 0.1), duration: 0.3 }}
          />
        ))}
      </svg>
      
      {/* X-axis labels */}
      {showLabels && (
        <div className="flex justify-between mt-2">
          {sortedData.map((d, i) => (
            <div key={i} className="text-xs text-muted-foreground">
              {new Date(d.date).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
