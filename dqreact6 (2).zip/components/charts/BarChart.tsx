"use client"

import { useRef } from "react"
import { motion } from "framer-motion"
import { cn } from "@/lib/utils"

interface BarChartProps {
  data: Array<{ name: string; value: number; color?: string }>
  height?: number
  className?: string
  showLabels?: boolean
  showValues?: boolean
  maxValue?: number
}

export function BarChart({
  data,
  height = 200,
  className,
  showLabels = true,
  showValues = true,
  maxValue,
}: BarChartProps) {
  const chartRef = useRef<HTMLDivElement>(null)
  const calculatedMaxValue = maxValue || Math.max(...data.map((item) => item.value), 0)

  // Default colors from the theme
  const defaultColors = [
    "hsl(var(--chart-1))",
    "hsl(var(--chart-2))",
    "hsl(var(--chart-3))",
    "hsl(var(--chart-4))",
    "hsl(var(--chart-5))",
  ]

  return (
    <div className={cn("w-full", className)} ref={chartRef}>
      <div className="flex items-end h-full space-x-2">
        {data.map((item, index) => {
          const barHeight = (item.value / calculatedMaxValue) * height
          const barColor = item.color || defaultColors[index % defaultColors.length]

          return (
            <div key={item.name} className="flex flex-col items-center flex-1">
              <div className="w-full relative" style={{ height: `${height}px` }}>
                <motion.div
                  className="absolute bottom-0 w-full rounded-t-sm"
                  style={{ backgroundColor: barColor }}
                  initial={{ height: 0 }}
                  animate={{ height: `${barHeight}px` }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                />
              </div>
              {showValues && (
                <motion.div
                  className="text-xs font-medium mt-1"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.5 + index * 0.1 }}
                >
                  {item.value}%
                </motion.div>
              )}
              {showLabels && (
                <motion.div
                  className="text-xs text-muted-foreground mt-1 truncate w-full text-center"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.7 + index * 0.1 }}
                >
                  {item.name}
                </motion.div>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}
