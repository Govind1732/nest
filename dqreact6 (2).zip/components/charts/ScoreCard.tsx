"use client"

import type React from "react"

import { motion } from "framer-motion"
import { cn } from "@/lib/utils"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface ScoreCardProps {
  title: string
  value: number
  icon: React.ComponentType<{ className?: string }>
  color?: string
  className?: string
}

export function ScoreCard({ title, value, icon: Icon, color = "hsl(var(--primary))", className }: ScoreCardProps) {
  return (
    <Card className={cn("overflow-hidden", className)}>
      <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", stiffness: 400, damping: 10 }}
          style={{ color }}
        >
          <Icon className="h-4 w-4" />
        </motion.div>
      </CardHeader>
      <CardContent>
        <motion.div
          className="text-2xl font-bold"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          {value}%
        </motion.div>
        <div className="h-2 w-full bg-muted mt-2 rounded-full overflow-hidden">
          <motion.div
            className="h-full rounded-full"
            style={{ backgroundColor: color, width: `${value}%` }}
            initial={{ width: 0 }}
            animate={{ width: `${value}%` }}
            transition={{ delay: 0.5, duration: 1 }}
          />
        </div>
      </CardContent>
    </Card>
  )
}
