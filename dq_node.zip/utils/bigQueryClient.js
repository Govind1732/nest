const { BigQuery } = require('@google-cloud/bigquery');
const { GoogleAuth } = require('google-auth-library');
const path = require('path');
const dotenv = require('dotenv');
const fs = require('fs');
const axios = require('axios');
const base64 = require('base-64');

// Load environment variables from .env file
const env = process.env.NODE_ENV || 'local';
console.log(`Loading environment variables from .env.${env}`);
dotenv.config({ path: `.env.${env}` });

const isTokenExpired = (tokenPath) => {
    try {
        if (fs.existsSync(tokenPath)) {
            console.log("Token File Available");
            const tokenData = JSON.parse(fs.readFileSync(tokenPath, 'utf8'));
            const oldAccessToken = tokenData.access_token.split('.')[1];
            const paddedAccessToken = oldAccessToken.padEnd(oldAccessToken.length + (4 - oldAccessToken.length % 4) % 4, '=');
            const decodedToken = JSON.parse(base64.decode(paddedAccessToken));
            const authTime = decodedToken.auth_time;
            const expiresIn = decodedToken.expires_in;
            const currEpochTime = Math.floor(Date.now() / 1000);
            if (currEpochTime - authTime < expiresIn - 120) {
                console.log("Access Token is Valid");
                return false;
            } else {
                console.log("Access Token is Invalid");
            }
        }
        return true;
    } catch (error) {
        throw error;
    }
};

const exchangeAndSaveOidcTokenForJwt = async (clientId, clientSecret, tokenPath, url) => {
    console.log('Retrieving JWT from OIDC provider...');
    const response = await axios.post(url, null, {
        params: {
            grant_type: "client_credentials",
            client_id: clientId,
            client_secret: clientSecret,
            scope: "read"
        }
    });

    const token = response.data;
    console.log('Saving token...');

    if (fs.existsSync(tokenPath)) {
        fs.unlinkSync(tokenPath);
    }
    fs.writeFileSync(tokenPath, JSON.stringify(token));
};

let bigqueryClientInstance = null;

const bigQueryClient = async () => {
    const keyFilename = process.env.DQ_SA_JSON;
    const tokenPath = process.env.DQ_SA_TOKEN_JSON;
    const projectId = process.env.DQ_PROJECT_ID;
    const clientId = process.env.DQ_CLIENT_ID;
    const clientSecret = process.env.DQ_CLIENT_SECRET_KEY;
    const tokenUrl = process.env.TOKEN_URL;

    if (isTokenExpired(tokenPath)) {
        await exchangeAndSaveOidcTokenForJwt(clientId, clientSecret, tokenPath, tokenUrl);
        bigqueryClientInstance = null; // Reset the client instance to ensure a new client is created
    }

    if (!bigqueryClientInstance) {
        const config = JSON.parse(fs.readFileSync(keyFilename), 'utf8');

        process.env.GOOGLE_APPLICATION_CREDENTIALS = keyFilename;
        process.env.GOOGLE_CLOUD_PROJECT = projectId;

        const auth = new GoogleAuth({
            credentials: config,
            projectId: projectId,
            scopes: ['https://www.googleapis.com/auth/cloud-platform'],
        });

        const client = await auth.getClient();

        bigqueryClientInstance = new BigQuery({
            projectId: projectId,
            auth: client,
        });
    }

    return bigqueryClientInstance;
};


module.exports = bigQueryClient;