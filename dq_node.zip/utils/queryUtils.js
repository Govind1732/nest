const executeQuery = async (bigquery, query, params) => {
    const options = { query, params };
    const [rows] = await bigquery.query(options);
    return rows;
};

const timeTracker = {
    start: () => process.hrtime(),
    end: (start) => {
        const diff = process.hrtime(start);
        return (diff[0] * 1e9 + diff[1]) / 1e6; // Convert to milliseconds
    }
};

const getDateRange = () => ({
    startDate: 'DATE_SUB(CURRENT_DATE(), INTERVAL 7 DAY)',
    endDate: 'CURRENT_DATE()'
});

const baseJoin = `
    FROM \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.dqaas_auto_prfl_tbl_rpt\` t1
    JOIN \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.dqaas_label_taxonomy_mtd\` t2
    ON t2.table_name = t1.src_tbl`;

module.exports = {
    executeQuery,
    getDateRange,
    baseJoin,
    timeTracker
};