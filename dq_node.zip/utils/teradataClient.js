// require('dotenv').config();
// const teradatasql = require('teradatasql');

// let teradataConnection;

// const executeQuery = async (query) => {
//     return new Promise((resolve, reject) => {
//         // console.log('Executing query:', query);
//         if(teradataConnection){
//             teradataConnection.lib.jsgoFetchRow.async(
//                 teradataConnection.nId,
//                 query,
//                 null,
//                 0,
//                 0,
//                 0,
//                 (error, row) => {
//                     if (error) {
//                         console.error('Query execution error:', error);
//                         reject(error);
//                     } else {
//                         console.log('Query result row:', row);
//                         resolve(row);
//                     }
//                 }
//             );
//         } else {
//             initializeTeradataConnection() 
//         }
//     });
// };

// const initializeTeradataConnection = async () => {
//     if (!teradataConnection) {
//         try {
//             // Log environment variables to ensure they are being read correctly
//             // console.log('TERADATA_HOSTNAME:', process.env.TERADATA_HOSTNAME);
//             // console.log('TERADATA_USERNAME:', process.env.TERADATA_USERNAME);
//             // console.log('TERADATA_PASSWORD:', process.env.TERADATA_PASSWORD);
//             // console.log('TERADATA_DB_NAME:', process.env.TERADATA_DB_NAME);

//             // Validate data types
//             const config = {
//                 host: process.env.TERADATA_HOSTNAME,
//                 user: process.env.TERADATA_USERNAME,
//                 password: process.env.TERADATA_PASSWORD,
//                 database: process.env.TERADATA_DB_NAME
//             };

//             // console.log('Config:', config);

//             if (typeof config.host !== 'string' || typeof config.user !== 'string' || typeof config.password !== 'string' || typeof config.database !== 'string') {
//                 throw new Error('Invalid configuration: Expected string values for host, user, password, and database');
//             }

//             teradataConnection = await teradatasql.connect(config);
//             console.log('✅ Teradata connection established successfully');
//             // console.log(teradataConnection)
//             // const result = await executeQuery('SELECT 1 AS test_value');
//             // console.log('Query result:', result);
//         } catch (error) {
//             console.error('❌ Teradata connection failed:', error);
//             throw error;
//         }
//     }
//     return teradataConnection;
// };

// module.exports = {
//     initializeTeradataConnection,
//     getTeradataConnection: () => teradataConnection,
//     executeQuery
// };

// // require('dotenv').config();
// // const odbc = require('odbc');

// // let teradataConnection;

// // const initializeTeradataConnection = async () => {
// //     if (!teradataConnection) {
// //         try {
// //             const connectionString = `DSN=${process.env.TERADATA_DSN};UID=${process.env.TERADATA_USERNAME};PWD=${process.env.TERADATA_PASSWORD};DATABASE=${process.env.TERADATA_DB_NAME}`;
// //             teradataConnection = await odbc.connect(connectionString);
// //             console.log('✅ Teradata connection established successfully');
// //         } catch (error) {
// //             console.error('❌ Teradata connection failed:', error);
// //             process.exit(1);
// //         }
// //     }
// //     return teradataConnection;
// // };

// // const executeQuery = async (query, params = []) => {
// //     try {
// //         const connection = await initializeTeradataConnection();
// //         const result = await connection.query(query, params);
// //         return result;
// //     } catch (error) {
// //         console.error('❌ Error executing query:', error);
// //         throw error;
// //     }
// // };

// // module.exports = {
// //     initializeTeradataConnection,
// //     executeQuery
// // };