const express = require('express');
const router = express.Router();
const NodeCache = require('node-cache');
const bigqueryClient = require('../../utils/bigQueryClient');
const topBottomScoresController = require('../../controllers/DQDomainLevelReport/topBottomScoresController');

const cache = new NodeCache({
    stdTTL: 300,
    checkperiod: 60
});

router.post('/top_bottom_five_scores', async (req, res) => {
    try {
        const bigquery = await bigqueryClient();
        const { product_name, score_type, level_2_name } = req.body;

        const result = await topBottomScoresController.getPillarData(bigquery, product_name, score_type, level_2_name);

        res.json(result);
    } catch (error) {
        console.error('API Error:', error);
        res.status(500).json({
            error: error.message,
            stack: error.stack
        });
    }
});

module.exports = router;
