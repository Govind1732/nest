const express = require('express');
const router = express.Router();
const NodeCache = require('node-cache');
const bigqueryClient = require('../../utils/bigQueryClient');
const dynamicFilterController = require('../../controllers/DQReports/dynamicFilterController');

const cache = new NodeCache({
    stdTTL: 300,  // 5 minutes for full data
    checkperiod: 60 // Check for expired keys every 60 seconds
});

router.get('/dynamicFilter', async (req, res) => {
    const cacheKey = 'dynamicFilter';
    try {
        const cachedData = cache.get(cacheKey);
        if (cachedData) {
            return res.json(cachedData);
        }

        const bigquery = await bigqueryClient();
        const dynamicFilterData = await dynamicFilterController.getDistinctFilterValues(bigquery);

        cache.set(cacheKey, dynamicFilterData);
        res.json(dynamicFilterData);

    } catch (error) {
        console.error('API Error:', error);
        res.status(500).json({
            error: error.message,
            stack: error.stack
        });
    }
});

router.post('/dynamicFilter', async (req, res) => {
    try {
        const bigquery = await bigqueryClient();
        const filters = req.body;
        const filterdropdownData = await dynamicFilterController.getFilteredData(bigquery, filters);

        res.json({ filterdropdownData });
    } catch (error) {
        console.error('API Error:', error);
        res.status(500).json({
            error: error.message,
            stack: error.stack
        });
    }
});

module.exports = router;