const express = require('express');
const router = express.Router();
const NodeCache = require('node-cache');
const bigqueryClient = require('../../utils/bigQueryClient');
const DQTrendController = require('../../controllers/DQReports/dqTrendController');

const cache = new NodeCache({
    stdTTL: 300,
    checkperiod: 60
});

router.get('/trendData', async (req, res) => {
    try {
        const bigquery = await bigqueryClient();
        const data = await DQTrendController.getTrendData(bigquery);
        res.json(data);
    } catch (error) {
        console.error('API Error:', error);
        res.status(500).json({
            error: error.message,
            stack: error.stack
        });
    }
});

router.post('/trendData', async (req, res) => {
    try {
        const bigquery = await bigqueryClient();
        const data = await DQTrendController.postTrendData(bigquery, req.body);
        res.json(data);
    } catch (error) {
        console.error('API Error:', error);
        res.status(500).json({
            error: error.message,
            stack: error.stack
        });
    }
});

module.exports = router;
