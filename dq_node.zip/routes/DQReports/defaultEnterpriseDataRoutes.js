const express = require('express');
const router = express.Router();
const NodeCache = require('node-cache');
const bigqueryClient = require('../../utils/bigQueryClient');
const enterpriseController = require('../../controllers/DQReports/defaultEnterpriseDataController');

const cache = new NodeCache({
    stdTTL: 300,
    checkperiod: 60
});

router.get('/enterpriseData', async (req, res) => {
    try {
        const bigquery = await bigqueryClient();
        const filters = {
            run_date: enterpriseController.getDefaultRunDateFilter()
        };
        const data = await enterpriseController.getEnterpriseData(bigquery, filters);
        res.json(data);
    } catch (error) {
        console.error('API Error:', error);
        res.status(500).json({
            error: error.message,
            stack: error.stack
        });
    }
});

router.post('/enterpriseData', async (req, res) => {
    try {
        const bigquery = await bigqueryClient();
        const filters = enterpriseController.processFilters(req.body);
        const data = await enterpriseController.getEnterpriseData(bigquery, filters);
        res.json(data);
    } catch (error) {
        console.error('API Error:', error);
        res.status(500).json({
            error: error.message,
            stack: error.stack
        });
    }
});

module.exports = router;
