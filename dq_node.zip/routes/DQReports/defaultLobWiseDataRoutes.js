const express = require('express');
const router = express.Router();
const NodeCache = require('node-cache');
const bigqueryClient = require('../../utils/bigQueryClient');
const lobWiseController = require('../../controllers/DQReports/defaultLobWiseController');

const cache = new NodeCache({
    stdTTL: 300,
    checkperiod: 60
});

router.get('/lobWiseData', async (req, res) => {
    try {
        const bigquery = await bigqueryClient();
        const filters = {
            run_date: lobWiseController.getDefaultRunDateFilter()
        };
        const data = await lobWiseController.getLobWiseData(bigquery, filters);
        res.json(data);
    } catch (error) {
        console.error('API Error:', error);
        res.status(500).json({
            error: error.message,
            stack: error.stack
        });
    }
});

router.post('/lobWiseData', async (req, res) => {
    try {
        const bigquery = await bigqueryClient();
        const filters = lobWiseController.processFilters(req.body);
        const data = await lobWiseController.getLobWiseData(bigquery, filters);
        res.json(data);
    } catch (error) {
        console.error('API Error:', error);
        res.status(500).json({
            error: error.message,
            stack: error.stack
        });
    }
});

module.exports = router;
