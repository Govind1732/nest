const express = require('express');
const router = express.Router();
const NodeCache = require('node-cache');
const bigqueryClient = require('../../utils/bigQueryClient');
const bigqueryController = require('../../controllers/DQReports/tableWiseDataController');

const cache = new NodeCache({
    stdTTL: 300,  // 5 minutes for full data
    checkperiod: 60 // Check for expired keys every 60 seconds
});

router.post('/TableWiseData', async (req, res) => {
    try {
        const bigquery = await bigqueryClient();
        const tableData = await bigqueryController.getTableWiseData(req, res,bigquery);
        res.json(tableData);
    } catch (error) {
        console.error('API Error:', error);
        res.status(500).json({
            error: error.message,
            stack: error.stack
        });
    }
});

module.exports = router;
