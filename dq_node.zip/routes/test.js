const express = require("express");
const router = express.Router();

router.get("/test", function (req, res, next) {
  try {
    res.status(200).json({ message: "Its working" });
  } catch (error) {
    res.status(500).json({ error: "An error occurred" });
  }
});

module.exports = router;
