const express = require('express');
const router = express.Router();
const multer = require('multer');
const upload = multer();
const { multiRequestController } = require('../../controllers/DataQualityProfile/multiRequestController.js');

router.post('/multiRequestProfile', upload.any(), multiRequestController);

module.exports = router;