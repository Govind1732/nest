const express = require('express');
const router = express.Router();
const { validateTable } = require('../../../controllers/DataQualityProfile/ConnectivityCheckController.js');

router.post('/connectivityCheck', async (req, res) => {
    try {
        const { data_source, project_name, dbname, table_name } = req.body;
        const result = await validateTable(data_source, project_name, dbname, table_name);
        if (result === 1) {
            res.status(200).json({
                combination_exists: true,
                message: "Access is Available. Please input further details to insert a new record"
            });
        } else if (result === 0) {
            res.status(200).json({
                combination_exists: false,
                message: "Connectivity/Access does not exist."
            });
        }
        else {
            res.status(500).json({
                error: result
            });
        }
    } catch (error) {
        console.error('API Error:', error);
        res.status(500).json({
            error: error.message,
            stack: error.stack
        });
    }
});

module.exports = router;