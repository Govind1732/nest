const express = require('express');
const router = express.Router();
const NodeCache = require('node-cache');
const bigqueryClient = require('../../../utils/bigQueryClient');
// const bigqueryController = require('../../controllers/DQDomainLevelReport/getProductDataController');
const singleTableLoadGCPController = require('../../../controllers/DataQualityProfile/singleTableLoadGCPController');

const cache = new NodeCache({
    stdTTL: 300,  // 5 minutes for full data
    checkperiod: 60 // Check for expired keys every 60 seconds
});

router.get('/singleTableLoadGCP', async (req, res) => {
    const cacheKey = 'singleTableLoadGCP';
    try {
        const cachedData = cache.get(cacheKey);
        if (cachedData) {
            return res.json(cachedData);
        }
        const bigquery = await bigqueryClient();
        const singleTableLoadGCPData = await singleTableLoadGCPController.getProjectId(bigquery);

        cache.set(cacheKey, singleTableLoadGCPData);
        res.json(singleTableLoadGCPData);

    } catch (error) {
        console.error('API Error:', error);
        res.status(500).json({
            error: error.message,
            stack: error.stack
        });
    }
});

router.post('/singleTableLoadGCP', async (req, res) => {
    try {
        const bigquery = await bigqueryClient();
        // const db_name = req.body;
        const singleTableLoadGCPData = await singleTableLoadGCPController.getDBNameTables(bigquery, req.body);

        res.json(singleTableLoadGCPData);
    } catch (error) {
        console.error('API Error:', error);
        res.status(500).json({
            error: error.message,
            stack: error.stack
        });
    }
});

module.exports = router;