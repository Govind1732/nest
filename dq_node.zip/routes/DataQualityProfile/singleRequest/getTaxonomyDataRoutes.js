const express = require('express');
const router = express.Router();
const NodeCache = require('node-cache');
const bigqueryClient = require('../../../utils/bigQueryClient');
const { getTaxonomyData, getProductNames, insertTaxonomyData,updateTaxonomyData } = require('../../../controllers/DataQualityProfile/getTaxonomyDataController.js');

const cache = new NodeCache({
    stdTTL: 300,  // 5 minutes for full data
    checkperiod: 60 // Check for expired keys every 60 seconds
});

router.get('/getTaxonomyProductNames', async (req, res) => {
    const cacheKey = 'taxonomyProductNames';
    try {
        const cachedData = cache.get(cacheKey);
        if (cachedData) {
            return res.json(cachedData);
        }
        const bigquery = await bigqueryClient();
        const taxonomyProductNames = await getProductNames(bigquery);

        cache.set(cacheKey, taxonomyProductNames);
        res.json(taxonomyProductNames);

    } catch (error) {
        console.error('API Error:', error);
        res.status(500).json({
            error: error.message,
            stack: error.stack
        });
    }
});
router.post('/fetchTaxonomyData', async (req, res) => {
    try {
        const { product_name, project_name, db_name, table_name } = req.body;
        const result = await getTaxonomyData(product_name, project_name, db_name, table_name);
        res.status(200).json(result);
    } catch (error) {
        console.error('API Error:', error);
        res.status(500).json({
            error: error.message,
            stack: error.stack
        });
    }
});

// router.post('/upsertTaxonomyData', async (req, res) => {
//     try {
//         const data = req.body;
//         const result = await upsertTaxonomyData(data);
//         res.status(200).json({ message: `Upsert operation completed successfully. Data was ${result.status}.` });
//     } catch (error) {
//         console.error('API Error:', error);
//         res.status(500).json({
//             error: error.message,
//             stack: error.stack
//         });
//     }
// });
router.post('/insertTaxonomyData', async (req, res) => {
    try {
        const data = req.body;
        const result = await insertTaxonomyData(data);
        res.status(200).json({ message: `Insert operation completed successfully. Data was ${result.status}.` });
    } catch (error) {
        console.error('API Error:', error);
        res.status(500).json({
            error: error.message,
            stack: error.stack
        });
    }
});

router.post('/updateTaxonomyData', async (req, res) => {
    try {
        const data = req.body;
        const result = await updateTaxonomyData(data);
        res.status(200).json({ message: `Update operation completed successfully. Data was ${result.status}.` });
    } catch (error) {
        console.error('API Error:', error);
        res.status(500).json({
            error: error.message,
            stack: error.stack
        });
    }
});

module.exports = router;