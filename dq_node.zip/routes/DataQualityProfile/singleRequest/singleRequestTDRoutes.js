const express = require('express');
const router = express.Router();
const NodeCache = require('node-cache');
const singleTableLoadTDController = require('../../../controllers/DataQualityProfile/singleTableLoadTDController');

const cache = new NodeCache({
    stdTTL: 300,  // 5 minutes for full data
    checkperiod: 60 // Check for expired keys every 60 seconds
});

router.get('/singleTableLoadTD', async (req, res) => {
    const cacheKey = 'singleTableLoadTD';
    try {
        const cachedData = cache.get(cacheKey);
        if (cachedData) {
            return res.json(cachedData);
        }

        const singleDBLoadTDData = await singleTableLoadTDController.getDatabases();

        cache.set(cacheKey, singleDBLoadTDData);
        res.json(singleDBLoadTDData);

    } catch (error) {
        console.error('API Error:', error);
        res.status(500).json({
            error: error.message,
            stack: error.stack
        });
    }
});

router.post('/singleTableLoadTD', async (req, res) => {
    try {
        const db_name = req.body;
        const singleTableLoadTDData = await singleTableLoadTDController.getTables(db_name);

        res.json({ singleTableLoadTDData });
    } catch (error) {
        console.error('API Error:', error);
        res.status(500).json({
            error: error.message,
            stack: error.stack
        });
    }
});

module.exports = router;