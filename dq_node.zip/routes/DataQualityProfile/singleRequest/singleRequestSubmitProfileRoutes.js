const express = require('express');
const router = express.Router();
const { submitProfile } = require('../../../controllers/DataQualityProfile/submitProfileController.js');

router.post('/submitProfile', async (req, res) => {
    try {
        const { data_source, project_name, dbname, table_name, profile_data } = req.body;
        const result = await submitProfile(data_source, project_name, dbname, table_name, profile_data);
        res.status(200).json(result);
    } catch (error) {
        console.error('API Error:', error);
        res.status(500).json({
            error: error.message,
            stack: error.stack
        });
    }
});

module.exports = router;