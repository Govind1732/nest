const express = require('express');
const router = express.Router();
const NodeCache = require('node-cache');
const bigqueryClient = require('../../utils/bigQueryClient');
const SSUIReportDataController = require('../../controllers/Home/SSUIReportDataController');

const cache = new NodeCache({ stdTTL: 300, checkperiod: 60 });

router.get('/SSUIReportData', async (req, res) => {
    try {
        const bigquery = await bigqueryClient();
        const data = await SSUIReportDataController.getBusinessPrograms(bigquery, cache);
        res.json(data);
    } catch (error) {
        res.status(500).json({
            error: error.message,
            stack: error.stack
        });
    }
});

router.post('/SSUIReportData', async (req, res) => {
    try {
        const bigquery = await bigqueryClient();
        const data = await SSUIReportDataController.getMetricsData(bigquery, cache, req.body);
        res.json(data);
    } catch (error) {
        console.error('API Error:', error);
        res.status(500).json({
            error: error.message,
            stack: error.stack
        });
    }
});

module.exports = router;
