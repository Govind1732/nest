const express = require('express');
const router = express.Router();
const fs = require('fs').promises; // Use promise-based fs
const path = require('path');
const puppeteer = require('puppeteer');
const { PDFDocument } = require('pdf-lib');

require('dotenv').config();

const resultDir = process.env.RESULT_DIR_PATH;
const outputDir = process.env.PDF_RESULT_DIR_PATH;

console.log(`Result Directory: ${resultDir}`);
console.log(`Output Directory: ${outputDir}`);

async function processHtmlFile(browser, filePath, timeout = 60000) {
    const page = await browser.newPage();
    try {
        await page.setJavaScriptEnabled(true);
        await page.setCacheEnabled(false); // Reduce memory usage
        
        console.log(`Processing HTML file: ${filePath}`);
        const htmlContent = await fs.readFile(filePath, 'utf8');
        
        await page.setContent(htmlContent, {
            waitUntil: ['domcontentloaded', 'networkidle0'],
            timeout
        });

        await page.evaluate(() => new Promise(resolve => setTimeout(resolve, 5000)));
        await Promise.all([
            page.waitForSelector('#barChart', { timeout }).catch(() => {}),
            page.waitForSelector('#lineChart', { timeout }).catch(() => {})
        ]);

        const pdf = await page.pdf({
            width: '10in',
            height: '18in',
            landscape: true,
            printBackground: true,
        });

        return pdf;
    } finally {
        await page.close(); // Ensure page is always closed
    }
}

async function convertHtmlFolderToPdf(htmlFolderPath, outputPdfPath, mainHtmlFile) {
    const htmlFiles = await fs.readdir(htmlFolderPath);
    const filteredFiles = htmlFiles.filter(file => file.endsWith('.html'));

    if (filteredFiles.length === 0) {
        throw new Error('No HTML files found in the specified folder');
    }

    const browser = await puppeteer.launch({
        headless: true,
        args: ['--no-sandbox', '--disable-setuid-sandbox'],
    });

    try {
        const pdfPages = [];
        const mainHtmlFilePath = path.join(htmlFolderPath, mainHtmlFile);

        if (await fs.access(mainHtmlFilePath).then(() => true).catch(() => false)) {
            const mainPdf = await processHtmlFile(browser, mainHtmlFilePath);
            pdfPages.push(mainPdf);
        }

        const remainingFiles = filteredFiles.filter(file => file !== mainHtmlFile);
        const remainingPdfs = await Promise.all(
            remainingFiles.map(file => 
                processHtmlFile(browser, path.join(htmlFolderPath, file))
            )
        );
        
        pdfPages.push(...remainingPdfs);
        const mergedPdf = await mergePDFPages(pdfPages);
        await fs.writeFile(outputPdfPath, mergedPdf);

    } finally {
        await browser.close();
    }
}

async function mergePDFPages(pdfPages) {
    const mergedPdf = await PDFDocument.create();
    for (const pdfBytes of pdfPages) {
        const pdf = await PDFDocument.load(pdfBytes);
        const copiedPages = await mergedPdf.copyPages(pdf, pdf.getPageIndices());
        copiedPages.forEach(page => mergedPdf.addPage(page));
    }
    return mergedPdf.save();
}

// Add progress tracking
async function processFoldersInBatches(folders, resultDir, outputDir, batchSize) {
    const results = [];
    const totalFolders = folders.length;
    
    console.log(`Starting conversion of ${totalFolders} folders in batches of ${batchSize}`);
    
    for (let i = 0; i < folders.length; i += batchSize) {
        console.log(`Processing batch ${Math.floor(i / batchSize) + 1} of ${Math.ceil(totalFolders / batchSize)}`);
        const batch = folders.slice(i, i + batchSize);
        const batchResults = await Promise.all(batch.map(async folder => {
            const folderPath = path.join(resultDir, folder);
            const outputPdfPath = path.join(outputDir, `${folder}.pdf`);
            
            try {
                await convertHtmlFolderToPdf(folderPath, outputPdfPath, `${folder}.html`);
                return {
                    product_name: folder,
                    outputPdfPath,
                    status: 'success',
                    message: 'PDF generated successfully'
                };
            } catch (error) {
                console.error(`Error processing folder ${folderPath}:`, error);
                return {
                    product_name: folder,
                    outputPdfPath,
                    status: 'failure',
                    message: `Error generating PDF: ${error.message}`
                };
            }
        }));
        results.push(...batchResults);
    }
    return results;
}

// Add directory creation if not exists
router.get('/convert', async (req, res) => {
    try {
        await fs.mkdir(outputDir, { recursive: true });
        await fs.access(resultDir);
        const folders = (await fs.readdir(resultDir))
            .filter(async file => (await fs.stat(path.join(resultDir, file))).isDirectory());
        
        const results = await processFoldersInBatches(folders, resultDir, outputDir, 5);
        res.status(200).json(results);
    } catch (error) {
        console.error('Error generating PDFs:', error);
        res.status(500).json({ 
            error: 'An error occurred while generating the PDFs',
            details: error.message 
        });
    }
});

module.exports = router;