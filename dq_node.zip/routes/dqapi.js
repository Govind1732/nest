const express = require("express");
const router = express.Router();

router.get("/", function (req, res, next) {
  try {
    var headers = req.headers;
    res.status(200).json({ headers: headers });
  } catch (error) {
    res.status(500).json({ error: "An error occurred" });
  }
});

module.exports = router;
