const bigqueryClient = require('../utils/bigQueryClient');

const bigQueryMiddleware = async (req, res, next) => {
    try {
        if (!req.app.locals.bigquery) {
            console.log('🔄 Initializing BigQuery client...');
            const bigquery = await bigqueryClient();
            
            // Test query to verify connection
            const [rows] = await bigquery.query('SELECT 1');
            console.log('✅ BigQuery connection established and tested successfully');
            
            req.app.locals.bigquery = bigquery;
        }
        next();
    } catch (error) {
        console.error('❌ BigQuery connection failed:', error);
        res.status(500).json({ error: 'Database connection failed' });
    }
};

module.exports = bigQueryMiddleware;
