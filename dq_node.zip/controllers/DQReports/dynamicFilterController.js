const { executeQuery } = require('../../utils/queryUtils');

const getDistinctFilterValues = async (bigquery) => {
    const query = `
        SELECT 
            ARRAY_AGG(DISTINCT data_lob) AS data_lob_values,
            ARRAY_AGG(DISTINCT product_type) AS product_type_values,
            ARRAY_AGG(DISTINCT product_area) AS product_area_values,
            ARRAY_AGG(DISTINCT product_name) AS product_name_values,
            ARRAY_AGG(DISTINCT business_program) AS business_program_values,
            ARRAY_AGG(DISTINCT DATA_SRC) AS data_src_values
        FROM \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.AUTO_PRFL_RPT_SAMPLE_V\`
    `;

    const rows = await executeQuery(bigquery, query);
    const distinctValues = rows[0];

    const dropdownData = [
        {
            label: "LOB",
            name: "data_lob",
            options: distinctValues.data_lob_values || []
        },
        {
            label: "Product Type",
            name: "product_type",
            options: distinctValues.product_type_values || []
        },
        {
            label: "Product Area",
            name: "product_area",
            options: distinctValues.product_area_values || []
        },
        {
            label: "Product Name",
            name: "product_name",
            options: distinctValues.product_name_values || []
        },
        {
            label: "Business Program",
            name: "business_program_data",
            options: distinctValues.business_program_values || []
        },
        {
            label: "DATA_SRC",
            name: "data_src",
            options: distinctValues.data_src_values || []
        }
    ];

    return dropdownData;
};

const getFilteredData = async (bigquery, filters) => {
    let baseQuery = `
        SELECT DISTINCT DATA_SRC, data_lob, product_type, product_area, product_name, business_program
        FROM \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.AUTO_PRFL_RPT_SAMPLE_V\`
    `;

    const conditions = [];
    if (filters.DATA_SRC) conditions.push(`DATA_SRC='${filters.DATA_SRC}'`);
    if (filters.data_lob) conditions.push(`data_lob='${filters.data_lob}'`);
    if (filters.product_type) conditions.push(`product_type='${filters.product_type}'`);
    if (filters.product_area) conditions.push(`product_area='${filters.product_area}'`);
    if (filters.product_name) conditions.push(`product_name='${filters.product_name}'`);
    if (filters.business_program_data) conditions.push(`business_program='${filters.business_program_data}'`);

    if (conditions.length > 0) {
        baseQuery += " WHERE " + conditions.join(" AND ");
    }

    const rows = await executeQuery(bigquery, baseQuery);

    const dataLobs = [];
    const productTypes = [];
    const productAreas = [];
    const productNames = [];
    const businessPrograms = [];

    rows.forEach(row => {
        if (!dataLobs.includes(row.data_lob)) dataLobs.push(row.data_lob);
        if (!productTypes.includes(row.product_type)) productTypes.push(row.product_type);
        if (!productAreas.includes(row.product_area)) productAreas.push(row.product_area);
        if (!productNames.includes(row.product_name)) productNames.push(row.product_name);
        if (!businessPrograms.includes(row.business_program)) businessPrograms.push(row.business_program);
    });

    // const singleOrArray = (values) => (values.length === 1 ? values[0] : values);
    const singleOrArray = (values) => values;

    const filterdropdownData = [
        {
            label: "LOB",
            name: "data_lob",
            options: singleOrArray(dataLobs),
        },
        {
            label: "Product Type",
            name: "product_type",
            options: singleOrArray(productTypes),
        },
        {
            label: "Product Area",
            name: "product_area",
            options: singleOrArray(productAreas),
        },
        {
            label: "Product Name",
            name: "product_name",
            options: singleOrArray(productNames),
        },
        {
            label: "Business Program",
            name: "business_program_data",
            options: singleOrArray(businessPrograms),
        }
    ];

    return filterdropdownData;
};

module.exports = {
    getDistinctFilterValues,
    getFilteredData
};
