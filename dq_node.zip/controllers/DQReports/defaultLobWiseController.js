const { executeQuery } = require('../../utils/queryUtils');

const getDefaultRunDateFilter = () => {
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(endDate.getDate() - 7);
    return [startDate, endDate];
};

const buildQuery = (filters) => {
    const [startDate, endDate] = filters.run_date || getDefaultRunDateFilter();
    const startDateStr = startDate.toISOString().split('T')[0];
    const endDateStr = endDate.toISOString().split('T')[0];

    const conditions = [];
    if (filters.data_lob) conditions.push(`data_lob = '${filters.data_lob}'`);
    if (filters.product_area) conditions.push(`product_area = '${filters.product_area}'`);
    if (filters.product_name) conditions.push(`product_name = '${filters.product_name}'`);
    if (filters.business_program) conditions.push(`business_program = '${filters.business_program}'`);
    if (filters.DATA_SRC) conditions.push(`DATA_SRC = '${filters.DATA_SRC}'`);

    const conditionsStr = conditions.length > 0 ? conditions.join(" AND ") + " AND " : "";

    return `
        WITH assets AS (
            SELECT DISTINCT SRC_TBL, DATA_LOB, OVERALL_DQ_SCORE, run_date
            FROM \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.AUTO_PRFL_RPT_SAMPLE_V\`
            WHERE ${conditionsStr} run_date BETWEEN '${startDateStr}' AND '${endDateStr}'
        )
        SELECT DATA_LOB AS lob_name, COUNT(DISTINCT SRC_TBL) AS no_of_assets, ROUND(AVG(OVERALL_DQ_SCORE), 2) AS lob_dq_score
        FROM assets
        GROUP BY data_lob;
    `;
};

const processFilters = (data) => {
    const filters = {};

    if (data.run_date) {
        const endDate = new Date();
        let startDate;

        switch (data.run_date) {
            case 'yesterday':
                startDate = new Date();
                startDate.setDate(endDate.getDate() - 1);
                endDate.setDate(endDate.getDate() - 1);
                break;
            case 'last_7_days':
                startDate = new Date();
                startDate.setDate(endDate.getDate() - 7);
                break;
            case 'last_14_days':
                startDate = new Date();
                startDate.setDate(endDate.getDate() - 14);
                break;
            case 'last_30_days':
                startDate = new Date();
                startDate.setDate(endDate.getDate() - 30);
                break;
            case 'last_90_days':
                startDate = new Date();
                startDate.setDate(endDate.getDate() - 90);
                break;
        }
        filters.run_date = [startDate, endDate];
    }

    ['data_lob', 'product_area', 'product_name', 'business_program', 'DATA_SRC'].forEach(key => {
        if (data[key]) filters[key] = data[key];
    });

    return filters;
};

const getLobWiseData = async (bigquery, filters) => {
    const query = buildQuery(filters);
    const results = await executeQuery(bigquery, query);
    return results;
};

module.exports = {
    getDefaultRunDateFilter,
    getLobWiseData,
    processFilters
};
