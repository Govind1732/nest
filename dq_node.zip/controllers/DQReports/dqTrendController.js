const { executeQuery } = require('../../utils/queryUtils');

const getTrendData = async (bigquery) => {
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(endDate.getDate() - 6);

    const query = `
        WITH trendlinescores AS (
            SELECT SRC_TBL, run_date, OVERALL_DQ_SCORE 
            FROM \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.AUTO_PRFL_RPT_SAMPLE_V\`
            WHERE run_date BETWEEN '${startDate.toISOString().split('T')[0]}' AND '${endDate.toISOString().split('T')[0]}'
        ),
        DailyAvgTableScores AS (
            SELECT SRC_TBL, run_date, AVG(OVERALL_DQ_SCORE) AS AVG_TBL_SCORE 
            FROM trendlinescores 
            GROUP BY run_date, SRC_TBL
        ),
        AvgDailyScores AS (
            SELECT run_date, AVG(AVG_TBL_SCORE) AS FINALSCORE 
            FROM DailyAvgTableScores 
            GROUP BY run_date
        )
        SELECT run_date, ROUND(FINALSCORE, 2) AS trend_score 
        FROM AvgDailyScores 
        ORDER BY run_date
    `;

    const results = await executeQuery(bigquery, query);

    const trendLine = results.map(row => ({
        run_date: row.run_date.value,
        trend_score: row.trend_score.toString()
    }));

    return { trend_line: trendLine };
};

const postTrendData = async (bigquery, data) => {
    const endDate = new Date();
    let startDate = new Date();

    switch (data.run_date) {
        case 'yesterday':
            startDate.setDate(endDate.getDate() - 1);
            endDate.setDate(endDate.getDate() - 1);
            break;
        case 'last_7_days':
            startDate.setDate(endDate.getDate() - 6);
            break;
        case 'last_14_days':
            startDate.setDate(endDate.getDate() - 13);
            break;
        case 'last_30_days':
            startDate.setDate(endDate.getDate() - 29);
            break;
        case 'last_90_days':
            startDate.setDate(endDate.getDate() - 89);
            break;
        default:
            throw new Error("Invalid run date option");
    }

    const filters = [];
    if (data.data_lob) filters.push(`data_lob = '${data.data_lob}'`);
    if (data.product_type) filters.push(`product_type = '${data.product_type}'`);
    if (data.product_area) filters.push(`product_area = '${data.product_area}'`);
    if (data.product_name) filters.push(`product_name = '${data.product_name}'`);
    if (data.business_program) filters.push(`business_program = '${data.business_program}'`);
    if (data.DATA_SRC) filters.push(`DATA_SRC = '${data.DATA_SRC}'`);

    const query = `
        WITH trendlinescores AS (
            SELECT data_lob, product_type, product_area, product_name, business_program, SRC_TBL, run_date, OVERALL_DQ_SCORE 
            FROM \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.AUTO_PRFL_RPT_SAMPLE_V\`
            WHERE run_date BETWEEN '${startDate.toISOString().split('T')[0]}' AND '${endDate.toISOString().split('T')[0]}'
            ${filters.length ? ' AND ' + filters.join(' AND ') : ''}
        ),
        DailyAvgTableScores AS (
            SELECT SRC_TBL, run_date, AVG(OVERALL_DQ_SCORE) AS AVG_TBL_SCORE 
            FROM trendlinescores 
            GROUP BY run_date, SRC_TBL
        ),
        AvgDailyScores AS (
            SELECT run_date, AVG(AVG_TBL_SCORE) AS FINALSCORE 
            FROM DailyAvgTableScores 
            GROUP BY run_date
        )
        SELECT run_date, ROUND(FINALSCORE, 2) AS trend_score 
        FROM AvgDailyScores 
        ORDER BY run_date
    `;

    const results = await executeQuery(bigquery, query);

    const trendLine = results.map(row => ({
        run_date: row.run_date.value,
        trend_score: row.trend_score.toString()
    }));

    return { trend_line: trendLine };
};

module.exports = {
    getTrendData,
    postTrendData
};