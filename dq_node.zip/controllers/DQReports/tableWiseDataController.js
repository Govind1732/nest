const { executeQuery } = require('../../utils/queryUtils');

const buildQuery = (data) => {
    const data_lob = data.data_lob;
    const product_type = data.product_type;
    const product_area = data.product_area;
    const product_name = data.product_name;
    const business_program = data.business_program;
    const DATA_SRC = data.DATA_SRC;
    const run_date_filter = data.run_date || 'last_7_days';

    let startDate, endDate;
    const today = new Date();

    switch (run_date_filter) {
        case 'yesterday':
            startDate = new Date(today);
            startDate.setDate(today.getDate() - 1);
            endDate = startDate;
            break;
        case 'last_7_days':
            startDate = new Date(today);
            startDate.setDate(today.getDate() - 7);
            endDate = today;
            break;
        case 'last_14_days':
            startDate = new Date(today);
            startDate.setDate(today.getDate() - 14);
            endDate = today;
            break;
        case 'last_30_days':
            startDate = new Date(today);
            startDate.setDate(today.getDate() - 30);
            endDate = today;
            break;
        case 'last_90_days':
            startDate = new Date(today);
            startDate.setDate(today.getDate() - 90);
            endDate = today;
            break;
        default:
            startDate = new Date(run_date_filter);
            endDate = new Date(run_date_filter);
            break;
    }

    const startDateStr = startDate.toISOString().split('T')[0];
    const endDateStr = endDate.toISOString().split('T')[0];

    let query = `
        WITH max_run_date AS (
            SELECT SRC_TBL, MAX(run_date) AS max_run_date 
            FROM \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.AUTO_PRFL_RPT_SAMPLE_V\` 
            WHERE run_date BETWEEN '${startDateStr}' AND '${endDateStr}'`;

    if (data_lob) query += ` AND data_lob='${data_lob}'`;
    if (product_type) query += ` AND product_type='${product_type}'`;
    if (product_area) query += ` AND product_area='${product_area}'`;
    if (product_name) query += ` AND product_name='${product_name}'`;
    if (business_program) query += ` AND business_program='${business_program}'`;
    if (DATA_SRC) query += ` AND DATA_SRC='${DATA_SRC}'`;

    query += `
            GROUP BY SRC_TBL
        )
        SELECT DISTINCT dt.SRC_TBL, dt.product_type, mrd.max_run_date, dt.TBL_COMPLETENESS, dt.TBL_TIMELINESS, dt.TBL_UNIQUENESS, dt.tbl_conformity, dt.tbl_consistency, dt.tbl_integrity, dt.tbl_validity, dt.OVERALL_DQ_SCORE 
        FROM \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.AUTO_PRFL_RPT_SAMPLE_V\` dt 
        JOIN max_run_date mrd ON dt.SRC_TBL = mrd.SRC_TBL AND dt.run_date = mrd.max_run_date 
        WHERE dt.product_type = '${product_type}' 
        ORDER BY dt.SRC_TBL`;

    return query;
};

const getTableWiseData = async (req, res,bigquery) => {
    try {
        const data = req.body;
        const query = buildQuery(data);
        const results = await executeQuery(bigquery, query);
        return results;
    } catch (error) {
        console.error('API Error:', error);
        throw error;
    }
};

module.exports = {
    getTableWiseData
};
