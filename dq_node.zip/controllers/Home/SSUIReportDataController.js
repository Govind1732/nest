const getBusinessPrograms = async (bigquery, cache) => {
    const cacheKey = 'business_programs';
    const cachedData = cache.get(cacheKey);

    if (cachedData) {
        return cachedData;
    }

    const query = `select distinct(business_program) from \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.AUTO_PRFL_RPT_SAMPLE_V\``;
    const [rows] = await bigquery.query(query);
    const result = { business_programs: rows.map(row => row.business_program) };
    
    cache.set(cacheKey, result);
    return result;
};

const getMetricsData = async (bigquery, cache, data) => {
    const cacheKey = `metrics_${JSON.stringify(data)}`;
    const cachedData = cache.get(cacheKey);

    if (cachedData) {
        return cachedData;
    }

    const BUSINESS_PROGRAMS = data.BUSINESS_PROGRAM.map(bp => `'${bp}'`).join(',');

    const query = `WITH MAX_SCORES AS (
        SELECT business_program,SRC_TBL,run_date,
        MAX(TBL_COMPLETENESS) AS MAX_COMPLETENESS,
        MAX(TBL_UNIQUENESS) AS MAX_UNIQUENESS,
        MAX(TBL_TIMELINESS) AS MAX_TIMELINESS,
        MAX(tbl_conformity) AS MAX_conformity,
        MAX(tbl_validity) AS MAX_validity,
        MAX(tbl_integrity) AS MAX_integrity,
        MAX(tbl_consistency) AS MAX_consistency,
        MAX(OVERALL_DQ_SCORE) AS MAX_DQ_SCORE
        FROM \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.AUTO_PRFL_RPT_SAMPLE_V\`
        WHERE run_date BETWEEN DATE_SUB(CURRENT_DATE(), INTERVAL 7 DAY) AND CURRENT_DATE()
        GROUP BY business_program,SRC_TBL,run_date),
        AVG_TABLE_SCORES AS (
            SELECT business_program,
            AVG(MAX_COMPLETENESS) AS AVG_COMPLETENESS,
            AVG(MAX_UNIQUENESS) AS AVG_UNIQUENESS,
            AVG(MAX_TIMELINESS) AS AVG_TIMELINESS,
            AVG(MAX_conformity) AS AVG_confirmity,
            AVG(MAX_validity) AS AVG_validity,
            AVG(MAX_integrity) AS AVG_integrity,
            AVG(MAX_consistency) AS AVG_consistency,
            AVG(MAX_DQ_SCORE) AS AVG_DQ_SCORE
            FROM MAX_SCORES
            GROUP BY business_program
        ),
        AVG_PROGRAM_SCORES AS (
            SELECT business_program,
            AVG(AVG_COMPLETENESS) AS AVG_COMPLETENESS_PG,
            AVG(AVG_UNIQUENESS) AS AVG_UNIQUENESS_PG,
            AVG(AVG_TIMELINESS) AS AVG_TIMELINESS_PG,
            AVG(AVG_confirmity) AS AVG_confirmity_PG,
            AVG(AVG_validity) AS AVG_validity_PG,
            AVG(AVG_integrity) AS AVG_integrity_PG,
            AVG(AVG_consistency) AS AVG_consistency_PG,
            AVG(AVG_DQ_SCORE) AS AVG_DQ_SCORE_PG
            FROM AVG_TABLE_SCORES
            GROUP BY business_program
        )
        SELECT
            AVG(AVG_COMPLETENESS_PG) AS OVERALL_AVG_COMPLETENESS_PG,
            AVG(AVG_UNIQUENESS_PG) AS OVERALL_AVG_UNIQUENESS_PG,
            AVG(AVG_TIMELINESS_PG) AS OVERALL_AVG_TIMELINESS_PG,
            AVG(AVG_confirmity_PG) AS OVERALL_AVG_confirmity_PG,
            AVG(AVG_validity_PG) AS OVERALL_AVG_validity_PG,
            AVG(AVG_integrity_PG) AS OVERALL_AVG_integrity_PG,
            AVG(AVG_consistency_PG) AS OVERALL_AVG_consistency_PG,
            AVG(AVG_DQ_SCORE_PG) AS OVERALL_AVG_DQ_SCORE_PG
        FROM AVG_PROGRAM_SCORES
        WHERE business_program IN (${BUSINESS_PROGRAMS})`;

    const [rows] = await bigquery.query(query);
    cache.set(cacheKey, rows);
    return rows;
};

module.exports = {
    getBusinessPrograms,
    getMetricsData
};
