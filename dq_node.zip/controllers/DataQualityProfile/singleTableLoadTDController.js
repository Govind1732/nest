const { getTeradataConnection,executeQuery } = require('../../utils/teradataClient');

const getDatabases = async () => {
    try {
        const query = "SELECT DISTINCT DatabaseName FROM dbc.Columns";
        const connection = getTeradataConnection();
        const result=await executeQuery(query);
        console.log(result)
        // const result = await connection.query(query);
        // const databaseNames = result.map(row => row.DatabaseName);
        // return { DatabaseName: databaseNames };
    } catch (error) {
        console.error('Error fetching databases:', error);
        throw error;
    }
};

const getTables = async (DatabaseName) => {
    try {
        const query = `SELECT DISTINCT TableName FROM dbc.Columns WHERE DatabaseName = '${DatabaseName.trim()}'`;
        const connection = getTeradataConnection();
        const result=await executeQuery(query);
        console.log(result)
        // const result = await connection.query(query);
        // const tableNames = result.map(row => row.TableName);
        // return { TableName: tableNames };
    } catch (error) {
        console.error('Error fetching tables:', error);
        throw error;
    }
};

module.exports = {
    getDatabases,
    getTables
};