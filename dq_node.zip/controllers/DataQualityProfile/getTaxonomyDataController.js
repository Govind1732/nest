require('dotenv').config();
const bigQueryClient = require('../../utils/bigQueryClient');
// const { initializeTeradataConnection } = require('../../utils/teradataClient');

const getProductNames = async (bigquery) => {
    try {
        const query = `SELECT DISTINCT product_name FROM \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.dqaas_label_taxonomy_mtd\``;
        const [rows] = await bigquery.query(query);
        return rows.map(row => row.product_name);
    } catch (error) {
        console.error('Error fetching databases:', error);
        throw error;
    }
};

const getTaxonomyData = async (product_name,project_name,db_name,table_name) => {
    if (!product_name) throw new Error("Product name is required");

    let client, query;
    query = `SELECT DISTINCT * FROM \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.dqaas_label_taxonomy_mtd\` WHERE product_name = '${product_name}' AND db_name='${project_name}.${db_name}' AND table_name = '${table_name}'`;
    client = await bigQueryClient();
    try {
        const [rows] = await client.query(query);
        return rows;
    } catch (error) {
        console.error(`Error executing query in BigQuery: ${error.message}`);
        throw error;
    }
};

const insertTaxonomyData = async (data) => {
    const {
        db_name,
        product_name,
        l1_label,
        l2_label,
        l3_label,
        subject_area_1,
        subject_area_2,
        subject_area_3,
        subject_area_4,
        subject_area_5,
        subject_area_6,
        subject_area_7,
        subject_area_8,
        subject_area_9,
        subject_area_10,
        entry_made_ts,
        update_made_ts,
        table_name,
        table_id,
        email_distro,
        opsgenie_flag,
        email_alert_level
    } = data;

    const client = await bigQueryClient();

    // Fetch the current maximum taxonomy_id
    const maxTaxonomyIdQuery = `SELECT MAX(taxonomy_id) AS max_taxonomy_id FROM \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.dqaas_label_taxonomy_mtd\``;
    const [maxTaxonomyIdResult] = await client.query(maxTaxonomyIdQuery);
    const maxTaxonomyId = maxTaxonomyIdResult[0].max_taxonomy_id || 0;
    const newTaxonomyId = maxTaxonomyId + 1;

    const query = `
        INSERT INTO \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.dqaas_label_taxonomy_mtd\` (
            product_name,
            db_name,
            table_name,
            taxonomy_id,
            l1_label,
            l2_label,
            l3_label,
            subject_area_1,
            subject_area_2,
            subject_area_3,
            subject_area_4,
            subject_area_5,
            subject_area_6,
            subject_area_7,
            subject_area_8,
            subject_area_9,
            subject_area_10,
            entry_made_ts,
            update_made_ts,
            table_id,
            email_distro,
            opsgenie_flag,
            email_alert_level
        ) VALUES (
            '${product_name}',
            '${db_name}',
            '${table_name}',
            ${newTaxonomyId},
            ${l1_label !== null ? `'${l1_label}'` : 'NULL'},
            ${l2_label !== null ? `'${l2_label}'` : 'NULL'},
            ${l3_label !== null ? `'${l3_label}'` : 'NULL'},
            ${subject_area_1 !== null ? `'${subject_area_1}'` : 'NULL'},
            ${subject_area_2 !== null ? `'${subject_area_2}'` : 'NULL'},
            ${subject_area_3 !== null ? `'${subject_area_3}'` : 'NULL'},
            ${subject_area_4 !== null ? `'${subject_area_4}'` : 'NULL'},
            ${subject_area_5 !== null ? `'${subject_area_5}'` : 'NULL'},
            ${subject_area_6 !== null ? `'${subject_area_6}'` : 'NULL'},
            ${subject_area_7 !== null ? `'${subject_area_7}'` : 'NULL'},
            ${subject_area_8 !== null ? `'${subject_area_8}'` : 'NULL'},
            ${subject_area_9 !== null ? `'${subject_area_9}'` : 'NULL'},
            ${subject_area_10 !== null ? `'${subject_area_10}'` : 'NULL'},
            ${entry_made_ts ? `'${entry_made_ts}'` : 'NULL'},
            ${update_made_ts ? `'${update_made_ts}'` : 'NULL'},
            ${table_id !== null && table_id !== undefined ? table_id : 'NULL'},
            ${email_distro !== null ? `'${email_distro}'` : 'NULL'},
            ${opsgenie_flag !== null ? `'${opsgenie_flag}'` : 'NULL'},
            ${email_alert_level !== null ? `'${email_alert_level}'` : 'NULL'}
        )
    `;

    try {
        const [job] = await client.createQueryJob({ query });
        console.log(`Job ${job.id} started.`);
        await job.getQueryResults();
        return { status: 'inserted' };
    } catch (error) {
        console.error('Error executing insert operation in BigQuery:', error);
        throw error;
    }
};
const updateTaxonomyData = async (data) => {
    const {
        db_name,
        product_name,
        l1_label,
        l2_label,
        l3_label,
        subject_area_1,
        subject_area_2,
        subject_area_3,
        subject_area_4,
        subject_area_5,
        subject_area_6,
        subject_area_7,
        subject_area_8,
        subject_area_9,
        subject_area_10,
        entry_made_ts,
        update_made_ts,
        table_name,
        table_id,
        email_distro,
        opsgenie_flag,
        email_alert_level
    } = data;

    const client = await bigQueryClient();

    // Construct the SET clause dynamically based on provided fields
    const setClauses = [];
    if (l1_label !== undefined) setClauses.push(`l1_label = ${l1_label !== null ? `'${l1_label}'` : 'NULL'}`);
    if (l2_label !== undefined) setClauses.push(`l2_label = ${l2_label !== null ? `'${l2_label}'` : 'NULL'}`);
    if (l3_label !== undefined) setClauses.push(`l3_label = ${l3_label !== null ? `'${l3_label}'` : 'NULL'}`);
    if (subject_area_1 !== undefined) setClauses.push(`subject_area_1 = ${subject_area_1 !== null ? `'${subject_area_1}'` : 'NULL'}`);
    if (subject_area_2 !== undefined) setClauses.push(`subject_area_2 = ${subject_area_2 !== null ? `'${subject_area_2}'` : 'NULL'}`);
    if (subject_area_3 !== undefined) setClauses.push(`subject_area_3 = ${subject_area_3 !== null ? `'${subject_area_3}'` : 'NULL'}`);
    if (subject_area_4 !== undefined) setClauses.push(`subject_area_4 = ${subject_area_4 !== null ? `'${subject_area_4}'` : 'NULL'}`);
    if (subject_area_5 !== undefined) setClauses.push(`subject_area_5 = ${subject_area_5 !== null ? `'${subject_area_5}'` : 'NULL'}`);
    if (subject_area_6 !== undefined) setClauses.push(`subject_area_6 = ${subject_area_6 !== null ? `'${subject_area_6}'` : 'NULL'}`);
    if (subject_area_7 !== undefined) setClauses.push(`subject_area_7 = ${subject_area_7 !== null ? `'${subject_area_7}'` : 'NULL'}`);
    if (subject_area_8 !== undefined) setClauses.push(`subject_area_8 = ${subject_area_8 !== null ? `'${subject_area_8}'` : 'NULL'}`);
    if (subject_area_9 !== undefined) setClauses.push(`subject_area_9 = ${subject_area_9 !== null ? `'${subject_area_9}'` : 'NULL'}`);
    if (subject_area_10 !== undefined) setClauses.push(`subject_area_10 = ${subject_area_10 !== null ? `'${subject_area_10}'` : 'NULL'}`);
    if (entry_made_ts !== undefined) setClauses.push(`entry_made_ts = ${entry_made_ts ? `'${entry_made_ts}'` : 'NULL'}`);
    if (update_made_ts !== undefined) setClauses.push(`update_made_ts = ${update_made_ts ? `'${update_made_ts}'` : 'NULL'}`);
    if (table_id !== undefined) setClauses.push(`table_id = ${table_id !== null ? table_id : 'NULL'}`);
    if (email_distro !== undefined) setClauses.push(`email_distro = ${email_distro !== null ? `'${email_distro}'` : 'NULL'}`);
    if (opsgenie_flag !== undefined) setClauses.push(`opsgenie_flag = ${opsgenie_flag !== null ? `'${opsgenie_flag}'` : 'NULL'}`);
    if (email_alert_level !== undefined) setClauses.push(`email_alert_level = ${email_alert_level !== null ? `'${email_alert_level}'` : 'NULL'}`);

    // Join the set clauses with commas
    const setClause = setClauses.join(', ');

    const query = `
        UPDATE \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.dqaas_label_taxonomy_mtd\`
        SET ${setClause}
        WHERE
            product_name = '${product_name}' AND
            db_name = '${db_name}' AND
            table_name = '${table_name}'
    `;

    try {
        const [job] = await client.createQueryJob({ query });
        console.log(`Job ${job.id} started.`);
        await job.getQueryResults();
        return { status: 'updated' };
    } catch (error) {
        console.error('Error executing update operation in BigQuery:', error);
        throw error;
    }
};
// const upsertTaxonomyData = async (data) => {
//     const {
//         db_name,
//         product_name,
//         l1_label,
//         l2_label,
//         l3_label,
//         subject_area_1,
//         subject_area_2,
//         subject_area_3,
//         subject_area_4,
//         subject_area_5,
//         subject_area_6,
//         subject_area_7,
//         subject_area_8,
//         subject_area_9,
//         subject_area_10,
//         entry_made_ts,
//         update_made_ts,
//         table_name,
//         table_id,
//         email_distro,
//         opsgenie_flag,
//         email_alert_level
//     } = data;

//     const client = await bigQueryClient();

//     // Fetch the current maximum taxonomy_id
//     const maxTaxonomyIdQuery = `SELECT MAX(taxonomy_id) AS max_taxonomy_id FROM \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.dqaas_label_taxonomy_mtd\``;
//     const [maxTaxonomyIdResult] = await client.query(maxTaxonomyIdQuery);
//     const maxTaxonomyId = maxTaxonomyIdResult[0].max_taxonomy_id || 0;
//     const newTaxonomyId = maxTaxonomyId + 1;

//     const query = `
//         MERGE \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.dqaas_label_taxonomy_mtd\` T
//         USING (SELECT
//             '${product_name}' AS product_name,
//             '${db_name}' AS db_name,
//             '${table_name}' AS table_name,
//             ${newTaxonomyId} AS taxonomy_id,
//             '${l1_label}' AS l1_label,
//             '${l2_label}' AS l2_label,
//             '${l3_label}' AS l3_label,
//             '${subject_area_1}' AS subject_area_1,
//             '${subject_area_2}' AS subject_area_2,
//             '${subject_area_3}' AS subject_area_3,
//             '${subject_area_4}' AS subject_area_4,
//             '${subject_area_5}' AS subject_area_5,
//             '${subject_area_6}' AS subject_area_6,
//             '${subject_area_7}' AS subject_area_7,
//             '${subject_area_8}' AS subject_area_8,
//             '${subject_area_9}' AS subject_area_9,
//             '${subject_area_10}' AS subject_area_10,
//             '${entry_made_ts}' AS entry_made_ts,
//             '${update_made_ts}' AS update_made_ts,
//             '${table_id}' AS table_id,
//             '${email_distro}' AS email_distro,
//             '${opsgenie_flag}' AS opsgenie_flag,
//             '${email_alert_level}' AS email_alert_level
//         ) S
//         ON T.product_name = S.product_name AND T.db_name = S.db_name AND T.table_name = S.table_name
//         WHEN MATCHED THEN
//           UPDATE SET
//             T.l1_label = S.l1_label,
//             T.l2_label = S.l2_label,
//             T.l3_label = S.l3_label,
//             T.subject_area_1 = S.subject_area_1,
//             T.subject_area_2 = S.subject_area_2,
//             T.subject_area_3 = S.subject_area_3,
//             T.subject_area_4 = S.subject_area_4,
//             T.subject_area_5 = S.subject_area_5,
//             T.subject_area_6 = S.subject_area_6,
//             T.subject_area_7 = S.subject_area_7,
//             T.subject_area_8 = S.subject_area_8,
//             T.subject_area_9 = S.subject_area_9,
//             T.subject_area_10 = S.subject_area_10,
//             T.entry_made_ts = S.entry_made_ts,
//             T.update_made_ts = S.update_made_ts,
//             T.table_id = S.table_id,
//             T.email_distro = S.email_distro,
//             T.opsgenie_flag = S.opsgenie_flag,
//             T.email_alert_level = S.email_alert_level
//         WHEN NOT MATCHED THEN
//           INSERT (
//             product_name,
//             db_name,
//             table_name,
//             taxonomy_id,
//             l1_label,
//             l2_label,
//             l3_label,
//             subject_area_1,
//             subject_area_2,
//             subject_area_3,
//             subject_area_4,
//             subject_area_5,
//             subject_area_6,
//             subject_area_7,
//             subject_area_8,
//             subject_area_9,
//             subject_area_10,
//             entry_made_ts,
//             update_made_ts,
//             table_id,
//             email_distro,
//             opsgenie_flag,
//             email_alert_level
//           )
//           VALUES (
//             S.product_name,
//             S.db_name,
//             S.table_name,
//             S.taxonomy_id,
//             S.l1_label,
//             S.l2_label,
//             S.l3_label,
//             S.subject_area_1,
//             S.subject_area_2,
//             S.subject_area_3,
//             S.subject_area_4,
//             S.subject_area_5,
//             S.subject_area_6,
//             S.subject_area_7,
//             S.subject_area_8,
//             S.subject_area_9,
//             S.subject_area_10,
//             S.entry_made_ts,
//             S.update_made_ts,
//             S.table_id,
//             S.email_distro,
//             S.opsgenie_flag,
//             S.email_alert_level
//           )
//     `;

//     try {
//         const [job] = await client.createQueryJob({ query });
//         console.log(`Job ${job.id} started.`);
//         await job.getQueryResults();
//         const [metadata] = await job.getMetadata();
//         const status = metadata.statistics.query.dmlStats.insertedRowCount > 0 ? 'inserted' : 'updated';
//         return { status };
//     } catch (error) {
//         console.error('Error executing upsert operation in BigQuery:', error);
//         throw error;
//     }
// };
// if (data_source.toUpperCase() === "GCP") {
//     client = await bigQueryClient();
// query = `
//     SELECT 
//         *
//     FROM \`${project_name}.${dbname}.dqaas_meta\` T1
//     JOIN \`${project_name}.${dbname}.dqaas_taxonomy_meta\` T2
//     ON T1.product_name = T2.product_name AND T1.table_name = T2.table_name
//     WHERE T1.data_src = 'GCP'
//     AND T1.project_name = 'vz-it-np-izcv-dev-idmcdo-0'
//     AND T1.database_name = 'dga_dq_tbls'
//     AND T1.table_name = 'dqaas_mtd_connections'
//     LIMIT ${limit} OFFSET ${offset}
// `;

// select distinct * from vz-it-np-izcv-dev-idmcdo-0.dga_dq_tbls.dqaas_label_taxonomy_mtd where product_name = 'Force to Load'
// try {
//     const [rows] = await client.query(query);
//     return rows;
// } catch (error) {
//     console.error(`Error executing query in BigQuery: ${error.message}`);
//     throw error;
// }
// } else if (data_source.toUpperCase() === "TD") {
//     client = await initializeTeradataConnection();
//     query = `
//         SELECT 
//             T1.project_name,
//             T1.database_name,
//             T1.table_name,
//             T1.lob,
//             T1.product_name,
//             T1.product_type,
//             T1.product_area,
//             T2.l1_label,
//             T2.l2_label,
//             T2.l3_label,
//             T2.subject_area_1,
//             T2.subject_area_2
//         FROM ${dbname}.dqaas_meta T1
//         JOIN ${dbname}.dqaas_taxonomy_meta T2
//         ON T1.product_name = T2.product_name AND T1.data_sub_dmn = T2.l2_label
//         LIMIT ${limit} OFFSET ${offset}
//     `;
//     try {
//         const result = await client.execute(query);
//         return result;
//     } catch (error) {
//         console.error(`Error executing query in Teradata: ${error.message}`);
//         throw error;
//     }
// } else {
//     throw new Error('Invalid database type');
// }
// };

module.exports = {
    getTaxonomyData,
    getProductNames,
    insertTaxonomyData,
    updateTaxonomyData
};