const path = require('path');
const fs = require('fs');
const { exec } = require('child_process');
const { promisify } = require('util');

const execAsync = promisify(exec);

// Assuming you have environment variables or a configuration file for these paths
const METADATA_INPUT_PATH = process.env.METADATA_INPUT_PATH || 'C:/projects/apps/opt/application/smartdq/dqaas/mtd_input_csv';
const METADATA_VALIDATION_SCRIPT = process.env.METADATA_VALIDATION_SCRIPT || 'C:/projects/apps/opt/application/smartdq/dqaas/scripts/metadata_schema_validation_generic.py';
const CONDA_ENV_NAME = process.env.CONDA_ENV_NAME || 'smartdq-venv';
const CONDA_PROFILE_PATH = process.env.CONDA_PROFILE_PATH || '/apps/opt/application/miniconda3/etc/profile.d/conda.sh';

const multiRequestController = async (req, res) => {
    try {
        console.log("File submission started");
        const files = req.files;

        if (!files || files.length === 0) {
            return res.status(400).json({ status: 'error', message: 'No files uploaded' });
        }

        const inputPath = path.join(METADATA_INPUT_PATH);
        if (!fs.existsSync(inputPath)) {
            fs.mkdirSync(inputPath, { recursive: true });
        }

        for (const file of files) {
            console.log("File ::", file);
            // Validation Starts
            if (!file.originalname.endsWith('.csv')) {
                return res.status(400).json({ status: 'error', message: 'Invalid File Format' });
            }

            // const lines = file.buffer.toString('utf-8').split('\n');
            // const headerReceived = lines[0].toLowerCase();

            // if (headerReceived.trim() !== config.cols_chk.auto_header_chk.trim() && headerReceived.trim() !== config.cols_chk.rule_header_chk.trim()) {
            //     return res.status(400).json({ status: 'error', message: 'Invalid Column Format' });
            // }
            // Validation Ends
            const inputFile = path.join(inputPath, file.originalname);
            fs.writeFileSync(inputFile, file.buffer);
        }

        const scriptPath = path.join(METADATA_VALIDATION_SCRIPT);
        console.log("Script Path ::", scriptPath);
        const command = `source ${CONDA_PROFILE_PATH}; conda activate ${CONDA_ENV_NAME}; python ${scriptPath}`;
        const { stdout, stderr } = await execAsync(command);

        if (stderr && stderr.toLowerCase().includes('error')) {
            console.error('Script Error:', stderr);
            return res.status(500).json({ status: 'error', message: 'Script execution failed' });
        }

        if (stdout.includes('e-Mail Triggered Successfully to Recipients Address') || stderr.includes('e-Mail Triggered Successfully to Recipients Address')) {
            console.log('Script Output:', stdout);
            return res.json({ status: 'success', message: 'File uploaded you will receive the status through email shortly.' });
        } else {
            console.error('Script Output:', stdout);
            return res.status(500).json({ status: 'error', message: 'Script execution did not complete successfully' });
        }

    } catch (error) {
        console.error('API Error:', error);
        res.status(500).json({ status: 'error', message: 'Internal Server Error' });
    }
};

module.exports = {
    multiRequestController
};