require('dotenv').config();
const bigQueryClient = require('../../utils/bigQueryClient');
const { initializeTeradataConnection } = require('../../utils/teradataClient');

const submitProfile = async (data_source, project_name, dbname, table_name, profile_data) => {
    if (!table_name) throw new Error("Table name is required");

    let client, query;
    if (data_source.toUpperCase() === "GCP") {
        client = await bigQueryClient();
        query = `
            INSERT INTO \`${project_name}.${dbname}.${table_name}\` (project_name, database_name, table_name, lob, product_name, product_type, product_area, l1_label, l2_label, l3_label, subject_area_1, subject_area_2)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `;
        try {
            const [rows] = await client.query(query, [
                profile_data.project_name,
                profile_data.database_name,
                profile_data.table_name,
                profile_data.lob,
                profile_data.product_name,
                profile_data.product_type,
                profile_data.product_area,
                profile_data.l1_label,
                profile_data.l2_label,
                profile_data.l3_label,
                profile_data.subject_area_1,
                profile_data.subject_area_2
            ]);
            return { success: true, message: "Profile submitted successfully", data: rows };
        } catch (error) {
            console.error(`Error executing query in BigQuery: ${error.message}`);
            throw error;
        }
    } else if (data_source.toUpperCase() === "TD") {
        client = await initializeTeradataConnection();
        query = `
            INSERT INTO ${dbname}.${table_name} (project_name, database_name, table_name, lob, product_name, product_type, product_area, l1_label, l2_label, l3_label, subject_area_1, subject_area_2)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `;
        try {
            const result = await client.execute(query, [
                profile_data.project_name,
                profile_data.database_name,
                profile_data.table_name,
                profile_data.lob,
                profile_data.product_name,
                profile_data.product_type,
                profile_data.product_area,
                profile_data.l1_label,
                profile_data.l2_label,
                profile_data.l3_label,
                profile_data.subject_area_1,
                profile_data.subject_area_2
            ]);
            return { success: true, message: "Profile submitted successfully", data: result };
        } catch (error) {
            console.error(`Error executing query in Teradata: ${error.message}`);
            throw error;
        }
    } else {
        throw new Error('Invalid database type');
    }
};

module.exports = {
    submitProfile
};