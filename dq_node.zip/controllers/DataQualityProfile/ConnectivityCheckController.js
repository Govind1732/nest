const axios = require('axios');
const bigQueryClient = require('../../utils/bigQueryClient');
require('dotenv').config();

const validateTable = async (data_source, project_name, dbname, table_name) => {
    if (!table_name) throw new Error("Table name is required");

    try {
        if (data_source.toUpperCase() === "GCP") {
            const client = await bigQueryClient();
            const query = `SELECT COUNT(*) FROM \`${project_name}.${dbname}.${table_name}\``;
            const [rows] = await client.query(query);
            return rows.length > 0 ? 1 : 0;
        } else if (data_source.toUpperCase() === "TD") {
            const djangoApiUrl = `${process.env.DJANGO_BASE_URL}/ml_profiler_config_form/ui_fetch/`;
            const payload = {
                data_source,
                dbname,
                table_name
            };

            const response = await axios.post(djangoApiUrl, payload);
            console.log(response.data);
            return response.data;
        } else {
            throw new Error('Invalid database type');
        }
    } catch (error) {
        console.error(`Error accessing table in ${data_source}: ${error.message}`);
        return `Error accessing table in ${data_source}: ${error.message}`;
    }
};

module.exports = {
    validateTable
};