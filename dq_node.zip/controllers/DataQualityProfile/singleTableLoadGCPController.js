const getProjectId = async (bigquery) => {
    try {
        const query = `SELECT DISTINCT db_name FROM \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.dqaas_enterprise_mtd\``;
        const [rows] = await bigquery.query(query);
        const projectIds = Array.from(new Set(rows.filter(row => row?.db_name !== null).map(row => row.db_name.split('.')[0])));
        return projectIds;
    } catch (error) {
        console.error('Error fetching databases:', error);
        throw error;
    }
};

const getDBNameTables = async (bigquery, data) => {
    try {
        const { project_id, db_name, table_name } = data;
        let query;
        let results;

        if (project_id && !db_name) {
            query = `SELECT DISTINCT db_name FROM \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.dqaas_enterprise_mtd\` WHERE db_name LIKE '${project_id}.%'`;
            const [rows] = await bigquery.query(query);
            results = { db_names: rows.filter(row => row?.db_name !== null).map(row => row.db_name.split('.')[1]) };
        }

        if (project_id && db_name && !table_name) {
            query = `SELECT DISTINCT src_tbl FROM \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.dqaas_enterprise_mtd\` where db_name LIKE '${project_id}.${db_name}%'`;
            const [rows] = await bigquery.query(query);
            results = { table_names: rows.map(row => row.src_tbl) };
        }

        return results;
    } catch (error) {
        console.error('Error fetching tables:', error);
        throw error;
    }
};

module.exports = {
    getProjectId,
    getDBNameTables
};
