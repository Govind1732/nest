const { executeQuery, getDateRange } = require('../../utils/queryUtils');
const { getDistinctProductNames, productNamesList } = require('../../queries/sharedQueries');

const getL2Data = async (bigquery, productName) => {
    const { startDate, endDate } = getDateRange();
    const query = `
    WITH l2_metrics AS (
        SELECT
            t2.l2_label,
            FORMAT_DATE('%Y-%m-%d', DATE(t1.auto_prfl_run_dt)) AS run_date,
            CAST(AVG(t1.tbl_dq_score) AS FLOAT64) AS avg_score,
            CAST(AVG(t1.tbl_completeness) AS FLOAT64) AS completeness,
            CAST(AVG(t1.tbl_timeliness) AS FLOAT64) AS timeliness,
            CAST(AVG(t1.tbl_uniqueness) AS FLOAT64) AS uniqueness,
            CAST(AVG(t1.tbl_conformity) AS FLOAT64) AS conformity,
            CAST(AVG(t1.tbl_validity) AS FLOAT64) AS validity,
            CAST(AVG(t1.tbl_consistency) AS FLOAT64) AS consistency
        FROM \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.dqaas_auto_prfl_tbl_rpt\` t1
        JOIN \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.dqaas_label_taxonomy_mtd\` t2
        ON t1.src_tbl = t2.table_name
        WHERE t2.product_name = @productName
        AND DATE(t1.auto_prfl_run_dt) BETWEEN ${startDate} AND ${endDate}
        GROUP BY t2.l2_label, run_date
    ),
    column_metrics AS (
        SELECT DISTINCT
            t2.l2_label,
            t1.src_tbl,
            t1.col_name,
            CAST(AVG(t1.col_completeness) AS FLOAT64) AS col_completeness,
            CAST(AVG(t1.col_validity) AS FLOAT64) AS col_validity,
            CAST(AVG(t1.col_conformity) AS FLOAT64) AS col_conformity
        FROM \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.dqaas_auto_prfl_col_rpt\` AS t1
        JOIN \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.dqaas_label_taxonomy_mtd\` AS t2
        ON t2.table_name = t1.src_tbl
        WHERE t2.product_name = @productName
        AND DATE(t1.auto_prfl_run_dt) BETWEEN ${startDate} AND ${endDate}
        GROUP BY t2.l2_label, t1.src_tbl, t1.col_name
    ),
    table_metrics AS (
        SELECT
            t2.l2_label,
            t1.src_tbl,
            CAST(AVG(t1.tbl_dq_score) AS FLOAT64) AS tbl_score
        FROM \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.dqaas_auto_prfl_tbl_rpt\` AS t1
        JOIN \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.dqaas_label_taxonomy_mtd\` AS t2
        ON t2.table_name = t1.src_tbl
        WHERE t2.product_name = @productName
        AND DATE(t1.auto_prfl_run_dt) BETWEEN ${startDate} AND ${endDate}
        GROUP BY t2.l2_label, t1.src_tbl
    )
    SELECT
        m.l2_label,
        m.run_date,
        m.avg_score AS score,
        c.src_tbl,
        c.col_name,
        c.col_completeness,
        c.col_validity,
        c.col_conformity,
        t.tbl_score,
        m.completeness,
        m.timeliness,
        m.uniqueness,
        m.conformity,
        m.validity,
        m.consistency
    FROM l2_metrics m
    LEFT JOIN column_metrics c USING (l2_label)
    LEFT JOIN table_metrics t USING (l2_label, src_tbl)
    ORDER BY m.l2_label, m.run_date, c.src_tbl, c.col_name`;

    const rows = await executeQuery(bigquery, query, { productName });
    const level2Data = new Map();

    rows.forEach(row => {
        const l2Label = row.l2_label;
        if (!level2Data.has(l2Label)) {
            level2Data.set(l2Label, {
                level2_name: l2Label,
                dq_score: {
                    completeness: row.completeness,
                    timeliness: row.timeliness,
                    uniqueness: row.uniqueness,
                    conformity: row.conformity,
                    validity: row.validity,
                    consistency: row.consistency
                },
                barChart_allTables: new Map(),
                lineChart: {},
            });
        }

        const l2Data = level2Data.get(l2Label);
        
        if (row.run_date && row.score) {
            l2Data.lineChart[row.run_date] = row.score;
        }

        if (row.src_tbl) {
            const tableData = l2Data.barChart_allTables.get(row.src_tbl) || {
                tableName: row.src_tbl,
                overall_DQ_Score: row.tbl_score,
                columns: []
            };

            if (row.col_name && !tableData.columns.some(col => col.columnName === row.col_name)) {
                tableData.columns.push({
                    columnName: row.col_name,
                    Completeness: row.col_completeness,
                    Validity: row.col_validity,
                    Conformity: row.col_conformity
                });
            }

            l2Data.barChart_allTables.set(row.src_tbl, tableData);
        }
    });

    return Array.from(level2Data.values()).map(l2Data => ({
        ...l2Data,
        barChart_allTables: Array.from(l2Data.barChart_allTables.values())
    }));
};

const buildJson = async (bigquery) => {
    const productNames = productNamesList.length === 0 ? await getDistinctProductNames(bigquery) : productNamesList;
    return Promise.all(productNames.map(async productName => ({
        product_id: productName,
        level2_data: await getL2Data(bigquery, productName)
    })));
};

module.exports = { buildJson };
