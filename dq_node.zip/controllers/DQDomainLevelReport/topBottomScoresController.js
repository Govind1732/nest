const { executeQuery } = require('../../utils/queryUtils');
const { getDateRange } = require('../../utils/queryUtils');

const getPillarData = async (bigquery, product_name, score_type, level_2_name) => {
    const baseQuery = `
        SELECT t1.src_tbl, AVG(t1.${score_type}) as tbl_level_score 
        FROM \`${process.env.GOOGLE_CLOUD_PROJECT}.dga_dq_tbls.dqaas_auto_prfl_tbl_rpt\` as t1 
        JOIN \`${process.env.GOOGLE_CLOUD_PROJECT}.dga_dq_tbls.dqaas_label_taxonomy_mtd\` as t2
        ON t2.table_name = t1.src_tbl  
        WHERE t2.product_name = '${product_name}' 
        AND DATE(t1.auto_prfl_run_dt) BETWEEN ${getDateRange().startDate} AND ${getDateRange().endDate}
        ${level_2_name ? `AND t2.l2_label = '${level_2_name}'` : ''}`;

    const top5Query = `${baseQuery} GROUP BY t1.src_tbl ORDER BY tbl_level_score DESC LIMIT 5`;
    const bottom5Query = `${baseQuery} GROUP BY t1.src_tbl ORDER BY tbl_level_score ASC LIMIT 5`;

    const [topTables, bottomTables] = await Promise.all([
        executeQuery(bigquery, top5Query),
        executeQuery(bigquery, bottom5Query)
    ]);

    const result = {
        product_name,
        top_5_scores: topTables.map(row => ({
            table: row.src_tbl,
            score: row.tbl_level_score
        })),
        bottom_5_scores: bottomTables.map(row => ({
            table: row.src_tbl,
            score: row.tbl_level_score
        }))
    };

    if (level_2_name) {
        result.level_2_name = level_2_name;
    }

    return result;
};

module.exports = {
    getPillarData
};