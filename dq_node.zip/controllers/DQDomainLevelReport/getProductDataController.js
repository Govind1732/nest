// const { executeQuery, getDateRange } = require('../../utils/queryUtils');
// const { getDistinctProductNames, productNamesList } = require('../../queries/sharedQueries');

// const getProductData = async (bigquery, productName) => {
//     const { startDate, endDate } = getDateRange();
//     const query = `
//     WITH product_metrics AS (
//         SELECT
//             t2.product_name,
//             FORMAT_DATE('%Y-%m-%d', DATE(t1.auto_prfl_run_dt)) AS run_date,
//             CAST(AVG(t1.tbl_dq_score) AS FLOAT64) AS avg_score,
//             CAST(AVG(t1.tbl_completeness) AS FLOAT64) AS completeness,
//             CAST(AVG(t1.tbl_timeliness) AS FLOAT64) AS timeliness,
//             CAST(AVG(t1.tbl_uniqueness) AS FLOAT64) AS uniqueness,
//             CAST(AVG(t1.tbl_conformity) AS FLOAT64) AS conformity,
//             CAST(AVG(t1.tbl_validity) AS FLOAT64) AS validity,
//             CAST(AVG(t1.tbl_consistency) AS FLOAT64) AS consistency
//         FROM \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.dqaas_auto_prfl_tbl_rpt\` t1
//         JOIN \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.dqaas_label_taxonomy_mtd\` t2
//         ON t1.src_tbl = t2.table_name
//         WHERE t2.product_name = @productName
//         AND DATE(t1.auto_prfl_run_dt) BETWEEN ${startDate} AND ${endDate}
//         GROUP BY t2.product_name, run_date
//     ),
//     column_metrics AS (
//         SELECT DISTINCT
//             t2.product_name,
//             t1.src_tbl,
//             t1.col_name,
//             CAST(AVG(t1.col_completeness) AS FLOAT64) AS col_completeness,
//             CAST(AVG(t1.col_validity) AS FLOAT64) AS col_validity,
//             CAST(AVG(t1.col_conformity) AS FLOAT64) AS col_conformity
//         FROM \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.dqaas_auto_prfl_col_rpt\` AS t1
//         JOIN \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.dqaas_label_taxonomy_mtd\` AS t2
//         ON t2.table_name = t1.src_tbl
//         WHERE t2.product_name = @productName
//         AND DATE(t1.auto_prfl_run_dt) BETWEEN ${startDate} AND ${endDate}
//         GROUP BY t2.product_name, t1.src_tbl, t1.col_name
//     ),
//     table_metrics AS (
//         SELECT
//             t2.product_name,
//             t1.src_tbl,
//             CAST(AVG(t1.tbl_dq_score) AS FLOAT64) AS tbl_score
//         FROM \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.dqaas_auto_prfl_tbl_rpt\` AS t1
//         JOIN \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.dqaas_label_taxonomy_mtd\` AS t2
//         ON t2.table_name = t1.src_tbl
//         WHERE t2.product_name = @productName
//         AND DATE(t1.auto_prfl_run_dt) BETWEEN ${startDate} AND ${endDate}
//         GROUP BY t2.product_name, t1.src_tbl
//     )
//     SELECT
//         m.product_name,
//         m.run_date,
//         m.avg_score AS score,
//         c.src_tbl,
//         c.col_name,
//         c.col_completeness,
//         c.col_validity,
//         c.col_conformity,
//         t.tbl_score,
//         m.completeness,
//         m.timeliness,
//         m.uniqueness,
//         m.conformity,
//         m.validity,
//         m.consistency
//     FROM product_metrics m
//     LEFT JOIN column_metrics c USING (product_name)
//     LEFT JOIN table_metrics t USING (product_name, src_tbl)
//     ORDER BY m.run_date, c.src_tbl, c.col_name`;

//     const rows = await executeQuery(bigquery, query, { productName });
    
//     const productData = {
//         product_id: productName,
//         dq_score: {
//             completeness: rows[0]?.completeness || 0,
//             timeliness: rows[0]?.timeliness || 0,
//             uniqueness: rows[0]?.uniqueness || 0,
//             conformity: rows[0]?.conformity || 0,
//             validity: rows[0]?.validity || 0,
//             consistency: rows[0]?.consistency || 0
//         },
//         barChart_allTables: new Map(),
//         lineChart: {},
//     };

//     rows.forEach(row => {
//         if (row.run_date && row.score) {
//             productData.lineChart[row.run_date] = row.score;
//         }

//         if (row.src_tbl) {
//             const tableData = productData.barChart_allTables.get(row.src_tbl) || {
//                 tableName: row.src_tbl,
//                 overall_DQ_Score: row.tbl_score,
//                 columns: []
//             };

//             if (row.col_name && !tableData.columns.some(col => col.columnName === row.col_name)) {
//                 tableData.columns.push({
//                     columnName: row.col_name,
//                     Completeness: row.col_completeness,
//                     Validity: row.col_validity,
//                     Conformity: row.col_conformity
//                 });
//             }

//             productData.barChart_allTables.set(row.src_tbl, tableData);
//         }
//     });

//     return {
//         ...productData,
//         barChart_allTables: Array.from(productData.barChart_allTables.values())
//     };
// };

// const buildJson = async (bigquery) => {
//     const productNames = productNamesList.length === 0 ? await getDistinctProductNames(bigquery) : productNamesList;
//     return Promise.all(productNames.map(productName => getProductData(bigquery, productName)));
// };

// module.exports = { buildJson };
const { executeQuery, getDateRange } = require('../../utils/queryUtils');
const { getDistinctProductNames,productNamesList } = require('../../queries/sharedQueries');

const fetchData = async (bigquery, productName) => {
    const { startDate, endDate } = getDateRange();
    const columnWiseQuery = `
        SELECT 
            t2.product_name, 
            t2.l2_label, 
            t1.src_tbl, 
            t1.col_name,
            AVG(t1.col_completeness) AS col_completeness,
            AVG(t1.col_validity) AS col_validity,
            AVG(t1.col_conformity) AS col_conformity
        FROM \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.dqaas_auto_prfl_col_rpt\` AS t1
        JOIN \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.dqaas_label_taxonomy_mtd\` AS t2
        ON t2.table_name = t1.src_tbl
        WHERE t2.product_name = @productName
        AND DATE(t1.auto_prfl_run_dt) BETWEEN ${startDate} AND ${endDate}
        GROUP BY t2.product_name, t2.l2_label, t1.src_tbl, t1.col_name
        ORDER BY t1.col_name`;

    const tableWiseScoreQuery = `
        WITH filtered_data AS (
            SELECT 
                t1.src_tbl, 
                AVG(t1.tbl_dq_score) AS tbl_level_score, 
                DATE(t1.auto_prfl_run_dt) AS run_date
            FROM \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.dqaas_auto_prfl_tbl_rpt\` AS t1
            JOIN \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.dqaas_label_taxonomy_mtd\` AS t2
            ON t2.table_name = t1.src_tbl
            WHERE t2.product_name = @productName
            AND DATE(t1.auto_prfl_run_dt) BETWEEN ${startDate} AND ${endDate}
            GROUP BY t1.src_tbl, t1.auto_prfl_run_dt
        ), ranked_data AS (
            SELECT src_tbl, AVG(tbl_level_score) AS tbl_score
            FROM filtered_data
            GROUP BY src_tbl
        )
        SELECT src_tbl AS table, tbl_score
        FROM ranked_data
        ORDER BY tbl_score ASC`;

    const [colRows, tblRows] = await Promise.all([
        executeQuery(bigquery, columnWiseQuery, { productName }),
        executeQuery(bigquery, tableWiseScoreQuery, { productName })
    ]);

    const groupedData = new Map();

    colRows.forEach(row => {
        const tablename = row.src_tbl;
        const columnInfo = {
            columnName: row.col_name,
            Completeness: row.col_completeness,
            Validity: row.col_validity,
            Conformity: row.col_conformity
        };
        if (!groupedData.has(tablename)) {
            groupedData.set(tablename, {
                overall_DQ_Score: null,
                columns: []
            });
        }
        groupedData.get(tablename).columns.push(columnInfo);
    });

    tblRows.forEach(row => {
        const tablename = row.table;
        const overallscore = row.tbl_score;
        if (groupedData.has(tablename)) {
            groupedData.get(tablename).overall_DQ_Score = overallscore;
        }
    });

    const bargraphData = Array.from(groupedData.entries()).map(([tablename, data]) => ({
        tableName: tablename,
        overall_DQ_Score: data.overall_DQ_Score,
        columns: data.columns
    }));
    return bargraphData;
};

const getScorecardData = async (bigquery, productName) => {
    const { startDate, endDate } = getDateRange();
    const scorecardQuery = `
        WITH filtered_data AS (
            SELECT t1.src_tbl, t1.tbl_completeness, t1.tbl_timeliness, t1.tbl_uniqueness, t1.tbl_conformity, t1.tbl_validity, t1.tbl_consistency, DATE(t1.auto_prfl_run_dt) AS run_date 
            FROM \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.dqaas_auto_prfl_tbl_rpt\` AS t1 
            JOIN \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.dqaas_label_taxonomy_mtd\` AS t2 
            ON t2.table_name = t1.src_tbl 
            WHERE t2.product_name = @productName 
            AND DATE(t1.auto_prfl_run_dt) BETWEEN ${startDate} AND ${endDate}
        ), table_avg AS (
            SELECT src_tbl, AVG(tbl_completeness) AS avg_tbl_completeness, AVG(tbl_timeliness) AS avg_tbl_timeliness, AVG(tbl_uniqueness) AS avg_tbl_uniqueness, AVG(tbl_conformity) AS avg_tbl_conformity, AVG(tbl_validity) AS avg_tbl_validity, AVG(tbl_consistency) AS avg_tbl_consistency 
            FROM filtered_data 
            GROUP BY src_tbl
        ) 
        SELECT AVG(avg_tbl_completeness) AS completeness, AVG(avg_tbl_timeliness) AS timeliness, AVG(avg_tbl_uniqueness) AS uniqueness, AVG(avg_tbl_conformity) AS conformity, AVG(avg_tbl_validity) AS validity, AVG(avg_tbl_consistency) AS consistency 
        FROM table_avg`;

    const rows = await executeQuery(bigquery, scorecardQuery, { productName });
    return rows[0];
};

const getLinechartData = async (bigquery, productName) => {
    const { startDate, endDate } = getDateRange();
    const query = `
        SELECT 
            FORMAT_DATE('%Y-%m-%d', DATE(t1.auto_prfl_run_dt)) as run_date,
            AVG(t1.tbl_dq_score) as score
        FROM \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.dqaas_auto_prfl_tbl_rpt\` t1
        JOIN \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.dqaas_label_taxonomy_mtd\` t2
        ON t1.src_tbl = t2.table_name
        WHERE t2.product_name = @productName
        AND DATE(t1.auto_prfl_run_dt) BETWEEN ${startDate} AND ${endDate}
        GROUP BY run_date
        ORDER BY run_date`;

    const rows = await executeQuery(bigquery, query, { productName });
    return rows.reduce((acc, row) => ({ ...acc, [row.run_date]: row.score }), {});
};

const buildJson = async (bigquery) => {
    const productNames = productNamesList.length === 0 ? await getDistinctProductNames(bigquery) : productNamesList;
    const allProductsData = await Promise.all(productNames.map(async (productName) => {
        const [scorecardData, linechartData, bargraphData, level2Info] = await Promise.all([
            getScorecardData(bigquery, productName),
            getLinechartData(bigquery, productName),
            fetchData(bigquery, productName),
        ]);

        return {
            product_id: productName,
            dq_score: scorecardData,
            barChart_allTables: bargraphData,
            lineChart: linechartData
        };
    }));
    return allProductsData;
};

module.exports = { buildJson };