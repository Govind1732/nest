const express = require('express');
const bigqueryClient = require('./utils/bigQueryClient');
// const { initializeTeradataConnection } = require('./utils/teradataClient');
const dotenv = require('dotenv');
const cookieParser = require('cookie-parser');
const session = require('express-session');
const cors = require('cors');
dotenv.config();
const app = express();
app.use(express.json());

const allowedOrigins = [
  'http://localhost:5173',
  'https://dqaas-dev.ebiz.verizon.com',
  'https://dqaas-prod.verizon.com',
  'https://tdcldizcva002.ebiz.verizon.com:8889',
  'https://tdclpizcva002.verizon.com:8443',
  'https://dqaas.verizon.com'
];

const corsOptions = {
  origin: function (origin, callback) {
    if (allowedOrigins.indexOf(origin) !== -1 || !origin) {
      callback(null, true);
    } else {
      callback(new Error('Not allowed by CORS'));
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
  exposedHeaders: ['Location']
};
app.use(cors(corsOptions));
app.options('*', cors(corsOptions));

// Middleware to parse URL-encoded payloads
app.use(express.urlencoded({ extended: true }));

// Middleware to parse cookies
app.use(cookieParser());

// Middleware to manage user sessions
app.use(session({
  secret: 'defaultSecret', // Secret for signing the session ID cookie
  saveUninitialized: false, // Do not create a session until something is stored
  resave: false, // Do not save the session if it wasn't modified
  cookie: { secure: false } // Session cookie configuration (secure should be true in production with HTTPS)
}));

// Initialize BigQuery and Teradata connections when app starts
(async () => {
  try {
    const bigquery = await bigqueryClient();
    console.log('✅ BigQuery connection established successfully');

    // Test query to verify connection
    const [rows] = await bigquery.query('SELECT 1');
    console.log('✅ BigQuery test query executed successfully');
  } catch (error) {
    console.error('❌ BigQuery connection failed:', error);
    process.exit(1);
  }

  // try {
  //   const teradataConnection = await initializeTeradataConnection();
  //   // executeQuery('SELECT 1 AS test_value')
  //   // Test query to verify Teradata connection
  //   //   const result = await teradataConnection.lib.jsgoCreateRows.async(
  //   //     teradataConnection.nId,
  //   //     'SELECT 1 AS test_value',
  //   //     null,
  //   //     0,
  //   //     0,
  //   //     0,
  //   //     0,
  //   //     (rows) => {
  //   //         const numericValue = Number(rows);
  //   //         console.log('✅ Teradata test query executed successfully:', numericValue);
  //   //     }
  //   // );
  // } catch (error) {
  //   console.error('❌ Teradata connection failed:', error);
  //   process.exit(1);
  // }
})();

// Routes
const routes = [
  './routes/dqapi',
  './routes/html2pdf',
  './routes/test',
  './routes/DQDomainLevelReport/getProductDataRoutes.js',
  './routes/DQDomainLevelReport/level2DataRoutes.js',
  './routes/DQDomainLevelReport/topBottomScoresRoutes.js',
  './routes/DQReports/dynamicFilterRoutes.js',
  './routes/DQReports/defaultEnterpriseDataRoutes.js',
  './routes/DQReports/defaultLobWiseDataRoutes.js',
  './routes/DQReports/dqTrendRoutes.js',
  './routes/DQReports/productTypeWiseDataRoutes.js',
  './routes/DQReports/tableWiseDataRoutes.js',
  './routes/Home/SSUIReportDataRoutes.js',
  './routes/DataQualityProfile/multiRequestRoutes.js',
  // './routes/DataQualityProfile/singleRequest/singleRequestTDRoutes.js',
  './routes/DataQualityProfile/singleRequest/singleRequestGCPRoutes.js',
  // './routes/DataQualityProfile/singleRequest/ConnectivityCheckRoutes.js',
  './routes/DataQualityProfile/singleRequest/getTaxonomyDataRoutes.js',
  './routes/DataQualityProfile/singleRequest/singleRequestSubmitProfileRoutes.js',
];

routes.forEach(route => app.use('/dqapi', require(route)));

// Add a catch-all route to log unhandled requests
app.use((req, res, next) => {
  console.log(`Unhandled request: ${req.method} ${req.url}`);
  next();
});

module.exports = app;