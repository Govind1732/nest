const { executeQuery } = require('../utils/queryUtils');

let productNamesList = [];
// const getDistinctProductNames = async (bigquery) => {
//     const query = `SELECT DISTINCT product_name FROM \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.dqaas_label_taxonomy_mtd\``;
//     const rows = await executeQuery(bigquery, query);
//     return rows.map(row => row.product_name);
// };
const getDistinctProductNames = async (bigquery) => {
    const query = `SELECT DISTINCT product_name FROM \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.dqaas_label_taxonomy_mtd\``;
    const rows = await executeQuery(bigquery, query);
    productNamesList = rows.map(row => row.product_name);
    // console.log('productNamesList', productNamesList);
    return productNamesList;
};

const getDistinctL2Label = async (bigquery, productName) => {
    const query = `
        SELECT DISTINCT l2_label
        FROM \`${process.env.DQ_PROJECT_ID}.dga_dq_tbls.dqaas_label_taxonomy_mtd\`
        WHERE product_name = @productName
        AND l2_label IS NOT NULL`;
    const rows = await executeQuery(bigquery, query, { productName });
    return rows.map(row => row.l2_label);
};

module.exports = {
    getDistinctProductNames,
    getDistinctL2Label,
    productNamesList
};