"use client"

import React from "react"
import { Outlet } from "react-router-dom"
import Header from "./Header"
import Sidebar from "./Sidebar"
import { useTheme } from "../../hooks/useTheme"
import { cn } from "../../utils/cn"

const Layout = () => {
  const { theme } = useTheme()
  const [sidebarExpanded, setSidebarExpanded] = React.useState(() => {
    const savedState = localStorage.getItem("sidebarExpanded")
    return savedState !== null ? savedState === "true" : true
  })

  React.useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 768) {
        setSidebarExpanded(false)
      }
    }

    window.addEventListener("resize", handleResize)
    handleResize()

    return () => {
      window.removeEventListener("resize", handleResize)
    }
  }, [])

  return (
    <div className={cn("min-h-screen bg-gray-50 dark:bg-gray-900", theme)}>
      <Header />
      <Sidebar expanded={sidebarExpanded} onToggle={() => setSidebarExpanded((prev) => !prev)} />
      <main className={cn("pt-16 transition-all duration-300", sidebarExpanded ? "md:pl-64" : "md:pl-16")}>
        <div className="container mx-auto p-4 md:p-6">
          <Outlet />
        </div>
      </main>
    </div>
  )
}

export default React.memo(Layout)

