"use client"

import { useState, useCallback, useRef } from "react"
import { Link, NavLink } from "react-router-dom"
import { useOnClickOutside } from "../../hooks/useOnClickOutside"
import { useTheme } from "../../hooks/useTheme"
import { useMediaQuery } from "../../hooks/useMediaQuery"

// Main navigation links
const navLinks = [
  { name: "Data Validation", path: "/data-validation" },
  { name: "DQ Domain Level Report", path: "/reports/dq-domain-level-report" },
  { name: "DQ Report", path: "/reports/dq-reports" },
  { name: "My Request", path: "/my-request" },
  { name: "Help", path: "/help" },
]

const Navbar = ({ toggleSidebar }) => {
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const userMenuRef = useRef(null);
  const notificationsRef = useRef(null);
  const mobileMenuRef = useRef(null);
  const { theme, toggleTheme } = useTheme();
  const isMobile = useMediaQuery('(max-width: 768px)');

  // Close menus when clicking outside
  useOnClickOutside(userMenuRef, () => setUserMenuOpen(false));
  useOnClickOutside(notificationsRef, () => setNotificationsOpen(false));
  useOnClickOutside(mobileMenuRef, () => setMobileMenuOpen(false));

  // Toggle user menu
  const toggleUserMenu = useCallback((e) => {
    e.stopPropagation();
    setUserMenuOpen(prev => !prev);
    setNotificationsOpen(false);
    setMobileMenuOpen(false);
  }, []);

  // Toggle notifications
  const toggleNotifications = useCallback((e) => {
    e.stopPropagation();
    setNotificationsOpen(prev => !prev);
    setUserMenuOpen(false);
    setMobileMenuOpen(false);
  }, []);

  // Toggle mobile menu
  const toggleMobileMenu = useCallback((e) => {
    e.stopPropagation();
    setMobileMenuOpen(prev => !prev);
    setUserMenuOpen(false);
    setNotificationsOpen(false);
  }, []);

  return (
    <header className="z-30 py-2 md:py-4 bg-white shadow-sm dark:bg-gray-800 transition-colors duration-300">
      <div className="container flex items-center justify-between h-full px-4 mx-auto">
        {/* Left side - Hamburger and Logo */}
        <div className="flex items-center">
          <button
            className="p-1 mr-3 -ml-1 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:ring-opacity-50"
            onClick={toggleSidebar}
            aria-label="Toggle Sidebar"
          >
            <svg className="w-6 h-6" aria-hidden="true" fill="currentColor" viewBox="0 0 20 20">
              <path
                fillRule="evenodd"
                d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 15a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z"
                clipRule="evenodd"
              ></path>
            </svg>
          </button>
          
          <Link to="/" className="flex items-center">
            <span className="ml-2 text-xl font-bold text-primary dark:text-white">
              LensX
            </span>
          </Link>
        </div>
        
        {/* Center - Navigation Links - Hidden on mobile */}
        <nav className="hidden md:flex items-center space-x-1 lg:space-x-4">
          {navLinks.map((link, index) => (
            <NavLink 
              key={index}
              to={link.path} 
              className={({ isActive }) => 
                `px-3 py-2 text-sm font-medium rounded-md transition-colors duration-150 ${
                  isActive 
                    ? 'bg-primary-50 text-primary dark:bg-gray-700 dark:text-primary-light' 
                    : 'text-gray-700 hover:text-primary dark:text-gray-200 dark:hover:text-primary-light hover:bg-gray-100 dark:hover:bg-gray-700'
                }`
              }
            >
              {link.name}
            </NavLink>
          ))}
        </nav>
        
        {/* Right side - Actions */}
        <div className="flex items-center space-x-2 md:space-x-4">
          {/* Mobile menu button - Visible only on mobile */}
          <div className="relative md:hidden" ref={mobileMenuRef}>
            <button
              onClick={toggleMobileMenu}
              className="p-2 text-gray-500 rounded-md hover:text-primary focus:outline-none focus:ring-2 focus:ring-primary focus:ring-opacity-50"
              aria-label="Mobile Menu"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16"></path>
              </svg>
            </button>
            
            {/* Mobile dropdown menu */}
            {mobileMenuOpen && (
              <div className="absolute right-0 w-56 mt-2 origin-top-right bg-white divide-y divide-gray-100 rounded-md shadow-lg dark:bg-gray-800 dark:divide-gray-700 ring-1 ring-black ring-opacity-5 focus:outline-none">
                <div className="py-1">
                  {navLinks.map((link, index) => (
                    <NavLink
                      key={index}
                      to={link.path}
                      className={({ isActive }) => 
                        `block px-4 py-2 text-sm ${
                          isActive 
                            ? 'bg-primary-50 text-primary dark:bg-gray-700 dark:text-primary-light' 
                            : 'text-gray-700 hover:bg-gray-100 hover:text-primary dark:text-gray-200 dark:hover:bg-gray-700 dark:hover:text-primary-light'
                        }`
                      }
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      {link.name}
                    </NavLink>
                  ))}
                </div>
              </div>
            )}
          </div>
          
          {/* Theme toggle */}
          <button
            onClick={toggleTheme}
            className="p-2 text-gray-500 rounded-md hover:text-primary focus:outline-none focus:ring-2 focus:ring-primary focus:ring-opacity-50"
            aria-label="Toggle color mode"
          >
            {theme === 'dark' ? (
              <svg className="w-5 h-5" aria-hidden="true" fill="currentColor" viewBox="0 0 20 20">
                <path
                  fillRule="evenodd"
                  d="M10 2a1 1 0 011 1v1a1 1 0 11-2 0V3a1 1 0 011-1zm4 8a4 4 0 11-8 0 4 4 0 018 0zm-.464 4.95l.707.707a1 1 0 001.414-1.414l-.707-.707a1 1 0 00-1.414 1.414zm2.12-10.607a1 1 0 010 1.414l-.706.707a1 1 0 11-1.414-1.414l.707-.707a1 1 0 011.414 0zM17 11a1 1 0 100-2\

