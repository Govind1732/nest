"use client"

import React, { useState, useEffect, useCallback } from "react"
import { NavLink, useLocation } from "react-router-dom"
import {
  ChevronDown,
  ChevronRight,
  Home,
  Database,
  FileText,
  Settings,
  BarChart2,
  GitBranch,
  Code,
  HelpCircle,
  MenuIcon,
  X,
} from "lucide-react"
import { useTheme } from "../../hooks/useTheme"
import { cn } from "../../utils/cn"

// Navigation structure
const navigation = [
  {
    name: "Home",
    icon: Home,
    path: "/",
    exact: true,
  },
  {
    name: "Profiling",
    icon: Database,
    children: [
      { name: "Auto Profile", path: "/profiling/auto-profile" },
      { name: "Rule Profile", path: "/profiling/rule-profile" },
      { name: "Data Profile", path: "/profiling/data-profile" },
      { name: "Custom Profile", path: "/profiling/custom-profile" },
    ],
  },
  {
    name: "Data Validation",
    icon: FileText,
    path: "/data-validation",
  },
  {
    name: "API Integration",
    icon: Code,
    children: [
      { name: "DQ Metrics API", path: "/api-integration/dq-metrics-api" },
      { name: "ETL Pipeline Integration", path: "/api-integration/etl-pipeline-integration" },
      { name: "DQ FallOut Subscription", path: "/api-integration/dq-fallout-subscription" },
      { name: "DQ Data Remediation", path: "/api-integration/dq-data-remediation" },
    ],
  },
  {
    name: "Data Drift",
    icon: BarChart2,
    path: "/data-drift",
  },
  {
    name: "Schema Drift",
    icon: GitBranch,
    path: "/schema-drift",
  },
  {
    name: "Metadata Generator",
    icon: Settings,
    path: "/metadata-generator",
  },
  {
    name: "Reports",
    icon: BarChart2,
    children: [
      { name: "DQ Reports", path: "/reports/dq-reports" },
      { name: "DQ Domain Level Report", path: "/reports/dq-domain-level-report" },
    ],
  },
  {
    name: "Help",
    icon: HelpCircle,
    path: "/help",
  },
]

const Sidebar = () => {
  const location = useLocation()
  const { theme } = useTheme()
  const [expanded, setExpanded] = useState(true)
  const [expandedItems, setExpandedItems] = useState({})
  const [isMobile, setIsMobile] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)

  // Check if current path is in a submenu
  useEffect(() => {
    const currentPath = location.pathname

    navigation.forEach((item) => {
      if (item.children) {
        const isActive = item.children.some((child) => currentPath === child.path)
        if (isActive) {
          setExpandedItems((prev) => ({ ...prev, [item.name]: true }))
        }
      }
    })
  }, [location.pathname])

  // Check for mobile view
  useEffect(() => {
    const checkIsMobile = () => {
      setIsMobile(window.innerWidth < 768)
      if (window.innerWidth < 768) {
        setExpanded(false)
      } else {
        // Get user preference from localStorage
        const savedExpanded = localStorage.getItem("sidebarExpanded")
        if (savedExpanded !== null) {
          setExpanded(savedExpanded === "true")
        }
      }
    }

    checkIsMobile()
    window.addEventListener("resize", checkIsMobile)

    return () => {
      window.removeEventListener("resize", checkIsMobile)
    }
  }, [])

  // Save sidebar state to localStorage
  useEffect(() => {
    if (!isMobile) {
      localStorage.setItem("sidebarExpanded", expanded.toString())
    }
  }, [expanded, isMobile])

  const toggleSidebar = useCallback(() => {
    if (isMobile) {
      setMobileOpen((prev) => !prev)
    } else {
      setExpanded((prev) => !prev)
    }
  }, [isMobile])

  const toggleItem = useCallback((itemName) => {
    setExpandedItems((prev) => ({
      ...prev,
      [itemName]: !prev[itemName],
    }))
  }, [])

  const closeMobileSidebar = useCallback(() => {
    if (isMobile) {
      setMobileOpen(false)
    }
  }, [isMobile])

  // Render a navigation item
  const renderNavItem = (item, depth = 0) => {
    const isActive = item.exact ? location.pathname === item.path : item.path && location.pathname.startsWith(item.path)

    const isExpanded = expandedItems[item.name]
    const Icon = item.icon

    if (item.children) {
      return (
        <div key={item.name} className="mb-1">
          <button
            className={cn(
              "flex items-center w-full px-3 py-2 text-left rounded-md transition-colors",
              "hover:bg-gray-100 dark:hover:bg-gray-800",
              isExpanded ? "bg-gray-100 dark:bg-gray-800" : "",
              expanded ? "justify-between" : "justify-center",
            )}
            onClick={() => toggleItem(item.name)}
          >
            <div className="flex items-center">
              {Icon && <Icon className="w-5 h-5 mr-2" />}
              {expanded && <span>{item.name}</span>}
            </div>
            {expanded && (isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />)}
          </button>

          {isExpanded && (
            <div
              className={cn(
                "pl-4 mt-1 space-y-1",
                !expanded &&
                  "absolute left-full top-0 ml-2 bg-white dark:bg-gray-900 rounded-md shadow-lg p-2 min-w-[200px] z-10",
              )}
            >
              {item.children.map((child) => (
                <NavLink
                  key={child.name}
                  to={child.path}
                  className={({ isActive }) =>
                    cn(
                      "flex items-center px-3 py-2 text-sm rounded-md transition-colors",
                      "hover:bg-gray-100 dark:hover:bg-gray-800",
                      isActive ? "bg-primary/10 text-primary font-medium" : "text-gray-700 dark:text-gray-300",
                    )
                  }
                  onClick={closeMobileSidebar}
                >
                  <span>{child.name}</span>
                </NavLink>
              ))}
            </div>
          )}
        </div>
      )
    }

    return (
      <NavLink
        key={item.name}
        to={item.path}
        className={({ isActive }) =>
          cn(
            "flex items-center px-3 py-2 rounded-md transition-colors mb-1",
            "hover:bg-gray-100 dark:hover:bg-gray-800",
            isActive ? "bg-primary/10 text-primary font-medium" : "text-gray-700 dark:text-gray-300",
            expanded ? "justify-start" : "justify-center",
          )
        }
        onClick={closeMobileSidebar}
      >
        {Icon && <Icon className={cn("w-5 h-5", expanded && "mr-2")} />}
        {expanded && <span>{item.name}</span>}
      </NavLink>
    )
  }

  // Mobile toggle button
  const MobileToggle = (
    <button
      className="fixed bottom-4 right-4 z-50 p-3 bg-primary text-white rounded-full shadow-lg md:hidden"
      onClick={toggleSidebar}
      aria-label="Toggle sidebar"
    >
      {mobileOpen ? <X className="w-6 h-6" /> : <MenuIcon className="w-6 h-6" />}
    </button>
  )

  return (
    <>
      {/* Desktop sidebar */}
      <aside
        className={cn(
          "fixed top-16 bottom-0 left-0 z-30 flex flex-col bg-white border-r border-gray-200 transition-all duration-300 ease-in-out dark:bg-gray-900 dark:border-gray-800",
          expanded ? "w-64" : "w-16",
          isMobile && "hidden",
        )}
      >
        <div className="flex-1 overflow-y-auto p-3">
          <nav className="space-y-1">{navigation.map((item) => renderNavItem(item))}</nav>
        </div>

        <div className="p-3 border-t border-gray-200 dark:border-gray-800">
          <button
            className="flex items-center justify-center w-full p-2 text-gray-500 rounded-md hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-800"
            onClick={toggleSidebar}
            aria-label={expanded ? "Collapse sidebar" : "Expand sidebar"}
          >
            {expanded ? (
              <ChevronRight className="w-5 h-5" />
            ) : (
              <ChevronRight className="w-5 h-5 transform rotate-180" />
            )}
          </button>
        </div>
      </aside>

      {/* Mobile sidebar */}
      {isMobile && (
        <>
          <div
            className={cn(
              "fixed inset-0 bg-black bg-opacity-50 z-40 transition-opacity duration-300",
              mobileOpen ? "opacity-100" : "opacity-0 pointer-events-none",
            )}
            onClick={closeMobileSidebar}
          />

          <aside
            className={cn(
              "fixed top-16 bottom-0 left-0 z-50 w-64 bg-white border-r border-gray-200 transition-transform duration-300 ease-in-out dark:bg-gray-900 dark:border-gray-800",
              mobileOpen ? "translate-x-0" : "-translate-x-full",
            )}
          >
            <div className="flex-1 overflow-y-auto p-3">
              <nav className="space-y-1">{navigation.map((item) => renderNavItem(item))}</nav>
            </div>
          </aside>

          {MobileToggle}
        </>
      )}
    </>
  )
}

export default React.memo(Sidebar)

