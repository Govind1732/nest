"use client"

import React, { useState, useCallback } from "react"
import { Link } from "react-router-dom"
import { Bell, User, LogOut, Settings, Moon, Sun, Search, HelpCircle, X } from "lucide-react"
import { useTheme } from "../../hooks/useTheme"
import { cn } from "../../utils/cn"
import IconButton from "../ui/IconButton"
import Tooltip from "../ui/Tooltip"
import { Menu, MenuItem } from "../ui/Menu"

const Header = () => {
  const { theme, toggleTheme } = useTheme()
  const [searchOpen, setSearchOpen] = useState(false)
  const [userMenuAnchor, setUserMenuAnchor] = useState(null)
  const [notificationsAnchor, setNotificationsAnchor] = useState(null)

  const handleUserMenuOpen = useCallback((event) => {
    setUserMenuAnchor(event.currentTarget)
  }, [])

  const handleUserMenuClose = useCallback(() => {
    setUserMenuAnchor(null)
  }, [])

  const handleNotificationsOpen = useCallback((event) => {
    setNotificationsAnchor(event.currentTarget)
  }, [])

  const handleNotificationsClose = useCallback(() => {
    setNotificationsAnchor(null)
  }, [])

  const toggleSearch = useCallback(() => {
    setSearchOpen((prev) => !prev)
  }, [])

  return (
    <header className="fixed top-0 left-0 right-0 z-40 h-16 bg-white border-b border-gray-200 dark:bg-gray-900 dark:border-gray-800">
      <div className="flex items-center justify-between h-full px-4">
        {/* Logo and Brand */}
        <div className="flex items-center">
          <Link to="/" className="flex items-center">
            <img src="/verizon-logo.svg" alt="Verizon Logo" className="h-8 w-auto mr-2" />
            <span className="text-xl font-bold text-primary hidden sm:inline">LensX</span>
          </Link>
        </div>

        {/* Search Bar */}
        <div
          className={cn(
            "absolute left-0 right-0 top-0 bg-white dark:bg-gray-900 h-16 flex items-center px-4 transition-all duration-300 ease-in-out",
            searchOpen ? "opacity-100 z-50" : "opacity-0 -z-10",
          )}
        >
          <div className="relative w-full max-w-2xl mx-auto">
            <input
              type="text"
              placeholder="Search..."
              className="w-full h-10 pl-10 pr-4 text-gray-900 bg-gray-100 border-0 rounded-md focus:ring-2 focus:ring-primary focus:outline-none dark:bg-gray-800 dark:text-gray-100"
            />
            <Search
              className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 dark:text-gray-400"
              size={18}
            />
            <button
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 dark:text-gray-400"
              onClick={toggleSearch}
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Right Side Actions */}
        <div className="flex items-center space-x-1 sm:space-x-2">
          <Tooltip title="Search" placement="bottom">
            <IconButton onClick={toggleSearch} aria-label="Search">
              <Search className="w-5 h-5" />
            </IconButton>
          </Tooltip>

          <Tooltip title="Toggle theme" placement="bottom">
            <IconButton onClick={toggleTheme} aria-label="Toggle theme">
              {theme === "dark" ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </IconButton>
          </Tooltip>

          <Tooltip title="Help" placement="bottom">
            <IconButton aria-label="Help">
              <Link to="/help">
                <HelpCircle className="w-5 h-5" />
              </Link>
            </IconButton>
          </Tooltip>

          <Tooltip title="Notifications" placement="bottom">
            <IconButton onClick={handleNotificationsOpen} aria-label="Notifications">
              <div className="relative">
                <Bell className="w-5 h-5" />
                <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[10px] text-white">
                  3
                </span>
              </div>
            </IconButton>
          </Tooltip>

          <Menu
            anchorEl={notificationsAnchor}
            open={Boolean(notificationsAnchor)}
            onClose={handleNotificationsClose}
            anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
            transformOrigin={{ vertical: "top", horizontal: "right" }}
          >
            <div className="px-4 py-2 font-medium border-b border-gray-200 dark:border-gray-700">Notifications</div>
            <MenuItem onClick={handleNotificationsClose}>
              <div className="flex flex-col">
                <span className="font-medium">Data Quality Alert</span>
                <span className="text-xs text-gray-500 dark:text-gray-400">
                  Table 'customers' has 5 new validation errors
                </span>
              </div>
            </MenuItem>
            <MenuItem onClick={handleNotificationsClose}>
              <div className="flex flex-col">
                <span className="font-medium">Profile Completed</span>
                <span className="text-xs text-gray-500 dark:text-gray-400">
                  Auto profile for 'orders' table completed
                </span>
              </div>
            </MenuItem>
            <MenuItem onClick={handleNotificationsClose}>
              <div className="flex flex-col">
                <span className="font-medium">System Update</span>
                <span className="text-xs text-gray-500 dark:text-gray-400">
                  LensX will be updated tonight at 2 AM EST
                </span>
              </div>
            </MenuItem>
            <div className="px-4 py-2 text-center border-t border-gray-200 dark:border-gray-700">
              <Link
                to="/notifications"
                className="text-sm text-primary hover:text-primary-dark"
                onClick={handleNotificationsClose}
              >
                View all notifications
              </Link>
            </div>
          </Menu>

          <Tooltip title="User menu" placement="bottom">
            <IconButton onClick={handleUserMenuOpen} className="ml-2" aria-label="User menu">
              <User className="w-5 h-5" />
            </IconButton>
          </Tooltip>

          <Menu
            anchorEl={userMenuAnchor}
            open={Boolean(userMenuAnchor)}
            onClose={handleUserMenuClose}
            anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
            transformOrigin={{ vertical: "top", horizontal: "right" }}
          >
            <div className="px-4 py-3 border-b border-gray-200 dark:border-gray-700">
              <p className="text-sm font-medium">John Doe</p>
              <p className="text-xs text-gray-500 dark:text-gray-400">john.doe@verizon.com</p>
            </div>
            <MenuItem onClick={handleUserMenuClose}>
              <User className="w-4 h-4 mr-2" />
              <span>My Profile</span>
            </MenuItem>
            <MenuItem onClick={handleUserMenuClose}>
              <Settings className="w-4 h-4 mr-2" />
              <span>Settings</span>
            </MenuItem>
            <MenuItem onClick={handleUserMenuClose} divider>
              <LogOut className="w-4 h-4 mr-2" />
              <span>Logout</span>
            </MenuItem>
          </Menu>
        </div>
      </div>
    </header>
  )
}

export default React.memo(Header)

