import React from "react"
import { cn } from "../../utils/cn"

const Typography = React.forwardRef(
  (
    {
      children,
      className,
      variant = "body1",
      component,
      color,
      align = "inherit",
      noWrap = false,
      gutterBottom = false,
      paragraph = false,
      ...props
    },
    ref,
  ) => {
    const variantMapping = {
      h1: "h1",
      h2: "h2",
      h3: "h3",
      h4: "h4",
      h5: "h5",
      h6: "h6",
      subtitle1: "h6",
      subtitle2: "h6",
      body1: "p",
      body2: "p",
      caption: "span",
      button: "span",
      overline: "span",
    }

    const Component = component || variantMapping[variant] || "span"

    const variantClasses = {
      h1: "text-4xl font-bold",
      h2: "text-3xl font-bold",
      h3: "text-2xl font-bold",
      h4: "text-xl font-semibold",
      h5: "text-lg font-semibold",
      h6: "text-base font-semibold",
      subtitle1: "text-lg font-medium",
      subtitle2: "text-base font-medium",
      body1: "text-base",
      body2: "text-sm",
      caption: "text-xs",
      button: "text-sm font-medium uppercase",
      overline: "text-xs font-medium uppercase tracking-wider",
    }

    const colorClasses = {
      initial: "",
      inherit: "",
      primary: "text-primary",
      secondary: "text-secondary",
      textPrimary: "text-gray-900 dark:text-white",
      textSecondary: "text-gray-600 dark:text-gray-400",
      error: "text-error",
      warning: "text-warning",
      info: "text-info",
      success: "text-success",
    }

    const alignClasses = {
      inherit: "",
      left: "text-left",
      center: "text-center",
      right: "text-right",
      justify: "text-justify",
    }

    return (
      <Component
        ref={ref}
        className={cn(
          variantClasses[variant],
          color && colorClasses[color],
          alignClasses[align],
          noWrap && "truncate",
          gutterBottom && "mb-2",
          paragraph && "mb-4",
          className,
        )}
        {...props}
      >
        {children}
      </Component>
    )
  },
)

Typography.displayName = "Typography"

export default React.memo(Typography)

