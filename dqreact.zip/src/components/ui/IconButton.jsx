"use client"

import React from "react"
import { cn } from "../../utils/cn"

const IconButton = React.forwardRef(
  (
    { children, className, color = "default", disabled = false, edge = false, size = "medium", onClick, ...props },
    ref,
  ) => {
    const colorClasses = {
      default: "text-gray-600 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-700",
      primary: "text-primary hover:bg-primary-50 dark:hover:bg-primary-900/20",
      secondary: "text-secondary hover:bg-secondary-50 dark:hover:bg-secondary-900/20",
      error: "text-error hover:bg-error-50 dark:hover:bg-error-900/20",
      warning: "text-warning hover:bg-warning-50 dark:hover:bg-warning-900/20",
      info: "text-info hover:bg-info-50 dark:hover:bg-info-900/20",
      success: "text-success hover:bg-success-50 dark:hover:bg-success-900/20",
    }

    const sizeClasses = {
      small: "p-1",
      medium: "p-2",
      large: "p-3",
    }

    const edgeClasses = {
      start: "-ml-2",
      end: "-mr-2",
      false: "",
    }

    return (
      <button
        ref={ref}
        className={cn(
          "inline-flex items-center justify-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 disabled:opacity-50 disabled:pointer-events-none",
          colorClasses[color],
          sizeClasses[size],
          edgeClasses[edge],
          className,
        )}
        disabled={disabled}
        onClick={onClick}
        type="button"
        {...props}
      >
        {children}
      </button>
    )
  },
)

IconButton.displayName = "IconButton"

export default React.memo(IconButton)

