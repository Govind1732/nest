"use client"

import React, { useState, useRef, useEffect, useCallback } from "react"
import { createPortal } from "react-dom"
import { cn } from "../../utils/cn"

const Menu = React.forwardRef(
  (
    {
      children,
      className,
      open = false,
      onClose,
      anchorEl,
      anchorOrigin = { vertical: "bottom", horizontal: "left" },
      transformOrigin = { vertical: "top", horizontal: "left" },
      ...props
    },
    ref,
  ) => {
    const menuRef = useRef(null)
    const [position, setPosition] = useState({ top: 0, left: 0 })

    const calculatePosition = useCallback(() => {
      if (!anchorEl || !menuRef.current) return

      const anchorRect = anchorEl.getBoundingClientRect()
      const menuRect = menuRef.current.getBoundingClientRect()

      let top = 0
      let left = 0

      // Calculate vertical position
      if (anchorOrigin.vertical === "top") {
        top = anchorRect.top
      } else if (anchorOrigin.vertical === "center") {
        top = anchorRect.top + anchorRect.height / 2
      } else if (anchorOrigin.vertical === "bottom") {
        top = anchorRect.bottom
      }

      // Calculate horizontal position
      if (anchorOrigin.horizontal === "left") {
        left = anchorRect.left
      } else if (anchorOrigin.horizontal === "center") {
        left = anchorRect.left + anchorRect.width / 2
      } else if (anchorOrigin.horizontal === "right") {
        left = anchorRect.right
      }

      // Apply transform origin
      if (transformOrigin.vertical === "top") {
        // No adjustment needed
      } else if (transformOrigin.vertical === "center") {
        top -= menuRect.height / 2
      } else if (transformOrigin.vertical === "bottom") {
        top -= menuRect.height
      }

      if (transformOrigin.horizontal === "left") {
        // No adjustment needed
      } else if (transformOrigin.horizontal === "center") {
        left -= menuRect.width / 2
      } else if (transformOrigin.horizontal === "right") {
        left -= menuRect.width
      }

      // Ensure menu stays within viewport
      const viewportWidth = window.innerWidth
      const viewportHeight = window.innerHeight

      if (left + menuRect.width > viewportWidth) {
        left = viewportWidth - menuRect.width
      }

      if (left < 0) {
        left = 0
      }

      if (top + menuRect.height > viewportHeight) {
        top = viewportHeight - menuRect.height
      }

      if (top < 0) {
        top = 0
      }

      setPosition({ top, left })
    }, [anchorEl, anchorOrigin, transformOrigin])

    useEffect(() => {
      if (open) {
        calculatePosition()

        // Recalculate position on window resize
        window.addEventListener("resize", calculatePosition)

        return () => {
          window.removeEventListener("resize", calculatePosition)
        }
      }
    }, [open, calculatePosition])

    useEffect(() => {
      const handleClickOutside = (event) => {
        if (
          menuRef.current &&
          !menuRef.current.contains(event.target) &&
          (!anchorEl || !anchorEl.contains(event.target))
        ) {
          onClose && onClose(event, "backdropClick")
        }
      }

      if (open) {
        document.addEventListener("mousedown", handleClickOutside)
        return () => {
          document.removeEventListener("mousedown", handleClickOutside)
        }
      }
    }, [open, anchorEl, onClose])

    if (!open) return null

    return createPortal(
      <div
        ref={(node) => {
          menuRef.current = node
          if (typeof ref === "function") {
            ref(node)
          } else if (ref) {
            ref.current = node
          }
        }}
        className={cn(
          "absolute z-50 min-w-[12rem] overflow-hidden rounded-md border border-gray-200 bg-white p-1 shadow-lg animate-in fade-in-80 data-[side=bottom]:slide-in-from-top-1 data-[side=left]:slide-in-from-right-1 data-[side=right]:slide-in-from-left-1 data-[side=top]:slide-in-from-bottom-1 dark:border-gray-800 dark:bg-gray-800",
          className,
        )}
        style={{
          top: `${position.top}px`,
          left: `${position.left}px`,
        }}
        {...props}
      >
        {children}
      </div>,
      document.body,
    )
  },
)

Menu.displayName = "Menu"

export default React.memo(Menu)

const MenuItem = React.forwardRef(
  ({ children, className, disabled = false, divider = false, selected = false, onClick, ...props }, ref) => {
    return (
      <div
        ref={ref}
        className={cn(
          "relative flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none transition-colors",
          "hover:bg-gray-100 hover:text-gray-900 focus:bg-gray-100 focus:text-gray-900 dark:hover:bg-gray-700 dark:hover:text-gray-50 dark:focus:bg-gray-700 dark:focus:text-gray-50",
          selected && "bg-gray-100 text-gray-900 dark:bg-gray-700 dark:text-gray-50",
          disabled && "pointer-events-none opacity-50",
          divider && "border-b border-gray-200 dark:border-gray-700",
          className,
        )}
        onClick={disabled ? undefined : onClick}
        {...props}
      >
        {children}
      </div>
    )
  },
)

MenuItem.displayName = "MenuItem"

export { MenuItem }

