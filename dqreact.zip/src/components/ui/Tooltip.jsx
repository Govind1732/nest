"use client"

import React, { useState, useRef, useEffect } from "react"
import { createPortal } from "react-dom"
import { cn } from "../../utils/cn"

const Tooltip = React.forwardRef(
  (
    { children, className, title, arrow = true, placement = "bottom", enterDelay = 100, leaveDelay = 0, ...props },
    ref,
  ) => {
    const [open, setOpen] = useState(false)
    const [position, setPosition] = useState({ top: 0, left: 0 })
    const childRef = useRef(null)
    const tooltipRef = useRef(null)
    const enterTimeoutRef = useRef(null)
    const leaveTimeoutRef = useRef(null)

    const calculatePosition = () => {
      if (!childRef.current || !tooltipRef.current) return

      const childRect = childRef.current.getBoundingClientRect()
      const tooltipRect = tooltipRef.current.getBoundingClientRect()

      let top = 0
      let left = 0

      switch (placement) {
        case "top":
          top = childRect.top - tooltipRect.height - 8
          left = childRect.left + childRect.width / 2 - tooltipRect.width / 2
          break
        case "bottom":
          top = childRect.bottom + 8
          left = childRect.left + childRect.width / 2 - tooltipRect.width / 2
          break
        case "left":
          top = childRect.top + childRect.height / 2 - tooltipRect.height / 2
          left = childRect.left - tooltipRect.width - 8
          break
        case "right":
          top = childRect.top + childRect.height / 2 - tooltipRect.height / 2
          left = childRect.right + 8
          break
        default:
          break
      }

      // Ensure tooltip stays within viewport
      const viewportWidth = window.innerWidth
      const viewportHeight = window.innerHeight

      if (left + tooltipRect.width > viewportWidth) {
        left = viewportWidth - tooltipRect.width - 8
      }

      if (left < 8) {
        left = 8
      }

      if (top + tooltipRect.height > viewportHeight) {
        top = viewportHeight - tooltipRect.height - 8
      }

      if (top < 8) {
        top = 8
      }

      setPosition({ top, left })
    }

    const handleMouseEnter = () => {
      clearTimeout(leaveTimeoutRef.current)
      enterTimeoutRef.current = setTimeout(() => {
        setOpen(true)
      }, enterDelay)
    }

    const handleMouseLeave = () => {
      clearTimeout(enterTimeoutRef.current)
      leaveTimeoutRef.current = setTimeout(() => {
        setOpen(false)
      }, leaveDelay)
    }

    useEffect(() => {
      if (open) {
        calculatePosition()
        window.addEventListener("resize", calculatePosition)
        window.addEventListener("scroll", calculatePosition)

        return () => {
          window.removeEventListener("resize", calculatePosition)
          window.removeEventListener("scroll", calculatePosition)
        }
      }
    }, [open])

    useEffect(() => {
      return () => {
        clearTimeout(enterTimeoutRef.current)
        clearTimeout(leaveTimeoutRef.current)
      }
    }, [])

    const child = React.cloneElement(React.Children.only(children), {
      ref: (node) => {
        childRef.current = node
        const childRefCallback = children.ref
        if (childRefCallback) {
          if (typeof childRefCallback === "function") {
            childRefCallback(node)
          } else {
            childRefCallback.current = node
          }
        }
      },
      onMouseEnter: (e) => {
        handleMouseEnter()
        if (children.props.onMouseEnter) {
          children.props.onMouseEnter(e)
        }
      },
      onMouseLeave: (e) => {
        handleMouseLeave()
        if (children.props.onMouseLeave) {
          children.props.onMouseLeave(e)
        }
      },
      onFocus: (e) => {
        handleMouseEnter()
        if (children.props.onFocus) {
          children.props.onFocus(e)
        }
      },
      onBlur: (e) => {
        handleMouseLeave()
        if (children.props.onBlur) {
          children.props.onBlur(e)
        }
      },
    })

    const tooltipPortal =
      open && title
        ? createPortal(
            <div
              ref={(node) => {
                tooltipRef.current = node
                if (typeof ref === "function") {
                  ref(node)
                } else if (ref) {
                  ref.current = node
                }
              }}
              className={cn(
                "absolute z-50 max-w-xs px-2 py-1 text-xs font-medium text-white bg-gray-900 rounded shadow-sm dark:bg-gray-700",
                className,
              )}
              style={{
                top: `${position.top}px`,
                left: `${position.left}px`,
              }}
              {...props}
            >
              {title}
              {arrow && (
                <div
                  className={cn(
                    "absolute w-2 h-2 bg-gray-900 rotate-45 dark:bg-gray-700",
                    placement === "top" && "bottom-[-4px]",
                    placement === "bottom" && "top-[-4px]",
                    placement === "left" && "right-[-4px]",
                    placement === "right" && "left-[-4px]",
                  )}
                  style={{
                    left: placement === "top" || placement === "bottom" ? "calc(50% - 4px)" : undefined,
                    top: placement === "left" || placement === "right" ? "calc(50% - 4px)" : undefined,
                  }}
                />
              )}
            </div>,
            document.body,
          )
        : null

    return (
      <>
        {child}
        {tooltipPortal}
      </>
    )
  },
)

Tooltip.displayName = "Tooltip"

export default React.memo(Tooltip)

