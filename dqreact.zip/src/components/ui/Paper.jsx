import React from "react"
import { cn } from "../../utils/cn"
import Box from "./Box"

const Paper = React.forwardRef(
  ({ children, className, elevation = 1, square = false, variant = "elevation", ...props }, ref) => {
    const elevationClasses = {
      0: "shadow-none",
      1: "shadow-sm",
      2: "shadow",
      3: "shadow-md",
      4: "shadow-lg",
      6: "shadow-xl",
      8: "shadow-2xl",
      12: "shadow-2xl",
      16: "shadow-2xl",
      24: "shadow-2xl",
    }

    const variantClasses = {
      elevation: elevationClasses[elevation] || "shadow",
      outlined: "border border-gray-300 dark:border-gray-700 shadow-none",
    }

    return (
      <Box
        ref={ref}
        className={cn("bg-white dark:bg-gray-800", !square && "rounded-md", variantClasses[variant], className)}
        {...props}
      >
        {children}
      </Box>
    )
  },
)

Paper.displayName = "Paper"

export default React.memo(Paper)

