"use client"

import React, { useMemo } from "react"
import { FixedSizeList as List } from "react-window"
import AutoSizer from "react-virtualized-auto-sizer"
import { cn } from "../../utils/cn"

const VirtualizedTable = React.forwardRef(
  ({ columns, data, rowHeight = 48, className, headerClassName, rowClassName, cellClassName, ...props }, ref) => {
    // Memoize column widths
    const columnWidths = useMemo(() => {
      const totalFlex = columns.reduce((sum, column) => sum + (column.flex || 1), 0)
      return columns.map((column) => ({
        ...column,
        width: column.width || `${((column.flex || 1) / totalFlex) * 100}%`,
      }))
    }, [columns])

    // Render table header
    const TableHeader = useMemo(
      () => (
        <div
          className={cn(
            "flex items-center sticky top-0 z-10 bg-gray-50 dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700",
            headerClassName,
          )}
        >
          {columnWidths.map((column, index) => (
            <div
              key={column.accessor || index}
              className={cn("px-4 py-3 font-medium text-sm text-gray-700 dark:text-gray-300", column.headerClassName)}
              style={{
                width: column.width,
                textAlign: column.align || "left",
              }}
            >
              {column.Header}
            </div>
          ))}
        </div>
      ),
      [columnWidths, headerClassName],
    )

    // Row renderer
    const Row = useMemo(
      () =>
        ({ index, style }) => {
          const row = data[index]

          return (
            <div
              style={style}
              className={cn(
                "flex items-center border-b border-gray-200 dark:border-gray-700",
                index % 2 === 0 ? "bg-white dark:bg-gray-900" : "bg-gray-50 dark:bg-gray-800",
                "hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors",
                rowClassName,
              )}
            >
              {columnWidths.map((column, colIndex) => {
                const cellValue = row[column.accessor]

                return (
                  <div
                    key={column.accessor || colIndex}
                    className={cn(
                      "px-4 py-3 text-sm text-gray-900 dark:text-gray-300 truncate",
                      cellClassName,
                      column.cellClassName,
                    )}
                    style={{
                      width: column.width,
                      textAlign: column.align || "left",
                    }}
                  >
                    {column.Cell ? column.Cell({ value: cellValue, row }) : cellValue}
                  </div>
                )
              })}
            </div>
          )
        },
      [data, columnWidths, rowClassName, cellClassName],
    )

    return (
      <div
        ref={ref}
        className={cn("border border-gray-200 dark:border-gray-700 rounded-md overflow-hidden", className)}
        {...props}
      >
        {TableHeader}
        <div className="flex-1">
          <AutoSizer>
            {({ height, width }) => (
              <List height={height} width={width} itemCount={data.length} itemSize={rowHeight}>
                {Row}
              </List>
            )}
          </AutoSizer>
        </div>
      </div>
    )
  },
)

VirtualizedTable.displayName = "VirtualizedTable"

export default React.memo(VirtualizedTable)

