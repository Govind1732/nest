import React from "react"
import { cn } from "../../utils/cn"

const Skeleton = React.forwardRef(
  ({ className, variant = "text", animation = "pulse", width, height, ...props }, ref) => {
    const variantClasses = {
      text: "h-4 rounded",
      circular: "rounded-full",
      rectangular: "rounded-md",
      rounded: "rounded-lg",
    }

    const animationClasses = {
      pulse: "animate-pulse",
      wave: "relative overflow-hidden before:absolute before:inset-0 before:-translate-x-full before:animate-[shimmer_2s_infinite] before:bg-gradient-to-r before:from-transparent before:via-white/20 before:to-transparent",
      none: "",
    }

    const styles = {
      width: width ? (typeof width === "number" ? `${width}px` : width) : undefined,
      height: height ? (typeof height === "number" ? `${height}px` : height) : undefined,
    }

    return (
      <div
        ref={ref}
        className={cn("bg-gray-200 dark:bg-gray-700", variantClasses[variant], animationClasses[animation], className)}
        style={styles}
        {...props}
      />
    )
  },
)

Skeleton.displayName = "Skeleton"

export default React.memo(Skeleton)

