/**
 * Format a number as a percentage
 * @param {number} value - The value to format
 * @param {number} decimals - Number of decimal places
 * @returns {string} Formatted percentage
 */
export const formatPercent = (value, decimals = 0) => {
  if (value === null || value === undefined) return "N/A"
  return `${value.toFixed(decimals)}%`
}

/**
 * Format a date string
 * @param {string|Date} date - The date to format
 * @param {object} options - Intl.DateTimeFormat options
 * @returns {string} Formatted date
 */
export const formatDate = (date, options = {}) => {
  if (!date) return "N/A"

  const defaultOptions = {
    year: "numeric",
    month: "short",
    day: "numeric",
    ...options,
  }

  return new Date(date).toLocaleDateString(undefined, defaultOptions)
}

/**
 * Truncate text with ellipsis
 * @param {string} text - The text to truncate
 * @param {number} length - Maximum length
 * @returns {string} Truncated text
 */
export const truncateText = (text, length = 30) => {
  if (!text) return ""
  return text.length > length ? `${text.substring(0, length)}...` : text
}

/**
 * Debounce a function
 * @param {Function} func - The function to debounce
 * @param {number} wait - Wait time in milliseconds
 * @returns {Function} Debounced function
 */
export const debounce = (func, wait = 300) => {
  let timeout

  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout)
      func(...args)
    }

    clearTimeout(timeout)
    timeout = setTimeout(later, wait)
  }
}

/**
 * Get a color based on a score value
 * @param {number} score - The score (0-100)
 * @returns {string} Color class
 */
export const getScoreColor = (score) => {
  if (score >= 80) return "text-success"
  if (score >= 60) return "text-warning"
  return "text-error"
}

/**
 * Get a status badge class
 * @param {string} status - The status
 * @returns {string} Badge class
 */
export const getStatusBadgeClass = (status) => {
  switch (status?.toLowerCase()) {
    case "completed":
    case "success":
    case "passed":
      return "bg-success-light/20 text-success"
    case "in progress":
    case "running":
    case "pending":
      return "bg-info-light/20 text-info"
    case "failed":
    case "error":
      return "bg-error-light/20 text-error"
    case "warning":
      return "bg-warning-light/20 text-warning"
    default:
      return "bg-gray-200 text-gray-700 dark:bg-gray-700 dark:text-gray-300"
  }
}

/**
 * Download data as a file
 * @param {object|string} data - The data to download
 * @param {string} filename - The filename
 * @param {string} type - The MIME type
 */
export const downloadFile = (data, filename, type = "text/plain") => {
  const blob = new Blob([typeof data === "object" ? JSON.stringify(data, null, 2) : data], { type })
  const url = URL.createObjectURL(blob)
  const link = document.createElement("a")

  link.href = url
  link.download = filename
  document.body.appendChild(link)
  link.click()

  setTimeout(() => {
    document.body.removeChild(link)
    URL.revokeObjectURL(url)
  }, 100)
}

