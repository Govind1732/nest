import { configureStore } from "@reduxjs/toolkit"
import userAuthorizationReducer from "../features/users/userAuthorizationSlice"
import dqReportReducer from "../features/DQReport/dqReportSlice"
import dqDomainLevelReportReducer from "../features/DQDomainLevelReport/dqDomainLevelReportSlice"
import dataQualityProfileSingleRowSlice from "../features/DataQualityProfileSingleRow/dataQualityProfileSingleRowSlice"
import { fastapiSlice } from "../features/api/fastapiSlice.js"
import { djangoapiSlice } from "../features/api/djangoapiSlice.js"
import { nodeapiSlice } from "../features/api/nodeapiSlice.js"
// import { djangoapiSlice2 } from '../features/api/djangoapiSlice2.js';

const store = configureStore({
  reducer: {
    userAuthorization: userAuthorizationReducer,
    dqReport: dqReportReducer,
    dqDomainLevelReport: dqDomainLevelReportReducer,
    dataQualityProfileSingleRow: dataQualityProfileSingleRowSlice,
    [fastapiSlice.reducerPath]: fastapiSlice.reducer,
    [djangoapiSlice.reducerPath]: djangoapiSlice.reducer,
    [nodeapiSlice.reducerPath]: nodeapiSlice.reducer,
    // [djangoapiSlice2.reducerPath]: djangoapiSlice2.reducer,
  },
  // Adding the api middleware enables caching, invalidation, polling, and other features of RTK Query
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware()
      .concat(fastapiSlice.middleware)
      .concat(djangoapiSlice.middleware)
      .concat(nodeapiSlice.middleware),
  // .concat(djangoapiSlice2.middleware)
})

export default store

