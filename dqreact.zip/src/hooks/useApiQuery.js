"use client"

import { useState, useEffect, useCallback } from "react"

/**
 * Custom hook for handling API queries with loading, error, and data states
 *
 * @param {Function} queryHook - RTK Query hook (e.g., useGetProductDataQuery)
 * @param {Object} options - Additional options for the query
 * @param {boolean} options.skip - Whether to skip the query
 * @param {Function} options.onSuccess - Callback function when query succeeds
 * @param {Function} options.onError - Callback function when query fails
 * @param {Function} options.transformData - Function to transform the data
 * @returns {Object} - { data, isLoading, error, refetch }
 */
const useApiQuery = (queryHook, options = {}) => {
  const { skip = false, onSuccess, onError, transformData = (data) => data, ...queryOptions } = options

  const [transformedData, setTransformedData] = useState(null)

  // Execute the RTK Query hook
  const { data: rawData, isLoading, isFetching, error, refetch } = queryHook({ ...queryOptions }, { skip })

  // Transform data when it changes
  useEffect(() => {
    if (rawData) {
      try {
        const transformed = transformData(rawData)
        setTransformedData(transformed)

        if (onSuccess) {
          onSuccess(transformed)
        }
      } catch (err) {
        console.error("Error transforming data:", err)
        if (onError) {
          onError(err)
        }
      }
    }
  }, [rawData, transformData, onSuccess, onError])

  // Handle errors
  useEffect(() => {
    if (error && onError) {
      onError(error)
    }
  }, [error, onError])

  // Enhanced refetch function with error handling
  const handleRefetch = useCallback(async () => {
    try {
      await refetch()
    } catch (err) {
      console.error("Error refetching data:", err)
      if (onError) {
        onError(err)
      }
    }
  }, [refetch, onError])

  return {
    data: transformedData,
    isLoading: isLoading || isFetching,
    error,
    refetch: handleRefetch,
  }
}

export default useApiQuery

