"use client"

import { useState, useCallback } from "react"

/**
 * Custom hook for handling API mutations with loading and error states
 *
 * @param {Function} mutationHook - RTK Query mutation hook (e.g., usePostDQTrendMutation)
 * @param {Object} options - Additional options for the mutation
 * @param {Function} options.onSuccess - Callback function when mutation succeeds
 * @param {Function} options.onError - Callback function when mutation fails
 * @param {Function} options.transformRequest - Function to transform the request data
 * @param {Function} options.transformResponse - Function to transform the response data
 * @returns {Object} - { mutate, isLoading, error, reset }
 */
const useApiMutation = (mutationHook, options = {}) => {
  const { onSuccess, onError, transformRequest = (data) => data, transformResponse = (data) => data } = options

  const [error, setError] = useState(null)

  // Execute the RTK Query mutation hook
  const [triggerMutation, { isLoading, reset: resetMutation }] = mutationHook()

  // Enhanced mutation function with request/response transformation and error handling
  const mutate = useCallback(
    async (data) => {
      setError(null)

      try {
        // Transform request data
        const transformedRequest = transformRequest(data)

        // Execute mutation
        const response = await triggerMutation(transformedRequest).unwrap()

        // Transform response data
        const transformedResponse = transformResponse(response)

        // Call success callback if provided
        if (onSuccess) {
          onSuccess(transformedResponse)
        }

        return transformedResponse
      } catch (err) {
        console.error("Mutation error:", err)
        setError(err)

        // Call error callback if provided
        if (onError) {
          onError(err)
        }

        throw err
      }
    },
    [triggerMutation, transformRequest, transformResponse, onSuccess, onError],
  )

  // Reset error state and mutation state
  const reset = useCallback(() => {
    setError(null)
    resetMutation()
  }, [resetMutation])

  return {
    mutate,
    isLoading,
    error,
    reset,
  }
}

export default useApiMutation

