import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react"

// Create a base query with error handling and authentication
const baseQueryWithAuth = fetchBaseQuery({
  baseUrl: `${import.meta.env.VITE_NODEAPI_BASE_URL}`,
  credentials: "include",
  prepareHeaders: (headers) => {
    headers.set("Accept", "application/json")
    return headers
  },
  // Add timeout to prevent hanging requests
  timeout: 30000,
})

// Enhanced base query with retry logic and error handling
const baseQueryWithRetry = async (args, api, extraOptions) => {
  let result = await baseQueryWithAuth(args, api, extraOptions)

  // Implement retry logic for network errors or 5xx responses
  let retries = 0
  const MAX_RETRIES = 2

  while (
    result.error &&
    (result.error.status >= 500 || result.error.status === "FETCH_ERROR") &&
    retries < MAX_RETRIES
  ) {
    console.log(`Retrying API call, attempt ${retries + 1}...`)
    // Exponential backoff: 1s, 2s, 4s, etc.
    await new Promise((resolve) => setTimeout(resolve, 1000 * Math.pow(2, retries)))
    retries++
    result = await baseQueryWithAuth(args, api, extraOptions)
  }

  return result
}

export const nodeapiSlice = createApi({
  reducerPath: "nodeApi",
  baseQuery: baseQueryWithRetry,
  // Enable caching for 5 minutes by default
  keepUnusedDataFor: 300,
  // Tag types for cache invalidation
  tagTypes: [
    "SSUIReportData",
    "ProductData",
    "DynamicFilter",
    "EnterpriseData",
    "LobWiseData",
    "DQTrend",
    "ProductTypeWiseData",
  ],
  endpoints: (builder) => ({
    // Home
    getSSUIReportData: builder.query({
      query: () => "dqapi/SSUIReportData",
      providesTags: ["SSUIReportData"],
      // Transform response to normalize data structure
      transformResponse: (response) => {
        if (!response) return { business_programs: [] }
        return {
          business_programs: Array.isArray(response.business_programs) ? response.business_programs : [],
        }
      },
      // Add error handling
      onQueryStarted: async (_, { queryFulfilled }) => {
        try {
          await queryFulfilled
        } catch (err) {
          console.error("Error fetching SSUI Report Data:", err)
        }
      },
    }),
    postSSUIReportData: builder.mutation({
      query: (data) => ({
        url: "dqapi/SSUIReportData",
        method: "POST",
        body: data,
      }),
      // Invalidate cache on mutation
      invalidatesTags: ["SSUIReportData"],
    }),

    // DQ Domain Level Report
    getProductData: builder.query({
      query: () => "dqapi/get_product_data",
      providesTags: ["ProductData"],
      // Add data transformation if needed
      transformResponse: (response) => {
        if (!response) return []
        return Array.isArray(response) ? response : []
      },
    }),
    getL2ProductData: builder.query({
      query: () => "dqapi/get_level2_data",
      providesTags: ["ProductData"],
      // Add data transformation if needed
      transformResponse: (response) => {
        if (!response) return []
        return Array.isArray(response) ? response : []
      },
    }),
    postTopBottomFiveScores: builder.mutation({
      query: (data) => ({
        url: "dqapi/top_bottom_five_scores",
        method: "POST",
        body: data,
      }),
    }),

    // DQ Reports
    getDynamicFilter: builder.query({
      query: () => "dqapi/DynamicFilter/",
      providesTags: ["DynamicFilter"],
    }),
    postDynamicFilter: builder.mutation({
      query: (body) => ({
        url: "dqapi/DynamicFilter/",
        method: "POST",
        body,
      }),
      invalidatesTags: ["DynamicFilter"],
    }),
    getDefaultEnterpriseData: builder.query({
      query: () => "dqapi/enterpriseData/",
      providesTags: ["EnterpriseData"],
    }),
    postDefaultEnterpriseData: builder.mutation({
      query: (body) => ({
        url: "dqapi/enterpriseData/",
        method: "POST",
        body,
      }),
      invalidatesTags: ["EnterpriseData"],
    }),

    getDefaultLobWiseData: builder.query({
      query: () => "dqapi/lobWiseData/",
      providesTags: ["LobWiseData"],
    }),
    postDefaultLobWiseData: builder.mutation({
      query: (body) => ({
        url: "dqapi/lobWiseData/",
        method: "POST",
        body,
      }),
      invalidatesTags: ["LobWiseData"],
    }),

    getDQTrend: builder.query({
      query: () => "dqapi/trendData/",
      providesTags: ["DQTrend"],
    }),
    postDQTrend: builder.mutation({
      query: (body) => ({
        url: "dqapi/trendData/",
        method: "POST",
        body,
      }),
      invalidatesTags: ["DQTrend"],
    }),

    getProductTypeWiseData: builder.query({
      query: () => "dqapi/ProductTypeWiseData/",
      providesTags: ["ProductTypeWiseData"],
    }),
    postProductTypeWiseData: builder.mutation({
      query: (body) => ({
        url: "dqapi/ProductTypeWiseData/",
        method: "POST",
        body,
      }),
      invalidatesTags: ["ProductTypeWiseData"],
    }),

    postHierarchalData: builder.mutation({
      query: (body) => ({
        url: "dqapi/HierarchalData/",
        method: "POST",
        body,
      }),
    }),
    postTableWiseData: builder.mutation({
      query: (body) => ({
        url: "dqapi/TableWiseData/",
        method: "POST",
        body,
      }),
    }),
    // DataQuality Profile
    postMultipleRequestProfile: builder.mutation({
      query: (formData) => ({
        url: "dqapi/multipleRequestProfile",
        method: "POST",
        body: formData,
      }),
    }),
    getSingleTableLoadGCP: builder.query({
      query: () => "dqapi/singleTableLoadGCP",
      // Cache for a shorter time since this data may change frequently
      keepUnusedDataFor: 60,
    }),
    postSingleTableLoadGCP: builder.mutation({
      query: (body) => ({
        url: "dqapi/singleTableLoadGCP",
        method: "POST",
        body,
      }),
    }),
    postConnectivityCheck: builder.mutation({
      query: (body) => ({
        url: "dqapi/connectivityCheck",
        method: "POST",
        body,
      }),
    }),
    getTaxonomyProductNames: builder.query({
      query: () => "dqapi/getTaxonomyProductNames",
    }),
    fetchTaxonomyData: builder.mutation({
      query: (body) => ({
        url: "dqapi/fetchTaxonomyData",
        method: "POST",
        body,
      }),
    }),
    insertTaxonomyData: builder.mutation({
      query: (body) => ({
        url: "dqapi/insertTaxonomyData",
        method: "POST",
        body,
      }),
    }),
    updateTaxonomyData: builder.mutation({
      query: (body) => ({
        url: "dqapi/updateTaxonomyData",
        method: "POST",
        body,
      }),
    }),
  }),
})

export const {
  useGetSSUIReportDataQuery,
  usePostSSUIReportDataMutation,

  useGetProductDataQuery,
  useGetL2ProductDataQuery,
  usePostTopBottomFiveScoresMutation,

  useGetDynamicFilterQuery,
  usePostDynamicFilterMutation,
  useGetDefaultEnterpriseDataQuery,
  usePostDefaultEnterpriseDataMutation,
  useGetDefaultLobWiseDataQuery,
  usePostDefaultLobWiseDataMutation,
  useGetDQTrendQuery,
  usePostDQTrendMutation,
  useGetProductTypeWiseDataQuery,
  usePostProductTypeWiseDataMutation,
  usePostHierarchalDataMutation,
  usePostTableWiseDataMutation,

  usePostMultipleRequestProfileMutation,
  useGetSingleTableLoadGCPQuery,
  usePostSingleTableLoadGCPMutation,
  usePostConnectivityCheckMutation,
  useGetTaxonomyProductNamesQuery,
  useFetchTaxonomyDataMutation,
  useInsertTaxonomyDataMutation,
  useUpdateTaxonomyDataMutation,
} = nodeapiSlice

