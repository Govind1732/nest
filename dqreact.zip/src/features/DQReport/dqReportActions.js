import { createAction } from "@reduxjs/toolkit"

export const setFilterValues = createAction("dqReport/setFilterValues")
export const resetFilterValues = createAction("dqReport/resetFilterValues")
export const setShowAllColumns = createAction("dqReport/setShowAllColumns")
export const setDashboardView = createAction("dqReport/setDashboardView")
export const setDataProductsView = createAction("dqReport/setDataProductsView")
export const setTableLevelAssetsView = createAction("dqReport/setTableLevelAssetsView")
export const startDate = createAction("dqReport/startDate")
export const endDate = createAction("dqReport/endDate")
export const setSelectedLabel = createAction("dqReport/setSelectedLabel")

