import { createSlice } from "@reduxjs/toolkit"
import {
  setActiveStep,
  setCompletedSteps,
  setTaxonomyData,
  setIsDataConfirmed,
  resetTaxonomyData,
  setSelectedValues,
} from "./dataQualityProfileSingleRowActions"

const initialState = {
  activeStep: 1,
  completedSteps: [],
  taxonomyData: {},
  isDataConfirmed: false,
  selectedValues: {
    environment: "",
    projectName: "",
    dbName: "",
    tableName: "",
  },
}

const dataQualityProfileSingleRowSlice = createSlice({
  name: "dataQualityProfileSingleRow",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(setActiveStep, (state, action) => {
        state.activeStep = action.payload
      })
      .addCase(setCompletedSteps, (state, action) => {
        state.completedSteps = action.payload
      })
      .addCase(setTaxonomyData, (state, action) => {
        state.taxonomyData = action.payload
      })
      .addCase(setIsDataConfirmed, (state, action) => {
        state.isDataConfirmed = action.payload
      })
      .addCase(resetTaxonomyData, (state) => {
        state.taxonomyData = {}
      })
      .addCase(setSelectedValues, (state, action) => {
        state.selectedValues = action.payload
      })
  },
})

export default dataQualityProfileSingleRowSlice.reducer

