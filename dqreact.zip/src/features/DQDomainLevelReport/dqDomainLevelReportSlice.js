import { createSlice } from "@reduxjs/toolkit"
import {
  setActiveProduct,
  setLast7days,
  setShowAllColumns,
  setDashboardView,
  setSelectedTable,
  setColumnsData,
} from "./dqDomainLevelReportActions"

const initialState = {
  activeProduct: { productId: "Journey Data Product", L2_productId: "", tableName: "" },
  last7days: [],
  showAllColumns: false,
  dashboardView: true,
  selectedTable: "",
  columnsData: [],
}

const dqDomainLevelReportSlice = createSlice({
  name: "dqDomainLevelReport",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(setActiveProduct, (state, action) => {
        state.activeProduct = action.payload
      })
      .addCase(setLast7days, (state, action) => {
        state.last7days = action.payload
      })
      .addCase(setShowAllColumns, (state, action) => {
        state.showAllColumns = action.payload
      })
      .addCase(setDashboardView, (state, action) => {
        state.dashboardView = action.payload
      })
      .addCase(setSelectedTable, (state, action) => {
        state.selectedTable = action.payload
      })
      .addCase(setColumnsData, (state, action) => {
        state.columnsData = action.payload
      })
  },
})

export default dqDomainLevelReportSlice.reducer

