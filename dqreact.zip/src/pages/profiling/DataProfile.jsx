"use client"

import React, { useState, useCallback, useMemo } from "react"
import { Search, Download, RefreshCw, Filter } from "lucide-react"
import Typography from "../../components/ui/Typography"
import Paper from "../../components/ui/Paper"
import Box from "../../components/ui/Box"
import Tabs from "../../components/ui/Tabs"
import Button from "../../components/ui/Button"
import VirtualizedTable from "../../components/ui/VirtualizedTable"
import Skeleton from "../../components/ui/Skeleton"
import IconButton from "../../components/ui/IconButton"
import Tooltip from "../../components/ui/Tooltip"
import { useToast } from "../../contexts/ToastContext"

// Mock data
const generateMockData = (count) => {
  return Array.from({ length: count }, (_, i) => ({
    id: i + 1,
    tableName: `table_${i % 10}_${Math.floor(i / 10)}`,
    dbName: `database_${i % 5}`,
    environment: i % 3 === 0 ? "TD" : "GCP",
    profileDate: new Date(Date.now() - i * 86400000).toLocaleDateString(),
    status: i % 5 === 0 ? "Failed" : i % 5 === 1 ? "In Progress" : "Completed",
    completeness: Math.round(Math.random() * 100),
    validity: Math.round(Math.random() * 100),
    consistency: Math.round(Math.random() * 100),
    uniqueness: Math.round(Math.random() * 100),
    timeliness: Math.round(Math.random() * 100),
    conformity: Math.round(Math.random() * 100),
    overallScore: Math.round(Math.random() * 100),
  }))
}

const DataProfile = () => {
  const [loading, setLoading] = useState(true)
  const [data, setData] = useState([])
  const [searchTerm, setSearchTerm] = useState("")
  const [activeTab, setActiveTab] = useState("submit")
  const toast = useToast()

  // Simulate data loading
  React.useEffect(() => {
    const loadData = async () => {
      try {
        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 1500))
        setData(generateMockData(1000))
        setLoading(false)
      } catch (error) {
        console.error(error)
        toast.showError("Failed to load data profiles")
        setLoading(false)
      }
    }

    loadData()
  }, [toast])

  // Handle search
  const handleSearchChange = useCallback((e) => {
    setSearchTerm(e.target.value)
  }, [])

  // Filter data based on search term
  const filteredData = useMemo(() => {
    if (!searchTerm.trim()) return data

    const term = searchTerm.toLowerCase()
    return data.filter(
      (item) =>
        item.tableName.toLowerCase().includes(term) ||
        item.dbName.toLowerCase().includes(term) ||
        item.environment.toLowerCase().includes(term),
    )
  }, [data, searchTerm])

  // Table columns
  const columns = useMemo(
    () => [
      {
        Header: "ID",
        accessor: "id",
        width: "60px",
      },
      {
        Header: "Table Name",
        accessor: "tableName",
        flex: 2,
      },
      {
        Header: "Database",
        accessor: "dbName",
        flex: 2,
      },
      {
        Header: "Environment",
        accessor: "environment",
        width: "120px",
      },
      {
        Header: "Profile Date",
        accessor: "profileDate",
        width: "120px",
      },
      {
        Header: "Status",
        accessor: "status",
        width: "120px",
        Cell: ({ value }) => {
          let badgeClass = ""

          if (value === "Completed") {
            badgeClass = "bg-success-light/20 text-success"
          } else if (value === "In Progress") {
            badgeClass = "bg-info-light/20 text-info"
          } else {
            badgeClass = "bg-error-light/20 text-error"
          }

          return <span className={`px-2 py-1 rounded-full text-xs font-medium ${badgeClass}`}>{value}</span>
        },
      },
      {
        Header: "Overall Score",
        accessor: "overallScore",
        width: "120px",
        Cell: ({ value }) => {
          let textClass = ""

          if (value >= 80) {
            textClass = "text-success"
          } else if (value >= 60) {
            textClass = "text-warning"
          } else {
            textClass = "text-error"
          }

          return <span className={`font-medium ${textClass}`}>{value}%</span>
        },
      },
      {
        Header: "Actions",
        width: "100px",
        Cell: ({ row }) => (
          <div className="flex space-x-1">
            <Tooltip title="Download Report" placement="top">
              <IconButton size="small" aria-label="Download Report">
                <Download className="w-4 h-4" />
              </IconButton>
            </Tooltip>
            <Tooltip title="Rerun Profile" placement="top">
              <IconButton size="small" aria-label="Rerun Profile">
                <RefreshCw className="w-4 h-4" />
              </IconButton>
            </Tooltip>
          </div>
        ),
      },
    ],
    [],
  )

  // Submit form handler
  const handleSubmit = useCallback(
    (e) => {
      e.preventDefault()
      toast.showSuccess("Profile request submitted successfully")
    },
    [toast],
  )

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <Typography variant="h4" color="textPrimary">
          Data Profile
        </Typography>

        <div className="flex flex-col sm:flex-row gap-2">
          <div className="relative">
            <input
              type="text"
              placeholder="Search..."
              value={searchTerm}
              onChange={handleSearchChange}
              className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-md focus:ring-2 focus:ring-primary focus:border-primary dark:bg-gray-800 dark:border-gray-700 dark:text-white"
            />
            <Search
              className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 dark:text-gray-400"
              size={18}
            />
          </div>

          <Button variant="outline" className="flex items-center gap-2">
            <Filter size={16} />
            <span>Filter</span>
          </Button>
        </div>
      </div>

      <Tabs activeKey={activeTab} onSelect={setActiveTab}>
        <Tabs.Tab eventKey="submit" title="Submit Request">
          <Paper className="p-6">
            {loading ? (
              <div className="space-y-4">
                <Skeleton variant="text" width="50%" height={24} />
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Skeleton variant="text" width="30%" height={20} />
                    <Skeleton variant="rectangular" height={40} />
                  </div>
                  <div className="space-y-2">
                    <Skeleton variant="text" width="30%" height={20} />
                    <Skeleton variant="rectangular" height={40} />
                  </div>
                  <div className="space-y-2">
                    <Skeleton variant="text" width="30%" height={20} />
                    <Skeleton variant="rectangular" height={40} />
                  </div>
                  <div className="space-y-2">
                    <Skeleton variant="text" width="30%" height={20} />
                    <Skeleton variant="rectangular" height={40} />
                  </div>
                </div>
                <div className="flex justify-end">
                  <Skeleton variant="rectangular" width={120} height={40} />
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit}>
                <Typography variant="h6" gutterBottom>
                  Submit Data Profile Request
                </Typography>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Environment
                    </label>
                    <select className="w-full border border-gray-300 rounded-md px-3 py-2 focus:ring-2 focus:ring-primary focus:border-primary dark:bg-gray-800 dark:border-gray-700 dark:text-white">
                      <option value="">Select Environment</option>
                      <option value="TD">TD</option>
                      <option value="GCP">GCP</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Database Name
                    </label>
                    <select className="w-full border border-gray-300 rounded-md px-3 py-2 focus:ring-2 focus:ring-primary focus:border-primary dark:bg-gray-800 dark:border-gray-700 dark:text-white">
                      <option value="">Select Database</option>
                      <option value="database_0">database_0</option>
                      <option value="database_1">database_1</option>
                      <option value="database_2">database_2</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Table Name
                    </label>
                    <select className="w-full border border-gray-300 rounded-md px-3 py-2 focus:ring-2 focus:ring-primary focus:border-primary dark:bg-gray-800 dark:border-gray-700 dark:text-white">
                      <option value="">Select Table</option>
                      <option value="table_0_0">table_0_0</option>
                      <option value="table_1_0">table_1_0</option>
                      <option value="table_2_0">table_2_0</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Email</label>
                    <input
                      type="email"
                      placeholder="Enter your email"
                      className="w-full border border-gray-300 rounded-md px-3 py-2 focus:ring-2 focus:ring-primary focus:border-primary dark:bg-gray-800 dark:border-gray-700 dark:text-white"
                    />
                  </div>
                </div>

                <div className="flex justify-end">
                  <Button type="submit">Submit Request</Button>
                </div>
              </form>
            )}
          </Paper>
        </Tabs.Tab>

        <Tabs.Tab eventKey="download" title="Download Reports">
          <Paper className="p-6">
            <Typography variant="h6" gutterBottom>
              Data Profile Reports
            </Typography>

            {loading ? (
              <Box height="400px" display="flex" alignItems="center" justifyContent="center">
                <div className="text-center">
                  <Skeleton variant="circular" width={48} height={48} className="mx-auto mb-4" />
                  <Skeleton variant="text" width={200} className="mx-auto" />
                </div>
              </Box>
            ) : (
              <Box height="600px" className="relative">
                <VirtualizedTable columns={columns} data={filteredData} rowHeight={56} />
              </Box>
            )}
          </Paper>
        </Tabs.Tab>
      </Tabs>
    </div>
  )
}

export default React.memo(DataProfile)

