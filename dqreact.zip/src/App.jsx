import { lazy, Suspense } from "react"
import { BrowserRouter as Router, Routes, Route } from "react-router-dom"
import { ToastProvider } from "./contexts/ToastContext"
import { ThemeProvider } from "./contexts/ThemeContext"
import Layout from "./components/layout/Layout"
import LoadingSpinner from "./components/ui/LoadingSpinner"

// Lazy load pages for better performance
const Dashboard = lazy(() => import("./pages/Dashboard"))
const AutoProfile = lazy(() => import("./pages/profiling/AutoProfile"))
const RuleProfile = lazy(() => import("./pages/profiling/RuleProfile"))
const DataProfile = lazy(() => import("./pages/profiling/DataProfile"))
const CustomProfile = lazy(() => import("./pages/profiling/CustomProfile"))
const ApiIntegration = lazy(() => import("./pages/api-integration/ApiIntegration"))
const DqMetricsApi = lazy(() => import("./pages/api-integration/DqMetricsApi"))
const EtlPipelineIntegration = lazy(() => import("./pages/api-integration/EtlPipelineIntegration"))
const DqFalloutSubscription = lazy(() => import("./pages/api-integration/DqFalloutSubscription"))
const DqDataRemediation = lazy(() => import("./pages/api-integration/DqDataRemediation"))
const DataDrift = lazy(() => import("./pages/DataDrift"))
const SchemaDrift = lazy(() => import("./pages/SchemaDrift"))
const MetadataGenerator = lazy(() => import("./pages/MetadataGenerator"))
const DqReports = lazy(() => import("./pages/reports/DqReports"))
const DqDomainLevelReport = lazy(() => import("./pages/reports/DqDomainLevelReport"))
const DataValidation = lazy(() => import("./pages/DataValidation"))
const Help = lazy(() => import("./pages/Help"))
const MyRequest = lazy(() => import("./pages/MyRequest"))
const NotFound = lazy(() => import("./pages/NotFound"))

// Loading component for suspense fallback
const Loading = () => (
  <div className="flex items-center justify-center h-screen">
    <LoadingSpinner size="lg" text="Loading..." />
  </div>
)

const App = () => {
  return (
    <ThemeProvider>
      <ToastProvider>
        <Router>
          <Suspense fallback={<Loading />}>
            <Routes>
              <Route path="/" element={<Layout />}>
                <Route index element={<Dashboard />} />
                <Route path="profiling/auto-profile" element={<AutoProfile />} />
                <Route path="profiling/rule-profile" element={<RuleProfile />} />
                <Route path="profiling/data-profile" element={<DataProfile />} />
                <Route path="profiling/custom-profile" element={<CustomProfile />} />
                <Route path="api-integration" element={<ApiIntegration />} />
                <Route path="api-integration/dq-metrics-api" element={<DqMetricsApi />} />
                <Route path="api-integration/etl-pipeline-integration" element={<EtlPipelineIntegration />} />
                <Route path="api-integration/dq-fallout-subscription" element={<DqFalloutSubscription />} />
                <Route path="api-integration/dq-data-remediation" element={<DqDataRemediation />} />
                <Route path="data-drift" element={<DataDrift />} />
                <Route path="schema-drift" element={<SchemaDrift />} />
                <Route path="metadata-generator" element={<MetadataGenerator />} />
                <Route path="reports/dq-reports" element={<DqReports />} />
                <Route path="reports/dq-domain-level-report" element={<DqDomainLevelReport />} />
                <Route path="data-validation" element={<DataValidation />} />
                <Route path="help" element={<Help />} />
                <Route path="my-request" element={<MyRequest />} />
                <Route path="*" element={<NotFound />} />
              </Route>
            </Routes>
          </Suspense>
        </Router>
      </ToastProvider>
    </ThemeProvider>
  )
}

export default App

