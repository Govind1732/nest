"use client"

import { createContext, useContext, useState, useCallback, useMemo } from "react"
import PropTypes from "prop-types"
import { Snackbar, Alert, AlertTitle, Typography, Box, IconButton, Slide } from "@mui/material"
import { Icon } from "@vds/icons"
import styles from "./Toast.module.css"

// Create context
const ToastContext = createContext({
  showToast: () => {},
  hideToast: () => {},
})

// Toast types
const TOAST_TYPES = {
  SUCCESS: "success",
  ERROR: "error",
  WARNING: "warning",
  INFO: "info",
}

// Default toast options
const DEFAULT_OPTIONS = {
  autoHideDuration: 5000,
  position: "bottom-right",
  showCloseButton: true,
}

// Toast Provider component
export const ToastProvider = ({ children }) => {
  const [toasts, setToasts] = useState([])

  // Generate unique ID for each toast
  const generateId = useCallback(() => {
    return `toast-${Date.now()}-${Math.floor(Math.random() * 1000)}`
  }, [])

  // Show toast
  const showToast = useCallback(
    (message, options = {}) => {
      const id = generateId()
      const newToast = {
        id,
        message: message || "Notification",
        type: options.type || TOAST_TYPES.INFO,
        title: options.title || "",
        autoHideDuration: options.autoHideDuration || DEFAULT_OPTIONS.autoHideDuration,
        position: options.position || DEFAULT_OPTIONS.position,
        showCloseButton:
          options.showCloseButton !== undefined ? options.showCloseButton : DEFAULT_OPTIONS.showCloseButton,
        action: options.action || null,
        onClose: options.onClose || null,
      }

      setToasts((prev) => [...prev, newToast])
      return id
    },
    [generateId],
  )

  // Hide toast
  const hideToast = useCallback((id) => {
    setToasts((prev) => prev.filter((toast) => toast.id !== id))
  }, [])

  // Shorthand methods for different toast types
  const success = useCallback(
    (message, options = {}) => {
      return showToast(message, { ...options, type: TOAST_TYPES.SUCCESS })
    },
    [showToast],
  )

  const error = useCallback(
    (message, options = {}) => {
      return showToast(message, { ...options, type: TOAST_TYPES.ERROR })
    },
    [showToast],
  )

  const warning = useCallback(
    (message, options = {}) => {
      return showToast(message, { ...options, type: TOAST_TYPES.WARNING })
    },
    [showToast],
  )

  const info = useCallback(
    (message, options = {}) => {
      return showToast(message, { ...options, type: TOAST_TYPES.INFO })
    },
    [showToast],
  )

  // Handle toast close
  const handleClose = useCallback(
    (id, reason, onClose) => {
      if (reason === "clickaway") return

      hideToast(id)

      if (onClose && typeof onClose === "function") {
        onClose(id)
      }
    },
    [hideToast],
  )

  // Get position style
  const getPositionStyle = useCallback((position) => {
    switch (position) {
      case "top-center":
        return { top: 24, left: "50%", transform: "translateX(-50%)" }
      case "top-left":
        return { top: 24, left: 24 }
      case "top-right":
        return { top: 24, right: 24 }
      case "bottom-center":
        return { bottom: 24, left: "50%", transform: "translateX(-50%)" }
      case "bottom-left":
        return { bottom: 24, left: 24 }
      case "bottom-right":
      default:
        return { bottom: 24, right: 24 }
    }
  }, [])

  // Group toasts by position
  const toastsByPosition = useMemo(() => {
    const grouped = {}

    toasts.forEach((toast) => {
      const position = toast.position || DEFAULT_OPTIONS.position
      if (!grouped[position]) {
        grouped[position] = []
      }
      grouped[position].push(toast)
    })

    return grouped
  }, [toasts])

  // Context value
  const contextValue = useMemo(
    () => ({
      showToast,
      hideToast,
      success,
      error,
      warning,
      info,
    }),
    [showToast, hideToast, success, error, warning, info],
  )

  return (
    <ToastContext.Provider value={contextValue}>
      {children}

      {/* Render toasts grouped by position */}
      {Object.entries(toastsByPosition).map(([position, positionToasts]) => (
        <Box key={position} className={styles.toastContainer} style={getPositionStyle(position)}>
          {positionToasts.map((toast) => (
            <Snackbar
              key={toast.id}
              open={true}
              autoHideDuration={toast.autoHideDuration}
              onClose={(event, reason) => handleClose(toast.id, reason, toast.onClose)}
              anchorOrigin={{ vertical: position.split("-")[0], horizontal: position.split("-")[1] }}
              TransitionComponent={Slide}
              className={styles.snackbar}
            >
              <Alert
                severity={toast.type}
                variant="filled"
                className={styles.alert}
                action={
                  <>
                    {toast.action}
                    {toast.showCloseButton && (
                      <IconButton size="small" aria-label="close" color="inherit" onClick={() => hideToast(toast.id)}>
                        <Icon name="close" size="small" />
                      </IconButton>
                    )}
                  </>
                }
              >
                {toast.title && <AlertTitle className={styles.alertTitle}>{toast.title}</AlertTitle>}
                <Typography variant="body2">{toast.message}</Typography>
              </Alert>
            </Snackbar>
          ))}
        </Box>
      ))}
    </ToastContext.Provider>
  )
}

ToastProvider.propTypes = {
  children: PropTypes.node.isRequired,
}

// Custom hook to use toast
export const useToast = () => {
  const context = useContext(ToastContext)

  if (!context) {
    throw new Error("useToast must be used within a ToastProvider")
  }

  return context
}

