"use client"

import { useState, useRef, useMemo } from "react"
import PropTypes from "prop-types"
import { Box, Paper, Typography, Skeleton, IconButton, Menu, MenuItem, Tooltip, useTheme } from "@mui/material"
import { Icon } from "@vds/icons"
import { Title, Body } from "@vds/typography"
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  RadialLinearScale,
  Tooltip as ChartTooltip,
  Legend,
  Filler,
} from "chart.js"
import { Line, Bar, Pie, Doughnut, PolarArea, Radar } from "react-chartjs-2"
import styles from "./ChartComponent.module.css"

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  RadialLinearScale,
  ChartTooltip,
  Legend,
  Filler,
)

// Default chart options
const defaultOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      position: "top",
      align: "start",
      labels: {
        boxWidth: 12,
        usePointStyle: true,
        pointStyle: "circle",
      },
    },
    tooltip: {
      backgroundColor: "rgba(0, 0, 0, 0.8)",
      titleColor: "#ffffff",
      bodyColor: "#ffffff",
      borderColor: "rgba(255, 255, 255, 0.2)",
      borderWidth: 1,
      padding: 10,
      displayColors: true,
      usePointStyle: true,
      intersect: false,
      mode: "index",
    },
  },
  scales: {
    x: {
      grid: {
        display: false,
      },
    },
    y: {
      beginAtZero: true,
      grid: {
        color: "rgba(0, 0, 0, 0.05)",
      },
    },
  },
  animation: {
    duration: 1000,
    easing: "easeOutQuart",
  },
}

// Chart types
const chartTypes = {
  line: Line,
  bar: Bar,
  pie: Pie,
  doughnut: Doughnut,
  polarArea: PolarArea,
  radar: Radar,
}

// Export options
const exportOptions = [
  { label: "PNG Image", value: "png" },
  { label: "JPEG Image", value: "jpeg" },
  { label: "SVG Image", value: "svg" },
  { label: "CSV Data", value: "csv" },
]

const ChartComponent = ({
  type = "bar",
  data,
  options = {},
  title,
  subtitle,
  loading = false,
  height = 300,
  width = "100%",
  exportable = true,
  refreshable = false,
  onRefresh = null,
  emptyStateMessage = "No data available",
  errorMessage = "Error loading chart data",
  error = null,
  actions = [],
  colorPalette = null,
  showLegend = true,
  legendPosition = "top",
  animation = true,
  responsive = true,
  gridLines = true,
  tooltips = true,
  borderRadius = 4,
  fill = false,
  tension = 0.4,
}) => {
  const chartRef = useRef(null)
  const [anchorEl, setAnchorEl] = useState(null)
  const theme = useTheme()

  // Generate color palette based on theme
  const defaultColorPalette = useMemo(
    () => [
      "#EE0000", // Verizon Red
      "#000000", // Black
      "#3366CC", // Blue
      "#FF9900", // Orange
      "#109618", // Green
      "#990099", // Purple
      "#DD4477", // Pink
      "#66AA00", // Lime
      "#B82E2E", // Dark Red
      "#316395", // Dark Blue
    ],
    [],
  )

  // Merge options with defaults
  const mergedOptions = useMemo(() => {
    const merged = { ...defaultOptions, ...options }

    // Apply custom settings
    merged.plugins.legend.display = showLegend
    merged.plugins.legend.position = legendPosition
    merged.animation = animation ? merged.animation : false
    merged.responsive = responsive
    merged.maintainAspectRatio = false

    // Apply grid lines setting
    if (!gridLines) {
      merged.scales = {
        ...merged.scales,
        x: { ...merged.scales.x, grid: { display: false } },
        y: { ...merged.scales.y, grid: { display: false } },
      }
    }

    // Apply tooltips setting
    if (!tooltips) {
      merged.plugins.tooltip.enabled = false
    }

    return merged
  }, [options, showLegend, legendPosition, animation, responsive, gridLines, tooltips])

  // Process chart data with custom styling
  const processedData = useMemo(() => {
    if (!data) return null

    const colors = colorPalette || defaultColorPalette
    const result = { ...data }

    if (result.datasets) {
      result.datasets = result.datasets.map((dataset, index) => {
        const color = dataset.backgroundColor || colors[index % colors.length]
        const borderColor = dataset.borderColor || color

        // Apply common styling
        const commonStyles = {
          backgroundColor: color,
          borderColor,
          borderWidth: 2,
        }

        // Apply chart-specific styling
        if (type === "line") {
          return {
            ...dataset,
            ...commonStyles,
            tension,
            fill,
            pointBackgroundColor: borderColor,
            pointBorderColor: "#ffffff",
            pointBorderWidth: 2,
            pointRadius: 4,
            pointHoverRadius: 6,
          }
        } else if (type === "bar") {
          return {
            ...dataset,
            ...commonStyles,
            borderRadius,
            maxBarThickness: 50,
            borderWidth: 0,
            backgroundColor: Array.isArray(dataset.backgroundColor) ? dataset.backgroundColor : color,
          }
        } else if (["pie", "doughnut", "polarArea"].includes(type)) {
          return {
            ...dataset,
            backgroundColor: Array.isArray(dataset.backgroundColor)
              ? dataset.backgroundColor
              : data.labels.map((_, i) => colors[i % colors.length]),
            borderColor: "#ffffff",
            borderWidth: 2,
            hoverOffset: 10,
          }
        } else if (type === "radar") {
          return {
            ...dataset,
            ...commonStyles,
            pointBackgroundColor: borderColor,
            pointBorderColor: "#ffffff",
            pointBorderWidth: 2,
            pointRadius: 3,
            pointHoverRadius: 5,
            fill,
          }
        }

        return { ...dataset, ...commonStyles }
      })
    }

    return result
  }, [data, type, colorPalette, defaultColorPalette, fill, tension, borderRadius])

  // Handle export menu
  const handleExportClick = (event) => {
    setAnchorEl(event.currentTarget)
  }

  const handleExportClose = () => {
    setAnchorEl(null)
  }

  // Export chart as image or data
  const handleExport = (format) => {
    handleExportClose()

    if (!chartRef.current) return

    const chart = chartRef.current

    if (format === "csv") {
      // Export as CSV
      if (!data || !data.labels || !data.datasets) return

      const headers = ["Label", ...data.datasets.map((ds) => ds.label || "Dataset")]
      const rows = data.labels.map((label, i) => {
        return [label, ...data.datasets.map((ds) => ds.data[i])]
      })

      const csvContent = [headers.join(","), ...rows.map((row) => row.join(","))].join("\n")

      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
      const url = URL.createObjectURL(blob)
      const link = document.createElement("a")
      link.setAttribute("href", url)
      link.setAttribute("download", `${title || "chart"}_data.csv`)
      link.style.visibility = "hidden"
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
    } else {
      // Export as image
      const link = document.createElement("a")
      link.download = `${title || "chart"}.${format}`
      link.href = chart.toBase64Image(format)
      link.click()
    }
  }

  // Render the appropriate chart type
  const renderChart = () => {
    if (loading) {
      return (
        <Box className={styles.loadingContainer} height={height}>
          <Skeleton variant="rectangular" width="100%" height="100%" />
        </Box>
      )
    }

    if (error) {
      return (
        <Box className={styles.errorContainer} height={height}>
          <Icon name="error" size="large" color="#EE0000" />
          <Typography variant="body1" color="error">
            {errorMessage}
          </Typography>
          {refreshable && (
            <IconButton onClick={onRefresh} size="small" className={styles.refreshButton}>
              <Icon name="refresh" size="medium" />
            </IconButton>
          )}
        </Box>
      )
    }

    if (!data || !processedData || !processedData.datasets || processedData.datasets.length === 0) {
      return (
        <Box className={styles.emptyContainer} height={height}>
          <Icon name="info" size="large" />
          <Typography variant="body1">{emptyStateMessage}</Typography>
        </Box>
      )
    }

    const ChartComponent = chartTypes[type]

    if (!ChartComponent) {
      return (
        <Box className={styles.errorContainer} height={height}>
          <Typography variant="body1" color="error">
            Invalid chart type: {type}
          </Typography>
        </Box>
      )
    }

    return (
      <Box height={height} width={width} className={styles.chartContainer}>
        <ChartComponent ref={chartRef} data={processedData} options={mergedOptions} />
      </Box>
    )
  }

  return (
    <Paper className={styles.container} elevation={2}>
      {/* Chart Header */}
      <Box className={styles.header}>
        <Box className={styles.titleContainer}>
          {title && (
            <Title size="small" bold>
              {title}
            </Title>
          )}
          {subtitle && (
            <Body size="small" className={styles.subtitle}>
              {subtitle}
            </Body>
          )}
        </Box>

        <Box className={styles.actions}>
          {actions.map((action, index) => (
            <Tooltip key={index} title={action.tooltip || action.label}>
              <IconButton
                onClick={action.onClick}
                size="small"
                disabled={action.disabled}
                className={styles.actionButton}
              >
                <Icon name={action.icon} size="medium" />
              </IconButton>
            </Tooltip>
          ))}

          {refreshable && onRefresh && (
            <Tooltip title="Refresh">
              <IconButton onClick={onRefresh} size="small" className={styles.actionButton}>
                <Icon name="refresh" size="medium" />
              </IconButton>
            </Tooltip>
          )}

          {exportable && (
            <>
              <Tooltip title="Export">
                <IconButton onClick={handleExportClick} size="small" className={styles.actionButton}>
                  <Icon name="download" size="medium" />
                </IconButton>
              </Tooltip>

              <Menu anchorEl={anchorEl} open={Boolean(anchorEl)} onClose={handleExportClose}>
                {exportOptions.map((option) => (
                  <MenuItem key={option.value} onClick={() => handleExport(option.value)}>
                    {option.label}
                  </MenuItem>
                ))}
              </Menu>
            </>
          )}
        </Box>
      </Box>

      {/* Chart Content */}
      <Box className={styles.content}>{renderChart()}</Box>
    </Paper>
  )
}

ChartComponent.propTypes = {
  type: PropTypes.oneOf(["line", "bar", "pie", "doughnut", "polarArea", "radar"]),
  data: PropTypes.object,
  options: PropTypes.object,
  title: PropTypes.string,
  subtitle: PropTypes.string,
  loading: PropTypes.bool,
  height: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  width: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  exportable: PropTypes.bool,
  refreshable: PropTypes.bool,
  onRefresh: PropTypes.func,
  emptyStateMessage: PropTypes.string,
  errorMessage: PropTypes.string,
  error: PropTypes.any,
  actions: PropTypes.arrayOf(
    PropTypes.shape({
      icon: PropTypes.string.isRequired,
      label: PropTypes.string,
      tooltip: PropTypes.string,
      onClick: PropTypes.func.isRequired,
      disabled: PropTypes.bool,
    }),
  ),
  colorPalette: PropTypes.array,
  showLegend: PropTypes.bool,
  legendPosition: PropTypes.oneOf(["top", "bottom", "left", "right"]),
  animation: PropTypes.bool,
  responsive: PropTypes.bool,
  gridLines: PropTypes.bool,
  tooltips: PropTypes.bool,
  borderRadius: PropTypes.number,
  fill: PropTypes.bool,
  tension: PropTypes.number,
}

export default ChartComponent

