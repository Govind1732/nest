"use client"

// import React, { useEffect, useRef } from 'react';
// import './Test.css';
// import Datalist from '../Components/LayoutComponents/Datalist/Datalist';
// import SearchIcon from '@mui/icons-material/Search';

// const Test = () => {
//     const browserOptions = ["Edge", "Firefox", "Chrome", "Opera", "Safari"];
//     const environmentOptions = ["Development", "Staging", "Production"];
//     const dbNameOptions = ["db1", "db2", "db3"];
//     const tableNameOptions = ["table1", "table2", "table3cvcxvxcvcxvgsfdgdfsgfdg"];
//     const tickcanvasRef = useRef(null);

//     useEffect(() => {
//         const canvas = tickcanvasRef.current;
//         const context = canvas.getContext('2d');

//         // Set canvas dimensions
//         const scale = 2; // Scale factor for higher resolution
//         canvas.width = 50 * scale;
//         canvas.height = 50 * scale;
//         canvas.style.width = '50px';
//         canvas.style.height = '50px';
//         context.scale(scale, scale);

//         // Draw tick mark
//         context.beginPath();
//         context.moveTo(10, 25); // Starting point of the tick
//         context.lineTo(20, 35); // Middle point of the tick
//         context.lineTo(40, 15); // End point of the tick
//         context.strokeStyle = '#000'; // Tick color
//         context.lineWidth = 2; // Tick width
//         context.stroke();
//     }, []);

//     return (
//         <>
//             <Datalist id="browsers" name="browser" label="Choose your browser from the list:" options={browserOptions} />
//             <Datalist id="environments" name="environment" label="Choose your environment:" options={environmentOptions} />
//             <Datalist id="dbNames" name="dbName" label="Choose your database name:" options={dbNameOptions} />
//             <Datalist id="tableNames" name="tableName" label="Choose your table name:" options={tableNameOptions} />

//             <div className="search-box">
//                 <div className="row">
//                     <input type='text' id='input-box' placeholder='Search anything' autoComplete='off' />
//                     <button><SearchIcon /></button>
//                 </div>
//                 <div className="result-box">
//                     <ul>
//                         <li>js</li>
//                         <li>ts</li>
//                     </ul>
//                 </div>
//             </div>
//             <canvas ref={tickcanvasRef} />
//             <svg
//                 xmlns="http://www.w3.org/2000/svg"
//                 viewBox="0 0 24 24"
//                 width="24"
//                 height="24"
//                 fill="none"
//                 stroke="currentColor"
//                 strokeWidth="2"
//                 strokeLinecap="round"
//                 strokeLinejoin="round"
//             >
//                 <path d="M1 21h4V9H1v12zM23 10c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14 2 7.59 8.41C7.22 8.78 7 9.3 7 9.83V19c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-1z" />
//             </svg>

//         </>
//     );
// };

// export default Test;
const Test = () => {
  return (
    <div>
      <h1>Test Component</h1>
      <p>This is a test component.</p>
    </div>
  )
}
export default Test

