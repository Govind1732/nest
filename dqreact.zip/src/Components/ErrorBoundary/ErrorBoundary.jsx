"use client"

import React from "react"
import PropTypes from "prop-types"
import { Button } from "@vds/buttons"
import { Title, Body } from "@vds/typography"
import { Icon } from "@vds/icons"
import styles from "./ErrorBoundary.module.css"

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      hasError: false,
      error: null,
      errorInfo: null,
    }
  }

  static getDerivedStateFromError(error) {
    // Update state so the next render will show the fallback UI
    return { hasError: true, error }
  }

  componentDidCatch(error, errorInfo) {
    // Log the error to an error reporting service
    console.error("Error caught by ErrorBoundary:", error, errorInfo)
    this.setState({ errorInfo })

    // You could also log to an error monitoring service here
    // Example: logErrorToService(error, errorInfo);
  }

  handleReset = () => {
    this.setState({ hasError: false, error: null, errorInfo: null })

    // If a reset handler was provided, call it
    if (this.props.onReset) {
      this.props.onReset()
    }
  }

  handleReload = () => {
    window.location.reload()
  }

  render() {
    if (this.state.hasError) {
      // Render fallback UI
      return (
        <div className={styles.errorContainer}>
          <div className={styles.errorContent}>
            <Icon name="error" size="XXLarge" color="#EE0000" />
            <Title size="large" bold color="#000000" className={styles.errorTitle}>
              Something went wrong
            </Title>
            <Body size="medium" className={styles.errorMessage}>
              {this.props.fallbackMessage || "We're sorry, but there was an error loading this component."}
            </Body>

            {this.props.showErrorDetails && this.state.error && (
              <div className={styles.errorDetails}>
                <Body size="small" bold>
                  Error details:
                </Body>
                <pre className={styles.errorStack}>{this.state.error.toString()}</pre>
              </div>
            )}

            <div className={styles.actionButtons}>
              <Button use="secondary" size="medium" onClick={this.handleReset}>
                Try Again
              </Button>
              <Button use="primary" size="medium" onClick={this.handleReload}>
                Reload Page
              </Button>
            </div>
          </div>
        </div>
      )
    }

    // If there's no error, render children normally
    return this.props.children
  }
}

ErrorBoundary.propTypes = {
  children: PropTypes.node.isRequired,
  fallbackMessage: PropTypes.string,
  showErrorDetails: PropTypes.bool,
  onReset: PropTypes.func,
}

ErrorBoundary.defaultProps = {
  fallbackMessage: "",
  showErrorDetails: false,
}

export default ErrorBoundary

