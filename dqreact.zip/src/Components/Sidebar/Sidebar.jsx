"use client"

import { useState, useEffect, useRef, useCallback, memo } from "react"
import { Link, useLocation } from "react-router-dom"
import Tooltip from "@mui/material/Tooltip"
import { ListGroup, ListGroupItem, ListGroupItemTitle } from "@vds/lists"
import { ButtonIcon } from "@vds/button-icons"
import { Icon } from "@vds/icons"
import { Title, Body } from "@vds/typography"
import styles from "./Sidebar.module.css"
import PropTypes from "prop-types"

// Define sidebar items as a constant outside the component to prevent re-creation
const SIDEBAR_ITEMS = [
  {
    title: "Home",
    icon: "home",
    path: "/dataQuality/",
    action: "closeDrawer",
  },
  {
    title: "Profiling",
    icon: "services",
    action: "profiling",
    subItems: [
      { title: "Auto Profile", path: "/dataQuality/auto-profile" },
      { title: "Rule Profile - DT Ran", path: "/dataQuality/rule-profile-dtran" },
      { title: "Rule Profile - One Corp", path: "/dataQuality/rule-profile-onecorp" },
      { title: "Rule Profile - MLE", path: "/dataQuality/rule-profile-mle" },
      { title: "Data Profile", path: "/dataQuality/data-profile" },
      { title: "Custom Profile", path: "/dataQuality/custom-profile" },
      { title: "DataQuality Validation", path: "/dataQuality/dataquality-validation" },
    ],
  },
  {
    title: "API Integration",
    icon: "server-stack",
    action: "API Integration",
    subItems: [
      { title: "DQ Metrics API", path: "/dataQuality/dq-metrics" },
      { title: "ETL Pipeline Integration API", path: "/dataQuality/etl-pipeline" },
      { title: "DQ Fallout Subscription", path: "/dataQuality/dq-falloutprediction" },
      { title: "DQ Data Remediation", path: "/dataQuality/dq-dataremediation" },
      { title: "Data Drift", path: "/dataQuality/data-drift" },
      { title: "Schema Drift", path: "/dataQuality/schema-drift" },
      { title: "Metadata Generator", path: "/dataQuality/metadata-generator" },
    ],
  },
  {
    title: "Reporting",
    icon: "professional-services-chart",
    action: "Reporting",
    subItems: [
      { title: "DQ Report", path: "/dataQuality/dq-reports" },
      { title: "DQ Domain Level Report", path: "/dataQuality/dq-domainlevelreport" },
    ],
  },
]

// Memoized SidebarButton component
const SidebarButton = memo(({ icon, title, onClick, isSelected }) => (
  <Tooltip title={title} placement="right">
    <button
      type="button"
      onClick={onClick}
      className={`${styles.sidebarItems} ${isSelected ? styles.selected : ""}`}
      aria-label={title}
    >
      <ListGroupItem actionElement="none">
        <ListGroupItemTitle>
          <Icon name={icon} size="XLarge" color={isSelected ? "#EE0000" : "#000000"} />
        </ListGroupItemTitle>
      </ListGroupItem>
    </button>
  </Tooltip>
))

SidebarButton.propTypes = {
  icon: PropTypes.string.isRequired,
  title: PropTypes.string.isRequired,
  onClick: PropTypes.func.isRequired,
  isSelected: PropTypes.bool.isRequired,
}

SidebarButton.displayName = "SidebarButton"

// Memoized SubMenu component
const SubMenu = memo(({ title, items, onClose, currentPath }) => {
  return (
    <div className={styles.options}>
      <ul>
        <li className={styles.optionHeading}>
          <Title bold color="#000000">
            {title}
          </Title>
          <ButtonIcon
            kind="ghost"
            size="large"
            surface="light"
            surfaceType="colorFill"
            hideBorder
            iconOffset={{ x: 0, y: 0 }}
            renderIcon={() => <Icon name="close" />}
            onClick={onClose}
            aria-label="Close submenu"
          />
        </li>
        {items.map(({ title: itemTitle, path }) => (
          <Link key={path} to={path} className={styles.link}>
            <li className={currentPath === path ? styles.selected : ""}>
              <Body size="large" color="#000000">
                {itemTitle}
              </Body>
            </li>
          </Link>
        ))}
      </ul>
    </div>
  )
})

SubMenu.propTypes = {
  title: PropTypes.string.isRequired,
  items: PropTypes.arrayOf(
    PropTypes.shape({
      title: PropTypes.string.isRequired,
      path: PropTypes.string.isRequired,
    }),
  ).isRequired,
  onClose: PropTypes.func.isRequired,
  currentPath: PropTypes.string.isRequired,
}

SubMenu.displayName = "SubMenu"

// Main Sidebar component
const Sidebar = () => {
  const [selectedOption, setSelectedOption] = useState("Home")
  const [drawerOpen, setDrawerOpen] = useState(false)
  const sidebarRef = useRef(null)
  const sidebarOptionsRef = useRef(null)

  const location = useLocation()
  const currentPath = location.pathname

  // Memoize the getSelectedSection function to prevent recalculation
  const getSelectedSection = useCallback((path) => {
    if (path === "/dataQuality/" || path === "/dataQuality") {
      return "Home"
    }

    const profilingPaths = [
      "/dataQuality/auto-profile",
      "/dataQuality/rule-profile-dtran",
      "/dataQuality/rule-profile-onecorp",
      "/dataQuality/rule-profile-mle",
      "/dataQuality/data-profile",
      "/dataQuality/custom-profile",
      "/dataQuality/dataquality-validation",
      "/dataQuality/referental-integrity",
    ]

    const apiPaths = [
      "/dataQuality/dq-metrics",
      "/dataQuality/etl-pipeline",
      "/dataQuality/dq-falloutprediction",
      "/dataQuality/dq-dataremediation",
      "/dataQuality/data-drift",
      "/dataQuality/schema-drift",
      "/dataQuality/metadata-generator",
    ]

    const reportingPaths = ["/dataQuality/dq-reports", "/dataQuality/dq-domainlevelreport"]

    if (profilingPaths.some((p) => path.includes(p))) return "profiling"
    if (apiPaths.some((p) => path.includes(p))) return "API Integration"
    if (reportingPaths.some((p) => path.includes(p))) return "Reporting"

    return ""
  }, [])

  const selectedSection = getSelectedSection(currentPath)

  // Memoize the handleSidebarClick function
  const handleSidebarClick = useCallback(
    (option, path) => {
      if (path) {
        setDrawerOpen(false)
        return
      }

      if (option === selectedOption && drawerOpen) {
        setDrawerOpen(false)
      } else {
        setSelectedOption(option)
        setDrawerOpen(true)
      }
    },
    [selectedOption, drawerOpen],
  )

  // Handle clicks outside the sidebar
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        sidebarRef.current &&
        !sidebarRef.current.contains(event.target) &&
        sidebarOptionsRef.current &&
        !sidebarOptionsRef.current.contains(event.target)
      ) {
        setDrawerOpen(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  // Close drawer when route changes
  useEffect(() => {
    setDrawerOpen(false)
  }, [currentPath])

  return (
    <>
      <div className={styles.sidebar} ref={sidebarRef}>
        <ListGroup topLine={false} bottomLine={false} surface="light" viewport="desktop">
          {SIDEBAR_ITEMS.map((item, index) =>
            item.path ? (
              <Link key={index} to={item.path}>
                <SidebarButton
                  icon={item.icon}
                  title={item.title}
                  onClick={() => handleSidebarClick(item.action, item.path)}
                  isSelected={item.title === selectedSection}
                />
              </Link>
            ) : (
              <SidebarButton
                key={index}
                icon={item.icon}
                title={item.title}
                onClick={() => handleSidebarClick(item.action, item.path)}
                isSelected={item.action === selectedSection}
              />
            ),
          )}
        </ListGroup>
      </div>

      <div
        className={`${styles.sidebarOptions} ${drawerOpen ? styles.open : ""}`}
        ref={sidebarOptionsRef}
        role="menu"
        aria-hidden={!drawerOpen}
      >
        {SIDEBAR_ITEMS.find((item) => item.action === selectedOption)?.subItems && (
          <SubMenu
            title={SIDEBAR_ITEMS.find((item) => item.action === selectedOption).title}
            items={SIDEBAR_ITEMS.find((item) => item.action === selectedOption).subItems}
            onClose={() => setDrawerOpen(false)}
            currentPath={currentPath}
          />
        )}
      </div>
    </>
  )
}

export default Sidebar

