"use client"

import { Modal } from "react-bootstrap"
import { Button } from "@vds/core"

const ModalComponent = ({ show, handleClose, modalTitle, modalBody }) => {
  return (
    <Modal show={show} onHide={handleClose} dialogClassName="modal-90w" variant="secondary">
      <Modal.Header closeButton>
        <Modal.Title>{modalTitle}</Modal.Title>
      </Modal.Header>
      <Modal.Body>{modalBody}</Modal.Body>
      <Modal.Footer>
        <Button use="secondary" onClick={handleClose}>
          Close
        </Button>
      </Modal.Footer>
    </Modal>
  )
}

export default ModalComponent

