const Datalist = ({ id, name, label, options }) => {
  return (
    <>
      {/* label for===input id */}
      {/* input list===datalist id */}
      <label for={name}>{label}</label>
      <input list={id} id={name} name={name} />

      <datalist id={id}>
        {options.map((option, index) => (
          <option key={index} value={option} />
        ))}
      </datalist>
    </>
  )
}

export default Datalist

