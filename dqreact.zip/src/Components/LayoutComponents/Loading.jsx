import { Backdrop, Container } from "@mui/material"
import { GridLoader } from "react-spinners"

const Loading = ({ loading }) => {
  return (
    <Backdrop sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }} open={loading}>
      <Container
        className="loading-overlay"
        sx={{ display: "flex", justifyContent: "center", alignItems: "center", height: "100vh" }}
      >
        <GridLoader color="#ff0000" loading={loading} size={20} aria-label="Loading Spinner" data-testid="loader" />
      </Container>
    </Backdrop>
  )
}

export default Loading

