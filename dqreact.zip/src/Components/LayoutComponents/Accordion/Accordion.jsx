"use client"

import { useState } from "react"
import "./Accordion.css"

const Accordion = ({ title, children }) => {
  const [isOpen, setIsOpen] = useState(false)

  const toggleAccordion = () => {
    setIsOpen(!isOpen)
  }

  return (
    <div className="accordion">
      <button className="accordion-button" onClick={toggleAccordion}>
        {title}
      </button>
      <div className={`accordion-content ${isOpen ? "open" : ""}`}>{children}</div>
    </div>
  )
}

export default Accordion

