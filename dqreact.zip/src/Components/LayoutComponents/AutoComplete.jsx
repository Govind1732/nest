"use client"

import { memo, useMemo } from "react"
import Autocomplete from "@mui/material/Autocomplete"
import TextField from "@mui/material/TextField"
import Checkbox from "@mui/material/Checkbox"
import ListItemText from "@mui/material/ListItemText"
import Chip from "@mui/material/Chip"
import CircularProgress from "@mui/material/CircularProgress"
import { useTheme } from "@mui/material/styles"

// Optimized AutoComplete component with memoization
const AutoComplete = memo(({ options, selectedOptions, loading, handleChange, label = "Projects", placeholder }) => {
  const theme = useTheme()

  // Memoize the options to prevent unnecessary re-renders
  const sortedOptions = useMemo(() => {
    return ["Select All", ...(options || [])].sort()
  }, [options])

  // Memoize the chip rendering function
  const renderTags = useMemo(() => {
    return (value, getTagProps) => {
      if (value.length > 2) {
        return [
          ...value.slice(0, 2).map((option, index) => (
            <Chip
              key={`chip-${option}-${index}`}
              variant="secondary"
              label={option}
              {...getTagProps({ index })}
              sx={{
                backgroundColor: theme.palette.primary.light,
                color: theme.palette.primary.contrastText,
                "&:hover": {
                  backgroundColor: theme.palette.primary.main,
                },
              }}
            />
          )),
          <Chip key="more-chip" variant="outlined" label={`+${value.length - 2} more`} />,
        ]
      }

      return value.map((option, index) => (
        <Chip
          key={`chip-${option}-${index}`}
          variant="secondary"
          label={option}
          {...getTagProps({ index })}
          sx={{
            backgroundColor: theme.palette.primary.light,
            color: theme.palette.primary.contrastText,
            "&:hover": {
              backgroundColor: theme.palette.primary.main,
            },
          }}
        />
      ))
    }
  }, [theme.palette.primary])

  return (
    <Autocomplete
      multiple
      id="checkboxes-tags"
      options={sortedOptions}
      disableCloseOnSelect
      getOptionLabel={(option) => option}
      value={selectedOptions || []}
      onChange={handleChange}
      renderOption={(props, option, { selected }) => (
        <li {...props}>
          <Checkbox
            checked={option === "Select All" ? selectedOptions?.length === options?.length : selected}
            sx={{
              color: theme.palette.primary.main,
              "&.Mui-checked": {
                color: theme.palette.primary.main,
              },
            }}
          />
          <ListItemText primary={option} />
        </li>
      )}
      size="small"
      renderInput={(params) => (
        <TextField
          {...params}
          variant="outlined"
          label={label}
          placeholder={selectedOptions?.length === 0 ? placeholder || `Select your ${label}` : ""}
          InputProps={{
            ...params.InputProps,
            style: { borderRadius: 4 },
            endAdornment: (
              <>
                {loading ? <CircularProgress color="inherit" size={20} /> : null}
                {params.InputProps.endAdornment}
              </>
            ),
          }}
          sx={{
            "& .MuiOutlinedInput-root": {
              "&:hover fieldset": {
                borderColor: theme.palette.primary.main,
              },
              "&.Mui-focused fieldset": {
                borderColor: theme.palette.primary.main,
              },
            },
          }}
        />
      )}
      renderTags={renderTags}
      ListboxProps={{
        style: {
          maxHeight: "200px",
        },
      }}
      filterSelectedOptions={false}
      limitTags={2}
    />
  )
})

AutoComplete.displayName = "AutoComplete"

export default AutoComplete

