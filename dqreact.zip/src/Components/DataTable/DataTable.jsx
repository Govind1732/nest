"use client"

import { useState, useEffect, useMemo, useCallback } from "react"
import PropTypes from "prop-types"
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
  Paper,
  TextField,
  IconButton,
  Tooltip,
  Box,
  Typography,
  Checkbox,
  Chip,
} from "@mui/material"
import { Icon } from "@vds/icons"
import { Button } from "@vds/buttons"
import { debounce } from "../../utils/performance"
import styles from "./DataTable.module.css"

const DataTable = ({
  columns,
  data,
  title,
  loading = false,
  pagination = true,
  selectable = false,
  onRowSelect = () => {},
  onRowClick = null,
  actions = [],
  defaultSortColumn = null,
  defaultSortDirection = "asc",
  searchable = true,
  searchPlaceholder = "Search...",
  emptyStateMessage = "No data available",
  rowsPerPageOptions = [10, 25, 50, 100],
  defaultRowsPerPage = 10,
  stickyHeader = true,
  maxHeight = "600px",
  dense = false,
  exportable = false,
  onExport = null,
  customFilters = null,
  onFilterChange = null,
  refreshable = false,
  onRefresh = null,
  highlightedRows = [],
  customRowStyle = null,
}) => {
  // State for table controls
  const [page, setPage] = useState(0)
  const [rowsPerPage, setRowsPerPage] = useState(defaultRowsPerPage)
  const [sortColumn, setSortColumn] = useState(defaultSortColumn)
  const [sortDirection, setSortDirection] = useState(defaultSortDirection)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedRows, setSelectedRows] = useState([])
  const [filters, setFilters] = useState({})

  // Reset page when data changes
  useEffect(() => {
    setPage(0)
  }, [data.length, searchTerm, JSON.stringify(filters)])

  // Handle search input with debounce
  const handleSearchChange = useCallback(
    debounce((event) => {
      setSearchTerm(event.target.value)
    }, 300),
    [],
  )

  // Handle sort column change
  const handleSort = (column) => {
    const isAsc = sortColumn === column && sortDirection === "asc"
    setSortDirection(isAsc ? "desc" : "asc")
    setSortColumn(column)
  }

  // Handle row selection
  const handleSelectRow = (event, id) => {
    event.stopPropagation()
    const selectedIndex = selectedRows.indexOf(id)
    let newSelected = []

    if (selectedIndex === -1) {
      newSelected = [...selectedRows, id]
    } else {
      newSelected = selectedRows.filter((rowId) => rowId !== id)
    }

    setSelectedRows(newSelected)
    onRowSelect(newSelected)
  }

  // Handle select all rows
  const handleSelectAllClick = (event) => {
    if (event.target.checked) {
      const newSelected = filteredData.map((row) => row.id)
      setSelectedRows(newSelected)
      onRowSelect(newSelected)
    } else {
      setSelectedRows([])
      onRowSelect([])
    }
  }

  // Handle pagination
  const handleChangePage = (event, newPage) => {
    setPage(newPage)
  }

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(Number.parseInt(event.target.value, 10))
    setPage(0)
  }

  // Handle filter changes
  const handleFilterChange = (filterName, value) => {
    const newFilters = { ...filters, [filterName]: value }
    setFilters(newFilters)
    if (onFilterChange) {
      onFilterChange(newFilters)
    }
  }

  // Apply sorting and filtering to data
  const filteredData = useMemo(() => {
    let filtered = [...data]

    // Apply search filter
    if (searchTerm) {
      const searchLower = searchTerm.toLowerCase()
      filtered = filtered.filter((row) => {
        return columns.some((column) => {
          const value = row[column.field]
          if (value === null || value === undefined) return false
          return String(value).toLowerCase().includes(searchLower)
        })
      })
    }

    // Apply custom filters
    if (Object.keys(filters).length > 0) {
      filtered = filtered.filter((row) => {
        return Object.entries(filters).every(([key, value]) => {
          if (!value) return true // Skip empty filters
          const rowValue = row[key]
          if (Array.isArray(value)) {
            return value.length === 0 || value.includes(rowValue)
          }
          return rowValue === value
        })
      })
    }

    // Apply sorting
    if (sortColumn) {
      filtered.sort((a, b) => {
        const valueA = a[sortColumn]
        const valueB = b[sortColumn]

        // Handle null or undefined values
        if (valueA === null || valueA === undefined) return sortDirection === "asc" ? -1 : 1
        if (valueB === null || valueB === undefined) return sortDirection === "asc" ? 1 : -1

        // Compare based on data type
        if (typeof valueA === "string") {
          return sortDirection === "asc" ? valueA.localeCompare(valueB) : valueB.localeCompare(valueA)
        } else {
          return sortDirection === "asc" ? valueA - valueB : valueB - valueA
        }
      })
    }

    return filtered
  }, [data, searchTerm, sortColumn, sortDirection, filters, columns])

  // Get current page data
  const paginatedData = useMemo(() => {
    if (!pagination) return filteredData
    return filteredData.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
  }, [filteredData, page, rowsPerPage, pagination])

  // Check if a row is selected
  const isRowSelected = (id) => selectedRows.indexOf(id) !== -1

  // Handle export
  const handleExport = () => {
    if (onExport) {
      onExport(filteredData)
    } else {
      // Default CSV export
      const headers = columns.map((column) => column.headerName).join(",")
      const rows = filteredData
        .map((row) =>
          columns
            .map((column) => {
              const value = row[column.field]
              // Handle values with commas by wrapping in quotes
              return typeof value === "string" && value.includes(",") ? `"${value}"` : value
            })
            .join(","),
        )
        .join("\n")

      const csv = `${headers}\n${rows}`
      const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" })
      const url = URL.createObjectURL(blob)
      const link = document.createElement("a")
      link.setAttribute("href", url)
      link.setAttribute("download", `${title || "data"}_export.csv`)
      link.style.visibility = "hidden"
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
    }
  }

  // Render cell content based on column type
  const renderCellContent = (row, column) => {
    const value = row[column.field]

    if (value === null || value === undefined) {
      return column.emptyValue || "-"
    }

    if (column.renderCell) {
      return column.renderCell({ value, row })
    }

    switch (column.type) {
      case "date":
        return new Date(value).toLocaleDateString()
      case "datetime":
        return new Date(value).toLocaleString()
      case "boolean":
        return value ? "Yes" : "No"
      case "number":
        return typeof value === "number" ? value.toLocaleString() : value
      case "status":
        return (
          <Chip
            label={value}
            color={
              value === "Success" || value === "Completed"
                ? "success"
                : value === "Error" || value === "Failed"
                  ? "error"
                  : value === "Warning" || value === "Pending"
                    ? "warning"
                    : "default"
            }
            size="small"
          />
        )
      default:
        return value
    }
  }

  return (
    <Paper className={styles.tableWrapper} elevation={2}>
      {/* Table Header */}
      <Box className={styles.tableHeader}>
        {title && (
          <Typography variant="h6" component="h2" className={styles.tableTitle}>
            {title}
          </Typography>
        )}

        <Box className={styles.tableControls}>
          {/* Search Field */}
          {searchable && (
            <TextField
              placeholder={searchPlaceholder}
              onChange={handleSearchChange}
              variant="outlined"
              size="small"
              className={styles.searchField}
              InputProps={{
                startAdornment: <Icon name="search" size="small" />,
              }}
            />
          )}

          {/* Custom Filters */}
          {customFilters && <Box className={styles.filtersContainer}>{customFilters}</Box>}

          {/* Action Buttons */}
          <Box className={styles.actionButtons}>
            {refreshable && (
              <Tooltip title="Refresh">
                <IconButton onClick={onRefresh} size="small">
                  <Icon name="refresh" size="medium" />
                </IconButton>
              </Tooltip>
            )}

            {exportable && (
              <Button use="secondary" size="small" onClick={handleExport} className={styles.exportButton}>
                Export
              </Button>
            )}

            {actions.map((action, index) => (
              <Button
                key={index}
                use={action.primary ? "primary" : "secondary"}
                size="small"
                onClick={action.onClick}
                disabled={action.disabled}
                className={styles.actionButton}
              >
                {action.label}
              </Button>
            ))}
          </Box>
        </Box>
      </Box>

      {/* Table Content */}
      <TableContainer style={{ maxHeight: stickyHeader ? maxHeight : "none" }} className={styles.tableContainer}>
        <Table stickyHeader={stickyHeader} size={dense ? "small" : "medium"} className={styles.table}>
          <TableHead>
            <TableRow>
              {/* Selection Checkbox */}
              {selectable && (
                <TableCell padding="checkbox">
                  <Checkbox
                    indeterminate={selectedRows.length > 0 && selectedRows.length < filteredData.length}
                    checked={filteredData.length > 0 && selectedRows.length === filteredData.length}
                    onChange={handleSelectAllClick}
                  />
                </TableCell>
              )}

              {/* Column Headers */}
              {columns.map((column) => (
                <TableCell
                  key={column.field}
                  align={column.type === "number" ? "right" : "left"}
                  style={{
                    minWidth: column.minWidth || "auto",
                    width: column.width || "auto",
                    ...column.headerStyle,
                  }}
                  sortDirection={sortColumn === column.field ? sortDirection : false}
                  className={styles.tableHeaderCell}
                >
                  <Box
                    className={styles.headerContent}
                    onClick={() => column.sortable !== false && handleSort(column.field)}
                    style={{ cursor: column.sortable !== false ? "pointer" : "default" }}
                  >
                    {column.headerName}

                    {column.sortable !== false && (
                      <Box className={styles.sortIcon}>
                        {sortColumn === column.field ? (
                          sortDirection === "asc" ? (
                            <Icon name="arrow-up" size="small" />
                          ) : (
                            <Icon name="arrow-down" size="small" />
                          )
                        ) : (
                          <Icon name="sort" size="small" style={{ opacity: 0.3 }} />
                        )}
                      </Box>
                    )}
                  </Box>
                </TableCell>
              ))}
            </TableRow>
          </TableHead>

          <TableBody>
            {loading ? (
              // Loading state
              Array.from(new Array(rowsPerPage)).map((_, index) => (
                <TableRow key={`skeleton-${index}`}>
                  {selectable && <TableCell padding="checkbox"></TableCell>}
                  {columns.map((column, colIndex) => (
                    <TableCell key={`skeleton-cell-${colIndex}`}>
                      <Box className={styles.skeleton}></Box>
                    </TableCell>
                  ))}
                </TableRow>
              ))
            ) : paginatedData.length > 0 ? (
              // Data rows
              paginatedData.map((row, index) => {
                const isItemSelected = selectable && isRowSelected(row.id)
                const isHighlighted = highlightedRows.includes(row.id)

                return (
                  <TableRow
                    hover
                    key={row.id || index}
                    selected={isItemSelected}
                    className={`
                      ${isHighlighted ? styles.highlightedRow : ""}
                      ${onRowClick ? styles.clickableRow : ""}
                    `}
                    onClick={onRowClick ? () => onRowClick(row) : undefined}
                    style={customRowStyle ? customRowStyle(row) : undefined}
                  >
                    {selectable && (
                      <TableCell padding="checkbox">
                        <Checkbox checked={isItemSelected} onClick={(event) => handleSelectRow(event, row.id)} />
                      </TableCell>
                    )}

                    {columns.map((column) => (
                      <TableCell
                        key={`${row.id || index}-${column.field}`}
                        align={column.type === "number" ? "right" : "left"}
                        style={column.cellStyle}
                      >
                        {renderCellContent(row, column)}
                      </TableCell>
                    ))}
                  </TableRow>
                )
              })
            ) : (
              // Empty state
              <TableRow>
                <TableCell colSpan={columns.length + (selectable ? 1 : 0)} align="center" className={styles.emptyState}>
                  <Box className={styles.emptyStateContent}>
                    <Icon name="info" size="large" />
                    <Typography variant="body1">{emptyStateMessage}</Typography>
                  </Box>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Pagination */}
      {pagination && (
        <TablePagination
          rowsPerPageOptions={rowsPerPageOptions}
          component="div"
          count={filteredData.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
          className={styles.pagination}
        />
      )}
    </Paper>
  )
}

DataTable.propTypes = {
  columns: PropTypes.arrayOf(
    PropTypes.shape({
      field: PropTypes.string.isRequired,
      headerName: PropTypes.string.isRequired,
      type: PropTypes.oneOf(["string", "number", "date", "datetime", "boolean", "status"]),
      width: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
      minWidth: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
      sortable: PropTypes.bool,
      renderCell: PropTypes.func,
      headerStyle: PropTypes.object,
      cellStyle: PropTypes.object,
      emptyValue: PropTypes.string,
    }),
  ).isRequired,
  data: PropTypes.array.isRequired,
  title: PropTypes.string,
  loading: PropTypes.bool,
  pagination: PropTypes.bool,
  selectable: PropTypes.bool,
  onRowSelect: PropTypes.func,
  onRowClick: PropTypes.func,
  actions: PropTypes.arrayOf(
    PropTypes.shape({
      label: PropTypes.string.isRequired,
      onClick: PropTypes.func.isRequired,
      primary: PropTypes.bool,
      disabled: PropTypes.bool,
    }),
  ),
  defaultSortColumn: PropTypes.string,
  defaultSortDirection: PropTypes.oneOf(["asc", "desc"]),
  searchable: PropTypes.bool,
  searchPlaceholder: PropTypes.string,
  emptyStateMessage: PropTypes.string,
  rowsPerPageOptions: PropTypes.array,
  defaultRowsPerPage: PropTypes.number,
  stickyHeader: PropTypes.bool,
  maxHeight: PropTypes.string,
  dense: PropTypes.bool,
  exportable: PropTypes.bool,
  onExport: PropTypes.func,
  customFilters: PropTypes.node,
  onFilterChange: PropTypes.func,
  refreshable: PropTypes.bool,
  onRefresh: PropTypes.func,
  highlightedRows: PropTypes.array,
  customRowStyle: PropTypes.func,
}

export default DataTable

