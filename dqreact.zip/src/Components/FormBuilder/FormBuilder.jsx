"use client"

import { useState, useEffect, useCallback } from "react"
import PropTypes from "prop-types"
import {
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  FormHelperText,
  Checkbox,
  FormControlLabel,
  Radio,
  RadioGroup,
  Switch,
  Autocomplete,
  Chip,
  Grid,
  Box,
  Typography,
  Paper,
  Divider,
  CircularProgress,
} from "@mui/material"
import { DatePicker } from "@mui/x-date-pickers/DatePicker"
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider"
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns"
import { Button } from "@vds/buttons"
import { Title, Body } from "@vds/typography"
import styles from "./FormBuilder.module.css"

const FormBuilder = ({
  fields,
  values,
  onChange,
  onSubmit,
  title,
  subtitle,
  submitButtonText = "Submit",
  cancelButtonText = "Cancel",
  onCancel,
  loading = false,
  disabled = false,
  layout = "vertical",
  spacing = 2,
  sections = null,
  showRequiredLabel = true,
  dense = false,
  fullWidth = true,
  validateOnChange = false,
  validateOnBlur = true,
  customValidation = null,
  resetAfterSubmit = false,
  initialErrors = {},
  submitOnEnter = true,
}) => {
  const [errors, setErrors] = useState(initialErrors)
  const [touched, setTouched] = useState({})
  const [isSubmitting, setIsSubmitting] = useState(false)

  // Reset form when values change externally
  useEffect(() => {
    setTouched({})
  }, [JSON.stringify(values)])

  // Validate a single field
  const validateField = useCallback(
    (name, value) => {
      const field = fields.find((f) => f.name === name)
      if (!field) return ""

      // Skip validation if field is disabled or hidden
      if (field.disabled || field.hidden) return ""

      // Required field validation
      if (field.required && (value === undefined || value === null || value === "")) {
        return `${field.label} is required`
      }

      // Pattern validation
      if (field.pattern && value && !new RegExp(field.pattern).test(value)) {
        return field.patternError || `Invalid format for ${field.label}`
      }

      // Min/max validation for numbers
      if (field.type === "number") {
        const numValue = Number(value)
        if (value && isNaN(numValue)) {
          return `${field.label} must be a number`
        }
        if (field.min !== undefined && numValue < field.min) {
          return `${field.label} must be at least ${field.min}`
        }
        if (field.max !== undefined && numValue > field.max) {
          return `${field.label} must be at most ${field.max}`
        }
      }

      // Min/max length validation for text
      if (field.type === "text" || field.type === "textarea") {
        if (field.minLength && value && value.length < field.minLength) {
          return `${field.label} must be at least ${field.minLength} characters`
        }
        if (field.maxLength && value && value.length > field.maxLength) {
          return `${field.label} must be at most ${field.maxLength} characters`
        }
      }

      // Email validation
      if (field.type === "email" && value) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
        if (!emailRegex.test(value)) {
          return `Please enter a valid email address`
        }
      }

      // Custom validation function
      if (field.validate) {
        return field.validate(value, values)
      }

      return ""
    },
    [fields, values],
  )

  // Validate all fields
  const validateForm = useCallback(() => {
    const newErrors = {}
    let isValid = true

    fields.forEach((field) => {
      if (field.hidden) return

      const error = validateField(field.name, values[field.name])
      if (error) {
        newErrors[field.name] = error
        isValid = false
      }
    })

    // Run custom form-level validation if provided
    if (isValid && customValidation) {
      const customErrors = customValidation(values)
      if (customErrors && Object.keys(customErrors).length > 0) {
        Object.assign(newErrors, customErrors)
        isValid = false
      }
    }

    setErrors(newErrors)
    return isValid
  }, [fields, values, validateField, customValidation])

  // Handle field change
  const handleChange = (name, value) => {
    // Update form values
    onChange({ ...values, [name]: value })

    // Mark field as touched
    setTouched({ ...touched, [name]: true })

    // Validate on change if enabled
    if (validateOnChange) {
      const error = validateField(name, value)
      setErrors((prev) => ({ ...prev, [name]: error }))
    }
  }

  // Handle field blur
  const handleBlur = (name) => {
    // Mark field as touched
    setTouched({ ...touched, [name]: true })

    // Validate on blur if enabled
    if (validateOnBlur) {
      const error = validateField(name, values[name])
      setErrors((prev) => ({ ...prev, [name]: error }))
    }
  }

  // Handle form submission
  const handleSubmit = async (event) => {
    if (event) {
      event.preventDefault()
    }

    // Validate all fields
    const isValid = validateForm()

    // Mark all fields as touched
    const allTouched = fields.reduce((acc, field) => {
      acc[field.name] = true
      return acc
    }, {})
    setTouched(allTouched)

    if (!isValid) {
      return
    }

    setIsSubmitting(true)

    try {
      await onSubmit(values)

      // Reset form if needed
      if (resetAfterSubmit) {
        const defaultValues = fields.reduce((acc, field) => {
          acc[field.name] = field.defaultValue !== undefined ? field.defaultValue : ""
          return acc
        }, {})
        onChange(defaultValues)
        setTouched({})
        setErrors({})
      }
    } catch (error) {
      console.error("Form submission error:", error)

      // Handle validation errors returned from API
      if (error.errors) {
        setErrors((prev) => ({ ...prev, ...error.errors }))
      }
    } finally {
      setIsSubmitting(false)
    }
  }

  // Handle key press for submit on enter
  const handleKeyPress = (event) => {
    if (submitOnEnter && event.key === "Enter" && !event.shiftKey) {
      handleSubmit()
    }
  }

  // Render a form field based on its type
  const renderField = (field) => {
    const {
      name,
      label,
      type,
      placeholder,
      helperText,
      required,
      disabled: fieldDisabled,
      hidden,
      options,
      multiple,
      rows,
      fullWidth: fieldFullWidth,
      size,
      startAdornment,
      endAdornment,
      ...rest
    } = field

    // Don't render hidden fields
    if (hidden) return null

    const isDisabled = disabled || fieldDisabled || loading
    const fieldFullWidthValue = fieldFullWidth !== undefined ? fieldFullWidth : fullWidth
    const fieldSize = size || (dense ? "small" : "medium")
    const error = touched[name] && errors[name]
    const value = values[name] !== undefined ? values[name] : ""

    // Common props for all field types
    const commonProps = {
      id: `form-field-${name}`,
      name,
      value,
      required,
      disabled: isDisabled,
      error: !!error,
      size: fieldSize,
      fullWidth: fieldFullWidthValue,
      onChange: (e) => handleChange(name, e.target.value),
      onBlur: () => handleBlur(name),
      ...rest,
    }

    switch (type) {
      case "text":
      case "email":
      case "password":
      case "number":
      case "tel":
      case "url":
        return (
          <TextField
            {...commonProps}
            type={type}
            label={label}
            placeholder={placeholder}
            helperText={error || helperText}
            InputProps={{
              startAdornment,
              endAdornment,
            }}
          />
        )

      case "textarea":
        return (
          <TextField
            {...commonProps}
            label={label}
            placeholder={placeholder}
            helperText={error || helperText}
            multiline
            rows={rows || 4}
          />
        )

      case "select":
        return (
          <FormControl error={!!error} fullWidth={fieldFullWidthValue} size={fieldSize}>
            <InputLabel id={`${name}-label`}>{label}</InputLabel>
            <Select
              {...commonProps}
              labelId={`${name}-label`}
              label={label}
              multiple={multiple}
              renderValue={
                multiple
                  ? (selected) => (
                      <Box sx={{ display: "flex", flexWrap: "wrap", gap: 0.5 }}>
                        {selected.map((value) => (
                          <Chip
                            key={value}
                            label={options.find((opt) => opt.value === value)?.label || value}
                            size="small"
                          />
                        ))}
                      </Box>
                    )
                  : undefined
              }
            >
              {options?.map((option) => (
                <MenuItem key={option.value} value={option.value}>
                  {option.label}
                </MenuItem>
              ))}
            </Select>
            {(error || helperText) && <FormHelperText>{error || helperText}</FormHelperText>}
          </FormControl>
        )

      case "autocomplete":
        return (
          <Autocomplete
            multiple={multiple}
            options={options || []}
            getOptionLabel={(option) => {
              if (typeof option === "string") return option
              return option.label || option.value || ""
            }}
            value={multiple ? value || [] : value}
            onChange={(_, newValue) => handleChange(name, newValue)}
            disabled={isDisabled}
            renderInput={(params) => (
              <TextField
                {...params}
                label={label}
                placeholder={placeholder}
                error={!!error}
                helperText={error || helperText}
                size={fieldSize}
                fullWidth={fieldFullWidthValue}
                onBlur={() => handleBlur(name)}
              />
            )}
            renderTags={(value, getTagProps) =>
              value.map((option, index) => (
                <Chip
                  key={index}
                  label={typeof option === "string" ? option : option.label || option.value}
                  {...getTagProps({ index })}
                  size="small"
                />
              ))
            }
          />
        )

      case "checkbox":
        return (
          <FormControl error={!!error} fullWidth={fieldFullWidthValue}>
            <FormControlLabel
              control={
                <Checkbox {...commonProps} checked={!!value} onChange={(e) => handleChange(name, e.target.checked)} />
              }
              label={label}
              disabled={isDisabled}
            />
            {(error || helperText) && <FormHelperText>{error || helperText}</FormHelperText>}
          </FormControl>
        )

      case "radio":
        return (
          <FormControl error={!!error} fullWidth={fieldFullWidthValue}>
            <Typography variant="body2" component="div" className={styles.fieldLabel}>
              {label} {required && <span className={styles.requiredStar}>*</span>}
            </Typography>
            <RadioGroup {...commonProps} row={field.row}>
              {options?.map((option) => (
                <FormControlLabel
                  key={option.value}
                  value={option.value}
                  control={<Radio size={fieldSize} />}
                  label={option.label}
                  disabled={isDisabled || option.disabled}
                />
              ))}
            </RadioGroup>
            {(error || helperText) && <FormHelperText>{error || helperText}</FormHelperText>}
          </FormControl>
        )

      case "switch":
        return (
          <FormControl error={!!error} fullWidth={fieldFullWidthValue}>
            <FormControlLabel
              control={
                <Switch {...commonProps} checked={!!value} onChange={(e) => handleChange(name, e.target.checked)} />
              }
              label={label}
              disabled={isDisabled}
            />
            {(error || helperText) && <FormHelperText>{error || helperText}</FormHelperText>}
          </FormControl>
        )

      case "date":
        return (
          <LocalizationProvider dateAdapter={AdapterDateFns}>
            <DatePicker
              label={label}
              value={value || null}
              onChange={(newValue) => handleChange(name, newValue)}
              disabled={isDisabled}
              renderInput={(params) => (
                <TextField
                  {...params}
                  error={!!error}
                  helperText={error || helperText}
                  fullWidth={fieldFullWidthValue}
                  size={fieldSize}
                  onBlur={() => handleBlur(name)}
                />
              )}
            />
          </LocalizationProvider>
        )

      case "custom":
        return field.render({
          value,
          onChange: (newValue) => handleChange(name, newValue),
          onBlur: () => handleBlur(name),
          error,
          touched: !!touched[name],
          disabled: isDisabled,
          values,
          setFieldValue: (fieldName, fieldValue) => handleChange(fieldName, fieldValue),
        })

      default:
        return null
    }
  }

  // Render form sections
  const renderSections = () => {
    if (!sections) {
      // Render all fields in a single section
      return (
        <Grid container spacing={spacing}>
          {fields.map((field) => (
            <Grid
              item
              key={field.name}
              xs={12}
              sm={field.gridSm || 12}
              md={field.gridMd || 12}
              lg={field.gridLg || 12}
              style={{ display: field.hidden ? "none" : "block" }}
            >
              {renderField(field)}
            </Grid>
          ))}
        </Grid>
      )
    }

    // Render fields in sections
    return sections.map((section, index) => (
      <Box key={section.id || index} className={styles.section} mb={3}>
        {section.title && (
          <Box mb={2}>
            <Title size="small" bold>
              {section.title}
            </Title>
            {section.subtitle && (
              <Body size="small" className={styles.sectionSubtitle}>
                {section.subtitle}
              </Body>
            )}
          </Box>
        )}

        <Grid container spacing={spacing}>
          {fields
            .filter((field) => field.section === section.id)
            .map((field) => (
              <Grid
                item
                key={field.name}
                xs={12}
                sm={field.gridSm || 12}
                md={field.gridMd || 6}
                lg={field.gridLg || 4}
                style={{ display: field.hidden ? "none" : "block" }}
              >
                {renderField(field)}
              </Grid>
            ))}
        </Grid>

        {index < sections.length - 1 && <Divider className={styles.sectionDivider} />}
      </Box>
    ))
  }

  return (
    <Paper className={styles.formContainer} elevation={2}>
      <form onSubmit={handleSubmit} onKeyPress={handleKeyPress} noValidate>
        {/* Form Header */}
        {(title || subtitle) && (
          <Box className={styles.formHeader}>
            {title && (
              <Title size="medium" bold>
                {title}
              </Title>
            )}
            {subtitle && (
              <Body size="medium" className={styles.subtitle}>
                {subtitle}
              </Body>
            )}
          </Box>
        )}

        {/* Required Fields Label */}
        {showRequiredLabel && fields.some((f) => f.required && !f.hidden) && (
          <Box className={styles.requiredFieldsNote}>
            <Body size="small">
              Fields marked with <span className={styles.requiredStar}>*</span> are required
            </Body>
          </Box>
        )}

        {/* Form Fields */}
        <Box className={styles.formFields}>{renderSections()}</Box>

        {/* Form Actions */}
        <Box className={styles.formActions}>
          {onCancel && (
            <Button
              use="secondary"
              size="medium"
              onClick={onCancel}
              disabled={isSubmitting || loading}
              className={styles.cancelButton}
            >
              {cancelButtonText}
            </Button>
          )}

          <Button
            use="primary"
            size="medium"
            type="submit"
            onClick={handleSubmit}
            disabled={isSubmitting || loading || disabled}
            className={styles.submitButton}
          >
            {isSubmitting || loading ? (
              <>
                <CircularProgress size={16} color="inherit" className={styles.buttonProgress} />
                Loading...
              </>
            ) : (
              submitButtonText
            )}
          </Button>
        </Box>
      </form>
    </Paper>
  )
}

FormBuilder.propTypes = {
  fields: PropTypes.arrayOf(
    PropTypes.shape({
      name: PropTypes.string.isRequired,
      label: PropTypes.string.isRequired,
      type: PropTypes.oneOf([
        "text",
        "textarea",
        "select",
        "checkbox",
        "radio",
        "switch",
        "date",
        "email",
        "password",
        "number",
        "tel",
        "url",
        "autocomplete",
        "custom",
      ]).isRequired,
      placeholder: PropTypes.string,
      helperText: PropTypes.string,
      required: PropTypes.bool,
      disabled: PropTypes.bool,
      hidden: PropTypes.bool,
      options: PropTypes.array,
      multiple: PropTypes.bool,
      rows: PropTypes.number,
      defaultValue: PropTypes.any,
      validate: PropTypes.func,
      pattern: PropTypes.string,
      patternError: PropTypes.string,
      min: PropTypes.number,
      max: PropTypes.number,
      minLength: PropTypes.number,
      maxLength: PropTypes.number,
      section: PropTypes.string,
      gridSm: PropTypes.number,
      gridMd: PropTypes.number,
      gridLg: PropTypes.number,
      fullWidth: PropTypes.bool,
      size: PropTypes.oneOf(["small", "medium"]),
      startAdornment: PropTypes.node,
      endAdornment: PropTypes.node,
      render: PropTypes.func,
    }),
  ).isRequired,
  values: PropTypes.object.isRequired,
  onChange: PropTypes.func.isRequired,
  onSubmit: PropTypes.func.isRequired,
  title: PropTypes.string,
  subtitle: PropTypes.string,
  submitButtonText: PropTypes.string,
  cancelButtonText: PropTypes.string,
  onCancel: PropTypes.func,
  loading: PropTypes.bool,
  disabled: PropTypes.bool,
  layout: PropTypes.oneOf(["vertical", "horizontal"]),
  spacing: PropTypes.number,
  sections: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.string.isRequired,
      title: PropTypes.string,
      subtitle: PropTypes.string,
    }),
  ),
  showRequiredLabel: PropTypes.bool,
  dense: PropTypes.bool,
  fullWidth: PropTypes.bool,
  validateOnChange: PropTypes.bool,
  validateOnBlur: PropTypes.bool,
  customValidation: PropTypes.func,
  resetAfterSubmit: PropTypes.bool,
  initialErrors: PropTypes.object,
  submitOnEnter: PropTypes.bool,
}

export default FormBuilder

