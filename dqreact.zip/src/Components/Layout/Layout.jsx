import { memo } from "react"
import PropTypes from "prop-types"
import Header from "../Header/Header"
import Sidebar from "../Sidebar/Sidebar"
import { useLocation } from "react-router-dom"
import styles from "./Layout.module.css"

// Optimized Layout component with memoization
const Layout = memo(({ children }) => {
  const location = useLocation()
  const isIframePage = location.pathname.includes("/iframes/")

  return (
    <div className={styles.layout}>
      {!isIframePage && (
        <header className={styles.header}>
          <Header />
        </header>
      )}

      <div className={styles.mainContent}>
        <aside className={styles.sidebar}>
          <Sidebar />
        </aside>

        <main className={styles.main}>{children}</main>
      </div>
    </div>
  )
})

Layout.propTypes = {
  children: PropTypes.node.isRequired,
}

Layout.displayName = "Layout"

export default Layout

