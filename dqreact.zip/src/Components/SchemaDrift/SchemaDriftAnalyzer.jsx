"use client"

import { useState, useMemo } from "react"
import PropTypes from "prop-types"
import {
  Box,
  Paper,
  Tabs,
  Tab,
  Typography,
  Divider,
  Chip,
  TextField,
  Autocomplete,
  CircularProgress,
  Alert,
  Grid,
} from "@mui/material"
import { Button } from "@vds/buttons"
import { Title, Body } from "@vds/typography"
import { Icon } from "@vds/icons"
import DataTable from "../DataTable/DataTable"
import ChartComponent from "../Charts/ChartComponent"
import styles from "./SchemaDriftAnalyzer.module.css"

const SchemaDriftAnalyzer = ({
  onAnalyze,
  loading = false,
  error = null,
  results = null,
  environments = [],
  databases = [],
  tables = [],
  loadingDatabases = false,
  loadingTables = false,
  onDatabaseChange,
  onEnvironmentChange,
  onTableChange,
}) => {
  const [activeTab, setActiveTab] = useState(0)
  const [sourceEnv, setSourceEnv] = useState(null)
  const [targetEnv, setTargetEnv] = useState(null)
  const [sourceDb, setSourceDb] = useState(null)
  const [targetDb, setTargetDb] = useState(null)
  const [sourceTable, setSourceTable] = useState(null)
  const [targetTable, setTargetTable] = useState(null)
  const [analysisMode, setAnalysisMode] = useState("same") // 'same' or 'different'

  // Handle tab change
  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue)
    setAnalysisMode(newValue === 0 ? "same" : "different")
    // Reset form when switching tabs
    if (newValue === 0) {
      setSourceEnv(null)
      setTargetEnv(null)
    } else {
      setSourceEnv(null)
      setTargetEnv(null)
    }
    setSourceDb(null)
    setTargetDb(null)
    setSourceTable(null)
    setTargetTable(null)
  }

  // Handle environment changes
  const handleSourceEnvChange = (event, value) => {
    setSourceEnv(value)
    setSourceDb(null)
    setSourceTable(null)
    if (onEnvironmentChange) {
      onEnvironmentChange("source", value)
    }
  }

  const handleTargetEnvChange = (event, value) => {
    setTargetEnv(value)
    setSourceDb(null)
    setSourceTable(null)
    if (onEnvironmentChange) {
      onEnvironmentChange("target", value)
    }
  }

  // Handle database changes
  const handleSourceDbChange = (event, value) => {
    setSourceDb(value)
    setSourceTable(null)
    if (onDatabaseChange) {
      onDatabaseChange("source", value)
    }
  }

  const handleTargetDbChange = (event, value) => {
    setTargetDb(value)
    setSourceTable(null)
    if (onDatabaseChange) {
      onDatabaseChange("target", value)
    }
  }

  // Handle table changes
  const handleSourceTableChange = (event, value) => {
    setSourceTable(value)
    if (onTableChange) {
      onTableChange("source", value)
    }
  }

  const handleTargetTableChange = (event, value) => {
    setTargetTable(value)
    if (onTableChange) {
      onTableChange("target", value)
    }
  }

  // Handle analyze button click
  const handleAnalyze = () => {
    if (analysisMode === "same") {
      onAnalyze({
        mode: "same",
        environment: sourceEnv,
        database: sourceDb,
        table: sourceTable,
      })
    } else {
      onAnalyze({
        mode: "different",
        sourceEnvironment: sourceEnv,
        targetEnvironment: targetEnv,
        sourceDatabase: sourceDb,
        targetDatabase: targetDb,
        sourceTable: sourceTable,
        targetTable: targetTable,
      })
    }
  }

  // Check if analyze button should be disabled
  const isAnalyzeDisabled = useMemo(() => {
    if (loading) return true

    if (analysisMode === "same") {
      return !sourceEnv || !sourceDb || !sourceTable
    } else {
      return !sourceEnv || !targetEnv || !sourceDb || !targetDb || !sourceTable || !targetTable
    }
  }, [analysisMode, loading, sourceEnv, targetEnv, sourceDb, targetDb, sourceTable, targetTable])

  // Prepare columns for schema comparison table
  const schemaColumns = useMemo(
    () => [
      {
        field: "columnName",
        headerName: "Column Name",
        width: 200,
      },
      {
        field: "sourceDataType",
        headerName: "Source Data Type",
        width: 180,
        renderCell: ({ value, row }) => (
          <Box className={styles.dataTypeCell}>
            {value}
            {row.dataTypeDrift && <Chip label="Changed" size="small" color="error" className={styles.driftChip} />}
          </Box>
        ),
      },
      {
        field: "targetDataType",
        headerName: "Target Data Type",
        width: 180,
        renderCell: ({ value, row }) => <Box className={styles.dataTypeCell}>{value || "N/A"}</Box>,
      },
      {
        field: "sourceNullable",
        headerName: "Source Nullable",
        width: 150,
        renderCell: ({ value, row }) => (
          <Box className={styles.nullableCell}>
            {value ? "Yes" : "No"}
            {row.nullableDrift && <Chip label="Changed" size="small" color="error" className={styles.driftChip} />}
          </Box>
        ),
      },
      {
        field: "targetNullable",
        headerName: "Target Nullable",
        width: 150,
        renderCell: ({ value, row }) => (
          <Box className={styles.nullableCell}>{value !== undefined ? (value ? "Yes" : "No") : "N/A"}</Box>
        ),
      },
      {
        field: "status",
        headerName: "Status",
        width: 150,
        renderCell: ({ value }) => {
          let color = "success"
          if (value === "Added") color = "info"
          if (value === "Removed") color = "error"
          if (value === "Modified") color = "warning"

          return <Chip label={value} size="small" color={color} />
        },
      },
    ],
    [],
  )

  // Prepare chart data for schema drift summary
  const chartData = useMemo(() => {
    if (!results || !results.summary) return null

    return {
      labels: ["Unchanged", "Added", "Removed", "Modified"],
      datasets: [
        {
          label: "Column Count",
          data: [
            results.summary.unchanged || 0,
            results.summary.added || 0,
            results.summary.removed || 0,
            results.summary.modified || 0,
          ],
          backgroundColor: [
            "#4CAF50", // Green for unchanged
            "#2196F3", // Blue for added
            "#F44336", // Red for removed
            "#FF9800", // Orange for modified
          ],
        },
      ],
    }
  }, [results])

  // Render the form for same environment analysis
  const renderSameEnvironmentForm = () => (
    <Grid container spacing={3}>
      <Grid item xs={12} md={4}>
        <Autocomplete
          options={environments}
          value={sourceEnv}
          onChange={handleSourceEnvChange}
          renderInput={(params) => <TextField {...params} label="Environment" variant="outlined" fullWidth required />}
        />
      </Grid>
      <Grid item xs={12} md={4}>
        <Autocomplete
          options={databases}
          value={sourceDb}
          onChange={handleSourceDbChange}
          disabled={!sourceEnv || loadingDatabases}
          renderInput={(params) => (
            <TextField
              {...params}
              label="Database"
              variant="outlined"
              fullWidth
              required
              InputProps={{
                ...params.InputProps,
                endAdornment: (
                  <>
                    {loadingDatabases ? <CircularProgress size={20} /> : null}
                    {params.InputProps.endAdornment}
                  </>
                ),
              }}
            />
          )}
        />
      </Grid>
      <Grid item xs={12} md={4}>
        <Autocomplete
          options={tables}
          value={sourceTable}
          onChange={handleSourceTableChange}
          disabled={!sourceDb || loadingTables}
          renderInput={(params) => (
            <TextField
              {...params}
              label="Table"
              variant="outlined"
              fullWidth
              required
              InputProps={{
                ...params.InputProps,
                endAdornment: (
                  <>
                    {loadingTables ? <CircularProgress size={20} /> : null}
                    {params.InputProps.endAdornment}
                  </>
                ),
              }}
            />
          )}
        />
      </Grid>
    </Grid>
  )

  // Render the form for different environment analysis
  const renderDifferentEnvironmentForm = () => (
    <Grid container spacing={3}>
      <Grid item xs={12}>
        <Typography variant="subtitle1" gutterBottom>
          Source Environment
        </Typography>
      </Grid>
      <Grid item xs={12} md={4}>
        <Autocomplete
          options={environments}
          value={sourceEnv}
          onChange={handleSourceEnvChange}
          renderInput={(params) => (
            <TextField {...params} label="Source Environment" variant="outlined" fullWidth required />
          )}
        />
      </Grid>
      <Grid item xs={12} md={4}>
        <Autocomplete
          options={databases}
          value={sourceDb}
          onChange={handleSourceDbChange}
          disabled={!sourceEnv || loadingDatabases}
          renderInput={(params) => (
            <TextField
              {...params}
              label="Source Database"
              variant="outlined"
              fullWidth
              required
              InputProps={{
                ...params.InputProps,
                endAdornment: (
                  <>
                    {loadingDatabases ? <CircularProgress size={20} /> : null}
                    {params.InputProps.endAdornment}
                  </>
                ),
              }}
            />
          )}
        />
      </Grid>
      <Grid item xs={12} md={4}>
        <Autocomplete
          options={tables}
          value={sourceTable}
          onChange={handleSourceTableChange}
          disabled={!sourceDb || loadingTables}
          renderInput={(params) => (
            <TextField
              {...params}
              label="Source Table"
              variant="outlined"
              fullWidth
              required
              InputProps={{
                ...params.InputProps,
                endAdornment: (
                  <>
                    {loadingTables ? <CircularProgress size={20} /> : null}
                    {params.InputProps.endAdornment}
                  </>
                ),
              }}
            />
          )}
        />
      </Grid>

      <Grid item xs={12}>
        <Divider />
      </Grid>

      <Grid item xs={12}>
        <Typography variant="subtitle1" gutterBottom>
          Target Environment
        </Typography>
      </Grid>
      <Grid item xs={12} md={4}>
        <Autocomplete
          options={environments}
          value={targetEnv}
          onChange={handleTargetEnvChange}
          renderInput={(params) => (
            <TextField {...params} label="Target Environment" variant="outlined" fullWidth required />
          )}
        />
      </Grid>
      <Grid item xs={12} md={4}>
        <Autocomplete
          options={databases}
          value={targetDb}
          onChange={handleTargetDbChange}
          disabled={!targetEnv || loadingDatabases}
          renderInput={(params) => (
            <TextField
              {...params}
              label="Target Database"
              variant="outlined"
              fullWidth
              required
              InputProps={{
                ...params.InputProps,
                endAdornment: (
                  <>
                    {loadingDatabases ? <CircularProgress size={20} /> : null}
                    {params.InputProps.endAdornment}
                  </>
                ),
              }}
            />
          )}
        />
      </Grid>
      <Grid item xs={12} md={4}>
        <Autocomplete
          options={tables}
          value={targetTable}
          onChange={handleTargetTableChange}
          disabled={!targetDb || loadingTables}
          renderInput={(params) => (
            <TextField
              {...params}
              label="Target Table"
              variant="outlined"
              fullWidth
              required
              InputProps={{
                ...params.InputProps,
                endAdornment: (
                  <>
                    {loadingTables ? <CircularProgress size={20} /> : null}
                    {params.InputProps.endAdornment}
                  </>
                ),
              }}
            />
          )}
        />
      </Grid>
    </Grid>
  )

  // Render analysis results
  const renderResults = () => {
    if (!results) return null

    return (
      <Box className={styles.resultsContainer}>
        <Divider className={styles.resultsDivider} />

        <Box className={styles.resultsSummary}>
          <Title size="medium" bold>
            Analysis Results
          </Title>

          <Box className={styles.summaryCards}>
            <Paper className={styles.summaryCard} elevation={1}>
              <Icon name="check-circle" size="large" color="#4CAF50" />
              <Typography variant="h4">{results.summary.unchanged || 0}</Typography>
              <Typography variant="body2">Unchanged Columns</Typography>
            </Paper>

            <Paper className={styles.summaryCard} elevation={1}>
              <Icon name="add-circle" size="large" color="#2196F3" />
              <Typography variant="h4">{results.summary.added || 0}</Typography>
              <Typography variant="body2">Added Columns</Typography>
            </Paper>

            <Paper className={styles.summaryCard} elevation={1}>
              <Icon name="remove-circle" size="large" color="#F44336" />
              <Typography variant="h4">{results.summary.removed || 0}</Typography>
              <Typography variant="body2">Removed Columns</Typography>
            </Paper>

            <Paper className={styles.summaryCard} elevation={1}>
              <Icon name="edit" size="large" color="#FF9800" />
              <Typography variant="h4">{results.summary.modified || 0}</Typography>
              <Typography variant="body2">Modified Columns</Typography>
            </Paper>
          </Box>
        </Box>

        <Grid container spacing={3}>
          <Grid item xs={12} md={4}>
            <ChartComponent type="doughnut" data={chartData} title="Schema Drift Summary" height={300} />
          </Grid>

          <Grid item xs={12} md={8}>
            <DataTable
              title="Schema Comparison"
              columns={schemaColumns}
              data={results.columns || []}
              pagination={true}
              defaultRowsPerPage={10}
              searchable={true}
              exportable={true}
            />
          </Grid>
        </Grid>
      </Box>
    )
  }

  return (
    <Paper className={styles.container} elevation={2}>
      <Box className={styles.header}>
        <Title size="large" bold>
          Schema Drift Analysis
        </Title>
        <Body size="medium" className={styles.subtitle}>
          Compare database schemas across environments to identify changes and potential issues
        </Body>
      </Box>

      <Box className={styles.content}>
        <Tabs
          value={activeTab}
          onChange={handleTabChange}
          indicatorColor="primary"
          textColor="primary"
          className={styles.tabs}
        >
          <Tab label="Same Environment" />
          <Tab label="Different Environments" />
        </Tabs>

        <Box className={styles.formContainer}>
          {error && (
            <Alert severity="error" className={styles.errorAlert}>
              {error}
            </Alert>
          )}

          {activeTab === 0 ? renderSameEnvironmentForm() : renderDifferentEnvironmentForm()}

          <Box className={styles.actionButtons}>
            <Button use="primary" size="medium" onClick={handleAnalyze} disabled={isAnalyzeDisabled}>
              {loading ? (
                <>
                  <CircularProgress size={16} color="inherit" className={styles.buttonProgress} />
                  Analyzing...
                </>
              ) : (
                "Analyze Schema Drift"
              )}
            </Button>
          </Box>
        </Box>

        {renderResults()}
      </Box>
    </Paper>
  )
}

SchemaDriftAnalyzer.propTypes = {
  onAnalyze: PropTypes.func.isRequired,
  loading: PropTypes.bool,
  error: PropTypes.string,
  results: PropTypes.shape({
    summary: PropTypes.shape({
      unchanged: PropTypes.number,
      added: PropTypes.number,
      removed: PropTypes.number,
      modified: PropTypes.number,
    }),
    columns: PropTypes.array,
  }),
  environments: PropTypes.array,
  databases: PropTypes.array,
  tables: PropTypes.array,
  loadingDatabases: PropTypes.bool,
  loadingTables: PropTypes.bool,
  onDatabaseChange: PropTypes.func,
  onEnvironmentChange: PropTypes.func,
  onTableChange: PropTypes.func,
}

export default SchemaDriftAnalyzer

