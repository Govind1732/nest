"use client"

import { useCallback } from "react"
import { Link, useNavigate, useLocation } from "react-router-dom"
import { useSelector } from "react-redux"
import lens_x_final from "../../assets/images/lens_x_final.svg"
import { Icon } from "@vds/icons"
import { TextLink } from "@vds/buttons"
import { ButtonIcon } from "@vds/button-icons"
import { Body } from "@vds/core"
import styles from "./Header.module.css"

const Header = () => {
  const navigate = useNavigate()
  const location = useLocation()
  const user = useSelector((store) => store.userAuthorization.user)

  // Memoize navigation handler to prevent unnecessary re-renders
  const handleNavigation = useCallback(
    (path) => {
      navigate(path)
    },
    [navigate],
  )

  // Determine active link for styling
  const isActive = useCallback(
    (path) => {
      return location.pathname.includes(path) ? styles.activeLink : ""
    },
    [location.pathname],
  )

  return (
    <nav className={styles.navbar}>
      <div className={styles.logoContainer}>
        <Link to="/dataQuality">
          <img src={lens_x_final || "/placeholder.svg"} alt="Data Quality Logo" className={styles.logo} />
        </Link>
      </div>

      <div className={styles.navLinksContainer}>
        <ul>
          {user?.roles?.[0]?.name === "DQ Admin" && (
            <li>
              <TextLink
                type="standAlone"
                onClick={() => handleNavigation("/dataQuality/UserManagement")}
                className={isActive("/dataQuality/UserManagement")}
              >
                User Management
              </TextLink>
            </li>
          )}
          <li>
            <Link
              to="/dataQuality/dataquality-validation"
              className={`${styles.hoverUnderline} ${isActive("/dataQuality/dataquality-validation")}`}
            >
              <Body bold={true} size="large">
                DataQuality Validation
              </Body>
            </Link>
          </li>
          <li>
            <Link
              to="/dataQuality/dq-domainlevelreport"
              className={`${styles.hoverUnderline} ${isActive("/dataQuality/dq-domainlevelreport")}`}
            >
              <Body bold={true} size="large">
                DQ Domain Level Report
              </Body>
            </Link>
          </li>
          <li>
            <Link
              to="/dataQuality/dq-reports"
              className={`${styles.hoverUnderline} ${isActive("/dataQuality/dq-reports")}`}
            >
              <Body bold={true} size="large">
                DQ Report
              </Body>
            </Link>
          </li>
          <li>
            <Link
              to="/dataQuality/myrequest"
              className={`${styles.hoverUnderline} ${isActive("/dataQuality/myrequest")}`}
            >
              <Body bold={true} size="large">
                My Request
              </Body>
            </Link>
          </li>
          <li className={styles.helpItem}>
            <ButtonIcon
              kind="ghost"
              size="medium"
              surface="light"
              surfaceType="colorFill"
              hideBorder={true}
              focusBorderPosition="outside"
              iconOffset={{ x: 0, y: 0 }}
              renderIcon={(props) => <Icon name="question" {...props} />}
              onClick={() => handleNavigation("/dataQuality/help")}
            />
            <Link to="/dataQuality/help" className={`${styles.hoverUnderline} ${isActive("/dataQuality/help")}`}>
              <Body bold={true} size="large">
                Help
              </Body>
            </Link>
          </li>
          {user?.first_name && (
            <li className={styles.userProfile}>
              <ButtonIcon
                kind="ghost"
                size="large"
                surface="light"
                surfaceType="colorFill"
                hideBorder={true}
                focusBorderPosition="outside"
                iconOffset={{ x: 0, y: 0 }}
                renderIcon={(props) => <Icon name="my-account" {...props} />}
                onClick={() => handleNavigation("/dataQuality/userprofile")}
              />
              <TextLink type="standAlone" onClick={() => handleNavigation("/dataQuality/userprofile")}>
                <div className={styles.userInfo}>
                  <div>Welcome {user.first_name}</div>
                  <div>{user.roles?.[0]?.name}</div>
                </div>
              </TextLink>
            </li>
          )}
        </ul>
      </div>
    </nav>
  )
}

export default Header

