"use client"

import { useState } from "react"
import PropTypes from "prop-types"
import Tabs from "@mui/material/Tabs"
import Tab from "@mui/material/Tab"
import Box from "@mui/material/Box"
// import CorpDataViewEdit from '../RuleProfile/CorpData/CorpDataViewEdit';
// import RantDTViewEdit from '../RuleProfile/RantDT/RantDTViewEdit';
// import AllProjectsviewEdit from '../RuleProfile/AllProjects/AllProjectsviewEdit';
// import AutoViewEdit from '../AutoProfile/AutoViewEdit'
// import { useDispatch, useSelector } from 'react-redux';
import AutoProfileMetaData from "./AutoProfileMetaData"

function CustomTabPanel(props) {
  const { children, value, index, ...other } = props

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ p: 3 }}>{children}</Box>}
    </div>
  )
}

CustomTabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
}

function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    "aria-controls": `simple-tabpanel-${index}`,
  }
}

function MyRequest() {
  const [value, setValue] = useState(0)
  const [subValue, setSubValue] = useState(0)
  // const dispatch = useDispatch();
  // const user = useSelector((store) => store.userAuthorization.user);

  const handleChange = (event, newValue) => {
    setValue(newValue)
  }
  const handleSubChange = (event, newValue) => {
    setSubValue(newValue)
  }

  return (
    <Box sx={{ width: "100%" }}>
      <Box sx={{ borderBottom: 1, borderColor: "divider", display: "flex", justifyContent: "center" }}>
        <Tabs value={value} onChange={handleChange} aria-label="basic tabs example">
          <Tab label="Auto Profile" {...a11yProps(0)} />
          <Tab label="Rule Profile" {...a11yProps(1)} />
        </Tabs>
      </Box>
      <CustomTabPanel value={value} index={0}>
        <AutoProfileMetaData />
      </CustomTabPanel>
      <CustomTabPanel value={value} index={1}>
        {/* <CorpDataViewEdit /> */}
        {/* <Box sx={{ display: 'flex', justifyContent: 'center' }}>
          <Tabs value={subValue} onChange={handleSubChange} aria-label="tabs" >
            <Tab label="OneCorp" {...a11yProps(0)} />
            <Tab label="DT Ran" {...a11yProps(1)} />
            <Tab label="All Projects" {...a11yProps(2)} />
          </Tabs>
        </Box> */}
        <CustomTabPanel value={subValue} index={0}>
          {/* <OneCorpMetadata /> */}
        </CustomTabPanel>
        <CustomTabPanel value={subValue} index={1}>
          {/* <DTRanMetadata /> */}
        </CustomTabPanel>
        <CustomTabPanel value={subValue} index={2}>
          {/* <AllProjectsMetadata /> */}
        </CustomTabPanel>
      </CustomTabPanel>
    </Box>
  )
}

export default MyRequest

