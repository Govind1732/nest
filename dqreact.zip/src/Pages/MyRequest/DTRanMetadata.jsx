"use client"

import { useEffect, useState } from "react"
import { Container, Row, Col, Form, Button, Modal } from "react-bootstrap"
import axios from "axios"
import Backdrop from "@mui/material/Backdrop"
import { GridLoader } from "react-spinners"
import {
  TextField,
  TableContainer,
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  Paper,
  IconButton,
  TablePagination,
} from "@mui/material"
import EditIcon from "@mui/icons-material/Edit"
import SaveIcon from "@mui/icons-material/Save"
import LoadingButton from "@mui/lab/LoadingButton"
// import './AutoViewEdit.css';
import { Textarea } from "@mui/joy"
import Autocomplete from "@mui/material/Autocomplete"

const DTRanMetadata = () => {
  const [formData, setFormData] = useState({
    db_name: null,
    table_name: null,
  })
  const [submitToggle, setSubmitToggle] = useState(false)
  const [editingRow, setEditingRow] = useState(null)
  const [tableData, setTableData] = useState([])
  const [loading, setLoading] = useState(false)
  const [dataNotFound, setDataNotFound] = useState("")
  const [dbOptions, setDbOptions] = useState([])
  const [tableOptions, setTableOptions] = useState([])
  const [alert, setAlert] = useState(false)
  const [editedRow, setEditedRow] = useState({})
  const [page, setPage] = useState(0)
  const [rowsPerPage, setRowsPerPage] = useState(10)

  useEffect(() => {
    const fetchDBNames = async () => {
      try {
        const response = await axios.get("")
        const dbOptions = Array.isArray(response.data) ? response.data.map((option) => option || "") : []
        setDbOptions(dbOptions)
        // console.log(dbOptions)
        // console.log(response.data)
      } catch (err) {
        console.error("Error fetching database names:", err)
      }
    }
    fetchDBNames()
  }, [])

  useEffect(() => {
    const fetchTableNames = async () => {
      if (formData.db_name) {
        try {
          const response = await axios.post(
            "",
            { DB_NAME: formData.db_name },
            { headers: { "Content-Type": "application/json" } },
          )
          // console.log(response.data)
          setTableOptions(Array.isArray(response.data) ? response.data : [])
        } catch (error) {
          console.error("Error fetching table names:", error)
        }
      } else {
        setTableOptions([])
      }
    }
    fetchTableNames()
  }, [formData.db_name])

  const handleEdit = (index) => {
    setEditingRow(index)
    setEditedRow(tableData[index])
  }

  const [status, setStatus] = useState("")
  const [message, setMessage] = useState("")

  const handleSave = async (index) => {
    try {
      setLoading(true)
      // console.log(editedRow)
      const response = await axios.post(
        "",
        {
          rule_id: editedRow.RULE_ID ?? 0,
          data_lob: editedRow.DATA_LOB ?? "",
          data_bus_elem: editedRow.DATA_BUS_ELEM ?? "",
          data_dmn: editedRow.DATA_DMN ?? "",
          data_sub_dmn: editedRow.DATA_SUB_DMN ?? "",
          data_src: editedRow.DATA_SRC ?? "",
          db_name: editedRow.DB_NAME ?? "",
          src_tbl: editedRow.SRC_TBL ?? "",
          src_col: editedRow.SRC_COL ?? "",
          dq_pillar: editedRow.DQ_PILLAR ?? "",
          meas_name: editedRow.MEAS_NAME ?? "",
          meas_rule_desc: editedRow.MEAS_RULE_DESC ?? "",
          meas_rule_sql: editedRow.MEAS_RULE_SQL ?? "",
          is_active_flg: editedRow.IS_ACTIVE_FLG ?? "",
          rule_prfl_schd_ts: editedRow.RULE_PRFL_SCHD_TS ?? "",
          is_critical_flg: editedRow.IS_CRITICAL_FLG ?? "",
          mail_sub: editedRow.mail_sub ?? "",
          rule_min_thrsd: editedRow.RULE_MIN_THRSD ?? 0,
          rule_max_thrsd: editedRow.RULE_MAX_THRSD ?? 0,
          email_distro: editedRow.email_distro ?? "",
          invalid_rec_flg: editedRow.invalid_rec_flg ?? "",
          invalid_rec_sql: editedRow.invalid_rec_sql ?? "",
        },
        { headers: { "Content-Type": "application/json" } },
      )
      const responseMessage = response.data
      console.log(responseMessage)

      setEditingRow(null)
      setEditedRow({})
      setAlert(true)
      setStatus(responseMessage.status)
      setMessage(responseMessage.message)
    } catch (error) {
      console.error("Error saving edited row:", error)
      setAlert(true)
      setStatus("Error")
      setMessage("Error saving edited row :" + error)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e) => {
    if (e) {
      e.preventDefault()
    }
    setLoading(true)
    try {
      const response = await axios.post("", formData, { headers: { "Content-Type": "application/json" } })
      const data = response.data
      if (data.length === 0) {
        setDataNotFound("No such combination or files exist")
        setTableData([])
      } else {
        setDataNotFound("")
        setTableData(data)
        setSubmitToggle(true)
      }
    } catch (error) {
      console.error("Error in fetching details:", error)
      alert("Error in fetching details:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleChangePage = (event, newPage) => {
    setPage(newPage)
  }

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(+event.target.value)
    setPage(0)
  }

  const override = {
    display: "block",
    margin: "0 auto",
    borderColor: "red",
  }

  return (
    <>
      <Container fluid>
        <Container fluid className="my-2">
          <Form>
            <Row className="">
              <Col xs={3}>
                <Autocomplete
                  placeholder="Select your Option"
                  options={dbOptions}
                  autoHighlight
                  name="db_name"
                  size="small"
                  value={formData.db_name || null}
                  onChange={(_, value) => setFormData((prev) => ({ ...prev, db_name: value }))}
                  isOptionEqualToValue={(option, value) => option.toLowerCase() === value.toLowerCase()}
                  renderInput={(params) => <TextField {...params} variant="outlined" label="DB Name" />}
                />
              </Col>
              <Col xs={3}>
                <Autocomplete
                  placeholder="Select your Option"
                  options={tableOptions}
                  autoHighlight
                  name="table_name"
                  size="small"
                  value={formData.table_name || null}
                  onChange={(_, value) => setFormData((prev) => ({ ...prev, table_name: value }))}
                  isOptionEqualToValue={(option, value) => option.toLowerCase() === value.toLowerCase()}
                  renderInput={(params) => <TextField {...params} variant="outlined" label="Table Name" />}
                />
              </Col>
              <Col xs={2}>
                <Button variant="dark" type="submit" className="w-50">
                  Filter
                </Button>
              </Col>
            </Row>
          </Form>
        </Container>
        {/* )} */}

        {tableData.length > 0 ? (
          <Container fluid>
            <Paper sx={{ width: "100%", overflow: "hidden" }}>
              <TableContainer sx={{ maxHeight: 500 }}>
                <Table stickyHeader aria-label="sticky table">
                  <TableHead>
                    <TableRow>
                      {tableData[0] &&
                        Object.keys(tableData[0])
                          .filter((key) => key !== "update_made_ts" && key !== "entry_made_ts")
                          .map((key) => (
                            <TableCell
                              key={key}
                              style={{
                                backgroundColor: "black",
                                color: "white",
                                border: "1px solid white",
                                fontWeight: "bold",
                              }}
                            >
                              {key}
                            </TableCell>
                          ))}
                      <TableCell
                        key="action"
                        style={{
                          backgroundColor: "black",
                          color: "white",
                          border: "1px solid white",
                          fontWeight: "bold",
                        }}
                      >
                        Action
                      </TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {tableData.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row, index) => (
                      <TableRow key={index} hover role="checkbox" tabIndex={-1}>
                        {Object.entries(row)
                          .filter(([key]) => key !== "update_made_ts" && key !== "entry_made_ts")
                          .map(([key, value], valueIndex) => (
                            <TableCell
                              key={valueIndex}
                              sx={{
                                overflow: "hidden",
                                textOverflow: "ellipsis",
                                whiteSpace: "nowrap",
                                maxWidth: "300px",
                              }}
                            >
                              {editingRow === index &&
                              !["RULE_ID", "DB_NAME", "SRC_TBL", "MEAS_NAME", "SRC_COL"].includes(key) ? (
                                <Textarea
                                  aria-label="empty textarea"
                                  defaultValue={value}
                                  onChange={(e) =>
                                    setEditedRow((prevRow) => ({
                                      ...prevRow,
                                      [key]: e.target.value,
                                    }))
                                  }
                                />
                              ) : (
                                value
                              )}
                            </TableCell>
                          ))}
                        <TableCell key={`action-${index}`}>
                          {editingRow === index ? (
                            <LoadingButton
                              loading={false}
                              loadingPosition="start"
                              startIcon={<SaveIcon />}
                              onClick={() => handleSave(index)}
                            >
                              Save
                            </LoadingButton>
                          ) : (
                            <IconButton onClick={() => handleEdit(index)}>
                              <EditIcon /> Edit
                            </IconButton>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
              <TablePagination
                rowsPerPageOptions={[10, 20, 30, 40, 50, 100]}
                component="div"
                count={tableData.length}
                rowsPerPage={rowsPerPage}
                page={page}
                onPageChange={handleChangePage}
                onRowsPerPageChange={handleChangeRowsPerPage}
              />
            </Paper>
          </Container>
        ) : (
          <div className="d-flex justify-content-center m-2 blink">
            <h5>{dataNotFound}</h5>
          </div>
        )}

        <Backdrop sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }} open={loading}>
          <Container className="loading-overlay">
            <GridLoader
              color="#ff0000"
              loading={loading}
              cssOverride={override}
              size={20}
              aria-label="Loading Spinner"
              data-testid="loader"
            />
          </Container>
        </Backdrop>

        <Modal
          show={alert}
          onHide={() => {
            setAlert(false)
            handleSubmit()
          }}
        >
          <Modal.Header closeButton>
            <Modal.Title>{status}</Modal.Title>
          </Modal.Header>
          <Modal.Body>{message}</Modal.Body>
          <Modal.Footer>
            <Button
              variant="secondary"
              onClick={() => {
                setAlert(false)
                handleSubmit()
              }}
            >
              Close
            </Button>
          </Modal.Footer>
        </Modal>
      </Container>
    </>
  )
}

export default DTRanMetadata

