import { Container } from "react-bootstrap"
const PendingApprovals = () => {
  return (
    <Container fluid>
      <h4 className="text-center" style={{ color: "#EE0000" }}>
        Pending Approvals
      </h4>
    </Container>
  )
}
export default PendingApprovals

