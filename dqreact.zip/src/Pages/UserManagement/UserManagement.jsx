"use client"

import { useState } from "react"
import { Button, Container } from "react-bootstrap"
import UserList from "./UserList"
import History from "./History"
import PendingApprovals from "./PendingApprovals"
import AddUserComponent from "./AddUserComponent"

const UserManagement = () => {
  const [view, setView] = useState("UserList")

  const getView = () => {
    switch (view) {
      case "UserList":
        return <UserList />
      case "AddUser":
        return <AddUserComponent />
      case "History":
        return <History />
      case "PendingApprovals":
        return <PendingApprovals />
      default:
        return <UserList />
    }
  }
  return (
    <>
      <Container>
        <h2 className="text-center mt-2" style={{ color: "#EE0000" }}>
          User Management
        </h2>
        <Container fluid className="d-flex justify-content-end align-items-center">
          <Button variant={view === "UserList" ? "dark" : "white"} className="mx-2" onClick={() => setView("UserList")}>
            User List
          </Button>
          <Button variant={view === "AddUser" ? "dark" : "white"} className="mx-2" onClick={() => setView("AddUser")}>
            Add User
          </Button>
          {/* <Button variant={view === 'History' ? 'dark' : 'white'} className='mx-2' onClick={() => setView('History')}>History</Button>
                    <Button variant={view === 'PendingApprovals' ? 'dark' : 'white'} className='mx-2' onClick={() => setView('PendingApprovals')}>Pending Approvals</Button> */}
        </Container>
        {getView()}
      </Container>
    </>
  )
}

export default UserManagement

