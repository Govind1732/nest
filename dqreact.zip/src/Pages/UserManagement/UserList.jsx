"use client"

import React, { useEffect, useState } from "react"
import { Container, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from "@mui/material"
import axios from "axios"
import Loading from "../../Components/LayoutComponents/Loading"

const UserList = () => {
  const [tableData, setTableData] = useState([])
  const [loading, setLoading] = useState(false)
  const [open, setOpen] = React.useState(false)

  const handleClickOpen = () => {
    setOpen(true)
  }

  const handleClose = () => {
    setOpen(false)
  }

  const [openbusinessimpact, setOpenbusinessimpact] = React.useState(false)

  const handlebusinessimpactOpen = () => {
    setOpenbusinessimpact(true)
  }

  const handlebusinessimpactClose = () => {
    setOpenbusinessimpact(false)
  }

  useEffect(() => {
    setLoading(true)
    axios
      .get(`${import.meta.env.VITE_DJANGO_BASE_URL}user_management/GetUserDetails/`)
      .then((response) => {
        setTableData(response.data)
        setLoading(false)
      })
      .catch((error) => {
        console.log(error)
        setLoading(false)
      })
  }, [])

  return (
    <>
      {/* <h5 className="text-center mb-4 mt-2" style={{ color: '#EE0000' }}>
            User List
        </h5> */}
      <Container fluid className="my-5">
        <Loading loading={loading}></Loading>

        <Paper
          sx={{ width: "100%", overflow: "hidden", display: "flex", justifyContent: "center", alignItems: "center" }}
        >
          <TableContainer sx={{ maxHeight: 650, width: "100%" }}>
            <Table stickyHeader aria-label="sticky table">
              <TableHead>
                <TableRow>
                  {["#", "User Name", "First Name", "Last Name", "Email", "Project(s)", "Role"].map((key) => (
                    <TableCell key={key} style={{ border: "0", color: "black", backgroundColor: "#BEBEBE" }}>
                      {key}
                    </TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {tableData
                  .sort((a, b) => a.first_name.localeCompare(b.first_name))
                  .map((row, index) => (
                    <TableRow key={index} hover>
                      <TableCell
                        style={{
                          borderRight: "0",
                          borderLeft: "0",
                          borderBottom: "2px solid #F5F5F5",
                          borderTop: "2px solid #F5F5F5",
                        }}
                      >
                        {index + 1}
                      </TableCell>
                      <TableCell
                        style={{
                          borderRight: "0",
                          borderLeft: "0",
                          borderBottom: "2px solid #F5F5F5",
                          borderTop: "2px solid #F5F5F5",
                        }}
                      >
                        {row.vzid}
                      </TableCell>
                      <TableCell
                        style={{
                          borderRight: "0",
                          borderLeft: "0",
                          borderBottom: "2px solid #F5F5F5",
                          borderTop: "2px solid #F5F5F5",
                        }}
                      >
                        {row.first_name}
                      </TableCell>
                      <TableCell
                        style={{
                          borderRight: "0",
                          borderLeft: "0",
                          borderBottom: "2px solid #F5F5F5",
                          borderTop: "2px solid #F5F5F5",
                        }}
                      >
                        {row.last_name}
                      </TableCell>
                      <TableCell
                        style={{
                          borderRight: "0",
                          borderLeft: "0",
                          borderBottom: "2px solid #F5F5F5",
                          borderTop: "2px solid #F5F5F5",
                        }}
                      >
                        {row.email}
                      </TableCell>
                      <TableCell
                        style={{
                          borderRight: "0",
                          borderLeft: "0",
                          borderBottom: "2px solid #F5F5F5",
                          borderTop: "2px solid #F5F5F5",
                        }}
                      >
                        {row.projects.map((project) => project.name + ",")}
                      </TableCell>
                      <TableCell
                        style={{
                          borderRight: "0",
                          borderLeft: "0",
                          borderBottom: "2px solid #F5F5F5",
                          borderTop: "2px solid #F5F5F5",
                        }}
                      >
                        {row.roles[0].name}
                      </TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
          </TableContainer>
          {/* <TablePagination
      rowsPerPageOptions={[10, 25, 100]}
      component="div"
      count={rows.length}
      rowsPerPage={rowsPerPage}
      page={page}
      onPageChange={handleChangePage}
      onRowsPerPageChange={handleChangeRowsPerPage}
    /> */}
        </Paper>
      </Container>
    </>
  )
}
export default UserList

