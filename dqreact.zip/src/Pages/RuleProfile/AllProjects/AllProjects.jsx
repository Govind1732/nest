import { Tabs, Tab } from "@vds/tabs"
import { Title } from "@vds/typography"
import { Breadcrumbs, BreadcrumbItem } from "@vds/breadcrumbs"
import AllProjectsMultiRequest from "./AllProjectsMultiRequest"
import AllProjectViewEdit from "./AllProjectsviewEdit"
import styles from "./AllProjects.module.css"

const AllProjects = () => {
  return (
    <>
      <div className={styles.section}>
        <div className={styles.subHeading}>
          <Title size="medium" bold={true} color="#000">
            All Projects
          </Title>
          <Breadcrumbs surface="light">
            <BreadcrumbItem>Profiling</BreadcrumbItem>
            <BreadcrumbItem>All Projects</BreadcrumbItem>
          </Breadcrumbs>
        </div>
        <div className={styles.content}>
          <Tabs orientation="horizontal" indicatorPosition="bottom" size="medium">
            <Tab label="Submit Multiple Requests">
              <AllProjectsMultiRequest />
            </Tab>
            <Tab label="View/Edit Request">
              <AllProjectViewEdit />
            </Tab>
          </Tabs>
        </div>
      </div>
    </>
  )
}
export default AllProjects

