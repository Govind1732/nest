"use client"

import { useState, useRef } from "react"
import { Container, Modal } from "react-bootstrap"
import axios from "axios"
import { GridLoader } from "react-spinners"
import Backdrop from "@mui/material/Backdrop"
import { Button } from "@vds/core"
import styles from "./OneCorp.module.css"
import { CloudUpload } from "@mui/icons-material"

const override = {
  display: "block",
  margin: "0 auto",
  borderColor: "red",
}

const OneCorpRestart = () => {
  const [loading, setLoading] = useState(false)
  const [show, setShow] = useState(false)
  const [modalTitle, setModalTitle] = useState("")
  const [modalBody, setModalBody] = useState("")
  const [isDragging, setIsDragging] = useState(false)
  const [fileName, setFileName] = useState("")
  const fileInputRef = useRef(null)

  const handleClose = () => {
    setShow(false)
    resetHandler()
  }

  const handleUpload = () => {
    const file = fileInputRef.current.files[0]
    if (!file) {
      setModalTitle("")
      setModalBody("Please select a file")
      setShow(true)
      return
    }
    setLoading(true)
    const formData = new FormData()
    formData.append("file", file)

    axios
      .post(`${import.meta.env.VITE_DJANGO_BASE_URL}onecorp_restart/OneCorpRerun/`, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      })
      .then((response) => {
        setLoading(false)
        setModalTitle(response.data.status)
        setModalBody(response.data.message)
        setShow(true)
      })
      .catch((error) => {
        console.error("Error uploading file: ", error)
        setLoading(false)
        setModalTitle(error.status)
        setModalBody(error.message)
        setShow(true)
      })
  }

  const handleSectionClick = () => {
    fileInputRef.current.click()
  }
  const handleDragEnter = (e) => {
    e.preventDefault()
    setIsDragging(true)
  }

  const handleDragLeave = (e) => {
    e.preventDefault()
    setIsDragging(false)
  }
  const handleDrop = (e) => {
    e.preventDefault()
    setIsDragging(false)
    const files = e.dataTransfer.files
    if (files.length > 0) {
      fileInputRef.current.files = files
      setFileName(files[0].name)
    }
  }
  const handleFileChange = (e) => {
    if (e.target.files.length > 0) {
      setFileName(e.target.files[0].name)
    }
  }

  const resetHandler = () => {
    fileInputRef.current.value = ""
  }

  return (
    <>
      <div className={styles.mainContent}>
        <div
          className={styles.uploadSection}
          onClick={handleSectionClick}
          onDragEnter={handleDragEnter}
          onDragOver={(e) => e.preventDefault()}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          style={{
            border: `2px dashed ${isDragging ? "#EE0000" : "#dee2e6"}`,
            borderRadius: "10px",
            backgroundColor: isDragging ? "rgba(238, 0, 0, 0.05)" : "#f8f9fa",
            transition: "all 0.3s ease",
            cursor: "pointer",
          }}
        >
          <div className="text-center">
            <CloudUpload style={{ fontSize: 48, color: "#6c757d" }} />
            <p className="mt-2 text-muted">{fileName ? fileName : "Click or drag file to upload"}</p>
            <input
              type="file"
              accept=".csv"
              ref={fileInputRef}
              onChange={handleFileChange}
              style={{ display: "none" }}
            />
          </div>
        </div>

        <div className="d-flex justify-content-center my-3 gap-4">
          <Button onClick={resetHandler} use="secondary">
            Reset
          </Button>
          <Button onClick={handleUpload}>Submit</Button>
        </div>
      </div>

      <Modal show={show} onHide={() => handleClose()}>
        <Modal.Header closeButton>
          <Modal.Title>{modalTitle}</Modal.Title>
        </Modal.Header>
        <Modal.Body>{modalBody}</Modal.Body>
        <Modal.Footer>
          <Button use="secondary" onClick={handleClose}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>

      <Backdrop sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }} open={loading}>
        <Container className="loading-overlay">
          <GridLoader
            color="#ff0000"
            loading={loading}
            cssOverride={override}
            size={20}
            aria-label="Loading Spinner"
            data-testid="loader"
          />
        </Container>
      </Backdrop>
    </>
  )
}

export default OneCorpRestart

