import { Tabs, Tab } from "@vds/tabs"
import { Title } from "@vds/typography"
import { Breadcrumbs, BreadcrumbItem } from "@vds/breadcrumbs"
import RanDTMultiRequest from "./RanDTMultiRequest"
import DQRerun from "./DQRerun"
// import RanDTViewEdit from './RanDTViewEdit'
import styles from "./RanDT.module.css"

const RanDT = () => {
  return (
    <>
      <div className={styles.section}>
        <div className={styles.subHeading}>
          <Title size="medium" bold={true} color="#000">
            RanDT Rule Profile
          </Title>
          <Breadcrumbs surface="light">
            <BreadcrumbItem>Profiling</BreadcrumbItem>
            <BreadcrumbItem>Rule Profile</BreadcrumbItem>
            <BreadcrumbItem>Ran DT</BreadcrumbItem>
          </Breadcrumbs>
        </div>
        <div className={styles.content}>
          <Tabs orientation="horizontal" indicatorPosition="bottom" size="medium">
            <Tab label="Submit Multiple Requests">
              <RanDTMultiRequest />
            </Tab>
            <Tab label="DQ Rerun">
              <DQRerun />
            </Tab>
            {/* <Tab label="View/Edit Request">
              <RanDTViewEdit />
            </Tab> */}
          </Tabs>
        </div>
      </div>
    </>
  )
}
export default RanDT

