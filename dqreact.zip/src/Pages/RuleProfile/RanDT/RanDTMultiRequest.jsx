"use client"

import { useState, useRef } from "react"
import axios from "axios"
import styles from "./RanDT.module.css"
import { ContentCopy, Visibility, FileDownload, CloudUpload } from "@mui/icons-material"
import IconButton from "@mui/material/IconButton"
import Link from "@mui/material/Link"
import Tooltip from "@mui/material/Tooltip"
import { Button, Loader } from "@vds/core"
import ModalComponent from "../../../Components/LayoutComponents/ModalComponent"

const RanDTMultiRequest = () => {
  const [loading, setLoading] = useState(false)
  const [show, setShow] = useState(false)
  const [modalTitle, setModalTitle] = useState("")
  const [modalBody, setModalBody] = useState("")
  const [tooltipText, setTooltipText] = useState("Copy")
  const [isDragging, setIsDragging] = useState(false)
  const [fileName, setFileName] = useState("")
  const fileInputRef = useRef(null)

  const handleDragEnter = (e) => {
    e.preventDefault()
    setIsDragging(true)
  }

  const handleDragLeave = (e) => {
    e.preventDefault()
    setIsDragging(false)
  }

  const handleDrop = (e) => {
    e.preventDefault()
    setIsDragging(false)
    const files = e.dataTransfer.files
    if (files.length > 0) {
      fileInputRef.current.files = files
      setFileName(files[0].name)
    }
  }

  const handleFileChange = (e) => {
    if (e.target.files.length > 0) {
      setFileName(e.target.files[0].name)
    }
  }

  const handleCopy = () => {
    navigator.clipboard.writeText("dqaas_ran_rule_prfl_mtd.csv")
    setTooltipText("Copied!")
    setTimeout(() => setTooltipText("Copy"), 1500)
  }

  const handleClose = () => {
    setShow(false)
    resetHandler()
  }

  const handleSectionClick = () => {
    fileInputRef.current.click()
  }

  const handleUpload = () => {
    const file = fileInputRef.current.files[0]
    if (!file) {
      setModalTitle("")
      setModalBody("Please select a file")
      setShow(true)
      return
    }

    setLoading(true)
    const formData = new FormData()
    formData.append("file1", file)

    axios
      .post(`${import.meta.env.VITE_DJANGO_BASE_URL}dtran/dtranselfserve/`, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      })
      .then((response) => {
        setLoading(false)
        setModalTitle(response.data.status)
        setModalBody(response.data.message)
        setShow(true)
      })
      .catch((error) => {
        setLoading(false)
        setModalTitle(error.name)
        setModalBody(error.message)
        setShow(true)
      })
  }

  const resetHandler = () => {
    fileInputRef.current.value = ""
    setFileName("")
  }

  return (
    <>
      <div className={styles.mainContent}>
        <div
          className={styles.uploadSection}
          onClick={handleSectionClick}
          onDragEnter={handleDragEnter}
          onDragOver={(e) => e.preventDefault()}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          style={{
            border: `2px dashed ${isDragging ? "#EE0000" : "#dee2e6"}`,
            borderRadius: "10px",
            backgroundColor: isDragging ? "rgba(238, 0, 0, 0.05)" : "#f8f9fa",
            transition: "all 0.3s ease",
            cursor: "pointer",
          }}
        >
          <div className="text-center">
            <CloudUpload style={{ fontSize: 48, color: "#6c757d" }} />
            <p className="mt-2 text-muted">{fileName ? fileName : "Click or drag file to upload"}</p>
            <input
              type="file"
              accept=".csv"
              ref={fileInputRef}
              onChange={handleFileChange}
              style={{ display: "none" }}
            />
          </div>
        </div>
        <div className={styles.templateSection}>
          <Tooltip title={tooltipText} placement="top">
            <span onClick={handleCopy} className="d-flex align-items-center">
              <code
                style={{
                  backgroundColor: "#fff",
                  padding: "8px 12px",
                  borderRadius: "6px",
                  color: "#666",
                  fontSize: "0.9rem",
                  border: "1px solid #dee2e6",
                  cursor: "pointer",
                }}
              >
                dqaas_ran_rule_prfl_mtd.csv
              </code>
              <IconButton size="small" sx={{ ml: 1 }}>
                <ContentCopy fontSize="small" />
              </IconButton>
            </span>
          </Tooltip>

          <div className="template-actions d-flex align-items-center gap-3">
            <Tooltip title="View Template">
              <Link
                target="blank"
                href="https://drive.google.com/file/d/1c59WxnCUyqXiQhYvDsIqb8KsDi61-v3U/view?usp=drive_link"
                sx={{ color: "#444", "&:hover": { color: "#EE0000" } }}
              >
                <Visibility />
              </Link>
            </Tooltip>

            <span style={{ color: "#dee2e6" }}>|</span>

            <Tooltip title="Download Template">
              <Link
                href="https://drive.google.com/uc?export=download&id=1c59WxnCUyqXiQhYvDsIqb8KsDi61-v3U"
                download
                sx={{ color: "#444", "&:hover": { color: "#EE0000" } }}
              >
                <FileDownload />
              </Link>
            </Tooltip>
          </div>
        </div>
        <div className="d-flex justify-content-center gap-3">
          <Button use="secondary" onClick={resetHandler}>
            Reset
          </Button>

          <Button type="submit" onClick={handleUpload}>
            Submit
          </Button>
        </div>
        <Loader fullscreen={true} active={loading} surface="dark" />
        <ModalComponent show={show} handleClose={handleClose} modalTitle={modalTitle} modalBody={modalBody} />
      </div>
    </>
  )
}
export default RanDTMultiRequest

