"use client"

import { useState } from "react"
import { Modal } from "react-bootstrap"
import { Button } from "@vds/core"
import { OutlinedInput } from "@mui/material"
import { FormControl, FormLabel, Stack } from "@mui/joy"
import { Container } from "@mui/system"
import { AdapterDayjs } from "@mui/x-date-pickers-pro/AdapterDayjs"
import { LocalizationProvider, DateRangePicker } from "@mui/x-date-pickers-pro"
import { DemoItem } from "@mui/x-date-pickers/internals/demo"
import { GridLoader } from "react-spinners"
import Backdrop from "@mui/material/Backdrop"
import { LicenseInfo } from "@mui/x-license"
import axios from "axios"
import dayjs from "dayjs"
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Box } from "@mui/material"
import EditIcon from "@mui/icons-material/Edit"
import DeleteIcon from "@mui/icons-material/Delete"
import { IconButton, Tooltip } from "@mui/material"
import styles from "./DQRerun.module.css"

LicenseInfo.setLicenseKey(
  "e0d9bb8070ce0054c9d9ecb6e82cb58fTz0wLEU9MzI0NzIxNDQwMDAwMDAsUz1wcmVtaXVtLExNPXBlcnBldHVhbCxLVj0y",
)

const DQRerun = () => {
  const [sourceTable, setSourceTable] = useState("")
  const [dateRange, setDateRange] = useState([null, null])
  const [tableData, setTableData] = useState([])
  const [editIndex, setEditIndex] = useState(null)
  const [recentlyAdded, setRecentlyAdded] = useState(null)
  const [show, setShow] = useState(false)
  const [modalTitle, setModalTitle] = useState("")
  const [modalBody, setModalBody] = useState("")
  const [loading, setLoading] = useState(false)

  const handleAdd = () => {
    if (!sourceTable || !dateRange[0] || !dateRange[1]) {
      setModalTitle("Validation Error")
      setModalBody("Please fill all fields before adding.")
      setShow(true)
      return
    }
    const startDate = dateRange[0] ? new Date(dateRange[0]).toLocaleDateString("en-CA") : null
    const endDate = dateRange[1] ? new Date(dateRange[1]).toLocaleDateString("en-CA") : null

    const newRow = {
      sourceTable,
      startDate,
      endDate,
    }

    if (editIndex !== null) {
      const updatedData = [...tableData]
      updatedData[editIndex] = newRow
      setTableData(updatedData)
      setRecentlyAdded(editIndex)
      setEditIndex(null)
    } else {
      setTableData([...tableData, newRow])
      setRecentlyAdded(tableData.length)
    }

    // Remove highlight after 5 seconds
    setTimeout(() => {
      setRecentlyAdded(null)
    }, 500)

    resetHandler()
  }

  const handleDelete = (index) => {
    const updatedTableData = tableData.filter((_, i) => i !== index)
    setTableData(updatedTableData)
  }

  const handleEdit = (index) => {
    const rowToEdit = tableData[index]
    setSourceTable(rowToEdit.sourceTable)
    setDateRange([
      rowToEdit.startDate ? dayjs(rowToEdit.startDate) : null,
      rowToEdit.endDate ? dayjs(rowToEdit.endDate) : null,
    ])
    setEditIndex(index)
  }

  const handleDelectAll = () => {
    setTableData([])
  }
  const handleSubmit = async () => {
    console.log(tableData)
    setLoading(true)
    const apiData = tableData.map((row) => ({
      sourceTable: row.sourceTable,
      startDate: row.startDate,
      endDate: row.endDate,
    }))
    try {
      const response = await axios.post(`${import.meta.env.VITE_DJANGO_BASE_URL}dtran/DTRanReRunView/`, apiData)

      if (response.data.status === "SUCCESS") {
        setModalTitle(response.data.status)
        setModalBody(response.data.message)
        setShow(true)
        setTableData([])
      } else {
        throw new Error(response.data.message)
      }
    } catch (error) {
      setModalTitle("ERROR")
      setModalBody(error.message)
      setShow(true)
    } finally {
      setLoading(false)
    }
  }

  const resetHandler = () => {
    setSourceTable("")
    setDateRange([null, null])
  }

  return (
    <>
      <div className={styles.mainContent}>
        {/* <Container maxWidth="xxl"> */}
        <div
          className={styles.container}
          style={{
            display: "flex",
            flexDirection: "column",
            justifyContent: tableData.length > 0 ? "start" : "center",
            gap: "2rem",
            width: "100%",
          }}
        >
          <div
            className={styles.formContainer}
            style={{ display: "flex", flexDirection: "column", gap: "2rem", width: "80%" }}
          >
            <FormControl sx={{ width: "100%" }} required>
              <FormLabel sx={{ fontWeight: "bold" }}>Source Table</FormLabel>
              <OutlinedInput
                placeholder="Please enter text"
                value={sourceTable}
                onChange={(e) => setSourceTable(e.target.value)}
                required
              />
            </FormControl>

            <LocalizationProvider dateAdapter={AdapterDayjs}>
              <DemoItem sx={{ width: "100%" }} label={<span className="fw-bold">Date Range *</span>}>
                <DateRangePicker
                  value={dateRange}
                  onChange={setDateRange}
                  localeText={{ start: "Start Date", end: "End Date" }}
                  required
                />
              </DemoItem>
            </LocalizationProvider>

            <Stack direction="row" spacing={2} justifyContent="center" width="100%">
              <Button onClick={resetHandler} use="secondary">
                Reset
              </Button>

              <Button onClick={handleAdd}>{editIndex !== null ? "Update" : "Add"}</Button>
            </Stack>
          </div>
          {tableData.length > 0 && (
            <Container sx={{ marginTop: 4 }}>
              <TableContainer component={Paper} sx={{ boxShadow: 3 }}>
                <Table sx={{ minWidth: 650 }} aria-label="DQ rerun table">
                  <TableHead>
                    <TableRow
                      sx={{
                        backgroundColor: "black",
                        "& th": {
                          border: "1px solid white",
                          borderBottom: "none",
                        },
                        "& th:first-of-type": {
                          borderLeft: "1px solid black",
                        },
                        "& th:last-child": {
                          borderRight: "1px solid black",
                        },
                      }}
                    >
                      <TableCell
                        sx={{
                          color: "white",
                          fontWeight: "bold",
                          textAlign: "center",
                        }}
                      >
                        #
                      </TableCell>
                      <TableCell
                        sx={{
                          color: "white",
                          fontWeight: "bold",
                          textAlign: "center",
                        }}
                      >
                        Source Table
                      </TableCell>
                      <TableCell
                        sx={{
                          color: "white",
                          fontWeight: "bold",
                          textAlign: "center",
                        }}
                      >
                        Start Date
                      </TableCell>
                      <TableCell
                        sx={{
                          color: "white",
                          fontWeight: "bold",
                          textAlign: "center",
                        }}
                      >
                        End Date
                      </TableCell>
                      <TableCell
                        sx={{
                          color: "white",
                          fontWeight: "bold",
                          textAlign: "center",
                        }}
                      >
                        Actions
                      </TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {tableData.map((row, index) => (
                      <TableRow
                        key={index}
                        sx={{
                          // '&:nth-of-type(odd)': { backgroundColor: '#f5f5f5' },
                          backgroundColor: recentlyAdded === index ? "#ffece0" : "inherit",
                          transition: "background-color 0.5s ease",
                          "&:hover": {
                            backgroundColor: "#f5f5f5",
                          },
                        }}
                      >
                        <TableCell sx={{ textAlign: "center" }}>{index + 1}</TableCell>
                        <TableCell sx={{ textAlign: "center" }}>{row.sourceTable}</TableCell>
                        <TableCell sx={{ textAlign: "center" }}>{row.startDate}</TableCell>
                        <TableCell sx={{ textAlign: "center" }}>{row.endDate}</TableCell>

                        <TableCell sx={{ textAlign: "center" }}>
                          <Stack direction="row" spacing={3} justifyContent="center">
                            <Tooltip title="Edit">
                              <IconButton
                                onClick={() => handleEdit(index)}
                                sx={{
                                  color: "#000",
                                  "&:hover": {
                                    backgroundColor: "rgba(0, 0, 0, 0.1)",
                                    transform: "scale(1.1)",
                                    transition: "all 0.2s",
                                  },
                                }}
                              >
                                <EditIcon />
                              </IconButton>
                            </Tooltip>

                            <Tooltip title="Delete">
                              <IconButton
                                onClick={() => handleDelete(index)}
                                sx={{
                                  color: "#EE0000",
                                  "&:hover": {
                                    backgroundColor: "rgba(211, 47, 47, 0.1)",
                                    transform: "scale(1.1)",
                                    transition: "all 0.2s",
                                  },
                                }}
                              >
                                <DeleteIcon />
                              </IconButton>
                            </Tooltip>
                          </Stack>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>

              <Box
                sx={{
                  display: "flex",
                  justifyContent: "center",
                  gap: "1rem",
                  my: 3,
                }}
              >
                <Button onClick={handleDelectAll} use="secondary">
                  Delete All
                </Button>
                <Button onClick={handleSubmit}>Submit All</Button>
              </Box>
            </Container>
          )}
        </div>

        <Modal show={show} onHide={() => setShow(false)}>
          <Modal.Header closeButton>
            <Modal.Title>{modalTitle}</Modal.Title>
          </Modal.Header>
          <Modal.Body>{modalBody}</Modal.Body>
          <Modal.Footer>
            <Button use="secndary" onClick={() => setShow(false)}>
              Close
            </Button>
          </Modal.Footer>
        </Modal>

        <Backdrop open={loading} sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}>
          <GridLoader color="#ff0000" />
        </Backdrop>
        {/* </Container> */}
      </div>
    </>
  )
}

export default DQRerun

