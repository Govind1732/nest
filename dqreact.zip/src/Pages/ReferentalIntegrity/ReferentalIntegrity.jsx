const ReferentalIntegrity = () => {
  return <div>ReferentalIntegrity</div>
}
export default ReferentalIntegrity

