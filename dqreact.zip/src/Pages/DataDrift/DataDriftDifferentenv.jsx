"use client"

import { useState } from "react"
import { Modal } from "react-bootstrap"
import Backdrop from "@mui/material/Backdrop"
import { Button } from "@vds/core"
import CircularProgress from "@mui/material/CircularProgress"
import TDGCPConnectivityCheck from "../../Components/ConnectivityCheck/TDGCPConnectivityCheck"
import styled from "styled-components"
import styles from "./DataDrift.module.css"
// import ModalComponent from '../../../Components/LayoutComponents/ModalComponent/Modal';
// import { usePostAutopopulateColumnsMutation } from '../../../features/api/djangoapiSlice';
import { usePostDataDriftDifferentEnvMutation } from "../../features/api/djangoapiSlice"

const Container = styled.div`
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    gap: 3rem;
    // position: absolute;
    // top: 50%;
    // left: 50%;
    // transform: translate(-50%, -50%);
    width: 100%;
`
const Content = styled.div`
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    gap: 1em;
`

const DataDriftDifferentenv = () => {
  const [formData, setFormData] = useState({
    source_dbname: "",
    target_dbname: "",
    source_table: "",
    target_table: "",
    mail_distro: "",
  })
  const [additionalFieldsVisible, setAdditionalFieldsVisible] = useState(false)
  const [modalTitle, setModalTitle] = useState("")
  const [modalBody, setModalBody] = useState("")
  const [show, setShow] = useState(false)
  // const [TDformData, setTDFormData] = useState(null);
  // const [GCPformData, setGCPFormData] = useState(null);
  const handleTDData = (data) => {
    setFormData((prevState) => ({
      ...prevState,
      source_dbname: data.dbname,
      source_table: data.table_name,
    }))
    // console.log('Data received from child:', data);
  }
  const handleGCPData = (data) => {
    setFormData((prevState) => ({
      ...prevState,
      target_dbname: data.project_name + "." + data.dbname,
      target_table: data.table_name,
    }))
    // console.log('Data received from child:', data);
  }
  const handleEmailChange = (data) => {
    setFormData((prevState) => ({
      ...prevState,
      mail_distro: data,
    }))
  }
  const handleConnectivityStatus = (data) => {
    setAdditionalFieldsVisible(data)
  }
  // const [postAutopopulateColumns, { isLoading: isPostAutopopulateColumnsLoading }] = usePostAutopopulateColumnsMutation();
  const [postDataDriftDiffEnv, { isLoading: isPostDataDriftSameEnvLoading }] = usePostDataDriftDifferentEnvMutation()
  const loading = isPostDataDriftSameEnvLoading
  const resetHandler = () => {
    console.log("Resetting form")
    setFormData({
      source_dbname: "",
      target_dbname: "",
      source_table: "",
      target_table: "",
      mail_distro: "",
    })
    console.log(formData)
    // handleConnectivityStatus(false);
  }
  const handleClose = () => {
    setShow(false)
  }
  const dataDriftSameenvSubmitHandler = async () => {
    console.log(formData)
    try {
      const response = await postDataDriftDiffEnv(formData)
      console.log(response.data)
      setModalTitle("Data Drift Same Environment")
      setModalBody(response.data.message)
      setShow(true)
    } catch (err) {
      console.error("Error fetching additional details:", err)
    }
  }
  return (
    <>
      <ModalComponent show={show} handleClose={handleClose} title={modalTitle} body={modalBody} onClose={handleClose} />
      {loading && (
        <Backdrop sx={{ color: "#ddd", zIndex: (theme) => theme.zIndex.drawer + 1 }} open={loading}>
          <CircularProgress color="inherit" />
        </Backdrop>
      )}
      <div className={styles.mainContent}>
        <Container>
          {/* <h4 style={{ color: '#EE0000' }}>Data Drift Different Environment</h4> */}
          <Content>
            <div style={{}}>
              <TDGCPConnectivityCheck
                handleConnectivityStatus={handleConnectivityStatus}
                handleTDData={handleTDData}
                handleGCPData={handleGCPData}
                onEmailChange={handleEmailChange}
              />
            </div>
            <div
              style={{
                display: additionalFieldsVisible ? "flex" : "none",
                justifyContent: "center",
                alignItems: "center",
                gap: "1rem",
              }}
            >
              {/* <button onClick={resetHandler} style={{ display: 'block', background: '#000', color: '#fff', borderRadius: '30px', padding: '0.25em 1em' }}>Reset</button> */}
              <Button
                onClick={dataDriftSameenvSubmitHandler}
                style={{
                  display: additionalFieldsVisible ? "none" : "block",
                }}
              >
                Submit
              </Button>
            </div>
          </Content>
        </Container>
      </div>
    </>
  )
}

const ModalComponent = ({ show, title, body, onClose }) => (
  <Modal show={show} onHide={onClose}>
    <Modal.Header closeButton>
      <Modal.Title>{title}</Modal.Title>
    </Modal.Header>
    <Modal.Body>{body}</Modal.Body>
    <Modal.Footer>
      <Button
        variant="secondary"
        onClick={() => {
          onClose()
        }}
      >
        Close
      </Button>
    </Modal.Footer>
  </Modal>
)

export default DataDriftDifferentenv

