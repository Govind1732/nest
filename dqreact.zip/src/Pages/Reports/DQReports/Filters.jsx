"use client"

import { useState, useEffect, useCallback, useMemo } from "react"
import { Autocomplete, TextField, CircularProgress } from "@mui/material"
import styles from "./DQReport.module.css"
import { Title, Button, TextLink } from "@vds/core"
import { useGetDynamicFilterQuery, usePostDynamicFilterMutation } from "../../../features/api/nodeapiSlice.js"
import { yesterday, getLast7Days, getLast14Days, getLast30Days, getLast90Days } from "./dates.js"
import { useDispatch, useSelector } from "react-redux"
import { setFilterValues, resetFilterValues, startDate, endDate } from "../../../features/DQReport/dqReportActions"

const Filters = () => {
  const dispatch = useDispatch()
  const dropdownValues = useSelector((state) => state.dqReport.filterValues)
  const [postDynamicFilter, setPostDynamicFilter] = useState([])

  const { data: getDynamicFilter = [], isLoading: isGetDynamicFilterLoading } = useGetDynamicFilterQuery()
  const [postDynamicFilterMutation, { isLoading: isPostDynamicFilterLoading }] = usePostDynamicFilterMutation()

  const dateRanges = useMemo(
    () => ({
      yesterday: yesterday(),
      last7days: getLast7Days(),
      last14days: getLast14Days(),
      last30days: getLast30Days(),
      last90days: getLast90Days(),
    }),
    [],
  )

  useEffect(() => {
    const { run_date } = dropdownValues
    const formattedRunDate = run_date?.replaceAll("_", "").toLowerCase()
    const dateRange = dateRanges[formattedRunDate]
    console.log("dateRange:", dateRange)
    if (dateRange) {
      dispatch(startDate(dateRange[0]))
      dispatch(endDate(dateRange[dateRange.length - 1]))
    }
  }, [dropdownValues, dateRanges, dispatch])

  const handleRunDate = useCallback(
    (event, value, name) => {
      dispatch(setFilterValues({ ...dropdownValues, [name]: value.split(" ").join("_").toLowerCase() }))
    },
    [dispatch, dropdownValues],
  )

  const handleDropdownChange = useCallback(
    async (event, value, name) => {
      const newValues = { ...dropdownValues, [name]: value }
      dispatch(setFilterValues(newValues))

      if (["data_lob", "product_type", "product_area", "product_name", "business_program_data"].includes(name)) {
        try {
          const response = await postDynamicFilterMutation({ [name]: value }).unwrap()
          setPostDynamicFilter(response?.filterdropdownData)

          const updatedValues = { ...newValues }
          response.filterdropdownData.forEach((filter) => {
            if (filter.options.length === 1) {
              updatedValues[filter.name] = filter.options[0]
            }
          })
          dispatch(setFilterValues(updatedValues))
        } catch (error) {
          console.error("Failed to post data:", error)
        }
      }
    },
    [postDynamicFilterMutation, dropdownValues, dispatch],
  )

  const isFormValid = useMemo(() => {
    const nonRunDateKeys = Object.keys(dropdownValues).filter((key) => key !== "run_date")
    const selectedNonRunDateKeys = nonRunDateKeys.filter((key) => dropdownValues[key] !== null)
    return selectedNonRunDateKeys.length === 0 || selectedNonRunDateKeys.length === nonRunDateKeys.length
  }, [dropdownValues])

  const handleFilterSubmit = useCallback(
    async (e) => {
      e.preventDefault()
      if (!isFormValid) {
        alert("Please fill all the fields.")
        return
      }
      const filterValues = Object.keys(dropdownValues)
        .filter((key) => dropdownValues[key] !== null)
        .reduce((acc, key) => {
          acc[key] = dropdownValues[key]
          return acc
        }, {})

      filterValues.run_date = filterValues.run_date.split(" ").join("_").toLowerCase()
      console.log("Filter Values:", filterValues)

      try {
        const response = await postDynamicFilterMutation(filterValues).unwrap()
        console.log("API Response:", response)
      } catch (error) {
        console.error("Failed to submit filter values:", error)
      }
    },
    [dropdownValues, isFormValid, postDynamicFilterMutation],
  )

  const handleReset = useCallback(
    (e) => {
      e.preventDefault()
      dispatch(resetFilterValues())
      setPostDynamicFilter([])
    },
    [dispatch],
  )

  const renderAutocomplete = useCallback(
    (label, name, options, required = false) => (
      <Autocomplete
        key={name}
        autoHighlight
        options={Array.isArray(options) ? options : []}
        sx={{ width: "100%", backgroundColor: "#fff" }}
        size="small"
        loading={isGetDynamicFilterLoading || isPostDynamicFilterLoading}
        disabled={isGetDynamicFilterLoading || isPostDynamicFilterLoading}
        onChange={(event, value) =>
          name === "run_date" ? handleRunDate(event, value, name) : handleDropdownChange(event, value, name)
        }
        value={dropdownValues[name]}
        renderInput={(params) => (
          <TextField
            {...params}
            label={label}
            required={required}
            slotProps={{
              input: {
                ...params.InputProps,
                endAdornment: (
                  <>
                    {(isGetDynamicFilterLoading || isPostDynamicFilterLoading) && (
                      <CircularProgress color="inherit" size={20} />
                    )}
                    {params.InputProps.endAdornment}
                  </>
                ),
              },
            }}
          />
        )}
      />
    ),
    [dropdownValues, handleDropdownChange, isGetDynamicFilterLoading, isPostDynamicFilterLoading, handleRunDate],
  )

  const runDateOptions = useMemo(
    () => [
      { name: "Yesterday", label: "Yesterday" },
      { name: "Last_7_days", label: "Last 7 days" },
      { name: "Last_14_days", label: "Last 14 days" },
      { name: "Last_30_days", label: "Last 30 days" },
      { name: "Last_90_days", label: "Last 90 days" },
    ],
    [],
  )

  const filterFields = useMemo(
    () => [
      { label: "Run Date", name: "run_date", options: runDateOptions.map((option) => option.label), required: true },
      {
        label: "Platform",
        name: "platform",
        options: getDynamicFilter.find((filter) => filter.name === "data_src")?.options || [],
      },
      {
        label: "LOB",
        name: "data_lob",
        options:
          postDynamicFilter.find((filter) => filter.name === "data_lob")?.options ||
          getDynamicFilter.find((filter) => filter.name === "data_lob")?.options ||
          [],
      },
      {
        label: "Product Type",
        name: "product_type",
        options:
          postDynamicFilter.find((filter) => filter.name === "product_type")?.options ||
          getDynamicFilter.find((filter) => filter.name === "product_type")?.options ||
          [],
      },
      {
        label: "Product Area",
        name: "product_area",
        options:
          postDynamicFilter.find((filter) => filter.name === "product_area")?.options ||
          getDynamicFilter.find((filter) => filter.name === "product_area")?.options ||
          [],
      },
      {
        label: "Product Name",
        name: "product_name",
        options:
          postDynamicFilter.find((filter) => filter.name === "product_name")?.options ||
          getDynamicFilter.find((filter) => filter.name === "product_name")?.options ||
          [],
      },
      {
        label: "Business Program",
        name: "business_program_data",
        options:
          postDynamicFilter.find((filter) => filter.name === "business_program_data")?.options ||
          getDynamicFilter.find((filter) => filter.name === "business_program_data")?.options ||
          [],
        required: false,
      },
    ],
    [getDynamicFilter, postDynamicFilter, runDateOptions],
  )

  return (
    <div className={styles.filter}>
      <div className={styles.filterHeader}>
        <Title bold color="#000000">
          Filters
        </Title>
        <div>
          <TextLink type="inline" onClick={handleReset}>
            Clear All
          </TextLink>
        </div>
      </div>
      <div className={styles.filterBody}>
        {filterFields.map((field) => renderAutocomplete(field.label, field.name, field.options, field.required))}
        <div>
          <Button size="large" disabled={!isFormValid} use="primary" onClick={handleFilterSubmit}>
            Submit
          </Button>
        </div>
      </div>
    </div>
  )
}

export default Filters

