"use client"

import { useEffect, useRef } from "react"
import styles from "./DQReport.module.css"
import { strokeColorHigh, strokeColorMedium, strokeColorLow } from "../../../utils/colors"

const RadialBar = ({ percentage }) => {
  const radialBarRef = useRef(null)

  useEffect(() => {
    const radialBar = radialBarRef.current
    let color

    if (percentage > 90) {
      color = strokeColorHigh
    } else if (percentage > 80 && percentage <= 90) {
      color = strokeColorMedium
    } else if (percentage <= 80) {
      color = strokeColorLow
    } else {
      color = "#f6f6f6"
    }

    if (radialBar) {
      radialBar.style.background = `conic-gradient(${color} ${percentage}%, #f6f6f6 ${percentage}%)`
      const span = radialBar.querySelector("span")
      if (span) {
        span.innerText = `${percentage}%`
        if (percentage > 90) {
          span.style.color = strokeColorHigh
        } else if (percentage > 80 && percentage <= 90) {
          span.style.color = strokeColorMedium
        } else {
          span.style.color = strokeColorLow
        }
      }
    }
  }, [percentage])

  return (
    <div ref={radialBarRef} className={styles.radial_bar}>
      <span className={styles.radialBar_score}></span>
    </div>
  )
}

export default RadialBar

