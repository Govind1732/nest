"use client"

import { useRef, useEffect } from "react"
import styles from "./DQReport.module.css"
import Chart from "chart.js/auto"
import { strokeColorHigh, strokeColorMedium, strokeColorLow } from "../../../utils/colors"

const DQLinechart = ({ trendData }) => {
  const formatDate = (dateString) => {
    const [, month, day] = dateString.split("-")
    return `${month}/${day}`
  }
  const chartRef = useRef(null)

  useEffect(() => {
    if (!chartRef.current) return

    const ctx = chartRef.current.getContext("2d")

    const chartConfig = {
      type: "line",
      data: {
        labels: trendData.map((date) => formatDate(date.run_date)),
        datasets: [
          {
            fill: false,
            lineTension: 0,
            data: trendData.map((date) => date.trend_score),
            backgroundColor: (context) => getLineBackgroundColor(context.raw),
            borderColor: "#000",
            pointRadius: 5,
            pointHoverRadius: 10,
          },
        ],
      },
      options: {
        plugins: {
          legend: { display: false },
          tooltip: {
            bodyFont: { size: 15 },
            padding: 10,
            boxPadding: 10,
          },
          datalabels: {
            color: "#000",
            font: { size: 15 },
            anchor: "end",
            align: "bottom",
            formatter: (value) => (value !== null ? `${value}%` : ""),
          },
        },
        scales: {
          x: getXLineAxisConfig(),
          y: getYLineAxisConfig(),
        },
        layout: {
          padding: {
            right: 30,
            top: 0,
          },
        },
      },
      plugins: [
        {
          id: "datalabels",
          afterDatasetsDraw: (chart) => {
            const ctx = chart.ctx
            chart.data.datasets.forEach((dataset, i) => {
              const meta = chart.getDatasetMeta(i)
              meta.data.forEach((point, index) => {
                const value = dataset.data[index]
                if (value !== null && trendData.length <= 7) {
                  ctx.fillStyle = "#000"
                  ctx.font = "15px Arial"
                  ctx.fillText(value + "%", point.x - 12, point.y + 20)
                }
              })
            })
          },
        },
      ],
    }

    const myChart = new Chart(ctx, chartConfig)

    return () => myChart.destroy()
  }, [trendData])

  const getLineBackgroundColor = (value) => {
    if (value > 90) return strokeColorHigh
    if (value > 80 && value <= 90) return strokeColorMedium
    return strokeColorLow
  }
  const getXLineAxisConfig = () => ({
    display: true,
    grid: { display: false, color: "#D8DADA" },
    ticks: {
      font: { size: 14 },
      color: "#6F7171",
    },
    border: { color: "#000" },
  })

  const getYLineAxisConfig = () => ({
    display: true,
    grid: { display: false },
    beginAtZero: true,
    min: 0,
    max: 100,
    ticks: {
      stepSize: 20,
      font: { size: 14 },
      color: "#6F7171",
      callback: (value) => (value === 0 ? "" : `${value}%`),
    },
    border: { color: "#000" },
  })
  return (
    <>
      <canvas ref={chartRef} className={styles.trend_chart}></canvas>
    </>
  )
}

export default DQLinechart

