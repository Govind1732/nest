"use client"
// import { DQDomainLevelReportContext } from '../../../context/DQDomainLevelReportContext';
import { useSelector } from "react-redux"
import styles from "./DQDomainLevelReport.module.css"
import CompletenessIcon from "../../../assets/images/icons/checkmark-alt_blk 1.svg"
import UniquenessIcon from "../../../assets/images/icons/Medal_blk 1.svg"
import TimelinessIcon from "../../../assets/images/icons/real-time_blk 1.svg"
import ConsistencyIcon from "../../../assets/images/icons/grid-view_blk 1.svg"
import ValidityIcon from "../../../assets/images/icons/insurance_blk 1.svg"
import ConfirmityIcon from "../../../assets/images/icons/thumbs-up_blk 1.svg"
import truncateDecimal from "../../../utils/truncateDecimal"
import { strokeColorHigh, strokeColorMedium, strokeColorLow } from "../../../utils/colors"

const DQDomainLevelColumns = () => {
  // const { columnsData } = useContext(DQDomainLevelReportContext);
  const columnsData = useSelector((state) => state.dqDomainLevelReport.columnsData)
  const calculateColumnAverage = (obj) => {
    const values = Object.values(obj).map((value) => {
      const parsed = Number.parseFloat(value)
      return isNaN(parsed) ? value : parsed
    })

    const numericValues = values.filter((value) => typeof value === "number")
    const sum = numericValues.reduce((acc, value) => acc + value, 0)
    const average = sum / numericValues.length

    return average
  }

  const metricIcons = {
    completeness: CompletenessIcon,
    uniqueness: UniquenessIcon,
    timeliness: TimelinessIcon,
    consistency: ConsistencyIcon,
    validity: ValidityIcon,
    conformity: ConfirmityIcon,
  }

  return (
    <>
      <table className={styles.tableContainer}>
        <thead>
          {columnsData.length > 0 && (
            <tr>
              {Object.keys(columnsData[0]).map((columnName, index) =>
                columnName === "columnName" ? (
                  <th key={`column-${index}`}></th> // Added unique key here
                ) : (
                  <th key={index} className={styles.tableHeader}>
                    <div className={styles.tableColumnHeader}>
                      <div>
                        {metricIcons[columnName.toLowerCase()] ? (
                          <picture className={styles.metricIcon}>
                            <img
                              src={metricIcons[columnName.toLowerCase()]}
                              alt={columnName}
                              style={{ width: "30px", height: "30px" }}
                            />
                          </picture>
                        ) : null}
                      </div>
                      <div className={styles.columnHeader}>{columnName}</div>
                    </div>
                  </th>
                ),
              )}
              <th className={styles.overallScoreHeader}>
                Overall
                <br />
                Score
              </th>
            </tr>
          )}
        </thead>

        <tbody>
          {columnsData.map((column, index) => (
            <tr key={index} className={index % 2 === 0 ? styles.evenRow : styles.oddRow}>
              {Object.entries(column).map(([key, value], idx) => {
                const parsedValue = isNaN(value) ? value : Number.parseInt(value)

                return (
                  <td key={idx} className={styles.tableData}>
                    {parsedValue === null ? (
                      <span style={{ display: "flex", justifyContent: "center" }}>-</span>
                    ) : typeof parsedValue === "number" ? (
                      truncateDecimal(parsedValue, 1) > 90 ? (
                        <span style={{ color: strokeColorHigh, display: "flex", justifyContent: "center" }}>
                          {truncateDecimal(parsedValue, 1)}%
                        </span>
                      ) : truncateDecimal(parsedValue, 1) > 80 ? (
                        <span style={{ color: strokeColorMedium, display: "flex", justifyContent: "center" }}>
                          {truncateDecimal(parsedValue, 1)}%
                        </span>
                      ) : (
                        <span style={{ color: strokeColorLow, display: "flex", justifyContent: "center" }}>
                          {truncateDecimal(parsedValue, 1)}%
                        </span>
                      )
                    ) : (
                      <span className={styles.tableName} style={{ textAlign: "left" }}>
                        {parsedValue}
                      </span>
                    )}
                  </td>
                )
              })}

              <td
                className={styles.tableData}
                style={{ textAlign: "center", backgroundColor: index % 2 === 0 ? "#FFFFFF" : "#E3F2FD" }}
              >
                {calculateColumnAverage(column) !== null ? (
                  truncateDecimal(calculateColumnAverage(column), 1) > 90 ? (
                    <span style={{ color: strokeColorHigh }}>
                      {truncateDecimal(calculateColumnAverage(column), 1)}%
                    </span>
                  ) : truncateDecimal(calculateColumnAverage(column), 1) > 80 ? (
                    <span style={{ color: strokeColorMedium }}>
                      {truncateDecimal(calculateColumnAverage(column), 1)}%
                    </span>
                  ) : (
                    <span style={{ color: strokeColorLow }}>{truncateDecimal(calculateColumnAverage(column), 1)}%</span>
                  )
                ) : (
                  "-"
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  )
}
export default DQDomainLevelColumns

