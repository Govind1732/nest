import CircularProgress from "@mui/material/CircularProgress"
import styles from "./DQDomainLevelReport.module.css"
import truncateDecimal from "../../../utils/truncateDecimal"
import { strokeColorHigh } from "../../../utils/colors"

const ModalBodyContent = ({ topBottomScores, isTopBottomScoresLoading, isTopBottomScoresError, selectedPillar }) => {
  console.log(
    "topBottomScores:",
    topBottomScores?.top_5_scores &&
      topBottomScores?.bottom_5_scores &&
      [
        ...topBottomScores.top_5_scores.map((item) => item.score),
        ...topBottomScores.bottom_5_scores.map((item) => item.score),
      ].some((item) => Number.parseInt(item) !== "100"),
  )
  return (
    <>
      {isTopBottomScoresLoading ? (
        <div className={styles.loader}>
          <CircularProgress color="inherit" />
        </div>
      ) : isTopBottomScoresError ? (
        <div className={styles.error}>
          <p>There was an error loading the scores. Please try again later.</p>
        </div>
      ) : (
        <div className={styles.modalBody}>
          {topBottomScores?.top_5_scores &&
          topBottomScores?.bottom_5_scores &&
          [
            ...topBottomScores.top_5_scores.map((item) => item.score),
            ...topBottomScores.bottom_5_scores.map((item) => item.score),
          ].some((item) => Number.parseInt(item) !== 100) ? (
            <>
              <table className={styles.modalTable}>
                <thead style={{ background: "#dcf5e6", color: "#008331", borderRadius: "10px 10px 0 0" }}>
                  <tr style={{ display: "flex", justifyContent: "center", alignItems: "center", padding: "0.5em 0" }}>
                    <th colSpan={2}>Top 5 Scores</th>
                  </tr>
                </thead>
                <tbody>
                  {topBottomScores.top_5_scores.length > 0 &&
                    topBottomScores.top_5_scores.map((item, index) => (
                      <tr
                        key={index}
                        style={{
                          borderBottom: "none",
                          borderLeft: "none",
                          borderRight: "none",
                          borderTop: "1px solid #ddd",
                        }}
                      >
                        <td style={{ padding: "0.5em" }}>{item.table}</td>
                        <td
                          style={{
                            padding: "0.5em",
                            textAlign: "end",
                          }}
                        >
                          <span
                            style={{
                              backgroundColor:
                                truncateDecimal(item.score, 1) > 90
                                  ? "var(--vds-color-feedback-success)"
                                  : truncateDecimal(item.score, 1) > 80
                                    ? "var(--vds-color-feedback-warning)"
                                    : "var(--vds-color-feedback-error)",
                              color:
                                truncateDecimal(item.score, 1) > 90
                                  ? "var(--stroke-color-success)"
                                  : truncateDecimal(item.score, 1) > 80
                                    ? "var(--stroke-color-medium)"
                                    : "var(--stroke-color-low)",
                              padding: "0.25em 0.5em",
                              borderRadius: "20px",
                            }}
                          >
                            {truncateDecimal(item.score, 1)}%
                          </span>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>

              {topBottomScores.bottom_5_scores.length > 0 &&
                topBottomScores.bottom_5_scores.filter((item, index) => item.score !== 100).length > 0 && (
                  <table className={styles.modalTable}>
                    <thead style={{ background: "#FFECE0", color: "#B95319", borderRadius: "10px 10px 0 0" }}>
                      <tr
                        style={{ display: "flex", justifyContent: "center", alignItems: "center", padding: "0.5em 0" }}
                      >
                        <th colSpan={2}>Low 5 Scores</th>
                      </tr>
                    </thead>
                    <tbody>
                      {topBottomScores.bottom_5_scores.length > 0 &&
                        topBottomScores.bottom_5_scores
                          .filter((item, index) => item.score !== 100)
                          .map((item, index) => (
                            <tr
                              key={index}
                              style={{
                                borderBottom: "none",
                                borderLeft: "none",
                                borderRight: "none",
                                borderTop: "1px solid #ddd",
                              }}
                            >
                              <td style={{ padding: "0.5em" }}>{item.table}</td>
                              <td
                                style={{
                                  padding: "0.5em",
                                  textAlign: "end",
                                }}
                              >
                                <span
                                  style={{
                                    backgroundColor:
                                      truncateDecimal(item.score, 1) > 90
                                        ? "var(--vds-color-feedback-success)"
                                        : truncateDecimal(item.score, 1) > 80
                                          ? "var(--vds-color-feedback-warning)"
                                          : "var(--vds-color-feedback-error)",
                                    color:
                                      truncateDecimal(item.score, 1) > 90
                                        ? "var(--stroke-color-success)"
                                        : truncateDecimal(item.score, 1) > 80
                                          ? "var(--stroke-color-medium)"
                                          : "var(--stroke-color-low)",
                                    padding: "0.25em 0.5em",
                                    borderRadius: "20px",
                                  }}
                                >
                                  {truncateDecimal(item.score, 1)}%
                                </span>
                              </td>
                            </tr>
                          ))}
                    </tbody>
                  </table>
                )}
            </>
          ) : (
            <b style={{ color: strokeColorHigh }} className={styles.pillar100}>
              All tables scored 100% in {selectedPillar}.
            </b>
          )}
        </div>
      )}
    </>
  )
}

export default ModalBodyContent

