"use client"

import { useRef, useEffect } from "react"
import styles from "./DQDomainLevelReport.module.css"
// import styles from './DQReport.module.css';
import Chart from "chart.js/auto"
import PropTypes from "prop-types"
import { strokeColorHigh, strokeColorMedium, strokeColorLow } from "../../../utils/colors"
import GraphLoader from "../../../Components/LayoutComponents/GraphLoader"
// import { Loader } from "@vds/loaders"
import { Title } from "@vds/typography"

const DQReportLineChart = ({ dqTrendData, isDqTrendDataLoading }) => {
  const formatDate = (dateString) => {
    const [year, month, day] = dateString.split("-")
    return `${month}/${day}`
  }

  const chartRef = useRef(null)

  useEffect(() => {
    if (!chartRef.current) return

    const ctx = chartRef.current.getContext("2d")

    const chartConfig = {
      type: "line",
      data: {
        labels: dqTrendData?.trend_line.map((date) => formatDate(date.run_date)),
        datasets: [
          {
            fill: false,
            lineTension: 0,
            data: dqTrendData?.trend_line.map((date) => date.trend_score),
            backgroundColor: (context) => getLineBackgroundColor(context.raw),
            borderColor: "#000",
            pointRadius: 5,
            pointHoverRadius: 10,
          },
        ],
      },
      options: {
        plugins: {
          legend: { display: false },
          tooltip: {
            bodyFont: { size: 15 },
            padding: 10,
            boxPadding: 10,
          },
          datalabels: {
            color: "#000",
            font: { size: 15 },
            anchor: "end",
            align: "bottom",
            formatter: (value) => (value !== null ? `${value}%` : ""),
          },
        },
        scales: {
          x: getXLineAxisConfig(),
          y: getYLineAxisConfig(),
        },
        layout: {
          padding: {
            right: 50,
            top: 20,
          },
        },
      },
      plugins: [
        {
          id: "datalabels",
          afterDatasetsDraw: (chart) => {
            const ctx = chart.ctx
            chart.data.datasets.forEach((dataset, i) => {
              const meta = chart.getDatasetMeta(i)
              meta.data.forEach((point, index) => {
                const value = dataset.data[index]
                if (value !== null && dqTrendData?.trend_line.length <= 7) {
                  ctx.fillStyle = "#000"
                  ctx.font = "15px Arial"
                  ctx.fillText(value + "%", point.x - 12, point.y + 20)
                }
              })
            })
          },
        },
      ],
    }

    const myChart = new Chart(ctx, chartConfig)

    return () => myChart.destroy()
  }, [dqTrendData])

  const getLineBackgroundColor = (value) => {
    if (value > 90) return strokeColorHigh
    if (value > 80 && value <= 90) return strokeColorMedium
    return strokeColorLow
  }
  const getXLineAxisConfig = () => ({
    display: true,
    grid: { display: false, color: "#D8DADA" },
    ticks: {
      font: { size: 14 },
      color: "#6F7171",
    },
    border: { color: "#000" },
  })

  const getYLineAxisConfig = () => ({
    display: true,
    grid: { display: false },
    beginAtZero: true,
    min: 0,
    max: 100,
    ticks: {
      stepSize: 20,
      font: { size: 14 },
      color: "#6F7171",
      callback: (value) => (value === 0 ? "" : `${value}%`),
    },
    border: { color: "#000" },
  })
  return (
    <>
      <div className={styles.trendChart}>
        {isDqTrendDataLoading ? (
          <div className={styles.loader}>
            <GraphLoader />
          </div>
        ) : (
          <>
            <div className={styles.trendChartHeader}>
              <Title size="small" bold={false} color="#EE0000">
                DQ Score for last 7 days
              </Title>
            </div>
            <canvas ref={chartRef}></canvas>
          </>
        )}
      </div>
    </>
  )
}

DQReportLineChart.propTypes = {
  dqTrendData: PropTypes.shape({
    trend_line: PropTypes.arrayOf(
      PropTypes.shape({
        run_date: PropTypes.string.isRequired,
        trend_score: PropTypes.number.isRequired,
      }),
    ).isRequired,
  }).isRequired,
  isDqTrendDataLoading: PropTypes.bool.isRequired,
}

export default DQReportLineChart

