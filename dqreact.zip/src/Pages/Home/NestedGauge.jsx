import { CircularProgress } from "@mui/material"

const NestedGauge = ({ dqScore }) => {
  const values =
    dqScore &&
    Object.entries(dqScore[0])
      .filter(
        ([key, value]) => key !== "OVERALL_AVG_integrity_PG" && key !== "OVERALL_AVG_DQ_SCORE_PG" && value !== "0",
      )
      .map(([key, value]) => Number.parseFloat(value))
  const size = 100 // Base size for the outermost CircularProgress
  const thickness = 1 // Thickness for each CircularProgress
  const colors = ["#EB9DA2", "#F0B884", "#E8E6A5", "#BBE8B5", "#ACBBE8", "#C5ACE8"]
  return (
    <div style={{ width: "100%", height: "100%", display: "flex", justifyContent: "center", alignItems: "center" }}>
      <NestedCircularProgress levels={6} values={values} size={size} thickness={thickness} colors={colors} />
    </div>
  )
}

const NestedCircularProgress = ({ levels, values, size, thickness, colors }) => {
  if (levels === 0) return null

  const currentValue = values[values.length - levels]
  const currentColor = colors[colors.length - levels]
  const currentSize = size - 10
  const currentThickness = thickness

  return (
    <div
      style={{
        position: "relative",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        width: `${currentSize}%`,
        height: `${currentSize}%`,
      }}
    >
      <CircularProgress
        variant="determinate"
        value={currentValue}
        thickness={currentThickness}
        style={{ color: currentColor, position: "absolute", top: 0, left: 0, width: "100%", height: "100%" }}
      />
      <div
        style={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          width: "100%",
          height: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <NestedCircularProgress levels={levels - 1} values={values} size={size} thickness={thickness} colors={colors} />
      </div>
    </div>
  )
}
//  width: `${currentSize}%`, height: `${currentSize}%`
export default NestedGauge

