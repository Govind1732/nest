"use client"

import { useRef, useEffect, useMemo } from "react"
import PropTypes from "prop-types"
import Chart from "chart.js/auto"
import { Title } from "@vds/typography"
import GraphLoader from "../../Components/LayoutComponents/GraphLoader"
import styles from "./Home.module.css"
import { strokeColorHigh, strokeColorMedium, strokeColorLow } from "../../utils/colors"

const DQReportLineChart = ({ dqTrendData, isDqTrendDataLoading }) => {
  const chartRef = useRef(null)

  const formatDate = (dateString) => {
    const [, month, day] = dateString.split("-")
    return `${month}/${day}`
  }

  const getLineBackgroundColor = (value) => {
    if (value > 90) return strokeColorHigh
    if (value > 80 && value <= 90) return strokeColorMedium
    return strokeColorLow
  }

  const axisConfig = useMemo(
    () => ({
      x: {
        display: true,
        grid: { display: false },
        ticks: { color: "#000" },
        border: { color: "#000" },
      },
      y: {
        display: true,
        grid: { display: false },
        ticks: {
          stepSize: 20,
          color: "#000",
          callback: (value) => (value === 0 ? "" : `${value}%`),
        },
        border: { color: "#000" },
        beginAtZero: true,
        min: 0,
        max: 100,
      },
    }),
    [],
  )

  useEffect(() => {
    if (!chartRef.current) return

    const ctx = chartRef.current.getContext("2d")

    const chartConfig = {
      type: "line",
      data: {
        labels: dqTrendData?.trend_line.map((date) => formatDate(date.run_date)),
        datasets: [
          {
            fill: false,
            lineTension: 0,
            data: dqTrendData?.trend_line.map((date) => date.trend_score),
            backgroundColor: (context) => getLineBackgroundColor(context.raw),
            borderColor: "#000",
            pointRadius: 5,
            pointHoverRadius: 10,
          },
        ],
      },
      options: {
        plugins: {
          legend: { display: false },
          tooltip: {
            padding: 10,
            boxPadding: 10,
          },
          datalabels: {
            color: "#000",
            anchor: "end",
            align: "bottom",
            formatter: (value) => (value !== null ? `${value}%` : ""),
          },
        },
        scales: {
          x: axisConfig.x,
          y: axisConfig.y,
        },
        layout: {
          padding: {
            top: 20,
            right: 30,
          },
        },
      },
      plugins: [
        {
          id: "datalabels",
          afterDatasetsDraw: (chart) => {
            const ctx = chart.ctx
            chart.data.datasets.forEach((dataset, i) => {
              const meta = chart.getDatasetMeta(i)
              meta.data.forEach((point, index) => {
                const value = dataset.data[index]
                if (value !== null && dqTrendData?.trend_line.length <= 7) {
                  ctx.fillStyle = "#000"
                  ctx.fillText(`${value}%`, point.x - 12, point.y + 20)
                }
              })
            })
          },
        },
      ],
    }

    const myChart = new Chart(ctx, chartConfig)

    return () => myChart.destroy()
  }, [dqTrendData, axisConfig])

  return (
    <div className={styles.trendChart}>
      {isDqTrendDataLoading ? (
        <div className={styles.loader}>
          <GraphLoader />
        </div>
      ) : (
        <>
          <div className={styles.trendChartHeader}>
            <Title size="small" bold color="#000">
              DQ Score for last 7 days
            </Title>
          </div>
          <div className={styles.lineChartBody}>
            <canvas ref={chartRef}></canvas>
          </div>
        </>
      )}
    </div>
  )
}

DQReportLineChart.propTypes = {
  dqTrendData: PropTypes.shape({
    trend_line: PropTypes.arrayOf(
      PropTypes.shape({
        run_date: PropTypes.string.isRequired,
        trend_score: PropTypes.number.isRequired,
      }),
    ).isRequired,
  }).isRequired,
  isDqTrendDataLoading: PropTypes.bool.isRequired,
}

export default DQReportLineChart

