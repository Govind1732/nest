"use client"

import { useState, useEffect } from "react"
import {
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  TextField,
} from "@mui/material"
import { Link } from "react-router-dom"
import Loading from "../../Components/LayoutComponents/Loading"
import Form from "react-bootstrap/Form"
import axios from "axios"
import {
  useGetOpenIssuesQuery,
  usePostBusinessImpactMutation,
  usePostOpportunityCostMutation,
} from "../../features/api/djangoapiSlice"

const OpenIssues = () => {
  const { data: tableData = [], isLoading } = useGetOpenIssuesQuery()
  const [postBusinessImpact] = usePostBusinessImpactMutation()
  const [postOpportunityCost] = usePostOpportunityCostMutation()
  const [open, setOpen] = useState(false)
  const [openBusinessImpact, setOpenBusinessImpact] = useState(false)
  const [opsgenieAlertNum, setOpsgenieAlertNum] = useState(0)
  const [statuses, setStatuses] = useState({})
  const [alertIds, setAlertIds] = useState({})

  useEffect(() => {
    const fetchStatuses = async () => {
      const newStatuses = {}
      const newAlertIds = {}
      for (const row of tableData) {
        const status = await fetchStatus(row.request_id)
        const alertId = await fetchAlertId(row.request_id)
        newStatuses[row.request_id] = status
        newAlertIds[row.request_id] = alertId
      }
      setStatuses(newStatuses)
      setAlertIds(newAlertIds)
    }

    if (tableData.length > 0) {
      fetchStatuses()
    }
  }, [tableData])

  const handleClickOpen = (alertNum) => {
    setOpsgenieAlertNum(alertNum)
    setOpen(true)
  }

  const handleClose = () => {
    setOpen(false)
  }

  const handleBusinessImpactOpen = (alertNum) => {
    setOpsgenieAlertNum(alertNum)
    setOpenBusinessImpact(true)
  }

  const handleBusinessImpactClose = () => {
    setOpenBusinessImpact(false)
  }

  const handleBusinessImpactSubmit = async (event) => {
    event.preventDefault()
    const formData = new FormData(event.currentTarget)
    const businessImpact = formData.get("business_impact")
    try {
      await postBusinessImpact({ opsgenie_alert_num: opsgenieAlertNum, business_impact: businessImpact })
      handleBusinessImpactClose()
    } catch (err) {
      console.error(err)
    }
  }

  const handleOpportunityCostSubmit = async (event) => {
    event.preventDefault()
    const formData = new FormData(event.currentTarget)
    const opportunityCost = formData.get("opportunity_cost")
    try {
      await postOpportunityCost({ opsgenie_alert_num: opsgenieAlertNum, opportunity_cost: opportunityCost })
      handleClose()
    } catch (err) {
      console.error(err)
    }
  }

  const fetchStatus = async (requestId) => {
    try {
      const response = await axios.get(`/api/v2/alerts/requests/${requestId}`, {
        headers: {
          Authorization: "GenieKey 965c8018-02d0-4369-8eb-cadf1396e0ff",
        },
      })
      return response.data.data.status
    } catch (error) {
      console.error(error)
    }
  }

  const fetchAlertId = async (requestId) => {
    try {
      const response = await axios.get(`/api/v2/alerts/requests/${requestId}`, {
        headers: {
          Authorization: "GenieKey 965c8018-02d0-4369-8e3b-cadf1396e0ff",
        },
      })
      return response.data.data.alertId
    } catch (error) {
      console.error(error)
    }
  }

  return (
    <>
      <h5 className="text-center mb-4 mt-2" style={{ color: "#EE0000" }}>
        My DQ Tickets
      </h5>

      <Loading loading={isLoading} />

      <Paper
        sx={{ width: "100%", overflow: "hidden", display: "flex", justifyContent: "center", alignItems: "center" }}
      >
        <TableContainer sx={{ maxHeight: 650, width: "100%", marginX: "50px" }}>
          <Table stickyHeader aria-label="sticky table">
            <TableHead>
              <TableRow>
                {[
                  "#",
                  "Domain",
                  "Sub Domain",
                  "Product Type",
                  "Product Area",
                  "Product Name",
                  "DB",
                  "Table",
                  "Column",
                  "DQ Rule",
                  "DQ Score",
                  "Threshold",
                  "Opportunity Cost",
                  "Business impact",
                  "Current Status",
                  "Opsgenie Ticket",
                ].map((key) => (
                  <TableCell key={key} style={{ border: "0", color: "black", backgroundColor: "#BEBEBE" }}>
                    {key}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {[...tableData]
                .sort((a, b) => a.opsgenie_alert_num - b.opsgenie_alert_num)
                .map((row, index) => (
                  <TableRow key={index} hover>
                    <TableCell
                      style={{
                        borderRight: "0",
                        borderLeft: "0",
                        borderBottom: "2px solid #F5F5F5",
                        borderTop: "2px solid #F5F5F5",
                      }}
                    >
                      {row.opsgenie_alert_num}
                    </TableCell>
                    <TableCell
                      style={{
                        borderRight: "0",
                        borderLeft: "0",
                        borderBottom: "2px solid #F5F5F5",
                        borderTop: "2px solid #F5F5F5",
                      }}
                    >
                      {row.data_dmn}
                    </TableCell>
                    <TableCell
                      style={{
                        borderRight: "0",
                        borderLeft: "0",
                        borderBottom: "2px solid #F5F5F5",
                        borderTop: "2px solid #F5F5F5",
                      }}
                    >
                      {row.data_sub_dmn}
                    </TableCell>
                    <TableCell
                      style={{
                        borderRight: "0",
                        borderLeft: "0",
                        borderBottom: "2px solid #F5F5F5",
                        borderTop: "2px solid #F5F5F5",
                      }}
                    >
                      {row.product_type}
                    </TableCell>
                    <TableCell
                      style={{
                        borderRight: "0",
                        borderLeft: "0",
                        borderBottom: "2px solid #F5F5F5",
                        borderTop: "2px solid #F5F5F5",
                      }}
                    >
                      {row.product_area}
                    </TableCell>
                    <TableCell
                      style={{
                        borderRight: "0",
                        borderLeft: "0",
                        borderBottom: "2px solid #F5F5F5",
                        borderTop: "2px solid #F5F5F5",
                      }}
                    >
                      {row.product_name}
                    </TableCell>
                    <TableCell
                      style={{
                        borderRight: "0",
                        borderLeft: "0",
                        borderBottom: "2px solid #F5F5F5",
                        borderTop: "2px solid #F5F5F5",
                      }}
                    >
                      {row.db_name}
                    </TableCell>
                    <TableCell
                      style={{
                        borderRight: "0",
                        borderLeft: "0",
                        borderBottom: "2px solid #F5F5F5",
                        borderTop: "2px solid #F5F5F5",
                      }}
                    >
                      {row.src_tbl}
                    </TableCell>
                    <TableCell
                      style={{
                        borderRight: "0",
                        borderLeft: "0",
                        borderBottom: "2px solid #F5F5F5",
                        borderTop: "2px solid #F5F5F5",
                      }}
                    >
                      {row.src_col}
                    </TableCell>
                    <TableCell
                      style={{
                        borderRight: "0",
                        borderLeft: "0",
                        borderBottom: "2px solid #F5F5F5",
                        borderTop: "2px solid #F5F5F5",
                      }}
                    >
                      {row.meas_rule}
                    </TableCell>
                    <TableCell
                      style={{
                        borderRight: "0",
                        borderLeft: "0",
                        borderBottom: "2px solid #F5F5F5",
                        borderTop: "2px solid #F5F5F5",
                      }}
                    >
                      {row.dq_score}
                    </TableCell>
                    <TableCell
                      style={{
                        borderRight: "0",
                        borderLeft: "0",
                        borderBottom: "2px solid #F5F5F5",
                        borderTop: "2px solid #F5F5F5",
                      }}
                    >
                      {row.threshold}
                    </TableCell>
                    <TableCell
                      style={{
                        borderRight: "0",
                        borderLeft: "0",
                        borderBottom: "2px solid #F5F5F5",
                        borderTop: "2px solid #F5F5F5",
                      }}
                    >
                      {row?.opportunity_cost}
                      <Link variant="outlined" onClick={() => handleClickOpen(row.opsgenie_alert_num)}>
                        Add Cost
                      </Link>
                    </TableCell>
                    <TableCell
                      style={{
                        borderRight: "0",
                        borderLeft: "0",
                        borderBottom: "2px solid #F5F5F5",
                        borderTop: "2px solid #F5F5F5",
                      }}
                    >
                      {row?.business_impact}
                      <Link variant="outlined" onClick={() => handleBusinessImpactOpen(row.opsgenie_alert_num)}>
                        Add Business impact
                      </Link>
                    </TableCell>
                    <TableCell
                      style={{
                        borderRight: "0",
                        borderLeft: "0",
                        borderBottom: "2px solid #F5F5F5",
                        borderTop: "2px solid #F5F5F5",
                      }}
                    >
                      {statuses[row.request_id]}
                    </TableCell>
                    <TableCell
                      style={{
                        borderRight: "0",
                        borderLeft: "0",
                        borderBottom: "2px solid #F5F5F5",
                        borderTop: "2px solid #F5F5F5",
                      }}
                    >
                      <a
                        href={`https://app.opsgenie.com/alert/detail/${alertIds[row.request_id]}/details`}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        Ticket ID
                      </a>
                    </TableCell>
                  </TableRow>
                ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      <Dialog
        open={open}
        onClose={handleClose}
        PaperProps={{
          component: "form",
          onSubmit: handleOpportunityCostSubmit,
        }}
      >
        <DialogContent>
          <TextField
            autoFocus
            required
            margin="dense"
            id="opportunity_cost"
            name="opportunity_cost"
            label="Opportunity Cost"
            type="text"
            fullWidth
            variant="standard"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>Cancel</Button>
          <Button type="submit">Add</Button>
        </DialogActions>
      </Dialog>

      <Dialog
        open={openBusinessImpact}
        onClose={handleBusinessImpactClose}
        PaperProps={{
          component: "form",
          onSubmit: handleBusinessImpactSubmit,
        }}
      >
        <DialogContent>
          <Form>
            <Form.Group controlId="business_impact">
              <Form.Label>Business Impact</Form.Label>
              <Form.Control as="textarea" rows={3} name="business_impact" />
            </Form.Group>
          </Form>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleBusinessImpactClose}>Cancel</Button>
          <Button type="submit">Add</Button>
        </DialogActions>
      </Dialog>
    </>
  )
}

export default OpenIssues

