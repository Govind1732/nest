import { Tabs, Tab } from "@vds/tabs"
import { Title } from "@vds/typography"
import { Breadcrumbs, BreadcrumbItem } from "@vds/breadcrumbs"
import DataProfileSubmitRequest from "./DataProfileSubmitRequest.jsx"
import DownloadReports from "./DownloadReports.jsx"
import styles from "./DataProfile.module.css"

const DataProfile = () => {
  return (
    <>
      <div className={styles.section}>
        <div className={styles.subHeading}>
          <Title size="medium" bold={true} color="#000">
            Data Profile
          </Title>
          <Breadcrumbs surface="light">
            <BreadcrumbItem>Profiling</BreadcrumbItem>
            <BreadcrumbItem>Data Profile</BreadcrumbItem>
          </Breadcrumbs>
        </div>
        <div className={styles.content}>
          <Tabs orientation="horizontal" indicatorPosition="bottom" size="medium">
            <Tab label="Submit Request">
              <DataProfileSubmitRequest />
            </Tab>
            <Tab label="Download Reports">
              <DownloadReports />
            </Tab>
          </Tabs>
        </div>
      </div>
    </>
  )
}
export default DataProfile

