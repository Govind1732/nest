"use client"

import { useState, useEffect } from "react"
import axios from "axios"
import { Container, Row, Col, Form, Modal } from "react-bootstrap"
import { Button } from "@vds/core"
import InputLabel from "@mui/material/InputLabel"
import MenuItem from "@mui/material/MenuItem"
import FormControl from "@mui/material/FormControl"
import Select from "@mui/material/Select"
import TextField from "@mui/material/TextField"
import Autocomplete from "@mui/material/Autocomplete"
import styles from "./DataProfile.module.css"

function DataProfileSubmitRequest() {
  const [formData, setFormData] = useState({
    data_source: "TD",
    project_name: "",
    dbname: "",
    table_name: "",
  })
  const [loading, setLoading] = useState(false)
  const [additionalFieldsVisible, setAdditionalFieldsVisible] = useState(false)
  const [show, setShow] = useState(false)
  const [body, setBody] = useState("")
  const [showModal, setShowModal] = useState(false)
  const [profileSuccess, setProfileSuccess] = useState(false)
  const [projectOptions, setProjectOptions] = useState([])
  const [dbOptions, setDbOptions] = useState([])
  const [tableOptions, setTableOptions] = useState([])
  const [dbOptionsTD, setDbOptionsTD] = useState([])
  const [tableOptionsTD, setTableOptionsTD] = useState([])

  const handleClose = () => {
    setShow(false)
    setShowModal(false)
    setProfileSuccess(false)
    if (body.includes("Connectivity/Access not available for")) {
      window.open("https://marketplace.verizon.com/#/subscriptionReqForm", "_blank")
    }
  }

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }))
  }

  const fetchProjectOptions = async () => {
    try {
      const response = await axios.get(`${import.meta.env.VITE_NODEAPI_BASE_URL}dqapi/singleTableLoadGCP`)
      setProjectOptions(response.data)
    } catch (error) {
      console.error("Error fetching project ids:", error)
      alert("Error fetching project ids")
    }
  }

  const fetchDbOptionsTD = async () => {
    try {
      const response = await axios.get(`${import.meta.env.VITE_DJANGO_BASE_URL}self_serve2/SingleTableLoadTD/`)
      setDbOptionsTD(response.data.DatabaseName.map((dbname) => dbname.trim()))
    } catch (error) {
      console.error("Error fetching Database Names:", error)
      alert("Error fetching Database Names")
    }
  }

  const fetchDbOptions = async () => {
    if (formData.project_name) {
      try {
        const response = await axios.post(
          `${import.meta.env.VITE_NODEAPI_BASE_URL}dqapi/singleTableLoadGCP`,
          {
            project_id: formData.project_name,
            db_name: formData.dbname,
          },
          {
            headers: {
              "Content-Type": "application/x-www-form-urlencoded",
            },
          },
        )
        if ("db_names" in response.data) {
          setDbOptions(response.data.db_names)
        } else if ("table_names" in response.data) {
          setTableOptions(response.data.table_names)
        }
      } catch (error) {
        console.error("Error fetching project ids:", error)
      }
    }
  }

  const fetchTableNames = async (dbname) => {
    try {
      const response = await axios.post(
        `${import.meta.env.VITE_DJANGO_BASE_URL}self_serve2/SingleTableLoadTD/`,
        {
          DatabaseName: dbname,
        },
        {
          headers: {
            "Content-Type": "application/json",
          },
        },
      )
      setTableOptionsTD(response.data.TableName.map((value) => value.trim()))
    } catch (error) {
      console.error("Error fetching project ids:", error)
    }
  }

  useEffect(() => {
    fetchProjectOptions()
    fetchDbOptionsTD()
  }, [])

  useEffect(() => {
    fetchDbOptions()
  }, [formData.project_name, formData.dbname])

  useEffect(() => {
    if (formData.dbname) {
      fetchTableNames(formData.dbname)
    }
  }, [formData.dbname])

  const handleConnectivityCheck = async () => {
    setLoading(true)
    const formDataUrlEncoded = new URLSearchParams()
    for (const [key, value] of Object.entries(formData)) {
      formDataUrlEncoded.append(key, value)
    }

    try {
      const response = await axios.post(
        `${import.meta.env.VITE_DJANGO_BASE_URL}ml_profiler_config_form/ui_fetch/`,
        formDataUrlEncoded,
        {
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
        },
      )
      setLoading(false)
      if (response.data.combination_exists) {
        setShow(true)
        setBody("Click on close button to redirect to marketplace to raise a request")
      } else {
        fetchAdditionalDetails()
        setBody("Please fill the remaining fields for profiling")
        setAdditionalFieldsVisible(true)
        setShowModal(true)
      }
    } catch (error) {
      setLoading(false)
      console.error("Error checking connectivity:", error)
      alert("error in handling data")
    }
  }

  const fetchAdditionalDetails = async () => {
    const formDataUrlEncoded = new URLSearchParams()
    for (const [key, value] of Object.entries(formData)) {
      formDataUrlEncoded.append(key, value)
    }

    try {
      const response = await axios.post(
        `${import.meta.env.VITE_DJANGO_BASE_URL}ml_profiler_config_form/autopopulate_columns/`,
        formDataUrlEncoded,
        {
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
        },
      )
      setFormData((prevState) => ({
        ...prevState,
        incr_col: response.data.INCR_DT_COL,
        incr_cond: response.data.INCR_DT_COND,
      }))
    } catch (error) {
      console.error("Error fetching additional details:", error)
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)

    const formDataUrlEncoded = new URLSearchParams()
    for (const [key, value] of Object.entries(formData)) {
      formDataUrlEncoded.append(key, value)
    }

    try {
      const response = await axios.post(
        `${import.meta.env.VITE_DJANGO_BASE_URL}self_serve2/dispatch_MLProfile_data/`,
        formDataUrlEncoded,
        {
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
        },
      )
      setLoading(false)
      setBody("Report will be sent through Email in few minutes.Redirecting to Report History page")
      setProfileSuccess(true)
    } catch (error) {
      setLoading(false)
      console.error("Error triggering Data Profiler:", error)
      alert("Error triggering Data Profiler:", error)
    }
  }

  const resetHandler = () => {
    setFormData({
      data_source: "TD",
      project_name: "",
      dbname: "",
      table_name: "",
      incr_col: "",
      incr_cond: "",
      email: "",
    })
    setAdditionalFieldsVisible(false)
  }

  return (
    <div className={styles.mainContent}>
      <Container fluid className="my-2 pt-3">
        <Container fluid className="mx-8 px-8 mb-2">
          <Form onSubmit={handleSubmit}>
            <Row className="justify-content-center align-items-center">
              <Col xl={3}>
                <fieldset disabled={additionalFieldsVisible || loading}>
                  <Form.Group className="mb-2" controlId="ControlInput1">
                    <FormControl fullWidth>
                      <InputLabel id="select-label">Environment</InputLabel>
                      <Select
                        labelId="select-label"
                        id="select"
                        value={formData.data_source}
                        label="Environment"
                        onChange={handleChange}
                        name="data_source"
                        size="small"
                        required
                        disabled={additionalFieldsVisible || loading}
                      >
                        <MenuItem value="TD">TeraData</MenuItem>
                        <MenuItem value="GCP">GCP</MenuItem>
                      </Select>
                    </FormControl>
                  </Form.Group>

                  <Form.Group
                    className="mb-2"
                    controlId="ControlInput2"
                    style={{ display: formData.data_source === "GCP" ? "block" : "none" }}
                  >
                    <Autocomplete
                      options={projectOptions || []}
                      autoHighlight
                      fullWidth
                      size="small"
                      name="project_name"
                      value={formData.project_name}
                      required
                      isOptionEqualToValue={(option, value) => option.id === value.id}
                      onChange={(_, value) => setFormData((prev) => ({ ...prev, project_name: value }))}
                      renderInput={(params) => <TextField {...params} label="Project" variant="outlined" />}
                    />
                  </Form.Group>

                  <Form.Group className="mb-2" controlId="ControlInput3">
                    <Autocomplete
                      style={{ display: formData.data_source === "TD" ? "block" : "none" }}
                      options={dbOptionsTD || []}
                      autoHighlight
                      fullWidth
                      size="small"
                      name="dbname"
                      value={formData.dbname}
                      required
                      isOptionEqualToValue={(option, value) => option.id === value.id}
                      onChange={(_, value) => setFormData((prev) => ({ ...prev, dbname: value }))}
                      renderInput={(params) => <TextField {...params} label="DB Name" variant="outlined" />}
                    />
                    <Autocomplete
                      style={{ display: formData.data_source === "GCP" ? "block" : "none" }}
                      options={dbOptions || []}
                      autoHighlight
                      fullWidth
                      size="small"
                      name="dbname"
                      value={formData.dbname}
                      required
                      isOptionEqualToValue={(option, value) => option.id === value.id}
                      onChange={(_, value) => setFormData((prev) => ({ ...prev, dbname: value }))}
                      renderInput={(params) => <TextField {...params} label="DB Name" variant="outlined" />}
                    />
                  </Form.Group>

                  <Form.Group className="mb-2" controlId="ControlInput4">
                    <Autocomplete
                      style={{ display: formData.data_source === "TD" ? "block" : "none" }}
                      options={tableOptionsTD || []}
                      value={formData.table_name}
                      required
                      name="table_name"
                      autoHighlight
                      fullWidth
                      size="small"
                      isOptionEqualToValue={(option, value) => option.id === value.id}
                      onChange={(_, value) => setFormData((prev) => ({ ...prev, table_name: value }))}
                      renderInput={(params) => <TextField {...params} label="Table Name" variant="outlined" />}
                    />
                    <Autocomplete
                      style={{ display: formData.data_source === "GCP" ? "block" : "none" }}
                      options={tableOptions || []}
                      value={formData.table_name}
                      required
                      name="table_name"
                      autoHighlight
                      fullWidth
                      size="small"
                      isOptionEqualToValue={(option, value) => option.id === value.id}
                      onChange={(_, value) => setFormData((prev) => ({ ...prev, table_name: value }))}
                      renderInput={(params) => <TextField {...params} label="Table Name" variant="outlined" />}
                    />
                  </Form.Group>

                  <div className="d-flex justify-content-center">
                    {!additionalFieldsVisible && (
                      <Button onClick={handleConnectivityCheck} disabled={loading}>
                        {loading ? "Checking..." : "Check For Connectivity"}
                      </Button>
                    )}
                  </div>
                </fieldset>
              </Col>
              <Col xl={3} style={{ display: additionalFieldsVisible ? "block" : "none" }}>
                <fieldset>
                  <Form.Group className="mb-2" controlId="ControlInput5">
                    <TextField
                      label="Incremental Column"
                      variant="outlined"
                      fullWidth
                      size="small"
                      focused
                      value={formData.incr_col}
                      name="incr_col"
                      onChange={handleChange}
                    />
                  </Form.Group>

                  <Form.Group className="mb-2" controlId="ControlInput6">
                    <TextField
                      label="Incremental Condition"
                      variant="outlined"
                      fullWidth
                      size="small"
                      value={formData.incr_cond}
                      name="incr_cond"
                      focused
                      onChange={handleChange}
                    />
                  </Form.Group>

                  <Form.Group className="mb-2" controlId="ControlInput7">
                    <TextField
                      label="Email"
                      variant="outlined"
                      fullWidth
                      required
                      size="small"
                      value={formData.email}
                      name="email"
                      type="email"
                      onChange={handleChange}
                    />
                  </Form.Group>
                </fieldset>
              </Col>
              <div className="d-flex justify-content-center mb-2 gap-2">
                {additionalFieldsVisible && (
                  <Button use="secondary" onClick={resetHandler}>
                    Reset
                  </Button>
                )}
                {additionalFieldsVisible && (
                  <Button type="submit" disabled={loading}>
                    {loading ? "loading..." : "Submit Profile"}
                  </Button>
                )}
              </div>
            </Row>
          </Form>
        </Container>

        <Modal show={show} onHide={handleClose}>
          <Modal.Header closeButton>
            <Modal.Title>Connectivity/Access does not exist.</Modal.Title>
          </Modal.Header>
          <Modal.Body>{body}</Modal.Body>
          <Modal.Footer>
            <Button
              variant="secondary"
              onClick={() => {
                handleClose()
                window.open("https://marketplace.verizon.com/#/subscriptionReqForm", "_blank")
              }}
            >
              Close
            </Button>
          </Modal.Footer>
        </Modal>

        <Modal show={showModal} onHide={handleClose}>
          <Modal.Header closeButton>
            <Modal.Title>Connectivity/Access available.</Modal.Title>
          </Modal.Header>
          <Modal.Body>{body}</Modal.Body>
          <Modal.Footer>
            <Button use="secondary" onClick={handleClose}>
              Close
            </Button>
          </Modal.Footer>
        </Modal>

        <Modal show={profileSuccess} onHide={handleClose} backdrop="static" keyboard={false}>
          <Modal.Header closeButton>
            <Modal.Title>Data Profiler Triggered.</Modal.Title>
          </Modal.Header>
          <Modal.Body>{body}</Modal.Body>
          <Modal.Footer>
            <Button use="secondary" onClick={handleClose}>
              Close
            </Button>
          </Modal.Footer>
        </Modal>
      </Container>
    </div>
  )
}

export default DataProfileSubmitRequest

