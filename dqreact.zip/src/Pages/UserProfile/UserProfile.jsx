"use client"

import { useState, useEffect } from "react"
import axios from "axios"
import { useSelector, useDispatch } from "react-redux"
import { fetchUserAuthorization } from "../../features/users/userAuthorizationSlice"
import { Backdrop } from "@mui/material"
import { GridLoader } from "react-spinners"

function UserProfile() {
  const [userHeaders, setUserHeaders] = useState({})
  const [loading, setLoading] = useState(false)
  const user = useSelector((store) => store.userAuthorization.user)
  const dispatch = useDispatch()
  const userRole = user?.roles?.[0]?.name
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const response = await axios.get(`${import.meta.env.VITE_REACT_APP_USER_HEADERS}dqapi/`)
        setUserHeaders(response.data.headers)
        if (!user.vzid) {
          dispatch(fetchUserAuthorization(response.data.headers.vzid.toString().toLowerCase()))
        }
        setLoading(false)
      } catch (error) {
        console.error("Error while fetching user headers", error)
        setLoading(false)
      }
    }
    fetchData()
  }, [dispatch, user.vzid])

  return (
    <>
      <div>
        <h2 className="mt-5 text-center" style={{ color: "#EE0000" }}>
          User Details
        </h2>
        <div className="">
          <p>User Name: {userHeaders?.vzid}</p>
          <p>First Name: {userHeaders?.firstname}</p>
          <p>Last Name: {userHeaders?.lastname}</p>
          <p>Enterprise ID: {userHeaders?.eid}</p>
          <p>Email: {user?.email}</p>
          <p>Role: {userRole} </p>
          <p>
            Project(s):{" "}
            {user?.projects?.map((project, index, array) => (
              <span key={index}>
                {project.name}
                {index === array.length - 1 ? "" : ", "}
              </span>
            ))}
          </p>
        </div>
      </div>
      <Backdrop sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }} open={loading}>
        <div className="loading-overlay">
          <GridLoader color="#ff0000" loading={loading} size={20} aria-label="Loading Spinner" data-testid="loader" />
        </div>
      </Backdrop>
    </>
  )
}

export default UserProfile

