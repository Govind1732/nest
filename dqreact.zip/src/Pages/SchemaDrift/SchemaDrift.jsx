import { Tabs, Tab } from "@vds/tabs"
import { Title } from "@vds/typography"
import { Breadcrumbs, BreadcrumbItem } from "@vds/breadcrumbs"
import styles from "./SchemaDrift.module.css"
import SchemaDriftDifferentenv from "./SchemaDriftDifferentenv"
import SchemaDriftSameenv from "./SchemaDriftSameenv"

const SchemaDrift = () => {
  return (
    <>
      <div className={styles.section}>
        <div className={styles.subHeading}>
          <Title size="medium" bold={true} color="#000">
            Schema Drift
          </Title>
          <Breadcrumbs surface="light">
            <BreadcrumbItem>API Integration</BreadcrumbItem>
            <BreadcrumbItem>Schema Drift</BreadcrumbItem>
          </Breadcrumbs>
        </div>
        <div className={styles.content}>
          <Tabs orientation="horizontal" indicatorPosition="bottom" size="medium">
            <Tab label="Same environment">
              <SchemaDriftSameenv />
            </Tab>
            <Tab label="Different environment">
              <SchemaDriftDifferentenv />
            </Tab>
          </Tabs>
        </div>
      </div>
    </>
  )
}
export default SchemaDrift

