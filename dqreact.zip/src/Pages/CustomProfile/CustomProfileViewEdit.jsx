"use client"

import { useEffect, useState } from "react"
import { Container, Modal } from "react-bootstrap"
import {
  useGetCustomProfileViewEditQuery,
  usePostCustomProfileViewEditMutation,
  usePostCustomProfileSaveMtdMutation,
} from "../../features/api/djangoapiSlice"
import {
  TextField,
  TableContainer,
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  Paper,
  IconButton,
  TablePagination,
  Autocomplete,
} from "@mui/material"
import EditIcon from "@mui/icons-material/Edit"
import SaveIcon from "@mui/icons-material/Save"
import LoadingButton from "@mui/lab/LoadingButton"
import styles from "./CustomProfile.module.css"
import { Button, Loader } from "@vds/core"

const CustomProfileViewEdit = () => {
  const [dbName, setDbName] = useState(null)
  const [submitToggle, setSubmitToggle] = useState(false)
  const [editingRow, setEditingRow] = useState(null)
  const [tableData, setTableData] = useState([])
  const [loading, setLoading] = useState(false)
  const [dataNotFound, setDataNotFound] = useState("")
  const [dbOptions, setDbOptions] = useState([])
  const [alert, setAlert] = useState(false)
  const [editedRow, setEditedRow] = useState({})
  const [page, setPage] = useState(0)
  const [rowsPerPage, setRowsPerPage] = useState(10)
  const [status, setStatus] = useState("")
  const [message, setMessage] = useState("")

  const { data: dbData, isLoading: isDbLoading } = useGetCustomProfileViewEditQuery()
  const [fetchTableNames, { isLoading: isTableLoading }] = usePostCustomProfileViewEditMutation()
  const [saveEditedRow] = usePostCustomProfileSaveMtdMutation()

  useEffect(() => {
    if (dbData) {
      const dbOptions = Array.isArray(dbData.distinct_db)
        ? dbData.distinct_db.map((option) => option.data_sub_dmn).filter((option) => option !== null)
        : []
      setDbOptions(dbOptions)
    }
  }, [dbData])

  const handleSubmit = async () => {
    setLoading(true)
    try {
      const response = await fetchTableNames({
        sub_domain: dbName,
      }).unwrap()
      if (response.length === 0) {
        setDataNotFound("No such combination or files exist")
        setTableData([])
      } else {
        setDataNotFound("")
        setTableData(
          response.map((obj) =>
            Object.fromEntries(Object.entries(obj).map(([key, value]) => [key.toUpperCase(), value])),
          ),
        )
        setSubmitToggle(true)
      }
    } catch (error) {
      console.error("Error in fetching details:", error)
      alert("Error in fetching details:", error)
    } finally {
      setLoading(false)
    }
  }

  const resetHandler = () => {
    setDataNotFound("")
    setDbName(null)
    setTableData([])
    setSubmitToggle(false)
  }

  const handleEdit = (index) => {
    setEditingRow(index)
    setEditedRow(tableData[index])
  }

  const handleSave = async () => {
    try {
      setLoading(true)
      const payload = { ...editedRow }
      const response = await saveEditedRow(payload).unwrap()
      setEditingRow(null)
      setEditedRow({})
      setAlert(true)
      setStatus(response.status)
      setMessage(response.message)
    } catch (error) {
      console.error("Error saving edited row:", error)
      setAlert(true)
      setStatus("Error")
      setMessage("Error saving edited row: " + error)
    } finally {
      setLoading(false)
    }
  }

  const handleChangePage = (event, newPage) => {
    setPage(newPage)
  }

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(+event.target.value)
    setPage(0)
  }

  return (
    <>
      <div
        className={styles.mainContent}
        style={
          submitToggle
            ? { justifyContent: "start", alignItems: "center", gap: "1rem" }
            : { justifyContent: "center", alignItems: "center" }
        }
      >
        {/* <div> */}
        <div
          className="d-flex justify-content-center align-items-center gap-3"
          style={submitToggle ? { flexDirection: "row", marginTop: "1rem" } : { flexDirection: "column" }}
        >
          <Autocomplete
            placeholder="Select your Option"
            options={dbOptions}
            autoHighlight
            value={dbName || null}
            onChange={(_, value) => setDbName(value)}
            isOptionEqualToValue={(option, value) => option.toLowerCase() === value.toLowerCase()}
            loading={isDbLoading}
            renderInput={(params) => <TextField {...params} label="Data Sub Domain" />}
            sx={{ width: 500 }}
          />
          <div className="d-flex justify-content-center align-items-center gap-3">
            <Button onClick={handleSubmit} use="primary">
              Submit
            </Button>
            <Button onClick={resetHandler} use="secondary">
              Reset
            </Button>
          </div>
        </div>

        {submitToggle && (
          <Container fluid className="my-3">
            {tableData.length > 0 ? (
              <Paper sx={{ width: "100%", overflow: "hidden" }}>
                <TableContainer sx={{ maxHeight: 500 }}>
                  <Table stickyHeader aria-label="sticky table">
                    <TableHead>
                      <TableRow>
                        {tableData[0] &&
                          Object.keys(tableData[0])
                            .filter((key) => key !== "update_made_ts" && key !== "entry_made_ts")
                            .map((key) => (
                              <TableCell
                                key={key}
                                style={{
                                  backgroundColor: "black",
                                  color: "white",
                                  border: "1px solid white",
                                  fontWeight: "bold",
                                }}
                              >
                                {key}
                              </TableCell>
                            ))}
                        <TableCell
                          key="action"
                          style={{
                            backgroundColor: "black",
                            color: "white",
                            border: "1px solid white",
                            fontWeight: "bold",
                          }}
                        >
                          Action
                        </TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {tableData.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row, index) => (
                        <TableRow key={index} hover role="checkbox" tabIndex={-1}>
                          {Object.entries(row)
                            .filter(([key]) => key !== "update_made_ts" && key !== "entry_made_ts")
                            .map(([key, value], valueIndex) => (
                              <TableCell key={valueIndex}>
                                {editingRow === index && !["prfl_id"].includes(key) ? (
                                  <TextField
                                    aria-label="empty textarea"
                                    defaultValue={value}
                                    disabled={key === "prfl_id" || key === "update_made_ts" || key === "entry_made_ts"}
                                    onChange={(e) =>
                                      setEditedRow((prevRow) => ({
                                        ...prevRow,
                                        [key]: e.target.value,
                                      }))
                                    }
                                  />
                                ) : (
                                  value
                                )}
                              </TableCell>
                            ))}
                          <TableCell key={`action-${index}`}>
                            {editingRow === index ? (
                              <LoadingButton
                                loading={false}
                                loadingPosition="start"
                                startIcon={<SaveIcon />}
                                onClick={() => handleSave(index)}
                              >
                                Save
                              </LoadingButton>
                            ) : (
                              <IconButton onClick={() => handleEdit(index)}>
                                <EditIcon /> Edit
                              </IconButton>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
                <TablePagination
                  rowsPerPageOptions={[10, 20, 30, 40, 50, 100]}
                  component="div"
                  count={tableData.length}
                  rowsPerPage={rowsPerPage}
                  page={page}
                  onPageChange={handleChangePage}
                  onRowsPerPageChange={handleChangeRowsPerPage}
                />
              </Paper>
            ) : (
              <div className="d-flex justify-content-center m-2 blink">
                <h5>{dataNotFound}</h5>
              </div>
            )}
          </Container>
        )}

        {loading && <Loader fullscreen={false} active={true} surface="light" />}

        <Modal show={alert}>
          <Modal.Header closeButton>
            <Modal.Title>{status}</Modal.Title>
          </Modal.Header>
          <Modal.Body>{message}</Modal.Body>
          <Modal.Footer>
            <Button
              variant="secondary"
              onClick={() => {
                setAlert(false)
                handleSubmit()
              }}
            >
              Close
            </Button>
          </Modal.Footer>
        </Modal>
      </div>
      {/* </div> */}
    </>
  )
}

export default CustomProfileViewEdit

