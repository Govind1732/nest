"use client"

import { useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import TextField from "@mui/material/TextField"
import Autocomplete from "@mui/material/Autocomplete"
import match from "autosuggest-highlight/match"
import parse from "autosuggest-highlight/parse"
import styles from "./DataQualityProfile.module.css"
import { Button, Notification } from "@vds/core"
import { useGetSingleTableLoadGCPQuery, usePostSingleTableLoadGCPMutation } from "../../features/api/nodeapiSlice"
import {
  useGetSingleTableLoadTDQuery,
  usePostSingleTableLoadTDMutation,
  usePostUiFetchMutation,
} from "../../features/api/djangoapiSlice"
import {
  setActiveStep,
  setCompletedSteps,
  setSelectedValues,
} from "../../features/DataQualityProfileSingleRow/dataQualityProfileSingleRowActions.js"

const Step1 = () => {
  const dispatch = useDispatch()
  const activeStep = useSelector((state) => state.dataQualityProfileSingleRow.activeStep)
  const completedSteps = useSelector((state) => state.dataQualityProfileSingleRow.completedSteps)
  const globalSelectedValues = useSelector((state) => state.dataQualityProfileSingleRow.selectedValues)

  const { data: gcpProjects = [] } = useGetSingleTableLoadGCPQuery()
  const [postSingleTableLoadGCP] = usePostSingleTableLoadGCPMutation()
  const { data: tdDbNames = {} } = useGetSingleTableLoadTDQuery()
  const [postSingleTableLoadTD] = usePostSingleTableLoadTDMutation()
  const [postUiFetch] = usePostUiFetchMutation()

  const [localSelectedValues, setLocalSelectedValues] = useState(globalSelectedValues)
  const [dbOptions, setDbOptions] = useState([])
  const [tableOptions, setTableOptions] = useState([])
  const [connectivityExists, setConnectivityExists] = useState(false)

  const handleValueChange = async (field, newValue) => {
    setConnectivityExists(false)
    const trimmedValue = newValue ? newValue.trim() : ""
    const updatedValues = {
      ...localSelectedValues,
      [field]: trimmedValue,
      ...(field === "environment" && { projectName: "", dbName: "", tableName: "" }),
      ...(field === "projectName" && { dbName: "", tableName: "" }),
      ...(field === "dbName" && { tableName: "" }),
    }

    setLocalSelectedValues(updatedValues)
    dispatch(setSelectedValues(updatedValues))

    if (field === "environment") {
      setDbOptions(trimmedValue === "TD" ? tdDbNames.DatabaseName.map((name) => name.trim()) : [])
      setTableOptions([])
    }

    if (field === "projectName" && trimmedValue && updatedValues.environment === "GCP") {
      try {
        const response = await postSingleTableLoadGCP({ project_id: trimmedValue }).unwrap()
        setDbOptions(response.db_names.map((name) => name.trim()) || [])
      } catch (error) {
        console.error("Failed to fetch database options:", error)
      }
    }

    if (field === "dbName" && trimmedValue) {
      try {
        const response =
          updatedValues.environment === "GCP"
            ? await postSingleTableLoadGCP({ project_id: updatedValues.projectName, db_name: trimmedValue }).unwrap()
            : await postSingleTableLoadTD({ DatabaseName: trimmedValue }).unwrap()
        setTableOptions(
          (updatedValues.environment === "GCP" ? response.table_names : response.TableName || []).map((name) =>
            name.trim(),
          ),
        )
      } catch (error) {
        console.error("Failed to fetch table options:", error)
      }
    }
  }

  const handleReset = () => {
    const resetValues = { environment: "", projectName: "", dbName: "", tableName: "" }
    setLocalSelectedValues(resetValues)
    dispatch(setSelectedValues(resetValues))
    setDbOptions([])
    setTableOptions([])
    setConnectivityExists(false)
  }

  const handleConnectivityCheck = async () => {
    try {
      const response = await postUiFetch({
        data_source: localSelectedValues.environment,
        ...(localSelectedValues.environment === "GCP" && { project_name: localSelectedValues.projectName }),
        dbname: localSelectedValues.dbName,
        table_name: localSelectedValues.tableName,
      }).unwrap()
      setConnectivityExists(true)
    } catch (error) {
      console.error("Failed to check connectivity:", error)
    }
  }

  const handleNext = () => {
    dispatch(setCompletedSteps([...new Set([...completedSteps, activeStep])]))
    dispatch(setActiveStep(activeStep + 1))
  }

  const renderHighlightedOption = (props, option, { inputValue }) => {
    const matches = match(option, inputValue, { insideWords: true })
    const parts = parse(option, matches)

    return (
      <li {...props}>
        {parts.map((part, index) => (
          <span key={index} style={{ fontWeight: part.highlight ? 700 : 400 }}>
            {part.text}
          </span>
        ))}
      </li>
    )
  }

  return (
    <div className={styles.sourceContainer}>
      <h2>Select source</h2>
      {connectivityExists && (
        <Notification
          type="success"
          title="Connectivity Check Successful"
          fullBleed={false}
          inline={false}
          disableFocus={true}
        />
      )}
      <div className={styles.formContainer}>
        <div className={styles.inputRow}>
          <div className={styles.inputField}>
            <Autocomplete
              options={["TD", "GCP"]}
              value={localSelectedValues.environment}
              onChange={(event, newValue) => handleValueChange("environment", newValue)}
              size="small"
              autoHighlight
              renderOption={renderHighlightedOption}
              renderInput={(params) => <TextField {...params} label="Environment" />}
            />
          </div>

          {localSelectedValues.environment === "GCP" && (
            <div className={styles.inputField}>
              <Autocomplete
                disablePortal
                options={gcpProjects.map((project) => project.trim())}
                value={localSelectedValues.projectName}
                onChange={(event, newValue) => handleValueChange("projectName", newValue)}
                size="small"
                autoHighlight
                renderOption={renderHighlightedOption}
                renderInput={(params) => <TextField {...params} label="Project Name" />}
              />
            </div>
          )}

          <div className={styles.inputField}>
            <Autocomplete
              disablePortal
              options={dbOptions}
              value={localSelectedValues.dbName}
              onChange={(event, newValue) => handleValueChange("dbName", newValue)}
              size="small"
              autoHighlight
              renderOption={renderHighlightedOption}
              renderInput={(params) => <TextField {...params} label="DB Name" />}
            />
          </div>
        </div>

        <div className={styles.tableNameField}>
          <Autocomplete
            disablePortal
            options={tableOptions}
            value={localSelectedValues.tableName}
            onChange={(event, newValue) => handleValueChange("tableName", newValue)}
            size="small"
            autoHighlight
            renderOption={renderHighlightedOption}
            renderInput={(params) => <TextField {...params} label="Table Name" />}
          />
        </div>
      </div>

      <div className={styles.navigationButtons}>
        {connectivityExists ? (
          <Button onClick={handleNext}>Save & Next</Button>
        ) : (
          <Button onClick={handleConnectivityCheck} disabled={!localSelectedValues.tableName}>
            Check Connectivity
          </Button>
        )}
        <Button onClick={handleReset} use="secondary">
          Reset
        </Button>
      </div>
    </div>
  )
}

export default Step1

