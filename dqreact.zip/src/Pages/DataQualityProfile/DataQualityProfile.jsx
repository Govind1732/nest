import { Tabs, Tab } from "@vds/tabs"
import { Title } from "@vds/typography"
import { Breadcrumbs, BreadcrumbItem } from "@vds/breadcrumbs"
import DataQualityProfileMultiRequest from "./DataQualityProfileMultiRequest"
import DataQualityProfileViewEdit from "./DataQualityProfileViewEdit.jsx"
import DataQualityProfileSingleRow from "./DataQualityProfileSingleRow.jsx"
import styles from "./DataQualityProfile.module.css"

const DataQualityProfile = () => {
  return (
    <>
      <div className={styles.section}>
        <div className={styles.subHeading}>
          <Title size="medium" bold={true} color="#000">
            DataQuality Validation
          </Title>
          <Breadcrumbs surface="light">
            <BreadcrumbItem>Profiling</BreadcrumbItem>
            <BreadcrumbItem>DataQuality Validation</BreadcrumbItem>
          </Breadcrumbs>
        </div>
        <div className={styles.content}>
          <Tabs orientation="horizontal" indicatorPosition="bottom" size="medium">
            <Tab label="Submit Multiple Requests">
              <DataQualityProfileMultiRequest />
            </Tab>
            <Tab label="Submit Single Request">
              <DataQualityProfileSingleRow />
            </Tab>
            <Tab label="View/Edit Request">
              <DataQualityProfileViewEdit />
            </Tab>
          </Tabs>
        </div>
      </div>
    </>
  )
}
export default DataQualityProfile

