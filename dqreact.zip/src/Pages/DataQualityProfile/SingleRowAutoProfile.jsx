"use client"

import { useState, useEffect } from "react"
import axios from "axios"
import { Container, Row, Col, Form, Button, Breadcrumb, Modal } from "react-bootstrap"
import InputLabel from "@mui/material/InputLabel"
import MenuItem from "@mui/material/MenuItem"
import FormControl from "@mui/material/FormControl"
import Select from "@mui/material/Select"
import TextField from "@mui/material/TextField"
import Autocomplete from "@mui/material/Autocomplete"
import Checkbox from "@mui/material/Checkbox"
import ListItemText from "@mui/material/ListItemText"
import Chip from "@mui/material/Chip"
import { CircularProgress } from "@mui/material"
import { useSelector } from "react-redux"

function SingleRowAutoProfile() {
  const [formData, setFormData] = useState({
    data_source: "TD",
    project_name: "",
    dbname: "",
    table_name: "",
  })
  const [loading, setLoading] = useState(false)
  const [additionalFieldsVisible, setAdditionalFieldsVisible] = useState(false)
  const [show, setShow] = useState(false)
  const [body, setBody] = useState("")
  const [showModal, setShowModal] = useState(false)
  const [profileSuccess, setProfileSuccess] = useState(false)
  const [projectOptions, setProjectOptions] = useState([])
  const [dbOptions, setDbOptions] = useState([])
  const [tableOptions, setTableOptions] = useState([])
  const [dbOptionsTD, setDbOptionsTD] = useState([])
  const [tableOptionsTD, setTableOptionsTD] = useState([])
  const [projectLoading, setProjectLoading] = useState(false)
  const [dbLoading, setDBLoading] = useState(false)
  const [tableLoading, setTableLoading] = useState(false)
  const fieldNames = [
    "DATA_SRC",
    "DB_NAME",
    "SRC_TBL",
    "Data_LOB",
    "DATA_DMN",
    "DATA_SUB_DMN",
    "DATA_BUS_ELEM",
    "INCR_DT_COL",
    "TBL_CDE",
    "INCR_DT_COND",
    "UNQ_INDEX_COLS",
    "AUTO_PRFL_FREQ",
    "AUTO_PRFL_SCHD_TS",
    "EMAIL_DIST",
    "IS_ACTIVE_FLG",
    "IS_COMPLETE_FLG",
    "IS_CRITICAL_FLG",
    "PRODUCT_NAME",
    "PRODUCT_TYPE",
    "PRODUCT_AREA",
    "BUSINESS_PROGRAM",
  ]

  const user = useSelector((store) => store.userAuthorization.user)
  const userRole = user?.roles?.[0]?.name

  const handleClose = () => {
    setShow(false)
    setShowModal(false)
    setProfileSuccess(false)
    if (body.includes("Connectivity/Access not available for")) {
      window.open("https://marketplace.verizon.com/#/subscriptionReqForm", "_blank")
    }
  }

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }))
  }

  // To fetch Project (GCP)
  useEffect(() => {
    // setProjectLoading(true);
    axios
      .get(`${import.meta.env.VITE_DJANGO_BASE_URL}self_serve2/SingleTableLoad/`)
      .then((response) => {
        setProjectOptions(response.data.project_ids)
        setProjectLoading(false)
      })
      .catch((error) => {
        console.error("Error fetching project ids:", error)
        setProjectLoading(false)
        alert("Error fetching project ids")
      })
  }, [])

  // To fetch DB Name(TD)
  useEffect(() => {
    axios
      .get(`${import.meta.env.VITE_DJANGO_BASE_URL}self_serve2/SingleTableLoadTD/`)
      .then((response) => {
        setDbOptionsTD(response.data.DatabaseName.map((dbname) => dbname.trim()))
      })
      .catch((error) => {
        console.error("Error fetching Database Names:", error)
        alert("Error fetching Database Names")
      })
  }, [])

  // To fetch DB Name based on Project Name (GCP)
  useEffect(() => {
    if (formData.project_name) {
      axios
        .post(
          `${import.meta.env.VITE_DJANGO_BASE_URL}self_serve2/SingleTableLoad/`,
          {
            project_id: formData.project_name,
            dataset: formData.dbname,
          },
          {
            headers: {
              "Content-Type": "application/x-www-form-urlencoded",
            },
          },
        )
        .then((response) => {
          if ("datasets" in response.data) {
            setDbOptions(response.data.datasets)
            setDBLoading(false)
          } else if ("table_names" in response.data) {
            setTableOptions(response.data.table_names)
            setTableLoading(false)
          }
        })
        .catch((error) => {
          console.error("Error fetching project ids:", error)
          setDBLoading(false)
          setTableLoading(false)
        })
    }
  }, [formData.project_name, formData.dbname])

  // To fetch Table Name based on DB Name (TD)
  const fetchTableNames = (dbname) => {
    // setTableLoading(true);
    axios
      .post(
        `${import.meta.env.VITE_DJANGO_BASE_URL}self_serve2/SingleTableLoadTD/`,
        {
          DatabaseName: dbname,
        },
        {
          headers: {
            "Content-Type": "application/json",
          },
        },
      )
      .then((response) => {
        setTableOptionsTD(response.data.TableName.map((value) => value.trim()))
        setTableLoading(false)
      })
      .catch((error) => {
        console.error("Error fetching project ids:", error)
        setTableLoading(false)
      })
  }

  useEffect(() => {
    if (formData.dbname) {
      fetchTableNames(formData.dbname)
    }
  }, [formData.dbname])

  const [tableWithAccess, setTableWithAccess] = useState([])
  const [formDataArray, setFormDataArray] = useState([])
  useEffect(() => {
    setFormDataArray(
      tableWithAccess.map((tableName) => ({
        Data_LOB: "",
        DATA_DMN: "",
        DATA_SUB_DMN: "",
        DATA_BUS_ELEM: "",
        DB_NAME: formData.dbname,
        SRC_TBL: tableName,
        INCR_DT_COL: "",
        TBL_CDE: "",
        INCR_DT_COND: "",
        UNQ_INDEX_COLS: "",
        AUTO_PRFL_FREQ: "",
        AUTO_PRFL_SCHD_TS: "",
        EMAIL_DIST: "",
        IS_ACTIVE_FLG: "",
        IS_COMPLETE_FLG: "",
        IS_CRITICAL_FLG: "",
        DATA_SRC: formData.data_source,
        PRODUCT_NAME: "",
        PRODUCT_TYPE: "",
        PRODUCT_AREA: "",
        BUSINESS_PROGRAM: "",
      })),
    )
  }, [tableWithAccess, formData])
  const handleConnectivityCheck = () => {
    setLoading(true)
    console.log(formData)

    let data = {}

    if (formData.data_source === "TD" && formData.dbname) {
      data = {
        teradata_info: {
          dbname: formData.dbname,
          tables: selectedTables,
        },
      }
    } else if (formData.data_source === "GCP" && formData.dbname) {
      data = {
        gcp_info: {
          project_id: formData.project_name,
          dataset: formData.dbname,
          tables: selectedTables,
        },
      }
    }

    axios
      .post(`${import.meta.env.VITE_DJANGO_BASE_URL}self_serve2/ConnectionCheck/`, data, {
        headers: {
          "Content-Type": "application/json",
        },
      })
      .then((response) => {
        setLoading(false)
        console.log(response.data)

        let tablesWithAccess = ""
        let tablesWithoutAccess = ""

        if (response.data.GCP) {
          tablesWithAccess = response.data.GCP.tables_with_access.map((table) => table.trim()).join(", ")
          tablesWithoutAccess = response.data.GCP.tables_without_access.map((table) => table.trim()).join(", ")
        }

        if (response.data.TD) {
          tablesWithAccess = response.data.TD.tables_with_access.map((table) => table.trim()).join(", ")
          tablesWithoutAccess = response.data.TD.tables_without_access.map((table) => table.trim()).join(", ")
        }

        let body = ""

        if (tablesWithAccess) {
          body += `Connectivity/Access available for ${tablesWithAccess}`
          setAdditionalFieldsVisible(true)
          if (response.data.GCP) {
            setTableWithAccess(response.data.GCP.tables_with_access)
          } else if (response.data.TD) {
            setTableWithAccess(response.data.TD.tables_with_access)
          }
        }

        if (tablesWithoutAccess) {
          if (body.length > 0) {
            body += " and "
          }
          body += `Connectivity/Access not available for ${tablesWithoutAccess}`
        }

        setBody(body)
        setShowModal(true)
      })
      .catch((error) => {
        setLoading(false)
        console.error("Error checking connectivity:", error)
        alert("error in handling data")
      })
  }

  const handleSubmit = (e) => {
    e.preventDefault()
  }

  const resetHandler = () => {
    setFormData((prevState) => ({
      ...prevState,
      data_source: "",
      project_name: "",
      dbname: "",
      table_name: "",
      Data_LOB: "",
      DATA_DMN: "",
      DATA_SUB_DMN: "",
      DATA_BUS_ELEM: "",
      DB_NAME: "",
      INCR_DT_COL: "",
      TBL_CDE: "",
      INCR_DT_COND: "",
      UNQ_INDEX_COLS: "",
      AUTO_PRFL_FREQ: "",
      AUTO_PRFL_SCHD_TS: "",
      EMAIL_DIST: "",
      IS_ACTIVE_FLG: "",
      IS_COMPLETE_FLG: "",
      IS_CRITICAL_FLG: "",
      DATA_SRC: "",
      PRODUCT_NAME: "",
      PRODUCT_TYPE: "",
      PRODUCT_AREA: "",
      BUSINESS_PROGRAM: "",
    }))
    setAdditionalFieldsVisible(false)
  }

  const [selectedTables, setSelectedTables] = useState([])
  const handleTableChange = (event, newValue) => {
    newValue = newValue.map((value) => value.trim())
    setSelectedTables(newValue)
  }

  return (
    <Container fluid className="">
      <Container fluid className="my-2 pt-3">
        <Breadcrumb>
          <Breadcrumb.Item active>Profiling Services</Breadcrumb.Item>
          <Breadcrumb.Item active>Auto Profile</Breadcrumb.Item>
          <Breadcrumb.Item active>
            <span className="fw-bold">Submit Auto Profile</span>
          </Breadcrumb.Item>
        </Breadcrumb>
      </Container>

      <Container fluid className="mx-8 px-8 mb-2">
        <h2 className="mb-2 text-center" style={{ color: "#EE0000" }}>
          Submit Auto Profile
        </h2>
        <Form onSubmit={handleSubmit} style={{ display: additionalFieldsVisible ? "none" : "block" }}>
          <Row className="justify-content-center align-items-center">
            <Col xl={3}>
              <fieldset disabled={additionalFieldsVisible || loading}>
                <Form.Group className="mb-2" controlId="ControlInput1">
                  <FormControl fullWidth>
                    <InputLabel id="select-label">Environment</InputLabel>
                    <Select
                      labelId="select-label"
                      id="select"
                      value={formData.data_source}
                      label="Environment"
                      onChange={handleChange}
                      name="data_source"
                      size="small"
                      disabled={additionalFieldsVisible || loading}
                    >
                      <MenuItem value="TD">TeraData</MenuItem>
                      <MenuItem value="GCP">GCP</MenuItem>
                    </Select>
                  </FormControl>
                </Form.Group>

                <Form.Group
                  className="mb-2"
                  controlId="ControlInput2"
                  style={{ display: formData.data_source === "GCP" ? "block" : "none" }}
                >
                  <Autocomplete
                    options={projectOptions || []}
                    autoHighlight
                    fullWidth
                    size="small"
                    name="project_name"
                    value={formData.project_name}
                    required
                    onChange={(_, value) => setFormData((prev) => ({ ...prev, project_name: value }))}
                    renderInput={(params) => <TextField {...params} label="Project" variant="outlined" />}
                  />
                </Form.Group>

                <Form.Group className="mb-2" controlId="ControlInput3">
                  <Autocomplete
                    style={{
                      display: formData.data_source === "TD" || formData.data_source === "" || "" ? "block" : "none",
                    }}
                    options={dbOptionsTD || []}
                    autoHighlight
                    fullWidth
                    size="small"
                    name="dbname"
                    // onChange={handleChange}
                    value={formData.dbname}
                    isOptionEqualToValue={(option, value) => option.id === value.id}
                    required
                    onChange={(_, value) => setFormData((prev) => ({ ...prev, dbname: value }))}
                    renderInput={(params) => <TextField {...params} label="DB Name" variant="outlined" />}
                  />
                  <Autocomplete
                    // id="combo-box"
                    style={{ display: formData.data_source === "GCP" ? "block" : "none" }}
                    options={dbOptions || []}
                    autoHighlight
                    fullWidth
                    size="small"
                    name="dbname"
                    value={formData.dbname}
                    required
                    onChange={(_, value) => setFormData((prev) => ({ ...prev, dbname: value }))}
                    renderInput={(params) => <TextField {...params} label="DB Name" variant="outlined" />}
                  />
                </Form.Group>

                <Form.Group className="" controlId="ControlInput4">
                  <Autocomplete
                    style={{ display: formData.data_source === "TD" || formData.data_source === "" ? "block" : "none" }}
                    multiple
                    // options={["Select All", ...tableOptionsTD] || []}
                    options={tableOptionsTD || []}
                    disableCloseOnSelect
                    getOptionLabel={(option) => option}
                    value={selectedTables}
                    onChange={handleTableChange}
                    required
                    renderOption={(props, option, { selected }) => (
                      <li {...props}>
                        <Checkbox checked={selected} />
                        <ListItemText primary={option} />
                      </li>
                    )}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        variant="outlined"
                        label="Table Name"
                        placeholder={selectedTables.length === 0 ? "Select Table Name(s)" : ""}
                        InputProps={{
                          ...params.InputProps,
                          style: { borderRadius: 0 },
                          endAdornment: (
                            <>
                              {tableLoading ? <CircularProgress color="inherit" size={20} /> : null}
                              {params.InputProps.endAdornment}
                            </>
                          ),
                        }}
                      />
                    )}
                    renderTags={(value, getTagProps) =>
                      value.length > 2
                        ? value
                            .slice(0, 2)
                            .map((option, index) => (
                              <Chip
                                key={option.id || index}
                                variant="secondary"
                                label={option}
                                {...getTagProps({ index })}
                              />
                            ))
                            .concat(<Chip key="more" variant="outlined" label="..." />)
                        : value.map((option, index) => (
                            <Chip
                              key={option.id || index}
                              variant="secondary"
                              label={option}
                              {...getTagProps({ index })}
                            />
                          ))
                    }
                    autoHighlight
                    fullWidth
                    size="small"
                  />
                  <Autocomplete
                    multiple
                    id="checkboxes-tags"
                    // options={["Select All", ...tableOptions] || []}
                    options={tableOptions || []}
                    disableCloseOnSelect
                    getOptionLabel={(option) => option}
                    value={selectedTables}
                    onChange={handleTableChange}
                    autoHighlight
                    fullWidth
                    required
                    size="small"
                    style={{ display: formData.data_source === "GCP" ? "block" : "none" }}
                    renderOption={(props, option, { selected }) => (
                      <li {...props}>
                        <Checkbox checked={selected} />
                        <ListItemText primary={option} />
                      </li>
                    )}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        variant="outlined"
                        label="Table Name"
                        placeholder={selectedTables.length === 0 ? "Select Table Name(s)" : ""}
                        InputProps={{
                          ...params.InputProps,
                          style: { borderRadius: 0 },
                          endAdornment: (
                            <>
                              {tableLoading ? <CircularProgress color="inherit" size={20} /> : null}
                              {params.InputProps.endAdornment}
                            </>
                          ),
                        }}
                      />
                    )}
                    renderTags={(value, getTagProps) =>
                      value.length > 2
                        ? value
                            .slice(0, 2)
                            .map((option, index) => (
                              <Chip
                                key={option.id || index}
                                variant="secondary"
                                label={option}
                                {...getTagProps({ index })}
                              />
                            ))
                            .concat(<Chip key="more" variant="outlined" label="..." />)
                        : value.map((option, index) => (
                            <Chip
                              key={option.id || index}
                              variant="secondary"
                              label={option}
                              {...getTagProps({ index })}
                            />
                          ))
                    }
                  />
                </Form.Group>

                {/* {userRole === 'Executive' ? (<>
                                    <div className="d-flex justify-content-center my-2">
                                        <Button
                                            variant="dark"
                                            type="button"
                                            style={{
                                                display: additionalFieldsVisible ? "none" : "block",
                                                borderRadius: "25px",
                                            }}
                                        >
                                            Check For Connectivity
                                        </Button>
                                    </div></>) : (<>
                                        <div className="d-flex justify-content-center my-2">
                                            <Button
                                                variant="dark"
                                                type="button"
                                                onClick={handleConnectivityCheck}
                                                disabled={loading}
                                                style={{
                                                    display: additionalFieldsVisible ? "none" : "block",
                                                    borderRadius: "25px",
                                                }}
                                            >
                                                {loading ? "Checking..." : "Check For Connectivity"}
                                            </Button>
                                        </div></>)} */}

                <div className="d-flex justify-content-center my-2">
                  <Button
                    variant="dark"
                    type="button"
                    onClick={handleConnectivityCheck}
                    disabled={loading}
                    style={{
                      display: additionalFieldsVisible ? "none" : "block",
                      borderRadius: "25px",
                    }}
                  >
                    {loading ? "Checking..." : "Check For Connectivity"}
                  </Button>
                </div>
              </fieldset>
            </Col>
          </Row>
        </Form>
        <Form style={{ display: additionalFieldsVisible ? "block" : "none" }}>
          <Container fluid={tableWithAccess.length >= 2}>
            <Row>
              {formDataArray.map((form, index) => (
                <Col key={index}>
                  {fieldNames.map((fieldName) => (
                    // <Form.Group className="mb-2" key={fieldName}>
                    <TextField
                      className="mb-2"
                      key={fieldName}
                      required
                      label={fieldName}
                      variant="outlined"
                      value={form[fieldName]}
                      name={fieldName}
                      onChange={(e) => {
                        const newFormData = [...formDataArray]
                        newFormData[index] = { ...newFormData[index], [fieldName]: e.target.value }
                        setFormDataArray(newFormData)
                      }}
                      size="small"
                      fullWidth
                      style={
                        fieldName === "SRC_TBL"
                          ? { position: "sticky", top: "0", zIndex: 1000, backgroundColor: "white" }
                          : {}
                      }
                    />
                    // </Form.Group>
                  ))}
                </Col>
              ))}
            </Row>
          </Container>
          <div className="d-flex justify-content-center mb-2">
            <Button
              variant="dark"
              style={{ display: additionalFieldsVisible ? "block" : "none", borderRadius: "25px" }}
              disabled={loading}
              className="mx-2"
              onClick={resetHandler}
            >
              Reset
            </Button>
            <Button
              variant="dark"
              type="submit"
              disabled={loading}
              style={{ display: additionalFieldsVisible ? "block" : "none", borderRadius: "25px" }}
              className="mx-2"
              onClick={handleSubmit}
            >
              {loading ? "loading..." : "Submit Profile"}
            </Button>
          </div>
        </Form>
      </Container>

      <></>

      <Modal show={show} onHide={() => handleClose()}>
        <Modal.Header closeButton>
          <Modal.Title>Connectivity/Access does not exist.</Modal.Title>
        </Modal.Header>
        <Modal.Body>{body}</Modal.Body>
        <Modal.Footer>
          <Button
            variant="secondary"
            onClick={() => {
              handleClose()
              window.open("https://marketplace.verizon.com/#/subscriptionReqForm", "_blank")
            }}
          >
            Close
          </Button>
        </Modal.Footer>
      </Modal>

      <Modal show={showModal} onHide={() => handleClose()}>
        <Modal.Header closeButton>
          <Modal.Title>Connectivity/Access available.</Modal.Title>
        </Modal.Header>
        <Modal.Body>{body}</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>

      <Modal show={profileSuccess} onHide={() => handleClose()} backdrop="static" keyboard={false}>
        <Modal.Header closeButton>
          <Modal.Title>Data Profiler Triggered.</Modal.Title>
        </Modal.Header>
        <Modal.Body>{body}</Modal.Body>
        <Modal.Footer>
          <Button
            variant="secondary"
            onClick={() => {
              handleClose()
            }}
          >
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </Container>
  )
}

export default SingleRowAutoProfile

