"use client"

import { useState, useEffect } from "react"
import { useDispatch, useSelector } from "react-redux"
import TextField from "@mui/material/TextField"
import Autocomplete from "@mui/material/Autocomplete"
import match from "autosuggest-highlight/match"
import parse from "autosuggest-highlight/parse"
import styles from "./DataQualityProfile.module.css"
import { Button, Notification } from "@vds/core"
import {
  useGetTaxonomyProductNamesQuery,
  useFetchTaxonomyDataMutation,
  useInsertTaxonomyDataMutation,
  useUpdateTaxonomyDataMutation,
} from "../../features/api/nodeapiSlice"
import {
  setActiveStep,
  setCompletedSteps,
  setTaxonomyData,
} from "../../features/DataQualityProfileSingleRow/dataQualityProfileSingleRowActions"

const Step2 = () => {
  const dispatch = useDispatch()
  const activeStep = useSelector((state) => state.dataQualityProfileSingleRow.activeStep)
  const completedSteps = useSelector((state) => state.dataQualityProfileSingleRow.completedSteps)
  const selectedValues = useSelector((state) => state.dataQualityProfileSingleRow.selectedValues)
  const taxonomyData = useSelector((state) => state.dataQualityProfileSingleRow.taxonomyData) || {}
  const [selectedProjectId, setSelectedProjectId] = useState("")
  const { data: projectIds = [] } = useGetTaxonomyProductNamesQuery()
  const [fetchTaxonomyData, { data: fetchedTaxonomyData }] = useFetchTaxonomyDataMutation()
  const [insertTaxonomyData] = useInsertTaxonomyDataMutation()
  const [updateTaxonomyData] = useUpdateTaxonomyDataMutation()
  const [formData, setFormData] = useState({})
  const [notification, setNotification] = useState({ open: false, message: "", type: "" })
  const [buttonText, setButtonText] = useState("Insert")

  useEffect(() => {
    if (fetchedTaxonomyData && fetchedTaxonomyData.length > 0) {
      const transformedData = {
        ...fetchedTaxonomyData[0],
        entry_made_ts: fetchedTaxonomyData[0].entry_made_ts?.value || "",
        update_made_ts: fetchedTaxonomyData[0].update_made_ts?.value || "",
      }
      dispatch(setTaxonomyData(transformedData))
      setFormData(transformedData)
      setButtonText("Update")
    } else {
      dispatch(setTaxonomyData({}))
      setFormData({})
      setButtonText("Insert")
    }
  }, [fetchedTaxonomyData, dispatch])

  const handleNext = () => {
    dispatch(setCompletedSteps([...new Set([...completedSteps, activeStep])]))
    dispatch(setActiveStep(activeStep + 1))
  }

  const handlePrevious = () => {
    dispatch(setActiveStep(activeStep - 1))
  }

  const handleProjectIdChange = (event, value) => {
    setSelectedProjectId(value)
    if (value && value !== "None") {
      fetchTaxonomyData({
        product_name: value,
        project_name: selectedValues.projectName,
        db_name: selectedValues.dbName,
        table_name: selectedValues.tableName,
      })
      setButtonText("Update")
    } else {
      dispatch(setTaxonomyData({}))
      setFormData({
        ...formData,
        table_name: "",
        db_name: "",
      })
      setButtonText("Insert")
    }
  }

  const handleInputChange = (field, value) => {
    setFormData({
      ...formData,
      [field]: value,
    })
  }

  const handleSubmit = async () => {
    try {
      const payload = { ...formData }
      payload.db_name = selectedValues.dbName
      payload.table_name = selectedValues.tableName
      optionalFields.forEach((field) => {
        if (!payload[field.name]) {
          payload[field.name] = null
        }
      })

      // Convert all fields to string format except null
      Object.keys(payload).forEach((key) => {
        if (payload[key] !== null) {
          if (typeof payload[key] === "object" && payload[key].value) {
            payload[key] = String(payload[key].value)
          } else {
            payload[key] = String(payload[key])
          }
        }
      })

      // Ensure timestamp fields are in valid TIMESTAMP format
      if (payload.entry_made_ts) {
        payload.entry_made_ts = new Date(payload.entry_made_ts).toISOString()
      }
      if (payload.update_made_ts) {
        payload.update_made_ts = new Date(payload.update_made_ts).toISOString()
      }

      if (selectedProjectId === "None") {
        await insertTaxonomyData(payload).unwrap()
        setNotification({ open: true, message: "Insertion was successful", type: "success" })
      } else {
        await updateTaxonomyData(payload).unwrap()
        setNotification({ open: true, message: "Updation was successful", type: "success" })
      }

      if (buttonText === "Next") {
        handleNext()
      } else {
        setButtonText("Next")
      }
      console.log("Taxonomy data:", payload)
    } catch (error) {
      console.error("Failed to submit taxonomy data:", error)
      setNotification({ open: true, message: "Failed to submit taxonomy data", type: "error" })
    }
  }

  const renderHighlightedOption = (props, option, { inputValue }) => {
    const matches = match(option, inputValue, { insideWords: true })
    const parts = parse(option, matches)

    return (
      <li {...props}>
        {parts.map((part, index) => (
          <span
            key={index}
            style={{
              fontWeight: part.highlight ? 700 : 400,
            }}
          >
            {part.text}
          </span>
        ))}
      </li>
    )
  }

  const mandatoryFields = [
    // { label: "Taxonomy ID", name: "taxonomy_id" },
    { label: "Table ID", name: "table_id" },
    { label: "Product Type", name: "product_type" },
    { label: "Product Area", name: "product_area" },
    { label: "Product Name", name: "product_name" },
    { label: "L1 Label", name: "l1_label" },
    { label: "L2 Label", name: "l2_label" },
  ]

  const optionalFields = [
    { label: "L3 Label", name: "l3_label" },
    { label: "Subject Area 1", name: "subject_area_1" },
    { label: "Subject Area 2", name: "subject_area_2" },
    { label: "Subject Area 3", name: "subject_area_3" },
    { label: "Subject Area 4", name: "subject_area_4" },
    { label: "Subject Area 5", name: "subject_area_5" },
    { label: "Subject Area 6", name: "subject_area_6" },
    { label: "Subject Area 7", name: "subject_area_7" },
    { label: "Subject Area 8", name: "subject_area_8" },
    { label: "Subject Area 9", name: "subject_area_9" },
    { label: "Subject Area 10", name: "subject_area_10" },
    { label: "Email Distribution", name: "email_distro" },
    { label: "Opsgenie Flag", name: "opsgenie_flag" },
    { label: "Email Alert Level", name: "email_alert_level" },
  ]

  const areMandatoryFieldsFilled = () => {
    return mandatoryFields.every((field) => formData[field.name])
  }

  return (
    <div className={styles.sourceContainer}>
      <h2>Check Taxonomy Data</h2>

      <div className={styles.formContainer}>
        <div className={styles.inputRow}>
          <div className={styles.inputField}>
            <TextField
              label="DB Name"
              value={`${selectedValues.projectName}.${selectedValues.dbName}`}
              size="small"
              InputProps={{ readOnly: true }}
            />
          </div>
          <div className={styles.inputField}>
            <TextField
              label="Table Name"
              value={selectedValues.tableName}
              size="small"
              InputProps={{ readOnly: true }}
            />
          </div>
        </div>

        <div className={styles.inputRow}>
          <div className={styles.inputField}>
            <Autocomplete
              options={["None", ...projectIds]}
              size="small"
              value={selectedProjectId}
              onChange={handleProjectIdChange}
              renderOption={renderHighlightedOption}
              renderInput={(params) => <TextField {...params} label="Product Name" required />}
            />
          </div>
        </div>

        {selectedProjectId && (
          <>
            <div className={styles.inputRow}>
              {mandatoryFields.map((field) => (
                <div key={field.name} className={styles.inputField}>
                  <TextField
                    label={field.label}
                    value={formData[field.name] || ""}
                    onChange={(e) => handleInputChange(field.name, e.target.value)}
                    size="small"
                    required
                  />
                </div>
              ))}
            </div>
            <div className={styles.inputRow}>
              {optionalFields.map((field) => (
                <div key={field.name} className={styles.inputField}>
                  <TextField
                    label={field.label}
                    value={formData[field.name] || ""}
                    onChange={(e) => handleInputChange(field.name, e.target.value)}
                    size="small"
                  />
                </div>
              ))}
            </div>
          </>
        )}
      </div>
      <div className={styles.navigationButtons}>
        <Button onClick={handleSubmit} disabled={!areMandatoryFieldsFilled()}>
          {buttonText}
        </Button>
        <Button onClick={handlePrevious} use="secondary">
          Previous Step
        </Button>
      </div>

      {notification.open && (
        <Notification
          type={notification.type}
          title={notification.message}
          onClose={() => setNotification({ open: false, message: "", type: "" })}
        />
      )}
    </div>
  )
}

export default Step2

