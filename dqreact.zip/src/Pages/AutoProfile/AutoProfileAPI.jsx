"use client"

import { useState } from "react"
import axios from "axios"
import { Container, Row, Col, Form, Button, Breadcrumb, Modal } from "react-bootstrap"
import Backdrop from "@mui/material/Backdrop"
import { GridLoader } from "react-spinners"

const override = {
  display: "block",
  margin: "0 auto",
  borderColor: "red",
}

function AutoProfileAPI() {
  const [formData, setFormData] = useState({
    prfl_tbl_id: "",
  })
  const [loading, setLoading] = useState(false)
  const [show, setShow] = useState(false)
  const [body, setBody] = useState("")
  const [title, setTitle] = useState("")

  const handleClose = () => {
    setShow(false)
    resetHandler()
  }

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }))
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    setLoading(true)

    axios
      .post(`${process.env.REACT_APP_BASE_URL}autoprofile/`, formData, {
        headers: {
          "Content-Type": "application/json",
        },
      })
      .then((response) => {
        setLoading(false)
        setTitle(response.data.message)
        setBody("")
        setShow(true)
      })
      .catch((error) => {
        setLoading(false)
        console.error(error)
        setTitle(error.name)
        setBody(error.message)
        setShow(true)
      })
  }

  const resetHandler = () => {
    setFormData((prevState) => ({
      ...prevState,
      prfl_tbl_id: "",
    }))
  }

  return (
    <>
      <Container fluid className="">
        <Container fluid className="my-2 pt-3">
          <Breadcrumb>
            <Breadcrumb.Item active>Profiling Services</Breadcrumb.Item>
            <Breadcrumb.Item active>Auto Profile</Breadcrumb.Item>
            <Breadcrumb.Item active>
              <span className="fw-bold">Auto Profile API</span>
            </Breadcrumb.Item>
          </Breadcrumb>
        </Container>

        <Container fluid className="mx-8 px-8 mb-2">
          <Form onSubmit={handleSubmit}>
            <h2 className="mb-2 text-center">AutoProfile API</h2>
            <Row className="justify-content-center align-items-center">
              <Col xl={6}>
                <Form.Group className="mb-2" controlId="ControlInput1">
                  <Form.Label>Profile Table ID</Form.Label>
                  <Form.Control
                    type="text"
                    value={formData.prfl_tbl_id}
                    name="prfl_tbl_id"
                    onChange={handleChange}
                    required
                    placeholder="Profile Table ID"
                  />
                </Form.Group>

                <div className="d-flex justify-content-center mb-2">
                  <Button variant="danger" className="mx-2" onClick={resetHandler}>
                    Reset
                  </Button>
                  <Button variant="danger" type="submit" className="mx-2">
                    Profile
                  </Button>
                </div>
              </Col>
            </Row>
          </Form>
        </Container>

        <Modal show={show} onHide={() => handleClose()}>
          <Modal.Header closeButton>
            <Modal.Title>{title}</Modal.Title>
          </Modal.Header>
          <Modal.Body>{body}</Modal.Body>
          <Modal.Footer>
            <Button
              variant="secondary"
              onClick={() => {
                handleClose()
              }}
            >
              Close
            </Button>
          </Modal.Footer>
        </Modal>

        {/* <Alert severity="success" sx={{ width: '50%',display: show? "block":"none" }} onClose={() => {}}>
                    <AlertTitle>dfds</AlertTitle>
                    Kindly check your mail
                </Alert> */}
      </Container>
      <Backdrop sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }} open={loading}>
        {/* <CircularProgress color="inherit" /> */}
        <Container className="loading-overlay">
          <GridLoader
            color="#ff0000"
            loading={loading}
            cssOverride={override}
            size={20}
            aria-label="Loading Spinner"
            data-testid="loader"
          />
        </Container>
      </Backdrop>
    </>
  )
}

export default AutoProfileAPI

