import { Tabs, Tab } from "@vds/tabs"
import { Title } from "@vds/typography"
import { Breadcrumbs, BreadcrumbItem } from "@vds/breadcrumbs"
import AutoProfileMultiRequest from "./AutoProfileMultiRequest"
// import SingleRowAutoProfile from "./SingleRowAutoProfile"
import AutoViewEdit from "./AutoViewEdit"
import styles from "./AutoProfile.module.css"

const AutoProfile = () => {
  return (
    <>
      <div className={styles.section}>
        <div className={styles.subHeading}>
          <Title size="medium" bold={true} color="#000">
            Auto Profile
          </Title>
          <Breadcrumbs surface="light">
            <BreadcrumbItem>Profiling</BreadcrumbItem>
            <BreadcrumbItem>Auto Profile</BreadcrumbItem>
          </Breadcrumbs>
        </div>
        <div className={styles.content}>
          <Tabs orientation="horizontal" indicatorPosition="bottom" size="medium">
            <Tab label="Submit Multiple Requests">
              <AutoProfileMultiRequest />
            </Tab>
            {/* <Tab label="Submit Single Request">
              <SingleRowAutoProfile />
            </Tab> */}
            <Tab label="View/Edit Request">
              <AutoViewEdit />
            </Tab>
          </Tabs>
        </div>
      </div>
    </>
  )
}
export default AutoProfile

