"use client"

import { useState, useRef } from "react"
import styles from "./MetaDataGenerator.module.css"
import { Breadcrumbs, BreadcrumbItem, Title, Button, Loader } from "@vds/core"
import { Form } from "react-bootstrap"
import TextField from "@mui/material/TextField"
import { Link } from "react-router-dom"
import { usePostMetadataGeneratorMutation } from "../../features/api/djangoapiSlice"
import ModalComponent from "../../Components/LayoutComponents/ModalComponent"

const MetaDataGenerator = () => {
  const [postMetadataGenerator, { isLoading: ispostMetadataGeneratorLoading }] = usePostMetadataGeneratorMutation()
  const [show, setShow] = useState(false)
  const [modalTitle, setModalTitle] = useState("")
  const [modalBody, setModalBody] = useState("")
  const [email, setEmail] = useState("")
  const fileInputRef = useRef(null)
  const handleClose = () => {
    setShow(false)
    resetHandler()
  }
  const handleUpload = () => {
    const file = fileInputRef.current.files[0]

    if (!file) {
      setModalTitle("")
      setModalBody("Please select a file")
      setShow(true)
      return
    }

    if (!email) {
      setModalTitle("")
      setModalBody("Please enter your email")
      setShow(true)
      return
    }

    const formData = new FormData()
    formData.append("fileName", file)
    formData.append("requestorEmail", email)

    postMetadataGenerator(formData)
      .unwrap()
      .then((response) => {
        if (response.message) {
          setModalTitle("Success")
          setModalBody(response.message)
        } else if (response.error) {
          throw new Error(response.error)
        }
        setShow(true)
      })
      .catch((error) => {
        setModalTitle("Error")
        setModalBody(error.message || "An unexpected error occurred")
        setShow(true)
      })
  }

  const resetHandler = () => {
    setShow(false)
    setModalTitle("")
    setModalBody("")
    fileInputRef.current.value = null
    setEmail("")
  }
  return (
    <>
      <div className={styles.section}>
        <div className={styles.subHeading}>
          <Title size="medium" bold={true} color="#000">
            Metadata Generator
          </Title>
          <Breadcrumbs surface="light">
            <BreadcrumbItem>API Integration</BreadcrumbItem>
            <BreadcrumbItem>Metadata Generator</BreadcrumbItem>
          </Breadcrumbs>
        </div>
        <div className={styles.content}>
          <div className={styles.mainContent}>
            <TextField
              sx={{ width: "50%" }}
              id="outlined"
              label="Email"
              variant="outlined"
              value={email}
              size="small"
              onChange={(e) => setEmail(e.target.value)}
            />
            <Form.Group controlId="file1" className="w-50">
              <Form.Control type="file" accept=".csv" ref={fileInputRef} />
            </Form.Group>
            <Link
              to="https://drive.google.com/uc?export=download&id=1fRPwVjpkPyjMgN9elGn_e-pyrS5CNiUr"
              className="text-decoration-none"
            >
              <span style={{ color: "#EE0000" }}>Download sample Template (test.csv)</span>
            </Link>
            <div style={{ display: "flex", gap: "1rem" }}>
              <Button onClick={resetHandler}>Reset</Button>
              <Button onClick={handleUpload}>Submit</Button>
            </div>
          </div>
        </div>
      </div>
      {ispostMetadataGeneratorLoading && <Loader active fullscreen={false} surface="light" />}
      <ModalComponent show={show} handleClose={handleClose} modalTitle={modalTitle} modalBody={modalBody} />
    </>
  )
}
export default MetaDataGenerator

