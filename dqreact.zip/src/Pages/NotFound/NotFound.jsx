import "./NotFound.css"

const NotFound = () => {
  return (
    <div className="container">
      <h1 className="heading">404 Not Found</h1>
      <p className="subheading">Oops! The page you're looking for doesn't exist.</p>
      <a href="/dataQuality" className="link">
        Go Home
      </a>
    </div>
  )
}

export default NotFound

