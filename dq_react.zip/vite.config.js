import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  base: '/dataQuality', // Set this to the subdirectory where your app is served
  plugins: [react()],
  assetsInclude: ['**/*.csv'],
  define: {
    global: 'window',
  },
  build: {
    chunkSizeWarningLimit: 1000, // Adjust the chunk size warning limit
    rollupOptions: {
      output: {
        manualChunks: {
          // Split the code into smaller chunks
          vendor: ['react', 'react-dom'],
        },
      },
    },
  },
  server: {
    cors: {
      origin: '*', // Adjust CORS settings if needed
    },
  },
});