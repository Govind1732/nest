import store from "./store/store";
import { Provider } from "react-redux";
import { BrowserRouter, Route, Routes, Navigate } from 'react-router-dom'
import Layout from "./Components/Layout/Layout";
import Home from "./Pages/Home/Home";
import AutoProfile from "./Pages/AutoProfile/AutoProfile";
import DataQualityProfile from "./Pages/DataQualityProfile/DataQualityProfile";
import DataProfile from "./Pages/DataProfile/DataProfile";
import DataDrift from "./Pages/DataDrift/DataDrift";
import SchemaDrift from "./Pages/SchemaDrift/SchemaDrift";
import RanDT from "./Pages/RuleProfile/RanDT/RanDT";
import OneCorp from "./Pages/RuleProfile/OneCorp/OneCorp";
import AllProjects from "./Pages/RuleProfile/AllProjects/AllProjects";
import DQDomainLevelReport from "./Pages/Reports/DQDomainLevelReport/DQDomainLevelReport";
import DQReports from "./Pages/Reports/DQReports/DQReports";
import DQMetrics from './Pages/DQMetricsAPI/DQMetricsAPI';
import ETLPipelineIntegrationAPI from './Pages/ETLPipelineIntegrationAPI/ETLPipelineIntegrationAPI'
import DQFalloutPrediction from './Pages/DQFalloutPrediction/DQFalloutPrediction';
import DQDataRemediation from './Pages/DQDataRemediation/DQDataRemediation';
import MyRequest from "./Pages/MyRequest/MyRequest";
import OpenIssues from "./Pages/OpenIssues/OpenIssues";
import Help from "./Pages/Help/Help";
import UserProfile from "./Pages/UserProfile/UserProfile";
import UserManagement from "./Pages/UserManagement/UserManagement";
import Test from "./Components/Test";
import NotFound from "./Pages/NotFound/NotFound";
import 'bootstrap/dist/css/bootstrap.min.css';
import "@vds-tokens/core/index.css"
import CustomProfile from "./Pages/CustomProfile/CustomProfile";
import MetaDataGenerator from "./Pages/MetaDataGenerator/MetaDataGenerator.jsx";
import { VDSManager } from '@vds/utilities';

const App = () => {
  return (
    <>
      <Provider store={store}>
        <BrowserRouter>
          {/* <TestManagerWithHOC> */}
          <VDSManager />
          <Layout>
            <Routes>
              <Route path="/dataQuality" element={<Navigate replace to="/dataQuality/" />} />
              <Route path="/dataQuality/" element={<DQReports />} />
              <Route path="/dataQuality/auto-profile" element={<AutoProfile />} />
              <Route path="/dataQuality/autoProfile" element={<AutoProfile />} />
              <Route path="/dataQuality/SingleRowAutoProfile" element={<AutoProfile />} />
              <Route path="/dataQuality/autoviewedit" element={<AutoProfile />} />
              <Route path="/dataQuality/autoProfileAPI" element={<AutoProfile />} />
              <Route path="/dataQuality/custom-profile" element={<CustomProfile />} />
              <Route path="/dataQuality/dataquality-validation" element={<DataQualityProfile />} />
              <Route path="/dataQuality/rule-profile-dtran" element={<RanDT />} />
              <Route path="/dataQuality/rantdt" element={<RanDT />} />
              <Route path="/dataQuality/rantdtviewedit" element={<RanDT />} />
              <Route path="/dataQuality/SingleRowRantDT" element={<RanDT />} />
              <Route path="/dataQuality/dq_rerun" element={<RanDT />} />
              <Route path="/dataQuality/rule-profile-onecorp" element={<OneCorp />} />
              <Route path="/dataQuality/corpData" element={<OneCorp />} />
              <Route path="/dataQuality/OneCorp_restart" element={<OneCorp />} />
              <Route path="/dataQuality/corpDataviewedit" element={<OneCorp />} />
              <Route path="/dataQuality/SingleRowCorpData" element={<OneCorp />} />
              <Route path="/dataQuality/rule-profile-mle" element={<AllProjects />} />
              <Route path="/dataQuality/allProjects" element={<AllProjects />} />
              <Route path="/dataQuality/allProjectsviewedit" element={<AllProjects />} />
              <Route path="/dataQuality/SingleRowAllProjects" element={<AllProjects />} />
              <Route path="/dataQuality/data-profile" element={<DataProfile />} />
              <Route path="/dataQuality/mlProfile" element={<DataProfile />} />
              <Route path="/dataQuality/mlProfileReports" element={<DataProfile />} />
              <Route path="/dataQuality/data-drift" element={<DataDrift />} />
              <Route path="/dataQuality/schema-drift" element={<SchemaDrift />} />
              <Route path="/dataQuality/datadrift" element={<DataDrift />} />
              <Route path="/dataQuality/schemadrift" element={<SchemaDrift />} />
              <Route path="/dataQuality/dq-metrics" element={<DQMetrics />} />
              <Route path="/dataQuality/etl-pipeline" element={<ETLPipelineIntegrationAPI />} />
              <Route path="/dataQuality/etl_pipeline_api" element={<ETLPipelineIntegrationAPI />} />
              <Route path="/dataQuality/dq-falloutprediction" element={<DQFalloutPrediction />} />
              <Route path="/dataQuality/dq-dataremediation" element={<DQDataRemediation />} />
              <Route path="/dataQuality/metadata-generator" element={<MetaDataGenerator />} />
              <Route path="/dataQuality/dq-reports" element={<DQReports />} />
              <Route path="/dataQuality/dqreports" element={<DQReports />} />
              <Route path="/dataQuality/dq-domainlevelreport" element={<DQDomainLevelReport />} />
              <Route path="/dataQuality/dqDomainLevelReport" element={<DQDomainLevelReport />} />
              <Route path="/dataQuality/myrequest" element={<MyRequest />} />
              <Route path="/dataQuality/openissues" element={<OpenIssues />} />
              <Route path="/dataQuality/help" element={<Help />} />
              <Route path="/dataQuality/dq_Knowledge_base" element={<Help />} />
              <Route path="/dataQuality/userprofile" element={<UserProfile />} />
              <Route path='/dataQuality/UserManagement' element={<UserManagement />} />
              <Route path="/dataQuality/test" element={<Test />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </Layout>
          {/* </TestManagerWithHOC> */}
        </BrowserRouter>
      </Provider>


    </>
  )
}

export default App
