import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

export const fastapiSlice = createApi({
    reducerPath: 'fastApi',
    baseQuery: fetchBaseQuery({ baseUrl: `${import.meta.env.VITE_FASTAPI_BASE_URL}` }),
    endpoints: (builder) => ({
        getProductData: builder.query({
            query: () => 'get_product_data',
        }),
        getL2ProductData: builder.query({
            query: () => 'get_level2_data',
        }),
        postTopBottomFiveScores: builder.mutation({
            query: (body) => ({
                url: 'top_bottom_five_scores',
                method: 'POST',
                body,
            }),
        }),
    }),
});

export const { useGetProductDataQuery, useGetL2ProductDataQuery, usePostTopBottomFiveScoresMutation } = fastapiSlice;