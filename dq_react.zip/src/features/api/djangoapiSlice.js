import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

export const djangoapiSlice = createApi({
  reducerPath: "djangoApi",
  // baseQuery: fetchBaseQuery({ baseUrl: `${process.env.REACT_APP_BASE_URL}` }),
  baseQuery: fetchBaseQuery({
    baseUrl: `${import.meta.env.VITE_DJANGO_BASE_URL}`,
  }),
  endpoints: (builder) => ({
    //Home Page API
    getProjectList: builder.query({
      query: () => "home_and_reports/SSUIReportData/",
    }),

    postSSUIReportData: builder.mutation({
      query: (body) => ({
        url: "home_and_reports/SSUIReportData/",
        method: "POST",
        body,
      }),
    }),
    // DQ Report API
    getDynamicFilter: builder.query({
      query: () => "home_and_reports/DynamicFilter/",
    }),
    postDynamicFilter: builder.mutation({
      query: (body) => ({
        url: "home_and_reports/DynamicFilter/",
        method: "POST",
        body,
      }),
    }),
    getDefaultEnterpriseData: builder.query({
      query: () => "self_serve2/DefaultEnterpriseData/",
    }),
    postDefaultEnterpriseData: builder.mutation({
      query: (body) => ({
        url: "self_serve2/DefaultEnterpriseData/",
        method: "POST",
        body,
      }),
    }),

    getDefaultLobWiseData: builder.query({
      query: () => "self_serve2/DefaultLobWiseData/",
    }),
    postDefaultLobWiseData: builder.mutation({
      query: (body) => ({
        url: "self_serve2/DefaultLobWiseData/",
        method: "POST",
        body,
      }),
    }),

    getDQTrend: builder.query({
      query: () => "self_serve2/DQTrend/",
    }),
    postDQTrend: builder.mutation({
      query: (body) => ({
        url: "self_serve2/DQTrend/",
        method: "POST",
        body,
      }),
    }),

    getProductTypeWiseData: builder.query({
      query: () => "self_serve2/ProductTypeWiseData/",
    }),
    postProductTypeWiseData: builder.mutation({
      query: (body) => ({
        url: "self_serve2/ProductTypeWiseData/",
        method: "POST",
        body,
      }),
    }),

    postHierarchalData: builder.mutation({
      query: (body) => ({
        url: "self_serve2/HierarchalData/",
        method: "POST",
        body,
      }),
    }),
    postTableWiseData: builder.mutation({
      query: (body) => ({
        url: "self_serve2/TableWiseData/",
        method: "POST",
        body,
      }),
    }),

    // My Request API
    getAutoPrflMyRequestData: builder.query({
      query: () => "mle/AutoPrflMyRequest/",
    }),

    getDropdownDbAutoMLEMtdData: builder.query({
      query: () => "mle/DropdownDbAutoMLEMtd/",
    }),
    postDropdownDbAutoMLEMtd: builder.mutation({
      query: (body) => ({
        url: "mle/DropdownDbAutoMLEMtd/",
        method: "POST",
        body,
      }),
    }),

    postViewEditAutoMLEMtd: builder.mutation({
      query: (body) => ({
        url: "mle/ViewEditAutoMLEMtd/",
        method: "POST",
        body,
      }),
    }),
    postSaveAutoMLEMtd: builder.mutation({
      query: (body) => ({
        url: "mle/SaveAutoMLEMtd/",
        method: "POST",
        body,
      }),
    }),

    getDropdownDbOneCorpMtdData: builder.query({
      query: () => "onecorp/DropdownDbOneCorpMtd/",
    }),
    postDropdownDbOneCorpMtdMtd: builder.mutation({
      query: (body) => ({
        url: "onecorp/DropdownDbOneCorpMtd/",
        method: "POST",
        body,
      }),
    }),

    postViewEditOneCorpMtd: builder.mutation({
      query: (body) => ({
        url: "onecorp/ViewEditOneCorpMtd/",
        method: "POST",
        body,
      }),
    }),
    postSaveOneCorpMtd: builder.mutation({
      query: (body) => ({
        url: "onecorp/SaveOneCorpMtd/",
        method: "POST",
        body,
      }),
    }),
    getDropdownDbRuleMLEMtdData: builder.query({
      query: () => "mle/DropdownDbRuleMLEMtd/",
    }),
    postDropdownDbRuleMLEMtd: builder.mutation({
      query: (body) => ({
        url: "mle/DropdownDbRuleMLEMtd/",
        method: "POST",
        body,
      }),
    }),

    postViewEditRuleMLEMtd: builder.mutation({
      query: (body) => ({
        url: "mle/ViewEditRuleMLEMtd/",
        method: "POST",
        body,
      }),
    }),
    postSaveRuleMLEMtd: builder.mutation({
      query: (body) => ({
        url: "mle/SaveRuleMLEMtd/",
        method: "POST",
        body,
      }),
    }),

    // Open Issues API
    getOpenIssues: builder.query({
      query: () => "self_serve2/OpenIssues/",
    }),
    postBusinessImpact: builder.mutation({
      query: (body) => ({
        url: "self_serve2/OpenIssues/",
        method: "POST",
        body,
      }),
    }),
    postOpportunityCost: builder.mutation({
      query: (body) => ({
        url: "self_serve2/OpenIssues/",
        method: "POST",
        body,
      }),
    }),

    // Connnectivity Check
    //TD
    getSingleTableLoadTD: builder.query({
      query: () => "self_serve2/SingleTableLoadTD/",
    }),
    postSingleTableLoadTD: builder.mutation({
      query: (body) => ({
        url: "self_serve2/SingleTableLoadTD/",
        method: "POST",
        body,
      }),
    }),
    // GCP
    getSingleTableLoad: builder.query({
      query: () => "self_serve2/SingleTableLoad/",
    }),
    postSingleTableLoad: builder.mutation({
      query: (body) => ({
        url: "self_serve2/SingleTableLoad/",
        method: "POST",
        body,
      }),
    }),
    //Connectivity Check submit button
    postUiFetch: builder.mutation({
      query: (body) => ({
        url: "ml_profiler_config_form/ui_fetch/",
        method: "POST",
        body,
      }),
    }),
    // To fetch Icremental Column and Condition
    postAutopopulateColumns: builder.mutation({
      query: (body) => ({
        url: "ml_profiler_config_form/autopopulate_columns/",
        method: "POST",
        body,
      }),
    }),

    // DataDrift Same Environment
    postDataDriftSameEnv: builder.mutation({
      query: (body) => ({
        url: "self_serve2/dispatch_data_drift_sameenv/",
        method: "POST",
        body,
      }),
    }),
    // DataDrift Different Environment
    postDataDriftDifferentEnv: builder.mutation({
      query: (body) => ({
        url: "self_serve2/dispatch_data_drift_diffenv/",
        method: "POST",
        body,
      }),
    }),
    // SchemaDrift Same Environment
    postSchemaDriftSameEnv: builder.mutation({
      query: (body) => ({
        url: "self_serve2/dispatch_schema_drift_sameenv/",
        method: "POST",
        body,
      }),
    }),
    // SchemaDrift Different Environment
    postSchemaDriftDifferentEnv: builder.mutation({
      query: (body) => ({
        url: "self_serve2/dispatch_schema_drift_diffenv/",
        method: "POST",
        body,
      }),
    }),

    // Custom Profile
    postCustomProfile: builder.mutation({
      query: (body) => ({
        url: "self_serve2/CustomProfiler/",
        method: "POST",
        body,
      }),
    }),

    // Custom Profile View Edit
    getCustomProfileViewEdit: builder.query({
      query: () => "mle/DropdownSubdmnCustomMtd/",
    }),
    postCustomProfileViewEdit: builder.mutation({
      query: (body) => ({
        url: "mle/DropdownSubdmnCustomMtd/",
        method: "POST",
        body,
      }),
    }),
    postCustomProfileSaveMtd: builder.mutation({
        query: (body) => ({
          url: "mle/SaveCustomMtd/",
          method: "POST",
          body,
        }),
      }),

    // Taxonomy
    postTaxonomy: builder.mutation({
      query: (body) => ({
        url: "self_serve2/UploadCSV/",
        method: "POST",
        body,
      }),
    }),

    // Metadata Generator
    postMetadataGenerator: builder.mutation({
      query: (body) => ({
        url: "self_serve2/dispatch_metadata_generator/",
        method: "POST",
        body,
      }),
    }),
  }),
});

export const {
  useGetProjectListQuery,
  usePostSSUIReportDataMutation,

  useGetAutoPrflMyRequestDataQuery,
  useGetDropdownDbAutoMLEMtdDataQuery,
  usePostDropdownDbAutoMLEMtdMutation,
  usePostViewEditAutoMLEMtdMutation,
  usePostSaveAutoMLEMtdMutation,
  useGetDropdownDbOneCorpMtdDataQuery,
  usePostDropdownDbOneCorpMtdMtdMutation,
  usePostViewEditOneCorpMtdMutation,
  usePostSaveOneCorpMtdMutation,
  useGetDropdownDbRuleMLEMtdDataQuery,
  usePostDropdownDbRuleMLEMtdMutation,
  usePostViewEditRuleMLEMtdMutation,
  usePostSaveRuleMLEMtdMutation,

  useGetOpenIssuesQuery,
  usePostBusinessImpactMutation,
  usePostOpportunityCostMutation,

  useGetDynamicFilterQuery,
  usePostDynamicFilterMutation,

  useGetDefaultEnterpriseDataQuery,
  usePostDefaultEnterpriseDataMutation,

  useGetDefaultLobWiseDataQuery,
  usePostDefaultLobWiseDataMutation,

  useGetDQTrendQuery,
  usePostDQTrendMutation,

  useGetProductTypeWiseDataQuery,
  usePostProductTypeWiseDataMutation,

  usePostHierarchalDataMutation,
  usePostTableWiseDataMutation,

  useGetSingleTableLoadTDQuery,
  usePostSingleTableLoadTDMutation,
  useGetSingleTableLoadQuery,
  usePostSingleTableLoadMutation,
  usePostUiFetchMutation,
  usePostAutopopulateColumnsMutation,

  usePostDataDriftSameEnvMutation,
  usePostDataDriftDifferentEnvMutation,
  usePostSchemaDriftSameEnvMutation,
  usePostSchemaDriftDifferentEnvMutation,

  usePostCustomProfileMutation,
  useGetCustomProfileViewEditQuery,
  usePostCustomProfileViewEditMutation,
  usePostCustomProfileSaveMtdMutation,

  usePostTaxonomyMutation,

  usePostMetadataGeneratorMutation,
} = djangoapiSlice;
