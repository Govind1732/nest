import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

const baseQueryWithAuth = fetchBaseQuery({
    baseUrl: `${import.meta.env.VITE_NODEAPI_BASE_URL}`,
    credentials: 'include',
    prepareHeaders: (headers) => {
        headers.set('Accept', 'application/json');
        return headers;
    }
});

export const nodeapiSlice = createApi({
    reducerPath: 'nodeApi',
    baseQuery: baseQueryWithAuth,
    endpoints: (builder) => ({
        // Home
        getSSUIReportData: builder.query({
            query: () => 'dqapi/SSUIReportData',
        }),
        postSSUIReportData: builder.mutation({
            query: (data) => ({
                url: 'dqapi/SSUIReportData',
                method: 'POST',
                body: data,
            }),
        }),
        // DQ Domain Level Report
        getProductData: builder.query({
            query: () => 'dqapi/get_product_data',
        }),
        getL2ProductData: builder.query({
            query: () => 'dqapi/get_level2_data',
        }),
        postTopBottomFiveScores: builder.mutation({
            query: (data) => ({
                url: 'dqapi/top_bottom_five_scores',
                method: 'POST',
                body: data,
            }),
        }),

        // DQ Reports
        getDynamicFilter: builder.query({
            query: () => 'dqapi/DynamicFilter/',
        }),
        postDynamicFilter: builder.mutation({
            query: (body) => ({
                url: 'dqapi/DynamicFilter/',
                method: 'POST',
                body,
            }),
        }),
        getDefaultEnterpriseData: builder.query({
            query: () => 'dqapi/enterpriseData/',
        }),
        postDefaultEnterpriseData: builder.mutation({
            query: (body) => ({
                url: 'dqapi/enterpriseData/',
                method: 'POST',
                body,
            }),
        }),

        getDefaultLobWiseData: builder.query({
            query: () => 'dqapi/lobWiseData/',
        }),
        postDefaultLobWiseData: builder.mutation({
            query: (body) => ({
                url: 'dqapi/lobWiseData/',
                method: 'POST',
                body,
            }),
        }),

        getDQTrend: builder.query({
            query: () => 'dqapi/trendData/',
        }),
        postDQTrend: builder.mutation({
            query: (body) => ({
                url: 'dqapi/trendData/',
                method: 'POST',
                body,
            }),
        }),

        getProductTypeWiseData: builder.query({
            query: () => 'dqapi/ProductTypeWiseData/',
        }),
        postProductTypeWiseData: builder.mutation({
            query: (body) => ({
                url: 'dqapi/ProductTypeWiseData/',
                method: 'POST',
                body,
            }),
        }),

        postHierarchalData: builder.mutation({
            query: (body) => ({
                url: 'dqapi/HierarchalData/',
                method: 'POST',
                body,
            }),
        }),
        postTableWiseData: builder.mutation({
            query: (body) => ({
                url: 'dqapi/TableWiseData/',
                method: 'POST',
                body,
            }),
        }),
        // DataQuality Profile 
        postMultipleRequestProfile: builder.mutation({
            query: (formData) => ({
                url: 'dqapi/multipleRequestProfile',
                method: 'POST',
                body: formData,
            }),
        }),
        getSingleTableLoadGCP: builder.query({
            query: () => 'dqapi/singleTableLoadGCP',
        }),
        postSingleTableLoadGCP: builder.mutation({
            query: (body) => ({
                url: 'dqapi/singleTableLoadGCP',
                method: 'POST',
                body,
            }),
        }),
        postConnectivityCheck: builder.mutation({
            query: (body) => ({
                url: 'dqapi/connectivityCheck',
                method: 'POST',
                body,
            }),
        }),
        getTaxonomyProductNames: builder.query({
            query: () => 'dqapi/getTaxonomyProductNames',
        }),
        fetchTaxonomyData: builder.mutation({
            query: (body) => ({
                url: 'dqapi/fetchTaxonomyData',
                method: 'POST',
                body,
            }),
        }),
        // postTaxonomyData: builder.mutation({
        //     query: (body) => ({
        //         url: 'dqapi/taxonomyData',
        //         method: 'POST',
        //         body,
        //     }),
        // }),
        insertTaxonomyData: builder.mutation({
            query: (body) => ({
                url: 'dqapi/insertTaxonomyData',
                method: 'POST',
                body,
            }),
        }),
        updateTaxonomyData: builder.mutation({
            query: (body) => ({
                url: 'dqapi/updateTaxonomyData',
                method: 'POST',
                body,
            }),
        }),
    }),
});

export const {
    useGetSSUIReportDataQuery,
    usePostSSUIReportDataMutation,

    useGetProductDataQuery,
    useGetL2ProductDataQuery,
    usePostTopBottomFiveScoresMutation,

    useGetDynamicFilterQuery,
    usePostDynamicFilterMutation,
    useGetDefaultEnterpriseDataQuery,
    usePostDefaultEnterpriseDataMutation,
    useGetDefaultLobWiseDataQuery,
    usePostDefaultLobWiseDataMutation,
    useGetDQTrendQuery,
    usePostDQTrendMutation,
    useGetProductTypeWiseDataQuery,
    usePostProductTypeWiseDataMutation,
    usePostHierarchalDataMutation,
    usePostTableWiseDataMutation,

    usePostMultipleRequestProfileMutation,
    useGetSingleTableLoadGCPQuery,
    usePostSingleTableLoadGCPMutation,
    usePostConnectivityCheckMutation,
    // usePostTaxonomyDataMutation,
    useGetTaxonomyProductNamesQuery,
    useFetchTaxonomyDataMutation,
    useInsertTaxonomyDataMutation,
    useUpdateTaxonomyDataMutation

} = nodeapiSlice;
