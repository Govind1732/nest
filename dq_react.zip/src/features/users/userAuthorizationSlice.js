import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

export const fetchUserAuthorization = createAsyncThunk('userAuthorization/fetchUserAuthorization', async (vzid) => {
    const response = await axios.post(`${import.meta.env.VITE_DJANGO_BASE_URL}user_management/GetUserDetails/`, { "vzid": vzid });
    localStorage.setItem('DQ_user', JSON.stringify(response.data));
    return response.data;
});



const userAuthorizationSlice = createSlice({
    name: 'userAuthorization',
    initialState: {
        user: {
            "vzid": "",
            "first_name": "",
            "last_name": "",
            "email": "",
            "projects": [],
            "roles": [
                {
                    // "name": "DQ Admin"
                    "name": "Executive"
                }
            ]
        },
        status: 'idle',
        error: null
    },
    reducers: {},
    extraReducers: (builder) => {
        builder.addCase(fetchUserAuthorization.pending, (state, action) => {
            state.status = 'loading';
        });
        builder.addCase(fetchUserAuthorization.fulfilled, (state, action) => {
            state.status = 'succeeded';
            state.user = action.payload;
        });
        builder.addCase(fetchUserAuthorization.rejected, (state, action) => {
            state.status = 'failed';
            state.error = action.error.message;
        });
    }
});

export default userAuthorizationSlice.reducer;