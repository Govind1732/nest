import { createAction } from '@reduxjs/toolkit';

export const setActiveStep = createAction('dataQualityProfileSingleRow/setActiveStep');
export const setCompletedSteps = createAction('dataQualityProfileSingleRow/setCompletedSteps');
export const setSelectedValues = createAction('dataQualityProfileSingleRow/setSelectedValues');
export const setTaxonomyData = createAction('dataQualityProfileSingleRow/setTaxonomyData');
export const setIsDataConfirmed = createAction('dataQualityProfileSingleRow/setIsDataConfirmed');
export const resetTaxonomyData = createAction('dataQualityProfileSingleRow/resetTaxonomyData');