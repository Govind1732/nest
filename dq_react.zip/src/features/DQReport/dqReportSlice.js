import { createSlice } from '@reduxjs/toolkit';
import {
    setFilterValues,
    resetFilterValues,
    startDate,
    endDate,
    setSelectedLabel,
    setDashboardView,
    setDataProductsView,
    setTableLevelAssetsView,
    setShowAllColumns,
} from './dqReportActions';

const initialState = {
    filterValues: {
        run_date: 'last_7_days',
        platform: null,
        data_lob: null,
        product_type: null,
        product_area: null,
        product_name: null,
        business_program_data: null
    },
    showAllColumns: false,
    dashboardView: true,
    dataProductsView: false,
    tableLevelAssetsView: false,
    startDate: null,
    endDate: null,
    selectedLabel: null
};

const dqReportSlice = createSlice({
    name: 'dqReport',
    initialState,
    reducers: {},
    extraReducers: (builder) => {
        builder
        .addCase(setFilterValues, (state, action) => {
            state.filterValues = action.payload;
        })
        .addCase(resetFilterValues, (state) => {
            state.filterValues = {
                run_date: 'last_7_days',
                platform: null,
                data_lob: null,
                product_type: null,
                product_area: null,
                product_name: null,
                business_program_data: null
            };
        })
        .addCase(startDate, (state, action) => {
            state.startDate = action.payload;
        })
        .addCase(endDate, (state, action) => {
            state.endDate = action.payload;
        })
        .addCase(setSelectedLabel, (state, action) => {
            state.selectedLabel = action.payload;
        })
        .addCase(setDashboardView, (state, action) => {
            state.dashboardView = action.payload;
        })
        .addCase(setShowAllColumns, (state, action) => {
            state.showAllColumns = action.payload;
        })
        .addCase(setDataProductsView, (state, action) => {
            state.dataProductsView = action.payload;
        })
        .addCase(setTableLevelAssetsView, (state, action) => {
            state.tableLevelAssetsView = action.payload;
        });
    },
});

export default dqReportSlice.reducer;