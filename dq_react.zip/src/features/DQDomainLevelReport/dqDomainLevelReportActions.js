import { createAction } from '@reduxjs/toolkit';

export const setActiveProduct = createAction('dqDomainLevelReport/setActiveProduct');
export const setLast7days = createAction('dqDomainLevelReport/setLast7days');
export const setShowAllColumns = createAction('dqDomainLevelReport/setShowAllColumns');
export const setDashboardView = createAction('dqDomainLevelReport/setDashboardView');
export const setSelectedTable = createAction('dqDomainLevelReport/setSelectedTable');
export const setColumnsData = createAction('dqDomainLevelReport/setColumnsData');