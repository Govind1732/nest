import '../styles/globals.css'
const rootStyles = getComputedStyle(document.documentElement);

export const strokeColorHigh = rootStyles
    .getPropertyValue("--stroke-color-success")
    .trim();

export const strokeColorMedium = rootStyles
    .getPropertyValue("--stroke-color-medium")
    .trim();

export const strokeColorLow = rootStyles
    .getPropertyValue("--stroke-color-low")
    .trim();

export const vdsColorHigh = rootStyles
    .getPropertyValue("--vds-color-feedback-success")
    .trim();

export const vdsColorMedium = rootStyles
    .getPropertyValue("--vds-color-feedback-warning")
    .trim();

export const vdsColorLow = rootStyles
    .getPropertyValue("--vds-color-feedback-error")
    .trim();