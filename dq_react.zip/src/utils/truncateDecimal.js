/**
 * Truncate a number to a specified number of decimal places without rounding.
 * @param {number} num - The number to truncate.
 * @param {number} decimalPlaces - The number of decimal places to keep.
 * @returns {string} - The truncated number as a string.
 */
const truncateDecimal = (num, decimalPlaces) => {
    const factor = Math.pow(10, decimalPlaces);
    const truncatedNum = Math.floor(num * factor) / factor;
    return truncatedNum.toFixed(decimalPlaces);
};

export default truncateDecimal;