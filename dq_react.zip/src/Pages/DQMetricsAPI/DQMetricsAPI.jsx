import React, { useState } from 'react';
import axios from 'axios';
import { Container, Row, Col, Form, Button, Breadcrumb, Modal } from 'react-bootstrap';
import { Breadcrumbs, BreadcrumbItem, Title } from "@vds/core"
import { Table, TableHead, TableRow, TableCell } from '@mui/material';
import Backdrop from '@mui/material/Backdrop';
import { GridLoader } from "react-spinners";
import { Link } from 'react-router-dom'
// import './APISubscription.css';
import { useNavigate } from 'react-router-dom';
import styles from './DQMetricsAPI.module.css';

const override = {
    display: "block",
    margin: "0 auto",
    borderColor: "red",
};

function DQMetricsAPI() {
    const [formData, setFormData] = useState({
        username: '',
        email_id: ''
    });
    const [loading, setLoading] = useState(false);
    const [show, setShow] = useState(false);
    const [showModal, setShowModal] = useState(false);
    const [body, setBody] = useState('')
    const [title, setTitle] = useState('')

    const navigate = useNavigate()
    const handleClose = () => {
        setShow(false);
        resetHandler();
    }
    const handleModalClose = () => {
        setShowModal(false);
        resetHandler();
        navigate('/dataQuality/AutoProfie/AutoProfileAPI', { state: { formData: formData } })

    }

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prevState => ({
            ...prevState,
            [name]: value
        }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        setLoading(true);

        axios.post(`${import.meta.env.VITE_DJANGO_BASE_URL}generate_api_key_view/`, formData, {
            headers: {
                'Content-Type': 'application/json',
            },
        })
            .then(response => {

                setLoading(false);
                setTitle(response.data.message)
                setBody("Kindly check your mail")
                setShow(true)

            })
            .catch(error => {
                setLoading(false);
                console.error(error);
                setTitle(error.name)
                setBody(error.message)
                setShow(true)
            });
    };


    const resetHandler = () => {
        setFormData(prevState => ({
            ...prevState,
            username: '',
            email_id: ''
        }))
    }

    return (
        <>
            <div className={styles.section}>
                <div className={styles.subHeading}>
                    <Title
                        size="medium"
                        bold={true}
                        color="#000">
                        DQ Metrics API
                    </Title>
                    <Breadcrumbs surface="light">
                        <BreadcrumbItem>API Integration</BreadcrumbItem>
                        <BreadcrumbItem>DQ Metrics API</BreadcrumbItem>
                    </Breadcrumbs>
                </div>
                <div className={styles.content}>
                    <div className={styles.mainContent}>
                        <Container fluid className=''>
                            <Form onSubmit={handleSubmit}>
                                {/* <h2 className="mb-2 text-center" style={{ color: '#EE0000' }}>DQ Metrics API</h2> */}
                                <Row className="justify-content-center align-items-center">
                                    <Col xl={6}>
                                        <Form.Group className="mb-2" controlId="ControlInput1" >
                                            <Form.Label>Project Name</Form.Label>
                                            <Form.Control type="text" value={formData.username} name='username' onChange={handleChange} required placeholder="Project" />
                                        </Form.Group>

                                        <Form.Group className="mb-2" controlId="ControlInput2">
                                            <Form.Label>EMail Id </Form.Label>
                                            <Form.Control type="email" value={formData.email_id} name='email_id' onChange={handleChange} required placeholder="EMail" />
                                        </Form.Group>

                                        <div className="d-flex justify-content-center mb-2" >
                                            <Button variant="dark" className='mx-2' onClick={resetHandler} style={{ borderRadius: '25px' }}>
                                                Reset
                                            </Button>
                                            <Button variant="dark" type="submit" className='mx-2' style={{ borderRadius: '25px' }}>
                                                Subscribe
                                            </Button>
                                            <Button variant="dark" className='mx-2' as={Link} to="/dataQuality/assets/DQ Knowledge Base/DQ Metrics API.pdf" download target="_blank" style={{ borderRadius: '25px' }}>
                                                Document for Enablement
                                            </Button>
                                            {/* https://docs.google.com/spreadsheets/d/136z8fedrMHPrVMbDGAZ9YXios_7boFF_y7trqkE1QFo/edit?pli=1#gid=1230713310 */}
                                        </div>
                                    </Col>
                                </Row>
                            </Form>


                            <Modal show={show} onHide={() => handleClose()}>
                                <Modal.Header closeButton>
                                    <Modal.Title>{title}</Modal.Title>
                                </Modal.Header>
                                <Modal.Body>{body}</Modal.Body>
                                <Modal.Footer>
                                    <Button variant="secondary" onClick={() => {
                                        handleClose();
                                    }} >
                                        Close
                                    </Button>

                                </Modal.Footer>
                            </Modal>

                            <Modal show={showModal} onHide={() => handleModalClose()}>
                                <Modal.Header closeButton>
                                    <Modal.Title>{title}</Modal.Title>
                                </Modal.Header>
                                <Modal.Body>{body}</Modal.Body>
                                <Modal.Footer>
                                    <Button variant="secondary" onClick={() => {
                                        handleModalClose();
                                    }} >
                                        Close
                                    </Button>

                                </Modal.Footer>
                            </Modal>

                            {/* <Alert severity="success" sx={{ width: '50%',display: show? "block":"none" }} onClose={() => {}}>
                    <AlertTitle>dfds</AlertTitle>
                    Kindly check your mail
                </Alert> */}

                        </Container >
                    </div>
                </div>
            </div>


            <Backdrop
                sx={{ color: '#fff', zIndex: (theme) => theme.zIndex.drawer + 1 }}
                open={loading}
            >
                {/* <CircularProgress color="inherit" /> */}
                <Container className="loading-overlay">
                    <GridLoader color="#ff0000" loading={loading} cssOverride={override} size={20} aria-label="Loading Spinner" data-testid='loader' />
                </Container>
            </Backdrop>
        </>
    );
}

export default DQMetricsAPI;