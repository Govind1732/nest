import { useEffect, useState } from "react";
import { Container, Row, Col, Form, Modal } from "react-bootstrap";
import {
  useGetDropdownDbAutoMLEMtdDataQuery,
  usePostDropdownDbAutoMLEMtdMutation,
  usePostViewEditAutoMLEMtdMutation,
  usePostSaveAutoMLEMtdMutation,
} from "../../features/api/djangoapiSlice";
import {
  TextField,
  TableContainer,
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  Paper,
  IconButton,
  TablePagination,
} from "@mui/material";
import EditIcon from "@mui/icons-material/Edit";
import SaveIcon from "@mui/icons-material/Save";
import LoadingButton from "@mui/lab/LoadingButton";
import "./AutoViewEdit.css";
import { FormControl, FormLabel, Autocomplete, Textarea } from "@mui/joy";
import styles from "./AutoProfile.module.css";
import { Button, Loader } from "@vds/core";

const AutoViewEdit = () => {
  const [formData, setFormData] = useState({
    db_name: null,
    table_name: null,
  });
  const [submitToggle, setSubmitToggle] = useState(false);
  const [editingRow, setEditingRow] = useState(null);
  const [tableData, setTableData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [dataNotFound, setDataNotFound] = useState("");
  const [dbOptions, setDbOptions] = useState([]);
  const [tableOptions, setTableOptions] = useState([]);
  const [alert, setAlert] = useState(false);
  const [editedRow, setEditedRow] = useState({});
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [status, setStatus] = useState("");
  const [message, setMessage] = useState("");

  const { data: dbData, isLoading: isDbLoading } =
    useGetDropdownDbAutoMLEMtdDataQuery();
  const [fetchTableNames, { isLoading: isTableLoading }] =
    usePostDropdownDbAutoMLEMtdMutation();
  const [fetchViewEditData] = usePostViewEditAutoMLEMtdMutation();
  const [saveEditedRow] = usePostSaveAutoMLEMtdMutation();

  useEffect(() => {
    if (dbData) {
      const dbOptions = Array.isArray(dbData.distinct_db)
        ? dbData.distinct_db
            .map((option) => option.db_name)
            .filter((option) => option !== null)
        : [];
      setDbOptions(dbOptions);
    }
  }, [dbData]);

  useEffect(() => {
    const fetchTableOptions = async () => {
      if (formData.db_name) {
        try {
          const response = await fetchTableNames({
            db_name: formData.db_name,
          }).unwrap();
          setTableOptions(
            Array.isArray(response.distinct_tbl) ? response.distinct_tbl : []
          );
        } catch (error) {
          console.error("Error fetching table names:", error);
        }
      } else {
        setTableOptions([]);
      }
    };
    fetchTableOptions();
  }, [formData.db_name, fetchTableNames]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleEdit = (index) => {
    setEditingRow(index);
    setEditedRow(tableData[index]);
  };

  const handleSave = async () => {
    try {
      setLoading(true);
      const payload = {
        prfl_tbl_id: editedRow.PRFL_TBL_ID ?? "",
        data_lob: editedRow.DATA_LOB ?? "",
        data_bus_elem: editedRow.DATA_BUS_ELEM ?? "",
        data_dmn: editedRow.DATA_DMN ?? "",
        data_sub_dmn: editedRow.DATA_SUB_DMN ?? "",
        data_src: editedRow.DATA_SRC ?? "",
        db_name: editedRow.DB_NAME ?? "",
        src_tbl: editedRow.SRC_TBL ?? "",
        incr_dt_col: editedRow.INCR_DT_COL ?? "",
        incr_dt_cond: editedRow.INCR_DT_COND ?? 0,
        unq_index_cols: editedRow.UNQ_INDEX_COLS ?? "",
        auto_prfl_freq: editedRow.AUTO_PRFL_FREQ ?? "",
        auto_prfl_schd_ts: editedRow.AUTO_PRFL_SCHD_TS ?? "",
        email_dist: editedRow.EMAIL_DIST ?? "",
        is_active_flg: editedRow.IS_ACTIVE_FLG ?? "",
        is_complete_flg: editedRow.IS_COMPLETE_FLG ?? "",
        is_critical_flg: editedRow.IS_CRITICAL_FLG ?? "",
        tbl_cde: editedRow.TBL_CDE ?? "",
      };

      const response = await saveEditedRow(payload).unwrap();
      setEditingRow(null);
      setEditedRow({});
      setAlert(true);
      setStatus(response.status);
      setMessage(response.message);
    } catch (error) {
      console.error("Error saving edited row:", error);
      setAlert(true);
      setStatus("Error");
      setMessage("Error saving edited row: " + error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    if (e) {
      e.preventDefault();
    }
    setLoading(true);
    try {
      const response = await fetchViewEditData(formData).unwrap();
      if (response.length === 0) {
        setDataNotFound("No such combination or files exist");
        setTableData([]);
      } else {
        setDataNotFound("");
        setTableData(
          response.map((obj) =>
            Object.fromEntries(
              Object.entries(obj).map(([key, value]) => [
                key.toUpperCase(),
                value,
              ])
            )
          )
        );
        setSubmitToggle(true);
      }
    } catch (error) {
      console.error("Error in fetching details:", error);
      alert("Error in fetching details:", error);
    } finally {
      setLoading(false);
    }
  };

  const resetHandler = () => {
    setDataNotFound("");
    setFormData({
      db_name: "",
      table_name: "",
    });
    setTableOptions([]);
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };

  return (
    <>
      {!submitToggle && (
        <div className={styles.mainContent}>
          <Container fluid className="mx-8 px-8 mb-2">
            <Row className="d-flex justify-content-center align-items-center text-align-center my-xl-1">
              <Col xl={5}>
                <div>
                  <Form onSubmit={handleSubmit}>
                    <FormControl sx={{ margin: 2 }}>
                      <FormLabel className="fw-bold">DB Name</FormLabel>
                      <Autocomplete
                        placeholder="Select your Option"
                        options={dbOptions}
                        autoHighlight
                        name="db_name"
                        value={formData.db_name || null}
                        onChange={(_, value) =>
                          setFormData((prev) => ({ ...prev, db_name: value }))
                        }
                        isOptionEqualToValue={(option, value) =>
                          option.toLowerCase() === value.toLowerCase()
                        }
                        loading={isDbLoading}
                      />
                    </FormControl>
                    <FormControl sx={{ margin: 2 }}>
                      <FormLabel className="fw-bold">Table Name</FormLabel>
                      <Autocomplete
                        placeholder="Select your Option"
                        options={tableOptions}
                        autoHighlight
                        name="table_name"
                        value={formData.table_name || null}
                        onChange={(_, value) =>
                          setFormData((prev) => ({
                            ...prev,
                            table_name: value,
                          }))
                        }
                        isOptionEqualToValue={(option, value) =>
                          option.toLowerCase() === value.toLowerCase()
                        }
                        loading={isTableLoading}
                      />
                    </FormControl>
                    <div className="d-flex justify-content-center my-3 mx-auto gap-2">
                      <Button use="secondary" onClick={resetHandler}>
                        Reset
                      </Button>
                      <Button type="submit">Submit</Button>
                    </div>
                  </Form>
                </div>
              </Col>
            </Row>
          </Container>
        </div>
      )}

      {submitToggle && (
        <div className={styles.subContent}>
          <Form onSubmit={handleSubmit}>
            <Row className="justify-content-center align-items-center">
              <Col xs={3}>
                <TextField
                  label="Database"
                  name="db_name"
                  value={formData.db_name}
                  onChange={handleChange}
                  variant="outlined"
                  fullWidth
                  size="small"
                />
              </Col>
              <Col xs={3}>
                <TextField
                  label="Table Name"
                  name="table_name"
                  value={formData.table_name}
                  onChange={handleChange}
                  variant="outlined"
                  fullWidth
                  size="small"
                />
              </Col>
              <Col xs={2}>
                <Button type="submit">Submit</Button>
              </Col>
            </Row>
          </Form>
          {tableData.length > 0 ? (
            <Container fluid>
              <Paper sx={{ width: "100%", overflow: "hidden" }}>
                <TableContainer sx={{ maxHeight: 500 }}>
                  <Table stickyHeader aria-label="sticky table">
                    <TableHead>
                      <TableRow>
                        {tableData[0] &&
                          Object.keys(tableData[0])
                            .filter(
                              (key) =>
                                key !== "update_made_ts" &&
                                key !== "entry_made_ts"
                            )
                            .map((key) => (
                              <TableCell
                                key={key}
                                style={{
                                  backgroundColor: "black",
                                  color: "white",
                                  border: "1px solid white",
                                  fontWeight: "bold",
                                }}
                              >
                                {key}
                              </TableCell>
                            ))}
                        <TableCell
                          key="action"
                          style={{
                            backgroundColor: "black",
                            color: "white",
                            border: "1px solid white",
                            fontWeight: "bold",
                          }}
                        >
                          Action
                        </TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {tableData
                        .slice(
                          page * rowsPerPage,
                          page * rowsPerPage + rowsPerPage
                        )
                        .map((row, index) => (
                          <TableRow
                            key={index}
                            hover
                            role="checkbox"
                            tabIndex={-1}
                          >
                            {Object.entries(row)
                              .filter(
                                ([key]) =>
                                  key !== "update_made_ts" &&
                                  key !== "entry_made_ts"
                              )
                              .map(([key, value], valueIndex) => (
                                <TableCell key={valueIndex}>
                                  {editingRow === index &&
                                  ![
                                    "PRFL_TBL_ID",
                                    "DB_NAME",
                                    "SRC_TBL",
                                    "DATA_SUB_DMN",
                                  ].includes(key) ? (
                                    <Textarea
                                      aria-label="empty textarea"
                                      defaultValue={value}
                                      onChange={(e) =>
                                        setEditedRow((prevRow) => ({
                                          ...prevRow,
                                          [key]: e.target.value,
                                        }))
                                      }
                                    />
                                  ) : (
                                    value
                                  )}
                                </TableCell>
                              ))}
                            <TableCell key={`action-${index}`}>
                              {editingRow === index ? (
                                <LoadingButton
                                  loading={false}
                                  loadingPosition="start"
                                  startIcon={<SaveIcon />}
                                  onClick={() => handleSave(index)}
                                >
                                  Save
                                </LoadingButton>
                              ) : (
                                <IconButton onClick={() => handleEdit(index)}>
                                  <EditIcon /> Edit
                                </IconButton>
                              )}
                            </TableCell>
                          </TableRow>
                        ))}
                    </TableBody>
                  </Table>
                </TableContainer>
                <TablePagination
                  rowsPerPageOptions={[10, 20, 30, 40, 50, 100]}
                  component="div"
                  count={tableData.length}
                  rowsPerPage={rowsPerPage}
                  page={page}
                  onPageChange={handleChangePage}
                  onRowsPerPageChange={handleChangeRowsPerPage}
                />
              </Paper>
            </Container>
          ) : (
            <div className="d-flex justify-content-center m-2 blink">
              <h5>{dataNotFound}</h5>
            </div>
          )}
        </div>
      )}

      {loading && <Loader fullscreen={false} active={true} surface="light" />}

      <Modal show={alert}>
        <Modal.Header closeButton>
          <Modal.Title>{status}</Modal.Title>
        </Modal.Header>
        <Modal.Body>{message}</Modal.Body>
        <Modal.Footer>
          <Button
            variant="secondary"
            onClick={() => {
              setAlert(false);
              handleSubmit();
            }}
          >
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
};

export default AutoViewEdit;
