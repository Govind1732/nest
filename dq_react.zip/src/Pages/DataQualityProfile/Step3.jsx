import { useDispatch, useSelector } from 'react-redux';
import TextField from '@mui/material/TextField';
import { Body, Button, RadioBoxGroup } from '@vds/core';
import styles from './DataQualityProfile.module.css';
import { setActiveStep, setCompletedSteps } from '../../features/DataQualityProfileSingleRow/dataQualityProfileSingleRowActions.js';
import { useState } from 'react';
import * as XLSX from 'xlsx';
import axios from 'axios';

const Step3 = () => {
    const dispatch = useDispatch();
    const activeStep = useSelector((state) => state.dataQualityProfileSingleRow.activeStep);
    const completedSteps = useSelector((state) => state.dataQualityProfileSingleRow.completedSteps);
    const [profileType, setProfileType] = useState('Auto Profile');
    const [formData, setFormData] = useState({});

    const handleNext = () => {
        dispatch(setCompletedSteps([...new Set([...completedSteps, activeStep])]));
        dispatch(setActiveStep(activeStep + 1));
    };

    const handlePrevious = () => {
        dispatch(setActiveStep(activeStep - 1));
    };

    const handleProfileTypeChange = (e) => {
        setProfileType(e.target.value);
    };

    const handleInputChange = (field, value) => {
        setFormData({
            ...formData,
            [field]: value
        });
    };

    const handleSubmit = async () => {
        try {
            const fieldsToDisplay = profileType === 'Auto Profile' ? autoProfileFields :
                profileType === 'Rule Profile' ? ruleProfileFields : ruleCustomFields;
    
            const data = fieldsToDisplay.map(field => ({
                [field]: formData[field] || ''
            }));
    
            const csvData = XLSX.utils.sheet_to_csv(XLSX.utils.json_to_sheet(data));
            const blob = new Blob([csvData], { type: 'text/csv' });
    
            const formDataToSend = new FormData();
            const originalFileName = 'profile_data.csv';
            const modifiedFileName = originalFileName.replace(/\s+/g, '').replace(/\.csv$/, '') + '_selfserve.csv';
            formDataToSend.append('file', blob, modifiedFileName);
    
            const apiUrl = `${import.meta.env.VITE_NODEAPI_BASE_URL}dqapi/multiRequestProfile`;
            await axios.post(apiUrl, formDataToSend, { headers: { "Content-Type": "multipart/form-data" } });
    
            handleNext();
        } catch (error) {
            console.error('Failed to submit profile data:', error);
        }
    };

    const autoProfileFields = [
        "project_name", "database_name", "table_name", "column_name", "cde", "unique_key_cols", "platform_name",
        "business_program", "profile_type", "profile_schedule_ts", "threshold_limit", "email_distro", "jira_assignee",
        "opsgenie_team", "opsgenie_api_key", "tag_name", "data_latency", "incr_date_column", "rule_desc", "run_frequency",
        "product_name", "auto_rerun_flag", "trigger_type"
    ];

    const ruleProfileFields = [
        "project_name", "database_name", "table_name", "column_name", "platform_name", "business_program", "profile_type",
        "rule_sql", "profile_schedule_ts", "threshold_limit", "email_distro", "jira_assignee", "opsgenie_team",
        "opsgenie_api_key", "tag_name", "rule_name", "dq_pillar_name", "rule_desc", "invalid_rec_sql", "business_term_desc",
        "run_frequency", "product_name", "auto_rerun_flag", "trigger_type"
    ];

    const ruleCustomFields = [
        "project_name", "database_name", "table_name", "column_name", "platform_name", "business_program", "profile_type",
        "rule_sql", "profile_schedule_ts", "threshold_limit", "email_distro", "jira_assignee", "opsgenie_team",
        "opsgenie_api_key", "tag_name", "rule_desc", "run_frequency", "product_name", "auto_rerun_flag", "trigger_type"
    ];

    const fieldsToDisplay = profileType === 'Auto Profile' ? autoProfileFields :
        profileType === 'Rule Profile' ? ruleProfileFields : ruleCustomFields;

    const optionalFields = [
        "tag_name", "rule_name", "rule_desc", "invalid_rec_sql", "business_term_desc", "run_frequency", "auto_rerun_flag", "trigger_type"
    ];

    return (
        <div className={styles.sourceContainer}>
            <h2>Select Profiling</h2>
            <RadioBoxGroup
                childWidth={'200px'}
                defaultValue='Auto Profile'
                orientation="horizontal"
                data={[
                    { id: 'Auto Profile', text: 'Auto Profile', value: 'Auto Profile', name: 'profileType' },
                    { id: 'Rule Profile', text: 'Rule Profile', value: 'Rule Profile', name: 'profileType' },
                    { id: 'Rule Custom Profile', text: 'Rule Custom Profile', value: 'Rule Custom Profile', name: 'profileType' }
                ]}
                onChange={handleProfileTypeChange}
            />

            <div className={styles.formContainer}>
                <div className={styles.inputRow}>
                    {fieldsToDisplay.map((field) => (
                        <div key={field} className={styles.inputField}>
                            <TextField
                                label={field.replace(/_/g, ' ')}
                                value={formData[field] || ''}
                                onChange={(e) => handleInputChange(field, e.target.value)}
                                size="small"
                                required={!optionalFields.includes(field)}
                            />
                        </div>
                    ))}
                </div>
            </div>
            <div className={styles.navigationButtons}>
                <Button onClick={handleSubmit}>
                    Submit Profile
                </Button>
                <Button onClick={handlePrevious} use="secondary">
                    Previous Step
                </Button>
            </div>
        </div>
    );
};

export default Step3;