import { useSelector, useDispatch } from 'react-redux';
import { Micro, Body } from '@vds/core';
import styles from './DataQualityProfile.module.css';
import Step1 from './Step1.jsx';
import Step2 from './Step2.jsx';
import Step3 from './Step3.jsx';
// import { setActiveStep, setCompletedSteps } from '../../features/DataQualityProfileSingleRow/dataQualityProfileSingleRowActions.js';

const DataQualityProfileSingleRow = () => {
    // const dispatch = useDispatch();
    const activeStep = useSelector((state) => state.dataQualityProfileSingleRow.activeStep);
    const completedSteps = useSelector((state) => state.dataQualityProfileSingleRow.completedSteps) || [];

    const steps = [
        { id: 1, label: 'Source', component: <Step1 /> },
        { id: 2, label: 'Taxonomy', component: <Step2 /> },
        { id: 3, label: 'Meta', component: <Step3 /> },
        // { id: 4, label: 'Threshold', component: <Step4 /> },
        // { id: 5, label: 'Product', component: <Step5 /> },
    ];

    return (
        <div className={styles.singleRowMainContent}>
            <div className={styles.stepperContainer}>
                <ul>
                    {steps.map((step) => (
                        <li
                            key={step.id}
                            className={`${styles.stepperItem} ${activeStep === step.id ? styles.active : ''}`}
                            // onClick={() => dispatch(setActiveStep(step.id))}
                        >
                            <div
                                className={`${styles.stepperCircle} ${activeStep === step.id ? styles.activeCircle : ''
                                    } ${completedSteps.includes(step.id) ? styles.completedCircle : ''}`}
                            >
                                {step.id}
                            </div>
                            <div className={styles.stepperLine}>
                                <Body size="large" color="#000000" bold={true}>
                                    {step.label}
                                </Body>
                                <Micro color="#6F7171">Step {step.id}</Micro>
                            </div>
                        </li>
                    ))}
                </ul>
            </div>
            <div className={styles.stepperContent}>
                {steps.find((step) => step.id === activeStep)?.component}
            </div>
        </div>
    );
};

export default DataQualityProfileSingleRow;