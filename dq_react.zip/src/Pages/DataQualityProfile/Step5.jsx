import TextField from '@mui/material/TextField';
import Autocomplete from '@mui/material/Autocomplete';
import { Grid, Row, Col, Body } from '@vds/core';

const Step5 = () => {
    return (<>
        <Body size="large" bold={true}>Product</Body>

        <Grid
            bleed="1272"
            rowGutter="20px"
            colSizes={{
                mobile: 1,
                tablet: 2,
                desktop: 4,
            }}
            style={{
                marginTop: '50px',
                marginBottom: '50px',
            }}
        >
            <Row>
                <Col>
                    <Autocomplete
                        disablePortal
                        options={['TD', 'GCP']}
                        // sx={{ width: 300 }}
                        size="small"
                        renderInput={(params) => <TextField {...params} label="Product Name" />}
                    />
                </Col>
                <Col>
                    <Autocomplete
                        disablePortal
                        options={['sample values']}
                        // sx={{ width: 300 }}
                        size="small"
                        renderInput={(params) => <TextField {...params} label="Product Type" />}
                    />
                </Col>
                <Col>
                    <Autocomplete
                        disablePortal
                        options={['db1', 'db2', 'db3', 'db4']}
                        // sx={{ width: 300 }}
                        size="small"
                        renderInput={(params) => <TextField {...params} label="Product Area" />}
                    />
                </Col>

            </Row>
            <Row>

                <Col>
                    <Autocomplete
                        disablePortal
                        options={['sample values']}
                        // sx={{ width: 500 }}
                        size="small"
                        renderInput={(params) => <TextField {...params} label="Business Program" />}
                    />
                </Col>
                
            </Row>

        </Grid>


    </>)
}
export default Step5;