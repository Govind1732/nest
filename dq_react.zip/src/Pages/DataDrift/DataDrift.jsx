import { Tabs, Tab } from "@vds/tabs"
import { Title } from "@vds/typography"
import { Breadcrumbs,BreadcrumbItem } from "@vds/breadcrumbs"
import DataDriftDifferentenv from './DataDriftDifferentenv'
import DataDriftSameenv from './DataDriftSameenv'
import styles from './DataDrift.module.css'

const DataDrift = () => {
  return (
    <>
      <div className={styles.section}>
        <div className={styles.subHeading}>
          <Title
            size="medium"
            bold={true}
            color="#000">
            Data Drift
          </Title>
          <Breadcrumbs surface="light">
            <BreadcrumbItem>API Integration</BreadcrumbItem>
            <BreadcrumbItem>Data Drift</BreadcrumbItem>
          </Breadcrumbs>
        </div>
        <div className={styles.content}>
          <Tabs orientation="horizontal" indicatorPosition="bottom" size="medium">
            <Tab label="Same environment">
              <DataDriftSameenv />
            </Tab>
            <Tab label="Different environment">
              <DataDriftDifferentenv />
            </Tab>
          </Tabs>
        </div>
      </div>
    </>
  )
}
export default DataDrift