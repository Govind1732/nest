import React, { useState } from 'react';
import axios from 'axios';
import { Container, Row, Col, Form, Button, Breadcrumb, Modal } from 'react-bootstrap';
import { Breadcrumbs, BreadcrumbItem, Title } from "@vds/core"
import Backdrop from '@mui/material/Backdrop';
import { GridLoader } from "react-spinners";
import styles from './DQFalloutPrediction.module.css';

const override = {
    display: "block",
    margin: "0 auto",
    borderColor: "red",
};

function DQFalloutPrediction() {
    const [formData, setFormData] = useState({
        table_name: '',
        db_name: '',
        email_id: ''
    });
    const [loading, setLoading] = useState(false);
    const [show, setShow] = useState(false);
    const [body, setBody] = useState('')
    const [title, setTitle] = useState('')

    const handleClose = () => {
        setShow(false);
        resetHandler();
    }

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prevState => ({
            ...prevState,
            [name]: value
        }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        setLoading(true);

        axios.post(`${import.meta.env.VITE_DJANGO_BASE_URL}self_serve2/falloutprediction/`, formData, {
            headers: {
                'Content-Type': 'application/json',
            },
        })
            .then(response => {

                setLoading(false);
                setTitle('Success')
                setBody(response.data.message)
                setShow(true)

            })
            .catch(error => {
                setLoading(false);
                console.error(error);
                setTitle(error.name)
                setBody(error.message)
                setShow(true)
            });
    };

    const resetHandler = () => {
        setFormData(prevState => ({
            ...prevState,
            table_name: '',
            db_name: '',
            email_id: ''
        }))
    }

    return (
        <>
            <div className={styles.section}>
                <div className={styles.subHeading}>
                    <Title
                        size="medium"
                        bold={true}
                        color="#000">
                        DQ Fallout Prediction
                    </Title>
                    <Breadcrumbs surface="light">
                        <BreadcrumbItem>API Integration</BreadcrumbItem>
                        <BreadcrumbItem>DQ Fallout Prediction</BreadcrumbItem>
                    </Breadcrumbs>
                </div>
                <div className={styles.content}>
                    <div className={styles.mainContent}>
                        <Container fluid className=''>
                            <Container fluid className='mx-8 px-8 mb-2 mt-5'>
                                <Form onSubmit={handleSubmit}>
                                    {/* <h2 className="mb-2 text-center">DQ Fallout Subscription</h2> */}
                                    <Row className="justify-content-center align-items-center">
                                        <Col xl={6}>
                                            <Form.Group className="mb-2" controlId="ControlInput1" >
                                                <Form.Group className="mb-2" controlId="ControlInput1" >
                                                    <Form.Label>DB Name</Form.Label>
                                                    <Form.Control type="text" value={formData.db_name} name='db_name' onChange={handleChange} placeholder="DB Name" />
                                                </Form.Group>
                                                <Form.Label>Table Name</Form.Label>
                                                <Form.Control type="text" value={formData.table_name} name='table_name' onChange={handleChange} required placeholder="Table Name" />
                                            </Form.Group>

                                            <Form.Group className="mb-2" controlId="ControlInput2">
                                                <Form.Label>EMail Id </Form.Label>
                                                <Form.Control type="email" value={formData.email_id} name='email_id' onChange={handleChange} required placeholder="EMail" />
                                            </Form.Group>

                                            <div className="d-flex justify-content-center mb-2" >
                                                <Button variant="outline-dark" className='mx-2' onClick={resetHandler}>
                                                    Reset
                                                </Button>
                                                <Button variant="outline-dark" type="submit" className='mx-2'>
                                                    Submit
                                                </Button>
                                            </div>
                                        </Col>
                                    </Row>
                                </Form>
                            </Container>



                            <Modal show={show} onHide={() => handleClose()}>
                                <Modal.Header closeButton>
                                    <Modal.Title>{title}</Modal.Title>
                                </Modal.Header>
                                <Modal.Body>{body}</Modal.Body>
                                <Modal.Footer>
                                    <Button variant="secondary" onClick={() => {
                                        handleClose();
                                    }} >
                                        Close
                                    </Button>

                                </Modal.Footer>
                            </Modal>

                        </Container >
                    </div>
                </div>
            </div>

            <Backdrop
                sx={{ color: '#fff', zIndex: (theme) => theme.zIndex.drawer + 1 }}
                open={loading}
            >
                <Container className="loading-overlay">
                    <GridLoader color="#ff0000" loading={loading} cssOverride={override} size={20} aria-label="Loading Spinner" data-testid='loader' />
                </Container>
            </Backdrop>
        </>
    );
}

export default DQFalloutPrediction;