import React, { useState } from 'react';
import axios from 'axios';
import { Container, Row, Col, Form, Button, Breadcrumb, Modal } from 'react-bootstrap';
import URLSearchParams from 'url-search-params'
import { Breadcrumbs, BreadcrumbItem, Title } from "@vds/core"
import styles from './DQDataRemediation.module.css';

function DQDataRemediation() {
    const [formData, setFormData] = useState({
        data_source: '',
        project_name: '',
        dbname: '',
        table_name: '',
        incr_col: '',
        incr_cond: '',
        email: ''
    });
    const [loading, setLoading] = useState(false);
    // const [accessCheckResult, setAccessCheckResult] = useState('');
    const [additionalFieldsVisible, setAdditionalFieldsVisible] = useState(false);
    const [show, setShow] = useState(false);
    const [body, setBody] = useState('')
    const [showModal, setShowModal] = useState(false)
    const [profileSuccess, setProfileSuccess] = useState(false)

    const handleClose = () => {
        setShow(false);
        setShowModal(false)
        setProfileSuccess(false)
    }

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prevState => ({
            ...prevState,
            [name]: value
        }));
    };

    const handleConnectivityCheck = () => {
        setLoading(true);
        const formDataUrlEncoded = new URLSearchParams();
        for (const [key, value] of Object.entries(formData)) {
            formDataUrlEncoded.append(key, value);
        }

        axios.post(`${import.meta.env.VITE_DJANGO_BASE_URL}ml_profiler_config_form/ui_fetch/`, formDataUrlEncoded, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        })
            .then(response => {
                setLoading(false);
                if (response.data.combination_exists) {
                    // alert('Connectivity/Access does not exist. Redirecting to marketplace to raise a request');
                    setShow(true)
                    setBody("Click on close button to redirect to marketplace to raise a request")

                } else {
                    fetchAdditionalDetails()
                    // alert('Connectivity/Access available. Please fill the remaining fields for profiling');
                    setBody("Please fill the remaining fields for profiling")
                    setAdditionalFieldsVisible(true);
                    setShowModal(true)

                }
            })
            .catch(error => {
                setLoading(false);
                console.error('Error checking connectivity:', error);
                alert("error in handling data")
            });
    };

    const fetchAdditionalDetails = () => {
        const formDataUrlEncoded = new URLSearchParams();
        for (const [key, value] of Object.entries(formData)) {
            formDataUrlEncoded.append(key, value);
        }

        axios.post(`${import.meta.env.VITE_DJANGO_BASE_URL}ml_profiler_config_form/autopopulate_columns/`, formDataUrlEncoded, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        })
            .then(response => {
                setFormData(prevState => ({
                    ...prevState,
                    incr_col: response.data.INCR_DT_COL,
                    incr_cond: response.data.INCR_DT_COND
                }));
            })
            .catch(error => {
                console.error('Error fetching additional details:', error);
            });
    };


    const handleSubmit = (e) => {
        e.preventDefault();
        setLoading(true);

        const formDataUrlEncoded = new URLSearchParams();
        for (const [key, value] of Object.entries(formData)) {
            formDataUrlEncoded.append(key, value);
        }

        axios.post(`${import.meta.env.VITE_DJANGO_BASE_URL}self_serve2/dispatch_remediation_data/`, formDataUrlEncoded, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        })
            .then(response => {

                setLoading(false);
                setBody("Report will be sent through Email in few minutes.")
                setProfileSuccess(true)

            })
            .catch(error => {
                setLoading(false);
                console.error('Error triggering Data Remediation:', error);
                alert('Error triggering Data Remediation:', error)
            });
    };

    const resetHandler = () => {
        setFormData(prevState => ({
            ...prevState,
            data_source: '',
            project_name: '',
            dbname: '',
            table_name: '',
            incr_col: '',
            incr_cond: '',
            email: ''
        }))
        setAdditionalFieldsVisible(false)
    }

    return (
        <>
            <div className={styles.section}>
                <div className={styles.subHeading}>
                    <Title
                        size="medium"
                        bold={true}
                        color="#000">
                        DQ Data Remediation
                    </Title>
                    <Breadcrumbs surface="light">
                        <BreadcrumbItem>API Integration</BreadcrumbItem>
                        <BreadcrumbItem>DQ Data Remediation</BreadcrumbItem>
                    </Breadcrumbs>
                </div>
                <div className={styles.content}>
                    <div className={styles.mainContent}>
                        <Container fluid className=''>
                            <Container fluid className='mx-8 px-8 mb-2'>
                                <Form onSubmit={handleSubmit}>
                                    {/* <h2 className="mb-2 text-center">DQ Data Remediation</h2> */}
                                    <Row className="justify-content-center align-items-center">
                                        <Col xl={3}>
                                            <fieldset disabled={additionalFieldsVisible || loading}>

                                                <Form.Group className="mb-2" controlId="ControlInput1">
                                                    <Form.Label>DataSource</Form.Label>
                                                    <Form.Select value={formData.data_source} name='data_source' onChange={handleChange} required>
                                                        <option value='' disabled>Select Environment</option>
                                                        <option value="GCP">GCP</option>
                                                        <option value="TD">Teradata</option>
                                                    </Form.Select>
                                                </Form.Group>

                                                <Form.Group className="mb-2" controlId="ControlInput2" style={{ display: formData.data_source === 'GCP' ? 'block' : 'none' }}>
                                                    <Form.Label>Select Project</Form.Label>
                                                    <Form.Control type="text" value={formData.project_name} name='project_name' onChange={handleChange} required placeholder="Project" />
                                                </Form.Group>

                                                <Form.Group className="mb-2" controlId="ControlInput3">
                                                    <Form.Label>Select Database</Form.Label>
                                                    <Form.Control type="text" value={formData.dbname} name='dbname' onChange={handleChange} required placeholder="Database" />
                                                </Form.Group>

                                                <Form.Group className="mb-2" controlId="ControlInput4">
                                                    <Form.Label>Select Tables</Form.Label>
                                                    <Form.Control type="text" value={formData.table_name} name='table_name' onChange={handleChange} required placeholder="Table" />
                                                </Form.Group>

                                                <div className="d-flex justify-content-center mb-2" >
                                                    <Button variant="outline-dark" type="button" onClick={handleConnectivityCheck} disabled={loading} style={{ display: additionalFieldsVisible ? 'none' : 'block' }}>
                                                        {loading ? 'Checking...' : 'Check For Connectivity'}
                                                    </Button>
                                                </div>
                                            </fieldset>
                                        </Col>
                                        <Col xl={3} style={{ display: additionalFieldsVisible ? 'block' : 'none' }}>

                                            <fieldset style={{ display: additionalFieldsVisible ? 'block' : 'none' }}>
                                                <Form.Group className="mb-2" controlId="ControlInput5">
                                                    <Form.Label>Incremental Column</Form.Label>
                                                    <Form.Control type="text" value={formData.incr_col} name='incr_col' onChange={handleChange} placeholder="Incremental Column" />
                                                </Form.Group>

                                                <Form.Group className="mb-2" controlId="ControlInput6">
                                                    <Form.Label>Incremental Condition</Form.Label>
                                                    <Form.Control type="text" value={formData.incr_cond} name='incr_cond' onChange={handleChange} placeholder="Incremental Condition" />
                                                </Form.Group>

                                                <Form.Group className="mb-2" controlId="ControlInput7">
                                                    <Form.Label>Select Email</Form.Label>
                                                    <Form.Control type="email" value={formData.email} name='email' onChange={handleChange} required placeholder="Email" />
                                                </Form.Group>


                                            </fieldset>


                                        </Col>
                                        <div className="d-flex justify-content-center mb-2" >
                                            <Button variant="outline-dark" style={{ display: additionalFieldsVisible ? 'block' : 'none' }} disabled={loading} className='mx-2' onClick={resetHandler}>
                                                Reset
                                            </Button>
                                            <Button variant="outline-dark" type="submit" disabled={loading} style={{ display: additionalFieldsVisible ? 'block' : 'none' }} className='mx-2'>
                                                {loading ? 'loading...' : 'Remediate'}
                                            </Button>
                                        </div>
                                    </Row>
                                </Form>

                            </Container>

                            <Modal show={show} onHide={() => handleClose()}>
                                <Modal.Header closeButton>
                                    <Modal.Title>Connectivity/Access does not exist.</Modal.Title>
                                </Modal.Header>
                                <Modal.Body>{body}</Modal.Body>
                                <Modal.Footer>
                                    <Button variant="secondary" onClick={() => {
                                        handleClose();
                                        window.open('https://marketplace.verizon.com/#/subscriptionReqForm', '_blank')
                                    }} >
                                        Close
                                    </Button>

                                </Modal.Footer>
                            </Modal>

                            <Modal show={showModal} onHide={() => handleClose()}>
                                <Modal.Header closeButton>
                                    <Modal.Title>Connectivity/Access available.</Modal.Title>
                                </Modal.Header>
                                <Modal.Body>{body}</Modal.Body>
                                <Modal.Footer>
                                    <Button variant="secondary" onClick={handleClose}>
                                        Close
                                    </Button>

                                </Modal.Footer>
                            </Modal>

                            <Modal show={profileSuccess} onHide={() => handleClose()} backdrop="static"
                                keyboard={false}>
                                <Modal.Header closeButton>
                                    <Modal.Title>Data Remediation Triggered.</Modal.Title>
                                </Modal.Header>
                                <Modal.Body>{body}</Modal.Body>
                                <Modal.Footer>
                                    <Button variant="secondary" onClick={() => {
                                        handleClose();
                                    }} >
                                        Close
                                    </Button>

                                </Modal.Footer>
                            </Modal>

                        </Container >
                    </div>
                </div>
            </div>

        </>);
}

export default DQDataRemediation;