import axios from "axios";
import URLSearchParams from "url-search-params";
import { TextField, TableContainer, Table, TableHead, TableBody, TableRow, TableCell, Paper, TablePagination } from "@mui/material";
import { useState, useEffect } from "react";
import { Container, Row, Col, Form } from "react-bootstrap";
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import Autocomplete from '@mui/material/Autocomplete';
import { Button } from "@vds/core";
import styles from "./DataProfile.module.css";

const DownloadReports = () => {
  const [formData, setFormData] = useState({
    data_source: "TD",
    project_id: "",
    db_name: "",
    table_name: "",
    date: "",
  });
  const [dataNotFound, setDataNotFound] = useState("");
  const [reportfetched, setReportFetched] = useState(false);
  const [responseData, setResponseData] = useState([]);
  const [projectOptions, setProjectOptions] = useState([]);
  const [dbOptions, setDbOptions] = useState([]);
  const [tableOptions, setTableOptions] = useState([]);
  const [dbOptionsTD, setDbOptionsTD] = useState([]);
  const [tableOptionsTD, setTableOptionsTD] = useState([]);
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const fetchProjectOptions = async () => {
    try {
      const response = await axios.get(`${import.meta.env.VITE_NODEAPI_BASE_URL}dqapi/singleTableLoadGCP`);
      setProjectOptions(response.data);
    } catch (error) {
      console.error('Error fetching project ids:', error);
      alert('Error fetching project ids');
    }
  };

  const fetchDbOptionsTD = async () => {
    try {
      const response = await axios.get(`${import.meta.env.VITE_DJANGO_BASE_URL}self_serve2/SingleTableLoadTD/`);
      setDbOptionsTD(response.data.DatabaseName.map(dbname => dbname.trim()));
    } catch (error) {
      console.error('Error fetching Database Names:', error);
      alert('Error fetching Database Names');
    }
  };

  const fetchDbOptions = async () => {
    if (formData.project_id) {
      try {
        const response = await axios.post(`${import.meta.env.VITE_NODEAPI_BASE_URL}dqapi/singleTableLoadGCP`, {
          project_id: formData.project_id,
          db_name: formData.db_name
        }, {
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
        });
        if ('db_names' in response.data) {
          setDbOptions(response.data.db_names);
        } else if ('table_names' in response.data) {
          setTableOptions(response.data.table_names);
        }
      } catch (error) {
        console.error('Error fetching project ids:', error);
      }
    }
  };

  const fetchTableNames = async (dbname) => {
    try {
      const response = await axios.post(`${import.meta.env.VITE_DJANGO_BASE_URL}self_serve2/SingleTableLoadTD/`, {
        DatabaseName: dbname
      }, {
        headers: {
          "Content-Type": "application/json",
        },
      });
      setTableOptionsTD(response.data.TableName.map(value => value.trim()));
    } catch (error) {
      console.error('Error fetching project ids:', error);
    }
  };

  useEffect(() => {
    fetchProjectOptions();
    fetchDbOptionsTD();
  }, []);

  useEffect(() => {
    fetchDbOptions();
  }, [formData.project_id, formData.db_name]);

  useEffect(() => {
    if (formData.db_name) {
      fetchTableNames(formData.db_name);
    }
  }, [formData.db_name]);

  const handleSubmit = (e) => {
    e.preventDefault();
    const formDataUrlEncoded = new URLSearchParams();
    for (const [key, value] of Object.entries(formData)) {
      formDataUrlEncoded.append(key, value);
    }

    axios
      .post(`${import.meta.env.VITE_DJANGO_BASE_URL}self_serve2/filter_reports/`,
        formDataUrlEncoded,
        {
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
        }
      )
      .then((response) => {
        if (response.data.filtered_reports.length === 0) {
          setDataNotFound("No such combination or files exist");
        } else {
          setResponseData(response.data.filtered_reports);
          setReportFetched(true);
        }
      })
      .catch((error) => {
        console.error(error);
      });
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };

  const resetHandler = () => {
    setDataNotFound("");
    setFormData({
      data_source: "",
      project_id: "",
      db_name: "",
      table_name: "",
      date: "",
    });
  };

  const handleDownload = (filename) => {
    axios
      .get(`${import.meta.env.VITE_DJANGO_BASE_URL}/self_serve2/download/${filename}/`)
      .then((response) => {
        console.log(response.config.url);
        window.location.href = response.config.url;
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <>
      <div className={styles.mainContent}>
        <Container fluid>
          <Container
            fluid
            className="mx-8 px-8 mb-2"
            style={{ display: reportfetched === false ? "block" : "none" }}
          >
            <Form onSubmit={handleSubmit} className="m-10">
              <Row className="justify-content-center align-items-center">
                <Col xl={3}>
                  <fieldset disabled={loading}>
                    <Form.Group className="mb-2" controlId="ControlInput1">
                      <FormControl fullWidth>
                        <InputLabel id="select-label">Environment</InputLabel>
                        <Select
                          labelId="select-label"
                          id="select"
                          value={formData.data_source}
                          label="Environment"
                          onChange={handleChange}
                          name="data_source"
                          size="small"
                          required
                        >
                          <MenuItem value="TD">TeraData</MenuItem>
                          <MenuItem value="GCP">GCP</MenuItem>
                        </Select>
                      </FormControl>
                    </Form.Group>

                    <Form.Group className="mb-2" controlId="ControlInput2" style={{ display: formData.data_source === "GCP" ? "block" : "none" }}>
                      <Autocomplete
                        options={projectOptions || []}
                        autoHighlight
                        fullWidth
                        size="small"
                        name="project_id"
                        value={formData.project_id}
                        required
                        isOptionEqualToValue={(option, value) => option.id === value.id}
                        onChange={(_, value) => setFormData((prev) => ({ ...prev, project_id: value }))}
                        renderInput={(params) => <TextField {...params} label="Project" variant="outlined" />}
                      />
                    </Form.Group>

                    <Form.Group className="mb-2" controlId="ControlInput3">
                      <Autocomplete
                        style={{ display: formData.data_source === "TD" ? "block" : "none" }}
                        options={dbOptionsTD || []}
                        autoHighlight
                        fullWidth
                        size="small"
                        name="db_name"
                        value={formData.db_name}
                        required
                        isOptionEqualToValue={(option, value) => option.id === value.id}
                        onChange={(_, value) => setFormData((prev) => ({ ...prev, db_name: value }))}
                        renderInput={(params) => <TextField {...params} label="DB Name" variant="outlined" />}
                      />
                      <Autocomplete
                        style={{ display: formData.data_source === "GCP" ? "block" : "none" }}
                        options={dbOptions || []}
                        autoHighlight
                        fullWidth
                        size="small"
                        name="db_name"
                        value={formData.db_name}
                        required
                        isOptionEqualToValue={(option, value) => option.id === value.id}
                        onChange={(_, value) => setFormData((prev) => ({ ...prev, db_name: value }))}
                        renderInput={(params) => <TextField {...params} label="DB Name" variant="outlined" />}
                      />
                    </Form.Group>

                    <Form.Group className="mb-2" controlId="ControlInput4">
                      <Autocomplete
                        style={{ display: formData.data_source === "TD" ? "block" : "none" }}
                        options={tableOptionsTD || []}
                        value={formData.table_name}
                        required
                        name='table_name'
                        autoHighlight
                        fullWidth
                        size="small"
                        isOptionEqualToValue={(option, value) => option.id === value.id}
                        onChange={(_, value) => setFormData((prev) => ({ ...prev, table_name: value }))}
                        renderInput={(params) => <TextField {...params} label="Table Name" variant="outlined" />}
                      />
                      <Autocomplete
                        style={{ display: formData.data_source === "GCP" ? "block" : "none" }}
                        options={tableOptions || []}
                        value={formData.table_name}
                        required
                        name='table_name'
                        autoHighlight
                        fullWidth
                        size="small"
                        isOptionEqualToValue={(option, value) => option.id === value.id}
                        onChange={(_, value) => setFormData((prev) => ({ ...prev, table_name: value }))}
                        renderInput={(params) => <TextField {...params} label="Table Name" variant="outlined" />}
                      />
                    </Form.Group>

                    <Form.Group className="" controlId="ControlInput5">
                      <Form.Control
                        type="date"
                        value={formData.date}
                        name="date"
                        onChange={handleChange}
                        placeholder="Date"
                      />
                    </Form.Group>
                    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', margin: "10px 0",gap: "10px" }}>
                      <Button use="secondary" onClick={resetHandler}>
                        Reset
                      </Button>
                      <Button type="submit">
                        Submit
                      </Button>
                    </div>
                  </fieldset>
                </Col>
              </Row>
            </Form>
          </Container>
          <Container
            fluid
            className=""
            style={{ display: reportfetched === true ? "block" : "none" }}
          >
            <Form onSubmit={handleSubmit}>
              <Row className="justify-content-center align-items-left">
                <Col xs={2}>
                  <TextField
                    id="outlined-required"
                    label="DataSource"
                    name="data_source"
                    value={formData.data_source}
                    onChange={handleChange}
                    className=""
                    style={{ width: "100%" }}
                    size="small"
                  />
                </Col>
                <Col
                  xs={2}
                  style={{
                    display: formData.data_source === "GCP" ? "block" : "none",
                  }}
                >
                  <TextField
                    id="outlined-required"
                    label="Project ID"
                    name="project_id"
                    value={formData.project_id}
                    onChange={handleChange}
                    style={{ width: "100%" }}
                    size="small"
                  />
                </Col>
                <Col xs={2}>
                  <TextField
                    id="outlined-required"
                    label="DB Name"
                    name="db_name"
                    value={formData.db_name}
                    onChange={handleChange}
                    style={{ width: "100%" }}
                    size="small"
                  />
                </Col>
                <Col xs={2}>
                  <TextField
                    id="outlined-required"
                    label="Table Name"
                    name="table_name"
                    value={formData.table_name}
                    onChange={handleChange}
                    style={{ width: "100%" }}
                    size="small"
                  />
                </Col>
                <Col xs={2}>
                  <Form.Group className="" controlId="ControlInput5">
                    <Form.Control
                      type="date"
                      value={formData.date}
                      name="date"
                      onChange={handleChange}
                      placeholder="Date"
                    />
                  </Form.Group>
                </Col>
                <Col xs={1}>
                  <Button use="secondary" onClick={resetHandler}>
                    Reset
                  </Button>
                </Col>
                <Col xs={1}>
                  <Button type="submit">
                    Submit
                  </Button>
                </Col>
              </Row>
            </Form>
          </Container>
        </Container>

        {responseData.length > 0 ? (
          <Container fluid className="">
            <Container className="d-flex justify-content-center my-2">
              <h5 className="m-2 text-danger fw-bold">Data Profile Report</h5>
            </Container>
            <Paper sx={{ width: "100%", overflow: "hidden" }}>
              <TableContainer sx={{ maxHeight: 500 }}>
                <Table stickyHeader aria-label="sticky table">
                  <TableHead>
                    <TableRow>
                      <TableCell
                        style={{
                          width: "auto",
                          border: "1px solid white",
                          fontWeight: "bold",
                        }}
                        className="bg-dark text-white text-center"
                      >
                        Database
                      </TableCell>
                      <TableCell
                        style={{
                          width: "auto",
                          border: "1px solid white",
                          fontWeight: "bold",
                        }}
                        className="bg-dark text-white text-center"
                      >
                        Table Name
                      </TableCell>
                      <TableCell
                        style={{
                          width: "auto",
                          border: "1px solid white",
                          fontWeight: "bold",
                        }}
                        className="bg-dark text-white text-center"
                      >
                        Download HTML File
                      </TableCell>
                      <TableCell
                        style={{
                          width: "auto",
                          border: "1px solid white",
                          fontWeight: "bold",
                        }}
                        className="bg-dark text-white text-center"
                      >
                        Date
                      </TableCell>
                    </TableRow>
                  </TableHead>

                  <TableBody>
                    {responseData
                      .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                      .map((filtered_reports, index) => (
                        <TableRow key={index} hover>
                          <TableCell className="fw-bold">
                            {filtered_reports.db_name}
                          </TableCell>
                          <TableCell className="fw-bold">
                            {filtered_reports.table_name}
                          </TableCell>
                          <TableCell>
                            <a
                              onClick={() =>
                                handleDownload(filtered_reports.filename)
                              }
                              href="#!"
                            >
                              {filtered_reports.filename}
                            </a>
                          </TableCell>
                          <TableCell className="fw-bold">
                            {filtered_reports.timestamp.slice(0, 10)}
                          </TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              </TableContainer>
              <TablePagination
                rowsPerPageOptions={[10, 20, 30, 40, 50, 100]}
                component="div"
                count={responseData.length}
                rowsPerPage={rowsPerPage}
                page={page}
                onPageChange={handleChangePage}
                onRowsPerPageChange={handleChangeRowsPerPage}
              />
            </Paper>
          </Container>
        ) : (
          <div className="d-flex justify-content-center m-2 blink">
            <h5>{dataNotFound}</h5>
          </div>
        )}
      </div>
    </>
  );
};

export default DownloadReports;