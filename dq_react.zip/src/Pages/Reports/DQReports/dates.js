export function yesterday() {
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(today.getDate() - 1);
    const formattedDate = `${String(yesterday.getMonth() + 1).padStart(2, "0")}/${String(yesterday.getDate()).padStart(2, "0")}`;
    return [formattedDate];
}

export function getLast7Days() {
    const dates = [];
    const today = new Date();

    for (let i = 1; i <= 7; i++) {
        const date = new Date(today);
        date.setDate(today.getDate() - i);
        const formattedDate = `${String(date.getMonth() + 1).padStart(2, "0")}/${String(date.getDate()).padStart(2, "0")}`;
        dates.push(formattedDate);
    }
    return dates.reverse();
}

export function getLast14Days() {
    const dates = [];
    const today = new Date();

    for (let i = 1; i <= 14; i++) {
        const date = new Date(today);
        date.setDate(today.getDate() - i);
        const formattedDate = `${String(date.getMonth() + 1).padStart(2, "0")}/${String(date.getDate()).padStart(2, "0")}`;
        dates.push(formattedDate);
    }

    return dates.reverse();
}

export function getLast30Days() {
    const dates = [];
    const today = new Date();

    for (let i = 1; i <= 30; i++) {
        const date = new Date(today);
        date.setDate(today.getDate() - i);
        const formattedDate = `${String(date.getMonth() + 1).padStart(2, "0")}/${String(date.getDate()).padStart(2, "0")}`;
        dates.push(formattedDate);
    }

    return dates.reverse();
}

export function getLast90Days() {
    const dates = [];
    const today = new Date();

    for (let i = 1; i <= 90; i++) {
        const date = new Date(today);
        date.setDate(today.getDate() - i);
        const formattedDate = `${String(date.getMonth() + 1).padStart(2, "0")}/${String(date.getDate()).padStart(2, "0")}`;
        dates.push(formattedDate);
    }

    return dates.reverse();
}