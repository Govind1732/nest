import React, { useState, useEffect, useRef } from "react";
import CircularProgress from "@mui/material/CircularProgress";
import Backdrop from "@mui/material/Backdrop";
import CompletenessIcon from "../../../assets/images/icons/checkmark-alt_blk 1.svg";
import UniquenessIcon from "../../../assets/images/icons/Medal_blk 1.svg";
import TimelinessIcon from "../../../assets/images/icons/real-time_blk 1.svg";
import ConsistencyIcon from "../../../assets/images/icons/grid-view_blk 1.svg";
import ValidityIcon from "../../../assets/images/icons/insurance_blk 1.svg";
import ConfirmityIcon from "../../../assets/images/icons/thumbs-up_blk 1.svg";
import styles from "./DQReport.module.css";
import { Loader } from "@vds/core";
import { useSelector, useDispatch } from "react-redux";
import {
  usePostTableWiseDataMutation,
  useGetProductTypeWiseDataQuery,
} from "../../../features/api/nodeapiSlice";
import {
  setDashboardView,
  setDataProductsView,
  setTableLevelAssetsView,
} from "../../../features/DQReport/dqReportActions.js";

const DQReportDataProducts = () => {
  const dispatch = useDispatch();
  const {
    data: productTypeWiseData = [],
    isLoading: productTypeWiseDataLoading,
  } = useGetProductTypeWiseDataQuery();
  const [selectedProductType, setSelectedProductType] = useState("");
  const [tableWiseData, setTableWiseData] = useState([]);
  const [postTableWiseData, { isLoading: ispostTableWiseDataLoading }] =
    usePostTableWiseDataMutation();
  const metricIcons = {
    tbl_completeness: CompletenessIcon,
    tbl_uniqueness: UniquenessIcon,
    tbl_timeliness: TimelinessIcon,
    tbl_consistency: ConsistencyIcon,
    tbl_validity: ValidityIcon,
    tbl_conformity: ConfirmityIcon,
  };

  useEffect(() => {
    setTableWiseData([]);
  }, [productTypeWiseData]);

  const AssetTableHandler = async (asset) => {
    try {
      const res = await postTableWiseData({ product_type: asset });
      setTableWiseData(res.data);
      setSelectedProductType(res.data[0]?.product_type);
    } catch (err) {
      console.log(err);
    }
  };
  const scoreFields = [
    { key: "TBL_COMPLETENESS", label: "Completeness" },
    { key: "TBL_TIMELINESS", label: "Timeliness" },
    { key: "TBL_UNIQUENESS", label: "Uniqueness" },
    { key: "tbl_conformity", label: "Conformity" },
    { key: "tbl_validity", label: "Validity" },
    { key: "tbl_consistency", label: "Consistency" },
    { key: "OVERALL_DQ_SCORE", label: "Overall DQ" },
  ];
  const scoreFields2 = [
    { key: "TBL_COMPLETENESS", label: "Completeness" },
    { key: "TBL_TIMELINESS", label: "Timeliness" },
    { key: "TBL_UNIQUENESS", label: "Uniqueness" },
    { key: "tbl_conformity", label: "Conformity" },
    { key: "tbl_consistency", label: "Consistency" },
    { key: "tbl_validity", label: "Validity" },
    { key: "OVERALL_DQ_SCORE", label: "Overall DQ" },
  ];
  const Row = ({ row, index }) => {
    const getColorAndTextColorForScore = (score) => {
      if (score > 90)
        return {
          color: "var(--vds-color-feedback-success)",
          textColor: "var(--stroke-color-success)",
        };
      if (score > 80)
        return {
          color: "var(--vds-color-feedback-warning)",
          textColor: "var(--stroke-color-medium)",
        };
      return {
        color: "var(--vds-color-feedback-error)",
        textColor: "var(--stroke-color-low)",
      };
    };

    return "SRC_TBL" in row ? (
      <tr className={index % 2 === 0 ? styles.evenRow : styles.oddRow}>
        <td align="center" className={styles.tableData}>
          {row?.SRC_TBL}
        </td>
        <td align="center" className={styles.tableData}>
          {row?.max_run_date?.value}
        </td>
        {scoreFields2.map(({ key }) => {
          const { textColor } = getColorAndTextColorForScore(row[key]);
          return (
            <td
              key={key}
              align="center"
              style={{ color: textColor }}
              className={styles.tableData}
            >
              {row[key] !== null ? parseFloat(row[key]).toFixed(2) : "N/A"}
            </td>
          );
        })}
      </tr>
    ) : (
      <tr className={index % 2 === 0 ? styles.evenRow : styles.oddRow}>
        <td align="center" className={styles.tableData}>
          {row?.product_type}
        </td>
        <td
          align="center"
          style={{ cursor: "pointer", ":hover": { backgroundColor: "red" } }}
          className={styles.tableData}
          onClick={() => {
            console.log(row?.product_type);
            AssetTableHandler(row?.product_type);
            dispatch(setDashboardView(false));
            dispatch(setDataProductsView(false));
            dispatch(setTableLevelAssetsView(true));
          }}
        >
          {row?.no_of_assets}
        </td>
        {scoreFields.map(({ key, label }) => {
          const { textColor } = getColorAndTextColorForScore(row[key]);
          return (
            <td
              key={key}
              align="center"
              style={{ color: textColor }}
              className={styles.tableData}
            >
              {parseFloat(row[key]).toFixed(2)}
            </td>
          );
        })}
      </tr>
    );
  };
  const dataProductsView = useSelector(
    (state) => state.dqReport.dataProductsView
  );
  //   const dashboardView = useSelector((state) => state.dqReport.dashboardView);
  const tableLevelAssetsView = useSelector(
    (state) => state.dqReport.tableLevelAssetsView
  );
  const startDate = useSelector((state) => state.dqReport.startDate);
  const endDate = useSelector((state) => state.dqReport.endDate);

  return (
    <>
      <div className={styles.mainContent}>
        {dataProductsView && productTypeWiseData && (
          <div>
            <div className="">
              <h6 className="heading-content">
                <strong>
                  <u
                    style={{
                      textDecorationColor: "red",
                      textDecorationThickness: "2px",
                    }}
                  >
                    Data Quality Summary at Product Level from {startDate} To{" "}
                    {endDate}
                  </u>
                </strong>
              </h6>
            </div>

            <div>
              <div>
                <table
                  className={styles.tableContainer}
                  style={{ width: "100%", borderCollapse: "collapse" }}
                >
                  <thead
                    style={{
                      position: "sticky",
                      top: 0,
                      backgroundColor: "#fff",
                      zIndex: 1,
                    }}
                  >
                    <tr>
                      {Object.keys(productTypeWiseData[0] || {})
                        .filter(
                          (header) =>
                            header !== "tbl_integrity" &&
                            header !== "OVERALL_DQ_SCORE"
                        )
                        .map((columnName, index) => (
                          <th key={index} className={styles.tableHeader}>
                            <div className={styles.tableColumnHeader}>
                              <div>
                                {metricIcons[columnName.toLowerCase()] ? (
                                  <picture className={styles.metricIcon}>
                                    <img
                                      src={
                                        metricIcons[columnName.toLowerCase()]
                                      }
                                      alt={columnName}
                                      style={{
                                        width: "30px",
                                        height: "30px",
                                      }}
                                    />
                                  </picture>
                                ) : null}
                              </div>
                              <div className={styles.columnHeader}>
                                {columnName
                                  .replace(/^(tbl|TBL)_/, "")
                                  .replaceAll("_", " ")
                                  .toUpperCase()}
                              </div>
                            </div>
                          </th>
                        ))}
                      <th className={styles.overallScoreHeader}>
                        OVERALL
                        <br />
                        DQ SCORE
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {productTypeWiseData.map((row, index) => (
                      <Row
                        textalign="center"
                        key={index}
                        row={row}
                        index={index}
                      />
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
        {tableLevelAssetsView && tableWiseData.length > 0 && (
          <>
            <div>
              <h6
                className="heading-content"
                style={{ align: "left", marginLeft: "50px" }}
              >
                <strong>
                  <u
                    style={{
                      textDecorationColor: "red",
                      textDecorationThickness: "2px",
                    }}
                  >
                    Data Quality Summary at Table Level for{" "}
                    {selectedProductType} from {startDate} To {endDate}
                  </u>
                </strong>
              </h6>
            </div>
            <div>
              <table
                className={styles.tableContainer}
                style={{ width: "100%", borderCollapse: "collapse" }}
              >
                <thead
                  style={{
                    position: "sticky",
                    top: 0,
                    backgroundColor: "#fff",
                    zIndex: 1,
                  }}
                >
                  <tr>
                    {Object.keys(tableWiseData[0] || {})
                      .filter(
                        (header) =>
                          header !== "product_type" &&
                          header !== "tbl_integrity" &&
                          header !== "OVERALL_DQ_SCORE"
                      )
                      .map((columnName, index) => (
                        <th key={index} className={styles.tableHeader}>
                          <div className={styles.tableColumnHeader}>
                            <div>
                              {metricIcons[columnName.toLowerCase()] ? (
                                <picture className={styles.metricIcon}>
                                  <img
                                    src={metricIcons[columnName.toLowerCase()]}
                                    alt={columnName}
                                    style={{ width: "30px", height: "30px" }}
                                  />
                                </picture>
                              ) : null}
                            </div>
                            <div className={styles.columnHeader}>
                              {columnName
                                .replace(/^(tbl|TBL)_/, "")
                                .replaceAll("_", " ")
                                .toUpperCase()}
                            </div>
                          </div>
                        </th>
                      ))}
                    <th className={styles.overallScoreHeader}>
                      OVERALL
                      <br />
                      DQ SCORE
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {tableWiseData.map((row, index) => (
                    <Row
                      textalign="center"
                      key={index}
                      row={row}
                      index={index}
                    />
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>
      {(productTypeWiseDataLoading || ispostTableWiseDataLoading) && (
        <Loader fullscreen={true} active={true} surface="light" />
      )}
    </>
  );
};

export default DQReportDataProducts;
