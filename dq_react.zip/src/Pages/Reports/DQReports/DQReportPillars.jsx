import { useState, useEffect } from "react";
import { useSelector } from 'react-redux';
import styles from './DQReport.module.css';
import { useGetDefaultEnterpriseDataQuery, useGetDefaultLobWiseDataQuery } from '../../../features/api/nodeapiSlice.js';
import CompletenessIcon from "../../../assets/images/icons/checkmark-alt_blk 1.svg";
import UniquenessIcon from "../../../assets/images/icons/Medal_blk 1.svg";
import TimelinessIcon from "../../../assets/images/icons/real-time_blk 1.svg";
import ConsistencyIcon from "../../../assets/images/icons/grid-view_blk 1.svg";
import ValidityIcon from "../../../assets/images/icons/insurance_blk 1.svg";
import ConfirmityIcon from "../../../assets/images/icons/thumbs-up_blk 1.svg";
import { Title, Body, Modal, ModalTitle, ModalBody, ModalFooter } from "@vds/core";
import Skeleton from '@mui/material/Skeleton';
import truncateDecimal from '../../../utils/truncateDecimal.js';
import Radialbar from './Radialbar.jsx';
import {
    strokeColorHigh,
    strokeColorMedium,
    strokeColorLow,
} from '../../../utils/colors';

const DQDomainLevelReportPillars = () => {
    const { data: enterpriseData = [], isLoading: enterpriseDataLoading } = useGetDefaultEnterpriseDataQuery();
    const { data: lobWiseData = [], isLoading: lobWiseDataLoading } = useGetDefaultLobWiseDataQuery();
    const [lobVisible, setLobVisible] = useState(false);

    const metricIcons = {
        completeness: CompletenessIcon,
        uniqueness: UniquenessIcon,
        timeliness: TimelinessIcon,
        consistency: ConsistencyIcon,
        validity: ValidityIcon,
        conformity: ConfirmityIcon,
    };
    const enterpriseClickHandler = () => {
        setLobVisible(!lobVisible);
    }

    const ScoreItem = ({ product, pillar, scoreValue }) => {
        scoreValue = +scoreValue;
        const backgroundColor = scoreValue > 90 ? 'var(--vds-color-feedback-success)' : scoreValue > 80 ? 'var(--vds-color-feedback-warning)' : 'var(--vds-color-feedback-error)';
        const color = scoreValue > 90 ? 'var(--stroke-color-success)' : scoreValue > 80 ? 'var(--stroke-color-medium)' : 'var(--stroke-color-low)';
        let dqpillar = pillar.split('_')[1].charAt(0).toUpperCase() + pillar.split('_')[1].slice(1).toLowerCase();
        return (
            <div key={`${product.product_id}-${pillar}`} className={styles.tile} style={{ backgroundColor }}>
                <picture className={styles.score_icon}>
                    <img src={metricIcons[dqpillar.toLowerCase()]} alt={`${pillar}Icon`} />
                </picture>
                <div style={{ display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", gap: '0.25em' }}>
                    <Title bold={true} color={color}>{truncateDecimal(scoreValue, 1)} %</Title>
                    <Body bold={true} size='large'>{dqpillar}</Body>
                </div>
            </div>
        );
    };
    return (
        <>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1em' }}>
                {(enterpriseDataLoading || lobWiseDataLoading) ? (
                    <div style={{ display: 'flex', gap: '1em', flex: '1' }}>
                        {[...Array(7)].map((_, index) => (
                            <Skeleton key={index} variant="rounded" width={"100%"} height={200} />
                        ))}
                    </div>
                ) : (
                    <div style={{ display: 'flex', gap: '1em' }}>
                        {(
                            enterpriseData.length > 0 &&
                            <div className={styles.tile} onClick={enterpriseClickHandler}>
                                <div className={styles.overallScore}>
                                    <Radialbar percentage={enterpriseData?.[0]?.OVERALL_DQ_SCORE} />
                                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '0.25em' }}>
                                        <Body size='large' bold={true}>Enterprise</Body>
                                        <Body bold={true}>CDA - {enterpriseData?.[0]?.no_of_assets}</Body>
                                    </div>
                                </div>
                            </div>
                        )}

                        {
                            enterpriseData.length > 0 && (
                                Object.entries(enterpriseData[0]).map(([pillar, scoreValue]) => (
                                    (pillar !== 'no_of_assets' && pillar !== 'OVERALL_DQ_SCORE' && pillar !== 'tbl_integrity') &&
                                    <ScoreItem key={`${pillar}`} product={enterpriseData[0]} pillar={pillar} scoreValue={scoreValue} />
                                ))
                            )
                        }
                    </div>
                )}
                <div className={styles.dq__lob_container} style={{ display: lobVisible ? 'flex' : 'none', gap: '0.5em' }}>
                    {lobWiseData.length > 0 && lobWiseData.map(({ lob_name, lob_dq_score, no_of_assets }) => (
                        <div className={styles.lobs__item} key={lob_name}>
                            <Radialbar percentage={lob_dq_score} />
                            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '0.25em' }}>
                                <Body size='large' bold={true}>{lob_name}</Body>
                                <Body bold={true}>CDA - {no_of_assets}</Body>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </>
    );
};

export default DQDomainLevelReportPillars;