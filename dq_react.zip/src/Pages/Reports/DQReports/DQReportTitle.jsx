// import React, { useContext, useEffect, useState } from 'react';
import { Title } from "@vds/typography"
import { Breadcrumbs,BreadcrumbItem } from "@vds/breadcrumbs"
// import { DQDomainLevelReportContext } from '../../../context/DQDomainLevelReportContext';
import styles from './DQReport.module.css';
// import { useSelector, useDispatch } from 'react-redux';
// import { setLast7days } from '../../../features/DQDomainLevelReport/dqDomainLevelReportActions';

const DQDomainLevelReportTitle = () => {
    // const [reportDates, setReportDates] = useState({
    //     todayDate: "",
    //     startDate: "",
    //     endDate: ""
    // });
    // const dispatch = useDispatch();
    // const { setLast7days } = useContext(DQDomainLevelReportContext);


    // useEffect(() => {
    //     const today = new Date();
    //     const dates = [];
    //     const mmDates = [];

    //     for (let i = 1; i <= 7; i++) {
    //         const date = new Date(today);
    //         date.setDate(today.getDate() - i);
    //         dates.push(date.toISOString().split('T')[0].replace(/-/g, '/'));
    //         mmDates.push(`${String(date.getMonth() + 1).padStart(2, "0")}/${String(date.getDate()).padStart(2, "0")}/${date.getFullYear()}`);
    //     }

    //     dispatch(setLast7days(dates));
    //     setReportDates({
    //         todayDate: today.toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" }),
    //         startDate: mmDates[mmDates.length - 1],
    //         endDate: mmDates[0]
    //     });
    // }, [dispatch]);
    return (
        <>
            <div className={styles.subHeadingText}>
                <Title
                    size="medium"
                    bold={true}
                    color="#000">
                    DQ Report
                </Title>
                {/* <div className={styles.dot}></div>
                <div>
                    {reportDates.startDate} - {reportDates.endDate}
                </div> */}
            </div>
            <Breadcrumbs surface="light">
                <BreadcrumbItem>Reporting</BreadcrumbItem>
                <BreadcrumbItem>DQ Report</BreadcrumbItem>
            </Breadcrumbs>
        </>
    )
}
export default DQDomainLevelReportTitle;