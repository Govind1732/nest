import { useState, useEffect } from "react";
import { Body, Title } from "@vds/typography";
import { TextLink } from "@vds/buttons";
import Download from "@vds/icons/download";
import _ from "lodash";
// import NestedGauge from './NestedGauge';
import { useSelector, useDispatch } from "react-redux";
import PropTypes from "prop-types";
import styles from "./DQReport.module.css";
import DQReportTitle from "./DQReportTitle.jsx";
import DQReportPillars from "./DQReportPillars.jsx";
import GraphLoader from "../../../Components/LayoutComponents/GraphLoader";
import {
  useGetDQTrendQuery,
  useGetProductTypeWiseDataQuery,
} from "../../../features/api/nodeapiSlice.js";
import Legend from "../DQDomainLevelReport/Legend.jsx";
import Filters from "../DQReports/Filters.jsx";
import DQBarchart from "./DQBarchart.jsx";
import DQLinechart from "./DQLinechart.jsx";
import FilteredReportTable from "./FilteredReportTable.jsx";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";
import {
  setDashboardView,
  setDataProductsView,
  setTableLevelAssetsView,
} from "../../../features/DQReport/dqReportActions.js";
// import DQReportTableLevelAssets from "./DQReportTableLevelAssets.jsx";
import DQReportDataProducts from "./DQReportDataProducts";

const DQReports = () => {
  const dispatch = useDispatch();
  const { data: dqTrend, isLoading: dqTrendLoading } = useGetDQTrendQuery();
  const {
    data: productTypeWiseData = [],
    isLoading: productTypeWiseDataLoading,
  } = useGetProductTypeWiseDataQuery();
  const dashboardView = useSelector((state) => state.dqReport.dashboardView);
  const dataProductsView = useSelector(
    (state) => state.dqReport.dataProductsView
  );
  const tableLevelAssetsView = useSelector(
    (state) => state.dqReport.tableLevelAssetsView
  );
  //   const showAllColumns = useSelector((state) => state.dqReport.showAllColumns);
  const label = useSelector((state) => state.dqReport.selectedLabel);
  const [trendData, setTrendData] = useState([]);
  // const [radialAndChartsVisible, setRadialAndChartsVisible] = useState(true);
  // const [productWiseDataVisible, setProductWiseDataVisible] = useState(true);
  // const [tableWiseDataVisible, setTableWiseDataVisible] = useState(false);

  useEffect(() => {
    if (dqTrend) {
      setTrendData(dqTrend?.trend_line);
    }
  }, [dqTrend, trendData]);

  const handleDownloadPDF = () => {
    const element = document.querySelector(`.${styles.content}`);
    // const sidebar = document.querySelector(`.${styles.sidebar}`);
    if (!element) {
      return;
    }
    // Hide the sidebar
    // if (sidebar) {
    //     sidebar.style.display = 'none';
    // }
    const icons = element.querySelectorAll(`.${styles.pdf}`);
    icons.forEach((icon) => (icon.style.display = "none"));
    html2canvas(element, { scale: 2 }).then((canvas) => {
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF({
        orientation: "l", // landscape
        unit: "mm",
        format: "a4",
      });

      // Define margins
      const margin = 2; // in mm
      const pdfWidth = pdf.internal.pageSize.getWidth() - 2 * margin;
      const pdfHeight = pdf.internal.pageSize.getHeight() - 2 * margin;

      // Adjust image dimensions to maintain aspect ratio
      const imgProps = pdf.getImageProperties(imgData);
      const imgWidth = imgProps.width;
      const imgHeight = imgProps.height;
      let finalImgWidth, finalImgHeight;

      // Calculate final image dimensions based on aspect ratio
      if (imgWidth / imgHeight > pdfWidth / pdfHeight) {
        finalImgWidth = pdfWidth;
        finalImgHeight = (imgHeight * pdfWidth) / imgWidth;
      } else {
        finalImgHeight = pdfHeight;
        finalImgWidth = (imgWidth * pdfHeight) / imgHeight;
      }

      // Calculate position to center the image
      const imgX = margin + (pdfWidth - finalImgWidth) / 2;
      const imgY = margin + (pdfHeight - finalImgHeight) / 2;

      pdf.addImage(imgData, "PNG", imgX, imgY, finalImgWidth, finalImgHeight);
      pdf.save("DQ Report.pdf");
      // Restore hidden elements after PDF generation
      // icons.forEach(icon => icon.style.display = '');
      // if (sidebar) {
      //     sidebar.style.display = '';
      // }
    });
  };

  const entireScoreHandler = () => {
    dispatch(setDashboardView(false));
    dispatch(setDataProductsView(true));
    dispatch(setTableLevelAssetsView(false));
  };

  return (
    <>
      <div className={styles.section}>
        <div className={styles.subHeading}>
          <DQReportTitle />
        </div>
        <div className={styles.content}>
          <div className={styles.sidebar}>
            <Filters />
          </div>
          <div className={styles.subContent}>
            <div className={styles.sub_title}>
              <div>
                <span className={styles.product_title}>
                  <span
                    style={{ cursor: "pointer" }}
                    className={
                      dashboardView ? styles.bold : styles.normal
                    }
                    onClick={() => {
                      dispatch(setDashboardView(true));
                      dispatch(setDataProductsView(false));
                      dispatch(setTableLevelAssetsView(false));
                    }}
                  >
                    DQ Reports
                  </span>
                  {(dataProductsView || tableLevelAssetsView) && (
                    <span
                      className={
                        dataProductsView ? styles.bold : styles.normal
                      }
                      style={{
                        fontWeight: dataProductsView
                          ? "bolder"
                          : "normal",
                        cursor: "pointer",
                      }}
                      onClick={() => {
                        dispatch(setDashboardView(false));
                        dispatch(setDataProductsView(true));
                        dispatch(setTableLevelAssetsView(false));
                      }}
                    >
                      {" "}
                      / All Data Products
                    </span>
                  )}
                  {tableLevelAssetsView && (
                    <span
                      className={
                        tableLevelAssetsView ? styles.bold : styles.normal
                      }
                    >
                      {" "}
                      / Table Level Assets
                    </span>
                  )}
                </span>
              </div>
              <div className={styles.colors}>
                <Legend />
                <div className={styles.pdf} onClick={handleDownloadPDF}>
                  <Download color="#000000" size="medium" />
                  <TextLink type="standAlone" surface="light" disabled={false}>
                    Download PDF
                  </TextLink>
                </div>
              </div>
            </div>
            <div className={styles.sub_body}>
              <div
                className={styles.dashboard}
                style={
                  dashboardView ? { display: "block" } : { display: "none" }
                }
              >
                <div className={styles.pillarContainer}>
                  <DQReportPillars />
                </div>

                <div className={styles.cards}>
                  <div className={styles.allTablesCard}>
                    <div
                      className={styles.cardTitle}
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        marginInline: "10%",
                      }}
                    >
                      <Title size="small" bold={true} color="#000000">
                        DQ Score Tables
                      </Title>
                      <div
                        style={{ cursor: "pointer" }}
                        onClick={entireScoreHandler}
                      >
                        All Data Products
                      </div>
                    </div>

                    <div className={styles.cardBody}>
                      {productTypeWiseDataLoading ? (
                        <GraphLoader />
                      ) : productTypeWiseData.length > 0 ? (
                        <DQBarchart productTypeWiseData={productTypeWiseData} />
                      ) : (
                        <div
                          className={styles.noData}
                          style={{
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                            height: "100%",
                          }}
                        >
                          <Body size="large" bold={true}>
                            No Data Available
                          </Body>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className={styles.last7daysCard}>
                    <div className={styles.cardTitle}>
                      <Title size="small" bold={true} color="#000000">
                        DQ Score Trend
                      </Title>
                    </div>
                    <div className={styles.cardBody}>
                      {dqTrendLoading ? (
                        <GraphLoader />
                      ) : dqTrend?.trend_line.length > 0 ? (
                        <DQLinechart trendData={trendData} />
                      ) : (
                        <div
                          className={styles.noData}
                          style={{
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                            height: "100%",
                          }}
                        >
                          <Body size="large" bold={true}>
                            No Data Available
                          </Body>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                <div>
                  {label && (
                    <FilteredReportTable
                      productTypeWiseData={productTypeWiseData}
                      label={label}
                    />
                  )}
                </div>
              </div>
              <div
                style={{
                  display: dataProductsView || tableLevelAssetsView ? "flex" : "none",
                }}
                className={styles.dataProductsView}
              >
                <DQReportDataProducts />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
export default DQReports;
