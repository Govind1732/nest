import React, { useRef, useCallback, useEffect, useState, useMemo } from 'react'
import styles from './DQReport.module.css';
import Chart from "chart.js/auto";
import {
    strokeColorHigh,
    strokeColorMedium,
    strokeColorLow,
    vdsColorHigh,
    vdsColorMedium,
    vdsColorLow
} from '../../../utils/colors';
import truncateDecimal from '../../../utils/truncateDecimal';
import { useDispatch,useSelector } from 'react-redux';
import { setSelectedLabel } from '../../../features/DQReport/dqReportActions';

const DQBarchart = React.memo(({ productTypeWiseData }) => {
    const dispatch = useDispatch();
    const selectedLabel = useSelector((state) => state.dqReport.selectedLabel);
    const [sortedTables, setSortedTables] = useState([]);
    const [labelLength, setLabelLength] = useState(0);

    const barChartRef = useRef(null);
    const allTablesstaticbarChartRef = useRef(null);

    const wrapLabel = useCallback((label) => {
        const maxLength = 10;
        if (label) {
            label = label.length > maxLength ? label.match(new RegExp('.{1,' + maxLength + '}', 'g')) : label;
            setLabelLength(prev => Math.max(prev, label.length));
        }
        return label;
    }, []);

    const handleChartClick = useCallback((event, elements, chart) => {
        if (elements.length > 0) {
            const clickedLabel = chart.data.labels[elements[0].index];
            if (clickedLabel === selectedLabel) {
                dispatch(setSelectedLabel(null));
            } else {
                dispatch(setSelectedLabel(clickedLabel));
            }
        }
    }, [dispatch, selectedLabel]);

    const handleChartHover = useCallback((event, elements) => {
        event.native.target.style.cursor = elements.length > 0 ? 'pointer' : 'default';
    }, []);

    const getColor = useCallback((value) => {
        if (value > 90) return { bg: vdsColorHigh, border: strokeColorHigh };
        if (value > 80) return { bg: vdsColorMedium, border: strokeColorMedium };
        return { bg: vdsColorLow, border: strokeColorLow };
    }, []);

    const axisConfig = useMemo(() => ({
        x: {
            display: false,
            grid: { display: false, drawTricks: false, drawBroder: false },
            ticks: { display: false },
        },
        y: {
            display: true,
            grid: { display: false },
            ticks: {
                color: "#6F7171",
                callback: (index) => wrapLabel(sortedTables[index]?.product_type),
                font: (context) => {
                    const label = sortedTables[context.index]?.product_type || '';
                    return { size: Math.max(9, 18 - label.length) };
                },
            },
            beginAtZero: true,
            border: { color: "#000" },
        },
        xBarStatic: {
            display: true,
            grid: { display: false },
            ticks: {
                font: { size: 14 },
                color: "#6F7171",
                stepSize: 10,
                min: 0,
                max: 100,
                callback: (value) => `${value}%`,
            },
            border: { color: "#000" },
        },
        yBarStatic: {
            display: false,
            grid: { display: false },
        },
    }), [sortedTables, wrapLabel]);

    useEffect(() => {
        if (productTypeWiseData.length > 0) {
            setSortedTables([...productTypeWiseData].sort((a, b) => parseFloat(a.OVERALL_DQ_SCORE) - parseFloat(b.OVERALL_DQ_SCORE)));
        }
    }, [productTypeWiseData]);

    
    const chartConfig = useMemo(() => ({
        type: "bar",
        data: {
            labels: sortedTables.map((table) => table['product_type']),
            datasets: [{
                label: "DQ Score",
                data: sortedTables.map((table) => table['OVERALL_DQ_SCORE']),
                backgroundColor: (context) => getColor(context.raw).bg,
                borderColor: (context) => getColor(context.raw).border,
                borderWidth: { top: 1, right: 1, bottom: 1, left: 0 },
                barThickness: 30,
                borderRadius: { topRight: 5, bottomRight: 5 },
            }],
        },
        options: {
            maintainAspectRatio: false,
            indexAxis: 'y',
            plugins: {
                legend: { display: false },
                tooltip: {
                    bodyFont: { size: 14 },
                    padding: 10,
                    boxPadding: 10,
                },
                datalabels: {
                    color: '#000',
                    font: { size: 14 },
                    anchor: 'end',
                    align: 'right',
                    formatter: (value) => `${value}%`,
                },
            },
            // layout: { padding: { right: 11 } },
            scales: {
                x: { ...axisConfig.x },
                y: axisConfig.y,
            },
            onClick: handleChartClick,
            onHover: handleChartHover,
        },
        plugins: [{
            id: "datalabels",
            afterDatasetsDraw: (chart) => {
                const ctx = chart.ctx;
                chart.data.datasets.forEach((dataset, i) => {
                    const meta = chart.getDatasetMeta(i);
                    meta.data.forEach((point, index) => {
                        const value = dataset.data[index];
                        ctx.fillStyle = "#000";
                        ctx.font = "14px Arial";
                        ctx.fillText(truncateDecimal(value,1) + "%", point.x - 60, point.y + (point.height / 10));
                    });
                });
            },
        }],
    }), [sortedTables, axisConfig, getColor, handleChartClick, handleChartHover]);

    useEffect(() => {
        const createChart = (ref, config) => {
            if (!ref.current) return;
            const ctx = ref.current.getContext('2d');
            const chart = new Chart(ctx, config);
            return () => chart.destroy();
        };

        const cleanupMainChart = createChart(barChartRef, chartConfig);
        const cleanupStaticChart = createChart(allTablesstaticbarChartRef, {
            type: "bar",
            data: {
                labels: [],
                datasets: [{ label: "DQ Score", data: sortedTables.map((table) => table['OVERALL_DQ_SCORE']) }],
            },
            options: {
                maintainAspectRatio: false,
                responsive: true,
                indexAxis: 'y',
                plugins: { legend: { display: false } },
                layout: { padding: { left: labelLength * 10, top: -30 } },
                scales: { x: axisConfig.xBarStatic, y: axisConfig.yBarStatic },
            },
        });

        return () => {
            cleanupMainChart();
            cleanupStaticChart();
        };
    }, [chartConfig, sortedTables, axisConfig, labelLength]);

    return (<>
        {/* <div className={styles.scrollBox}>
                <div className={styles.scrollBoxBody} style={{ minHeight: `${productTypeWiseData.length * 55}px` }}>
                    <canvas ref={barChartRef}></canvas>
                </div>
            </div>
            <div className={styles.staticBarchart}>
                <canvas ref={allTablesstaticbarChartRef}></canvas>
            </div> */}
        <div className={styles.barchart}>
            <div className={styles.scrollBox}>
                <div className={styles.scrollBoxBody} style={{ minHeight: `${productTypeWiseData.length * 50}px` }}>
                    <canvas ref={barChartRef}></canvas>
                </div>
            </div>
            <div className={styles.staticBarchart}>
                <canvas ref={allTablesstaticbarChartRef}></canvas>
            </div>
        </div>
    </>);
});
DQBarchart.displayName = 'DQBarchart';
export default DQBarchart;

