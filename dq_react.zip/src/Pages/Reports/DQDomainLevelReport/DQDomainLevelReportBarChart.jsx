import React, { useRef, useCallback, useEffect, useState, useMemo } from 'react'
import styles from './DQDomainLevelReport.module.css';
import Chart from "chart.js/auto";
import {
    strokeColorHigh,
    strokeColorMedium,
    strokeColorLow,
    vdsColorHigh,
    vdsColorMedium,
    vdsColorLow
} from '../../../utils/colors';
import { Title } from '@vds/typography';
import truncateDecimal from '../../../utils/truncateDecimal';

const DQReportBarChart = ({ dqScore }) => {
    const [sortedTables, setSortedTables] = useState([]);
    const [labelLength, setLabelLength] = useState(0);
    const barChartRef = useRef(null);

    const getColor = useCallback((value) => {
        if (value > 90) return { bg: vdsColorHigh, border: strokeColorHigh };
        if (value > 80) return { bg: vdsColorMedium, border: strokeColorMedium };
        return { bg: vdsColorLow, border: strokeColorLow };
    }, []);

    const axisConfig = useMemo(() => ({
        x: {
            display: true,
            grid: { display: false, drawTricks: false, drawBroder: false },
            ticks: { display: false },
        },
        y: {
            display: true,
            grid: { display: false },
            beginAtZero: true,
            border: { color: "#000" },
        },
    }), []);

    useEffect(() => {
        if (dqScore.length > 0) {
            const dqScoreObj = dqScore[0];
            const dqScorePG = ["Overall DQ Score", dqScoreObj["OVERALL_AVG_DQ_SCORE_PG"]];

            // Filter out the unwanted keys and sort the remaining key-value pairs
            const sortedArray = Object.entries(dqScoreObj)
                .filter(([key, value]) => key !== 'OVERALL_AVG_integrity_PG' && key !== 'OVERALL_AVG_DQ_SCORE_PG')
                .map(([key, value]) => {
                    let newKey = key.replace('OVERALL_AVG_', '').replace('_PG', '').toLowerCase();
                    newKey = newKey.charAt(0).toUpperCase() + newKey.slice(1);
                    return [newKey, value];
                })
                .sort((a, b) => parseFloat(a[1]) - parseFloat(b[1]));

            // Append the OVERALL_AVG_DQ_SCORE_PG key-value pair at the end
            sortedArray.push(dqScorePG);

            // Convert the sorted array back to an object
            const sortedObject = Object.fromEntries(sortedArray);

            setSortedTables([sortedObject]);
            setLabelLength(Object.keys(sortedObject).length);
        }
    }, [dqScore]);

    const chartConfig = useMemo(() => ({
        type: "bar",
        data: {
            labels: sortedTables.length > 0 ? Object.keys(sortedTables[0]) : [],
            datasets: [{
                label: "DQ Score",
                data: sortedTables.length > 0 ? Object.values(sortedTables[0]).map((value) => truncateDecimal(value)) : [],
                backgroundColor: (context) => getColor(context.raw).bg,
                borderColor: (context) => getColor(context.raw).border,
                borderWidth: { top: 1, right: 1, bottom: 1, left: 0 },
                barThickness: 30,
                borderRadius: { topRight: 5, bottomRight: 5 },
            }],
        },
        options: {
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    bodyFont: { size: 14 },
                    padding: 10,
                    boxPadding: 10,
                },
                datalabels: {
                    color: '#000',
                    font: { size: 14 },
                    anchor: 'end',
                    align: 'right',
                    formatter: (value) => `${value}%`,
                },
            },
            layout: { padding: { right: 11 } },
            scales: {
                x: { ...axisConfig.x },
                y: axisConfig.y,
            },
        },
        plugins: [{
            id: "datalabels",
            afterDatasetsDraw: (chart) => {
                const ctx = chart.ctx;
                chart.data.datasets.forEach((dataset, i) => {
                    const meta = chart.getDatasetMeta(i);
                    meta.data.forEach((point, index) => {
                        const value = dataset.data[index];
                        ctx.fillStyle = "#000";
                        ctx.font = "14px Arial";
                        ctx.fillText(value + "%", point.x - 60, point.y + (point.height / 10));
                    });
                });
            },
        }],
    }), [sortedTables, axisConfig, getColor]);

    useEffect(() => {
        const createChart = (ref, config) => {
            if (!ref.current) return;
            const ctx = ref.current.getContext('2d');
            const chart = new Chart(ctx, config);
            return () => chart.destroy();
        };

        const cleanupMainChart = createChart(barChartRef, chartConfig);

        return () => {
            cleanupMainChart();
        };
    }, [chartConfig]);

    return (
        <div>
            <canvas ref={barChartRef}></canvas>
        </div>
    );
};

export default DQReportBarChart;

