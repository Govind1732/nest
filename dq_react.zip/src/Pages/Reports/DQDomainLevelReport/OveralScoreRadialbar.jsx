import { useEffect, useContext } from "react";
import {
    strokeColorHigh,
    strokeColorMedium,
    strokeColorLow,
    vdsColorHigh,
    vdsColorMedium,
    vdsColorLow
} from '../../../utils/colors';
import { useSelector } from "react-redux";
import truncateDecimal from '../../../utils/truncateDecimal';
import { TileContainer } from "@vds/core";
import { DQDomainLevelReportContext } from '../../../context/DQDomainLevelReportContext';
import styles from "./DQDomainLevelReport.module.css";

const OverallScoreRadialbar = ({ productIdData, level2Scores }) => {
    const activeProduct = useSelector((state) => state.dqDomainLevelReport.activeProduct);

    const calculateAverageScore = (scores) => {
        const values = Object.entries(scores[0])
            .filter(([key, value]) => key !== 'level2_name')
            .map(([key, value]) => value);

        const sum = values.reduce((acc, val) => acc + val, 0);
        const average = truncateDecimal(sum / values.length, 1);

        return average;
    };

    // Radial Bar Chart
    function updateRadialBar(percentage) {
        const radialBar = document.querySelector(`.${styles.radial_bar}`);
        let color;

        if (percentage > 90) {
            color = strokeColorHigh;
        } else if (percentage > 80 && percentage <= 90) {
            color = strokeColorMedium;
        } else if (percentage <= 80) {
            color = strokeColorLow;
        } else {
            color = '#f6f6f6';
        }
        if (radialBar) {
            radialBar.style.background = `conic-gradient(${color} ${percentage}%, #f6f6f6 ${percentage}%)`;
            const span = radialBar.querySelector("span");
            if (span) {
                span.innerText = `${percentage}%`;
                if (percentage > 90) {
                    span.style.color = strokeColorHigh;
                } else if (percentage > 80 && percentage <= 90) {
                    span.style.color = strokeColorMedium;
                } else {
                    span.style.color = strokeColorLow;
                }
            }
        }
    }

    let activeProduct_overall_score = 0;
    if (activeProduct?.productId && !activeProduct?.L2_productId) {
        const product_id_obj = productIdData.filter(product => {
            return product?.product_id === activeProduct?.productId;
        });
        activeProduct_overall_score = truncateDecimal((Object.values(product_id_obj[0]?.['dq_score']).reduce((a, b) => parseFloat(a) + parseFloat(b), 0) / (Object.keys(product_id_obj[0]?.['dq_score']).length)), 1);
    } else if (activeProduct?.productId && activeProduct?.L2_productId) {
        activeProduct_overall_score = calculateAverageScore(level2Scores);
    } else {
        activeProduct_overall_score = 0;
    }

    useEffect(() => {
        updateRadialBar(activeProduct_overall_score);
    }, [activeProduct_overall_score]);

    return (
        <TileContainer
            padding='50px 10px'
            aspectRatio='1.5:1.5'
            width=''
            backgroundColor='#fff'
        >
            <div className={styles.overallScore}>
                <div id="radialBar" className={styles.radial_bar}>
                    <span className={styles.radialBar_score}></span>
                </div>
                <div className={styles.score_title}>Overall Score</div>
            </div>
        </TileContainer>
    );
};

export default OverallScoreRadialbar;