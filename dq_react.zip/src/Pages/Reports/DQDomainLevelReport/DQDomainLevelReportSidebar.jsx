import { useState, useEffect } from "react";
import { useDispatch, useSelector } from 'react-redux';
import {
    setActiveProduct,
    setShowAllColumns,
    setDashboardView,
} from '../../../features/DQDomainLevelReport/dqDomainLevelReportActions';
import Chevron from "../../../Components/LayoutComponents/Chevron/Chevron";
import styles from "./DQDomainLevelReport.module.css";
import truncateDecimal from '../../../utils/truncateDecimal';
import { useGetProductDataQuery, useGetL2ProductDataQuery } from '../../../features/api/nodeapiSlice.js';
import Skeleton from '@mui/material/Skeleton';

const DQDomainLevelReportSidebar = () => {
    const dispatch = useDispatch();
    const [openSections, setOpenSections] = useState({});
    const { data: productData = [], isLoading: productIdDataLoading } = useGetProductDataQuery();
    const { data: l2Data = [], isLoading: l2DataLoading } = useGetL2ProductDataQuery();
    const [productIdData, setProductIdData] = useState([]);
    const activeProduct = useSelector((state) => state.dqDomainLevelReport.activeProduct);

    useEffect(() => {
        if (productData?.length > 0) {
            const journeyDataIndex = productData.findIndex(product =>
                product.product_id === "Journey Data Product"
            );

            const sortedData = journeyDataIndex > 0
                ? [
                    productData[journeyDataIndex],
                    ...productData.slice(0, journeyDataIndex),
                    ...productData.slice(journeyDataIndex + 1)
                ]
                : productData;

            setProductIdData(sortedData);
        }
    }, [productData]);

    const L2Handler = (productId, L2_productId) => {
        if (l2Data.length > 0) {
            dispatch(setActiveProduct({ productId, L2_productId, tableName: "" }));
            dispatch(setShowAllColumns(false));
            dispatch(setDashboardView(true));
        } else {
            alert('No Level 2 data found for this product');
        }
    };

    const handleToggle = (section) => {
        setOpenSections((prevState) => ({
            ...prevState,
            [section]: !prevState[section],
        }));
    };

    return (
        <div className={styles.sidebarContainer}>
            {(productIdDataLoading || l2DataLoading) ? (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.25em', margin: '0.25em' }}>
                {[...Array(4)].map((_, index) => (
                    <Skeleton key={index} variant="rectangular" width="auto" height={40} />
                ))}
            </div>
            ) : (
                productIdData?.length > 0 && productIdData.map((section) => {
                    const overallDqScore = truncateDecimal((Object.values(section?.dq_score).reduce((a, b) => parseFloat(a) + parseFloat(b), 0) / (Object.keys(section?.dq_score).length)), 1);
                    return (
                        <div key={section?.product_id}>
                            <div
                                style={{
                                    display: "flex",
                                    justifyContent: "space-between",
                                    alignItems: "center",
                                    backgroundColor: "#F6F6F6",
                                    margin: "0.25em",
                                    padding: "0.5em",
                                }}
                            >
                                <div
                                    style={{
                                        cursor: overallDqScore > 0 ? "pointer" : "default",
                                        color: activeProduct.productId === section?.product_id ? "#EE0000" : "#000",
                                        fontWeight: activeProduct.productId === section?.product_id ? "bold" : "normal",
                                    }}
                                    className={styles.options_title}
                                    onClick={overallDqScore > 0 ? () => {
                                        dispatch(setActiveProduct({
                                            productId: section?.product_id,
                                            L2_productId: "",
                                            tableName: ""
                                        }));
                                        dispatch(setShowAllColumns(false));
                                        dispatch(setDashboardView(true));
                                    } : null}
                                >
                                    {section?.product_id}
                                </div>
                                <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "0.5em" }}>
                                    {overallDqScore > 0 && (
                                        <div
                                            style={{
                                                borderRadius: "20px",
                                                backgroundColor: overallDqScore > 90 ? "var(--vds-color-feedback-success)" : overallDqScore > 80 ? "var(--vds-color-feedback-warning)" : "var(--vds-color-feedback-error)",
                                                color: overallDqScore > 90 ? "var(--stroke-color-success)" : overallDqScore > 80 ? "var(--stroke-color-medium)" : "var(--stroke-color-low)",
                                                padding: "0.25em 0.5em",
                                            }}
                                        >
                                            {truncateDecimal(overallDqScore, 1)}%
                                        </div>
                                    )}
                                    <div onClick={() => handleToggle(section?.product_id)} style={{ cursor: "pointer" }}>
                                        {openSections[section?.product_id] ? <Chevron direction="top" /> : <Chevron direction="bottom" />}
                                    </div>
                                </div>
                            </div>
                            {openSections[section?.product_id] && (
                                <div
                                    className={styles.options_content}
                                    style={{ padding: "0.5em 2.5em", display: "flex", flexDirection: "column", gap: "0.5em" }}
                                >
                                    {l2Data && l2Data
                                        .filter(session => session.product_id === section.product_id)[0]
                                        ?.level2_data.map((obj, index) => {
                                            const overallL2DqScore = truncateDecimal((Object.values(obj?.dq_score).reduce((a, b) => parseFloat(a) + parseFloat(b), 0) / (Object.keys(obj?.dq_score).length)), 1);
                                            return (
                                                <div key={index} style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                                                    <div
                                                        onClick={overallL2DqScore > 0 ? () => L2Handler(section?.product_id, obj.level2_name) : null}
                                                        style={{
                                                            cursor: overallL2DqScore > 0 ? "pointer" : "default",
                                                            color: (activeProduct.productId === section.product_id && activeProduct.L2_productId === obj.level2_name) ? "#EE0000" : "#000",
                                                            fontWeight: (activeProduct.productId === section.product_id && activeProduct.L2_productId === obj.level2_name) ? "bold" : "normal",
                                                        }}
                                                    >
                                                        {obj.level2_name}
                                                    </div>
                                                    {overallL2DqScore > 0 && (
                                                        <div
                                                            style={{
                                                                borderRadius: "20px",
                                                                backgroundColor: overallL2DqScore > 90 ? "var(--vds-color-feedback-success)" : overallL2DqScore > 80 ? "var(--vds-color-feedback-warning)" : "var(--vds-color-feedback-error)",
                                                                color: overallL2DqScore > 90 ? "var(--stroke-color-success)" : overallL2DqScore > 80 ? "var(--stroke-color-medium)" : "var(--stroke-color-low)",
                                                                padding: "0.25em 0.5em",
                                                            }}
                                                        >
                                                            {truncateDecimal(overallL2DqScore, 1)}%
                                                        </div>
                                                    )}
                                                </div>
                                            );
                                        })}
                                </div>
                            )}
                        </div>
                    );
                })
            )}
        </div>
    );
};

export default DQDomainLevelReportSidebar;