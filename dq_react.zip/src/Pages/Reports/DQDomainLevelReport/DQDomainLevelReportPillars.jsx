import { useState, useEffect } from "react";
import { useGetProductDataQuery, useGetL2ProductDataQuery } from '../../../features/api/nodeapiSlice.js';
import { usePostTopBottomFiveScoresMutation } from '../../../features/api/fastapiSlice.js';
import { useSelector } from 'react-redux';
import styles from './DQDomainLevelReport.module.css';
import CompletenessIcon from "../../../assets/images/icons/checkmark-alt_blk 1.svg";
import UniquenessIcon from "../../../assets/images/icons/Medal_blk 1.svg";
import TimelinessIcon from "../../../assets/images/icons/real-time_blk 1.svg";
import ConsistencyIcon from "../../../assets/images/icons/grid-view_blk 1.svg";
import ValidityIcon from "../../../assets/images/icons/insurance_blk 1.svg";
import ConfirmityIcon from "../../../assets/images/icons/thumbs-up_blk 1.svg";
import { Body, Modal, ModalTitle, ModalBody,ModalFooter } from "@vds/core";
import Skeleton from '@mui/material/Skeleton';
import truncateDecimal from '../../../utils/truncateDecimal';
import ModalBodyContent from "./DQDomainLevelModal.jsx";

const DQDomainLevelReportPillars = () => {
    const { data: productData = [], isLoading: productIdDataLoading } = useGetProductDataQuery();
    const { data: l2Data = [], isLoading: l2DataLoading } = useGetL2ProductDataQuery();
    const [postTopBottomFiveScores, { isLoading: isTopBottomScoresLoading, isError: isTopBottomScoresError }] = usePostTopBottomFiveScoresMutation();
    const activeProduct = useSelector((state) => state.dqDomainLevelReport.activeProduct);
    const [showModal, setShowModal] = useState(false);
    const [selectedPillar, setSelectedPillar] = useState("");
    const [topBottomScores, setTopBottomScores] = useState({})
    const metricIcons = {
        completeness: CompletenessIcon,
        uniqueness: UniquenessIcon,
        timeliness: TimelinessIcon,
        consistency: ConsistencyIcon,
        validity: ValidityIcon,
        conformity: ConfirmityIcon,
    };

    const calculateAverageScore = () => {
        const scores = l2Data
            ?.find(product => product.product_id === activeProduct?.productId)
            ?.level2_data
            ?.find(level2 => level2.level2_name === activeProduct?.L2_productId)
            ?.dq_score;

        if (!scores) return 0;

        const values = Object.values(scores).filter(value => value !== null);
        const sum = values.reduce((acc, val) => acc + val, 0);
        return truncateDecimal(sum / values.length, 1);
    };

    let activeProduct_overall_score = 0;
    if (activeProduct?.productId && !activeProduct?.L2_productId && productData?.length > 0) {
        const product_id_obj = productData.filter(product => {
            return product?.product_id === activeProduct?.productId;
        });
        activeProduct_overall_score = truncateDecimal((Object.values(product_id_obj[0]?.['dq_score']).reduce((a, b) => parseFloat(a) + parseFloat(b), 0) / (Object.keys(product_id_obj[0]?.['dq_score']).length)), 1);
    } else if (activeProduct?.productId && activeProduct?.L2_productId && l2Data?.length > 0) {
        activeProduct_overall_score = calculateAverageScore();
    } else {
        activeProduct_overall_score = 0;
    }

    // Radial Bar Chart
    useEffect(() => {
        const radialBar = document.querySelector(`.${styles.radial_bar}`);
        if (radialBar) {
            const color = activeProduct_overall_score > 90 ? 'var(--stroke-color-success)' :
                activeProduct_overall_score > 80 ? 'var(--stroke-color-medium)' :
                    'var(--stroke-color-low)';
            radialBar.style.background = `conic-gradient(${color} ${activeProduct_overall_score}%, #f6f6f6 ${activeProduct_overall_score}%)`;
            const span = radialBar.querySelector("span");
            if (span) {
                span.innerText = `${activeProduct_overall_score}%`;
                span.style.color = color;
            }
        }
    }, [activeProduct_overall_score]);

    const handlePostTopBottomFiveScores = async (score_type) => {
        setSelectedPillar(score_type.charAt(0).toUpperCase() + score_type.slice(1));
        const inputData = {
            product_name: activeProduct.productId || "",
            score_type: "tbl_" + score_type.toString().toLowerCase(),
            level_2_name: activeProduct.L2_productId || "",
        };
        setShowModal(true);
        try {
            const response = await postTopBottomFiveScores(inputData).unwrap();
            setTopBottomScores(response);

        } catch (error) {
            console.error('Failed to post data:', error);
        }
    };

    return (
        <>
            <Modal
                surface="light"
                fullScreenDialog={false}
                disableAnimation={false}
                disableOutsideClick={false}
                ariaLabel={`${selectedPillar} Details`}
                opened={showModal}
                onOpenedChange={setShowModal}
                width="auto"
                // height="800px"
            >
                <ModalTitle>
                    {selectedPillar}
                </ModalTitle>
                <ModalBody>
                    <ModalBodyContent topBottomScores={topBottomScores} isTopBottomScoresLoading={isTopBottomScoresLoading} isTopBottomScoresError={isTopBottomScoresError} selectedPillar={selectedPillar} />
                </ModalBody>
                {/* <ModalFooter
                    buttonData={{
                        primary: {
                            width: '100%',
                            children: 'Close',
                            onClick: () => setShowModal(false),
                        },
                    }}
                /> */}
            </Modal>
            {(activeProduct.productId && !activeProduct.L2_productId) && (
                <>
                    {productIdDataLoading ? (
                        <div style={{ display: 'flex', gap: '0.25em' }}>
                            {[...Array(7)].map((_, index) => (
                                <Skeleton key={index} variant="rounded" width={"100%"} height={200} />
                            ))}
                        </div>
                    ) : (
                        <div className={styles.tile}>
                            <div className={styles.overallScore}>
                                <div id="radialBar" className={styles.radial_bar}>
                                    <span className={styles.radialBar_score}></span>
                                </div>
                                <Body size='large' bold={true}>Overall Score</Body>
                            </div>
                        </div>
                    )}

                    {productData.length > 0 ? (
                        Object.entries(productData.filter(product => product.product_id === activeProduct.productId)[0]?.dq_score)?.map(([key, value]) => {
                            const scoreValue = parseFloat(value);
                            const backgroundColor = scoreValue > 90 ? 'var(--vds-color-feedback-success)' : scoreValue > 80 ? 'var(--vds-color-feedback-warning)' : 'var(--vds-color-feedback-error)';
                            const color = scoreValue > 90 ? 'var(--stroke-color-success)' : scoreValue > 80 ? 'var(--stroke-color-medium)' : 'var(--stroke-color-low)';

                            return (
                                <div
                                    key={key}
                                    className={styles.tile}
                                    style={{ backgroundColor }}
                                    onClick={() => handlePostTopBottomFiveScores(key)}
                                >
                                    <picture className={styles.score_icon}>
                                        <img src={metricIcons[key]} alt={`${key}Icon`} />
                                    </picture>
                                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '10px' }}>
                                        <Body color={color} size='large' bold={true}>
                                            {truncateDecimal(value, 1)}
                                        </Body>
                                        <Body color='black' size='large' bold={true}>
                                            {key.charAt(0).toUpperCase() + key.slice(1)}
                                        </Body>
                                    </div>
                                </div>
                            );
                        })
                    ) : (<></>)}
                </>
            )}
            {(activeProduct.productId && activeProduct.L2_productId) && (<>
                {l2DataLoading ? (
                    <div style={{ display: 'flex', gap: '0.25em' }}>
                        {[...Array(7)].map((_, index) => (
                            <Skeleton key={index} variant="rounded" width={"100%"} height={200} />
                        ))}
                    </div>
                ) : (
                    <div className={styles.tile}>
                        <div className={styles.overallScore}>
                            <div id="radialBar" className={styles.radial_bar}>
                                <span className={styles.radialBar_score}></span>
                            </div>
                            <Body size='large' bold={true}>Overall Score</Body>
                        </div>
                    </div>
                )}

                {(activeProduct.productId && activeProduct.L2_productId) && (
                    l2Data.length > 0 && l2Data
                        .filter(product => product.product_id === activeProduct.productId)[0]
                        ?.level2_data
                        .filter(l2Item => l2Item.level2_name === activeProduct.L2_productId)[0]
                        ?.dq_score &&
                    Object.entries(l2Data
                        .filter(product => product.product_id === activeProduct.productId)[0]
                        ?.level2_data
                        .filter(l2Item => l2Item.level2_name === activeProduct.L2_productId)[0]
                        ?.dq_score)
                        .map(([key, value]) => {
                            if (value === null) return null;

                            const scoreValue = parseFloat(value);
                            const backgroundColor = scoreValue > 90 ? 'var(--vds-color-feedback-success)' :
                                scoreValue > 80 ? 'var(--vds-color-feedback-warning)' :
                                    'var(--vds-color-feedback-error)';
                            const color = scoreValue > 90 ? 'var(--stroke-color-success)' :
                                scoreValue > 80 ? 'var(--stroke-color-medium)' :
                                    'var(--stroke-color-low)';

                            return (
                                <div
                                    key={key}
                                    className={styles.tile}
                                    style={{ backgroundColor }}
                                    onClick={() => handlePostTopBottomFiveScores(key)}
                                >
                                    <picture className={styles.score_icon}>
                                        <img src={metricIcons[key]} alt={`${key}Icon`} />
                                    </picture>
                                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '10px' }}>
                                        <Body color={color} size='large' bold={true}>
                                            {truncateDecimal(value, 1)}
                                        </Body>
                                        <Body color='black' size='large' bold={true}>
                                            {key.charAt(0).toUpperCase() + key.slice(1)}
                                        </Body>
                                    </div>
                                </div>
                            );
                        }).filter(Boolean)
                )}

            </>)}
        </>
    );
};

export default DQDomainLevelReportPillars;