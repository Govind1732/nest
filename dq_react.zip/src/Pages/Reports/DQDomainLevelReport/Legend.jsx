import styles from "./DQDomainLevelReport.module.css";

const Legend = () => {
    return (
        <div className={styles.color_codes}>
            <div id={styles.legend}>
                <div className={styles.legend_item}>
                    <span
                        className={styles.legend_item_border}
                        style={{
                            backgroundColor: "var(--vds-color-feedback-success)",
                        }}
                    >
                        <span
                            className={styles.legend_color}
                            style={{
                                backgroundColor: "var(--stroke-color-success)",
                            }}
                        ></span>
                    </span>
                    90 - 100%
                </div>
                <div className={styles.legend_item}>
                    <span
                        className={styles.legend_item_border}
                        style={{
                            backgroundColor: "var(--vds-color-feedback-warning)",
                        }}
                    >
                        <span
                            className={styles.legend_color}
                            style={{
                                backgroundColor: "var(--stroke-color-medium)",
                            }}
                        ></span>
                    </span>
                    80% - 89%
                </div>
                <div className={styles.legend_item}>
                    <span
                        className={styles.legend_item_border}
                        style={{
                            backgroundColor: "var(--vds-color-feedback-error)",
                        }}
                    >
                        <span
                            className={styles.legend_color}
                            style={{ backgroundColor: "var(--stroke-color-low)" }}
                        ></span>
                    </span>
                    0% - 79%
                </div>
            </div>
        </div>
    )
}
export default Legend;