import { useState } from "react";
import { Body, Title } from "@vds/typography"
import { TextLink } from "@vds/buttons"
import Download from '@vds/icons/download';
import _ from 'lodash';
import { useGetProductDataQuery, useGetL2ProductDataQuery } from '../../../features/api/nodeapiSlice.js';
// import NestedGauge from './NestedGauge';
import { useSelector, useDispatch } from 'react-redux';
import PropTypes from 'prop-types';
import DQDomainLevelColumns from "./DQDomainLevelColumns.jsx";
import styles from './DQDomainLevelReport.module.css';
import DQDomainLevelReportTitle from './DQDomainLevelReportTitle';
import DQDomainLevelReportSidebar from './DQDomainLevelReportSidebar.jsx';
import DQDomainLevelReportPillars from './DQDomainLevelReportPillars.jsx';
import DQBarchart from './DQBarchart';
import DQLinechart from './DQLinechart';
import GraphLoader from '../../../Components/LayoutComponents/GraphLoader';
import { setDashboardView, setShowAllColumns, setActiveProduct } from '../../../features/DQDomainLevelReport/dqDomainLevelReportActions';
import Legend from './Legend';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';


const DQDomainLevelReport = () => {
    const { data: productData = [], error: productIdDataError, isLoading: productIdDataLoading } = useGetProductDataQuery();
    const { data: l2Data = [], error: l2DataError, isLoading: l2DataLoading } = useGetL2ProductDataQuery();
    // const { activeProduct, setActiveProduct, setShowAllTables, showAllColumns, setShowAllColumns, dashboardView, setDashboardView, selectedTable, columnsData } = useContext(DQDomainLevelReportContext);
    const activeProduct = useSelector((state) => state.dqDomainLevelReport.activeProduct);
    const dashboardView = useSelector((state) => state.dqDomainLevelReport.dashboardView);
    const showAllColumns = useSelector((state) => state.dqDomainLevelReport.showAllColumns);
    const dispatch = useDispatch();

    const handleDownloadPDF = () => {
        const element = document.querySelector(`.${styles.content}`);
        const sidebar = document.querySelector(`.${styles.sidebar}`);
        if (!element) {
            return;
        }
        // Hide the sidebar
        if (sidebar) {
            sidebar.style.display = 'none';
        }
        const icons = element.querySelectorAll(`.${styles.pdf}`);
        icons.forEach(icon => icon.style.display = 'none');
        html2canvas(element, { scale: 2 }).then(canvas => {
            const imgData = canvas.toDataURL('image/png');
            const pdf = new jsPDF({
                orientation: 'l', // landscape
                unit: 'mm',
                format: 'a4',
            });

            // Define margins
            const margin = 2; // in mm
            const pdfWidth = pdf.internal.pageSize.getWidth() - 2 * margin;
            const pdfHeight = pdf.internal.pageSize.getHeight() - 2 * margin;

            // Adjust image dimensions to maintain aspect ratio
            const imgProps = pdf.getImageProperties(imgData);
            const imgWidth = imgProps.width;
            const imgHeight = imgProps.height;
            let finalImgWidth, finalImgHeight;

            // Calculate final image dimensions based on aspect ratio
            if (imgWidth / imgHeight > pdfWidth / pdfHeight) {
                finalImgWidth = pdfWidth;
                finalImgHeight = (imgHeight * pdfWidth) / imgWidth;
            } else {
                finalImgHeight = pdfHeight;
                finalImgWidth = (imgWidth * pdfHeight) / imgHeight;
            }

            // Calculate position to center the image
            const imgX = margin + (pdfWidth - finalImgWidth) / 2;
            const imgY = margin + (pdfHeight - finalImgHeight) / 2;

            pdf.addImage(imgData, 'PNG', imgX, imgY, finalImgWidth, finalImgHeight);
            pdf.save('DQ Domain Level Report.pdf');
            // Restore hidden elements after PDF generation
            icons.forEach(icon => icon.style.display = '');
            if (sidebar) {
                sidebar.style.display = '';
            }
        });
    };

    return (
        <>
            <div className={styles.section}>
                <div className={styles.subHeading}>
                    <DQDomainLevelReportTitle />
                </div>
                <div className={styles.content}>
                    <div className={styles.sidebar}>
                        <DQDomainLevelReportSidebar />
                    </div>
                    <div className={styles.subContent}>
                        <div className={styles.sub_title}>
                            <div>
                                <span className={styles.product_title}>
                                    {activeProduct.productId && (
                                        <span onClick={() => { dispatch(setDashboardView(true)); dispatch(setActiveProduct({ productId: activeProduct.productId, L2_productId: "", tableName: "" })) }} style={{ cursor: 'pointer' }}>
                                            {(activeProduct.productId && !activeProduct.L2_productId && !activeProduct.tableName) ? <span className={styles.bold}>{activeProduct.productId}</span> : <span>{activeProduct.productId}</span>}
                                        </span>
                                    )}
                                    {activeProduct.L2_productId && (
                                        <span onClick={() => { dispatch(setDashboardView(true)); dispatch(setShowAllColumns(false)); dispatch(setActiveProduct({ productId: activeProduct.productId, L2_productId: activeProduct.L2_productId, tableName: "" })) }} style={{ cursor: 'pointer' }}>
                                            {activeProduct.tableName ? <span> / {activeProduct.L2_productId}</span> : <span className={styles.L2bold}> / {activeProduct.L2_productId}</span>}
                                        </span>
                                    )}
                                    {activeProduct.tableName && <span className={styles.L2bold}> / {activeProduct.tableName}</span>}
                                </span>
                            </div>
                            <div className={styles.colors}>
                                <Legend />
                                <div className={styles.pdf} onClick={handleDownloadPDF}>
                                    <Download
                                        color="#000000"
                                        size="medium"
                                    />
                                    <TextLink
                                        type="standAlone"
                                        surface="light"
                                        disabled={false}
                                    >Download PDF
                                    </TextLink>
                                </div>
                            </div>

                        </div>
                        <div className={styles.dashboard} style={dashboardView ? { display: "block" } : { display: "none" }} >
                            <div className={styles.pillarContainer}>
                                <DQDomainLevelReportPillars />
                            </div>
                            {(activeProduct.productId && !activeProduct.L2_productId) && (
                                <div className={styles.cards}>
                                    <div className={styles.allTablesCard}>
                                        <div className={styles.cardTitle}>
                                            <Title size="small" bold={true} color="#000000">DQ Score Tables</Title>
                                        </div>
                                        <div className={styles.cardBody}>
                                            {productIdDataLoading || l2DataLoading ? (
                                                <GraphLoader />
                                            ) : (
                                                productData.filter(product => product.product_id === activeProduct.productId)[0]?.barChart_allTables?.length > 0 ? (
                                                    <DQBarchart bargraphData={productData.filter(product => product.product_id === activeProduct.productId)[0]?.barChart_allTables} />
                                                ) : (
                                                    <div className={styles.noData} style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
                                                        <Body size="large" bold={true}>No Data Available</Body>
                                                    </div>
                                                )
                                            )}
                                        </div>
                                    </div>
                                    <div className={styles.last7daysCard}>
                                        <div className={styles.cardTitle}>
                                            <Title size="small" bold={true} color="#000000">DQ Score Trend</Title>
                                        </div>
                                        <div className={styles.cardBody}>
                                            {productIdDataLoading || l2DataLoading ? (
                                                <GraphLoader />
                                            ) : (
                                                productData.filter(product => product.product_id === activeProduct.productId)[0]?.lineChart ? (
                                                    <DQLinechart linechartData={productData.filter(product => product.product_id === activeProduct.productId)[0]?.lineChart} />
                                                ) : (
                                                    <div className={styles.noData} style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
                                                        <Body size="large" bold={true}>No Data Available</Body>
                                                    </div>
                                                )
                                            )}
                                        </div>
                                    </div>
                                </div>
                            )}
                            {(activeProduct.productId && activeProduct.L2_productId) && (
                                <div className={styles.cards}>
                                    <div className={styles.allTablesCard}>
                                        <div className={styles.cardTitle}>
                                            <Title size="small" bold={true} color="#000000">DQ Score Tables</Title>
                                        </div>
                                        <div className={styles.cardBody}>
                                            {productIdDataLoading || l2DataLoading ? (
                                                <GraphLoader />
                                            ) : (
                                                l2Data.filter(product => product.product_id === activeProduct.productId)[0]?.level2_data
                                                    .filter(level2 => level2.level2_name === activeProduct.L2_productId)[0]?.barChart_allTables?.length > 0 ? (
                                                    <DQBarchart bargraphData={l2Data.filter(product => product.product_id === activeProduct.productId)[0]?.level2_data
                                                        .filter(level2 => level2.level2_name === activeProduct.L2_productId)[0]?.barChart_allTables} />
                                                ) : (
                                                    <div className={styles.noData} style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
                                                        <Body size="large" bold={true}>No Data Available</Body>
                                                    </div>
                                                )
                                            )}
                                        </div>
                                    </div>
                                    <div className={styles.last7daysCard}>
                                        <div className={styles.cardTitle}>
                                            <Title size="small" bold={true} color="#000000">DQ Score Trend</Title>
                                        </div>
                                        <div className={styles.cardBody}>
                                            {productIdDataLoading || l2DataLoading ? (
                                                <GraphLoader />
                                            ) : (
                                                l2Data.filter(product => product.product_id === activeProduct.productId)[0]?.level2_data
                                                    .filter(level2 => level2.level2_name === activeProduct.L2_productId)[0]?.lineChart ? (
                                                    <DQLinechart linechartData={l2Data.filter(product => product.product_id === activeProduct.productId)[0]?.level2_data
                                                        .filter(level2 => level2.level2_name === activeProduct.L2_productId)[0]?.lineChart} />
                                                ) : (
                                                    <div className={styles.noData} style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
                                                        <Body size="large" bold={true}>No Data Available</Body>
                                                    </div>
                                                )
                                            )}
                                        </div>
                                    </div>
                                </div>
                            )}

                        </div>
                        <div style={{ display: showAllColumns ? 'flex' : 'none', justifyContent: "center", alignItems: "center" }} className={styles.tableDiv}>
                            <DQDomainLevelColumns />
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}
export default DQDomainLevelReport;