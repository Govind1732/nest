import React, { useState, useEffect, useCallback, useRef } from 'react';
import { TextField } from '@mui/material';
import { Modal } from 'react-bootstrap';
import Backdrop from '@mui/material/Backdrop';
import CircularProgress from '@mui/material/CircularProgress';
import ConnectivityCheck from '../../Components/ConnectivityCheck/ConnectivityCheck';
import styled from 'styled-components';
import styles from './SchemaDrift.module.css';
import {Button} from '@vds/core';
// import ModalComponent from '../../../Components/LayoutComponents/ModalComponent/Modal';
import { usePostAutopopulateColumnsMutation, usePostSchemaDriftSameEnvMutation } from '../../features/api/djangoapiSlice';

const Container = styled.div`
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    gap: 3rem;
    // position: absolute;
    // top: 50%;
    // left: 50%;
    // transform: translate(-50%, -50%);
    width: 100%;
`;
const Content = styled.div`
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    gap: 1em;
`;

const SchemaDriftSameenv = () => {
    const [additionalFieldsVisible, setAdditionalFieldsVisible] = useState(false);
    const [modalTitle, setModalTitle] = useState("");
    const [modalBody, setModalBody] = useState("");
    const [show, setShow] = useState(false);
    const [formData, setFormData] = useState({
        data_source: "TD",
        project_name: "",
        dbname: "",
        table_name: "",
        incr_date_col: "",
        email: ""
    });
    const [postAutopopulateColumns, { isLoading: isPostAutopopulateColumnsLoading }] = usePostAutopopulateColumnsMutation();
    const [postSchemaDriftSameEnv, { isLoading: isPostSchemaDriftSameEnvLoading }] = usePostSchemaDriftSameEnvMutation();
    let loading = isPostAutopopulateColumnsLoading || isPostSchemaDriftSameEnvLoading;
    const resetHandler = () => {
        setFormData({
            data_source: "TD",
            project_name: "",
            dbname: "",
            table_name: "",
            incr_date_col: "",
            email: ""
        });
        setAdditionalFieldsVisible(false);
    };
    const handleClose = () => {
        setShow(false)
    };
    const dataDriftSameenvSubmitHandler = async () => {
        console.log(formData);
        const data = {
            data_src: formData.data_source,
            dbname: formData.dbname,
            tablename: formData.table_name,
            incr_date_col: formData.incr_date_col,
            mail_distro: formData.email
        }
        try {
            const response = await postSchemaDriftSameEnv(data);
            console.log(response.data);
            setModalTitle('Data Drift Same Environment');
            setModalBody(response.data.message);
            setShow(true)
        }
        catch (err) {
            console.error("Error fetching additional details:", err);
        }
    };
    const fetchAdditionalDetails = useCallback(async () => {
        const formDataUrlEncoded = new URLSearchParams();
        for (const [key, value] of Object.entries(formData)) {
            formDataUrlEncoded.append(key, value);
        }
        try {
            const response = await postAutopopulateColumns(formDataUrlEncoded);
            if (response.data) {
                setFormData((prevState) => ({
                    ...prevState,
                    incr_date_col: response.data.INCR_DT_COL,
                    // incr_cond: response.data.INCR_DT_COND,
                }));
            }
        }
        catch (err) {
            console.error("Error fetching additional details:", err);
        }
    }, [formData, postAutopopulateColumns]);

    const prevAdditionalFieldsVisible = useRef(additionalFieldsVisible);

    useEffect(() => {
        if (additionalFieldsVisible && !prevAdditionalFieldsVisible.current) {
            fetchAdditionalDetails();
        }
        prevAdditionalFieldsVisible.current = additionalFieldsVisible;
    }, [additionalFieldsVisible, fetchAdditionalDetails]);
    return (<>
        <ModalComponent
            show={show}
            handleClose={handleClose}
            title={modalTitle}
            body={modalBody}
            onClose={handleClose}
        />
        {loading && (
            <Backdrop
                sx={{ color: '#ddd', zIndex: (theme) => theme.zIndex.drawer + 1 }}
                open={loading}
            >
                <CircularProgress color="inherit" />
            </Backdrop>
        )}
        <div className={styles.mainContent}>
            <Container>
                {/* <h4 style={{ color: '#EE0000' }}>Schema Drift Same Environment</h4> */}
                <Content>
                    <div style={{ display: 'flex', gap: '1rem' }}>
                        <ConnectivityCheck
                            additionalFieldsVisible={additionalFieldsVisible}
                            setAdditionalFieldsVisible={setAdditionalFieldsVisible}
                            formData={formData}
                            setFormData={setFormData}
                        />
                        <div style={{ display: additionalFieldsVisible ? 'flex' : 'none', flexDirection: 'column', gap: '1rem' }}>
                            <TextField label="Incremental Date Column" variant="outlined" size='small' sx={{ width: '25vw' }} onChange={(e) => setFormData((prevState) => ({ ...prevState, incr_date_col: e.target.value }))} value={formData.incr_date_col} />
                            <TextField label="EMail" variant="outlined" size='small' sx={{ width: '25vw' }} onChange={(e) => setFormData((prevState) => ({ ...prevState, email: e.target.value }))} value={formData.email} />
                        </div>
                    </div>
                    <div style={{ display: additionalFieldsVisible ? 'flex' : 'none', justifyContent: 'center', alignItems: "center", gap: '1rem' }}>
                        <Button onClick={resetHandler}>Reset</Button>
                        <Button onClick={dataDriftSameenvSubmitHandler}>Submit</Button>
                    </div>
                </Content>
            </Container>
        </div>
    </>);
};


const ModalComponent = ({ show, title, body, onClose }) => (
    <Modal show={show} onHide={onClose}>
        <Modal.Header closeButton>
            <Modal.Title>{title}</Modal.Title>
        </Modal.Header>
        <Modal.Body>{body}</Modal.Body>
        <Modal.Footer>
            <Button
                use="secondary"
                onClick={() => {
                    onClose();
                }}
            >
                Close
            </Button>
        </Modal.Footer>
    </Modal>
);

export default SchemaDriftSameenv;