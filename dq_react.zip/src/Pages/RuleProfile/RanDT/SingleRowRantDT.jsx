import React, { useState } from "react";
import axios from "axios";
import { Container, Row, Col, Form, Button, Modal } from "react-bootstrap";
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import TextField from '@mui/material/TextField';


function SingleRowRantDT() {
    const [formData, setFormData] = useState({
        data_source: "",
        project_name: "",
        dbname: "",
        table_name: "",
        incr_col: "",
        incr_cond: "",
        email: "",
    });
    const [loading, setLoading] = useState(false);
    const [additionalFieldsVisible, setAdditionalFieldsVisible] = useState(false);
    const [show, setShow] = useState(false);
    const [body, setBody] = useState("");
    const [showModal, setShowModal] = useState(false);
    const [profileSuccess, setProfileSuccess] = useState(false);

    const handleClose = () => {
        setShow(false);
        setShowModal(false);
        setProfileSuccess(false);
    };
    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prevState) => ({
            ...prevState,
            [name]: value,
        }));
    };

    const handleConnectivityCheck = () => {
        setLoading(true);
        axios
            .post(
                `${process.env.REACT_APP_BASE_URL}ml_profiler_config_form/ui_fetch/`,
                JSON.stringify(formData),
                {
                    headers: {
                        "Content-Type": "application/json",
                    },
                }
            )
            .then((response) => {
                setLoading(false);
                if (response.data.combination_exists) {
                    setShow(true);
                    setBody("Click on close button to redirect to marketplace to raise a request");
                } else {
                    fetchAdditionalDetails();
                    setBody("Please fill the remaining fields for profiling");
                    setAdditionalFieldsVisible(true);
                    setShowModal(true);
                }
            })
            .catch((error) => {
                setLoading(false);
                console.error("Error checking connectivity:", error);
                alert("error in handling data");
            });
    };

    const fetchAdditionalDetails = () => {
        axios
            .post(`${process.env.REACT_APP_BASE_URL}ml_profiler_config_form/autopopulate_columns/`,
                JSON.stringify(formData),
                {
                    headers: {
                        "Content-Type": "application/json",
                    },
                }
            )
            .then((response) => {
                setFormData((prevState) => ({
                    ...prevState,
                    incr_col: response.data.INCR_DT_COL,
                    incr_cond: response.data.INCR_DT_COND,
                }));
            })
            .catch((error) => {
                console.error("Error fetching additional details:", error);
            });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        setLoading(true);
        axios
            .post(`${process.env.REACT_APP_BASE_URL}self_serve2/dispatch_MLProfile_data/`,
                JSON.stringify(formData),
                {
                    headers: {
                        "Content-Type": "application/json",
                    },
                }
            )
            .then((response) => {
                setLoading(false);
                setBody("Report will be sent through Email in few minutes.Redirecting to Report History page");
                setProfileSuccess(true);
            })
            .catch((error) => {
                setLoading(false);
                console.error("Error triggering Data Profiler:", error);
                alert("Error triggering Data Profiler:", error);
            });
    };

    const resetHandler = () => {
        setFormData((prevState) => ({
            ...prevState,
            data_source: "",
            project_name: "",
            dbname: "",
            table_name: "",
            incr_col: "",
            incr_cond: "",
            email: "",
        }));
        setAdditionalFieldsVisible(false);
    };

    return (
        <Container fluid className="">

            <Container fluid className="mx-8 px-8 mb-2">
                <Form onSubmit={handleSubmit}>
                    <h2 className="mb-2 text-center" style={{ color: "#EE0000" }}>
                        SingleRow RanDT
                    </h2>
                    <Row className="justify-content-center align-items-center">
                        <Col xl={3}>
                            <fieldset disabled={additionalFieldsVisible || loading}>
                                <Form.Group className="mb-2" controlId="ControlInput1">
                                    <FormControl fullWidth>
                                        <InputLabel id="select-label">Environment</InputLabel>
                                        <Select
                                            labelId="select-label"
                                            id="select"
                                            value={formData.data_source}
                                            label="Environment"
                                            onChange={handleChange}
                                            name="data_source"
                                            size="small"
                                            disabled={additionalFieldsVisible || loading}
                                        >
                                            <MenuItem value="TD">TeraData</MenuItem>
                                            <MenuItem value="GCP">GCP</MenuItem>
                                        </Select>
                                    </FormControl>
                                </Form.Group>

                                <Form.Group
                                    className="mb-2"
                                    controlId="ControlInput2"
                                    style={{
                                        display: formData.data_source === "GCP" ? "block" : "none",
                                    }}
                                >
                                    <TextField required label="Project" variant="outlined" value={formData.project_name}
                                        name="project_name"
                                        onChange={handleChange}
                                        size="small" fullWidth />
                                </Form.Group>

                                <Form.Group className="mb-2" controlId="ControlInput3">
                                    <TextField required label="Database" variant="outlined" value={formData.dbname}
                                        name="dbname"
                                        onChange={handleChange}
                                        size="small" fullWidth />
                                </Form.Group>

                                <Form.Group className="" controlId="ControlInput4">
                                    <TextField required label="Table" variant="outlined" value={formData.table_name}
                                        name="table_name"
                                        onChange={handleChange}
                                        size="small"
                                        fullWidth />
                                </Form.Group>

                                <div className="d-flex justify-content-center my-2">
                                    <Button
                                        variant="dark"
                                        type="button"
                                        onClick={handleConnectivityCheck}
                                        disabled={loading}
                                        style={{
                                            display: additionalFieldsVisible ? "none" : "block",
                                            borderRadius: "25px",
                                        }}
                                    >
                                        {loading ? "Checking..." : "Check For Connectivity"}
                                    </Button>
                                </div>
                            </fieldset>
                            <fieldset style={{ display: additionalFieldsVisible ? "block" : "none" }} >

                            </fieldset>
                        </Col>
                        <Col xl={3} style={{ display: additionalFieldsVisible ? "block" : "none" }} >
                            <fieldset style={{ display: additionalFieldsVisible ? "block" : "none" }} >
                                <TextOutlineField name={'Data_LOB'} label={'Data_LOB'} value={formData.Data_LOB} onChange={handleChange} ></TextOutlineField>
                                <TextOutlineField name={'DATA_DMN'} label={'DATA_DMN'} value={formData.DATA_DMN} onChange={handleChange} ></TextOutlineField>
                                <TextOutlineField name={'DATA_SUB_DMN'} label={'DATA_SUB_DMN'} value={formData.DATA_SUB_DMN} onChange={handleChange} ></TextOutlineField>
                                <TextOutlineField name={'DATA_BUS_ELEM'} label={'DATA_BUS_ELEM'} value={formData.DATA_BUS_ELEM} onChange={handleChange} ></TextOutlineField>

                                <TextOutlineField name={'SRC_COL'} label={'SRC_COL'} value={formData.INCR_DT_COND} onChange={handleChange} ></TextOutlineField>
                                <TextOutlineField name={'DQ_PILLAR'} label={'DQ_PILLAR'} value={formData.DQ_PILLAR} onChange={handleChange} ></TextOutlineField>
                                <TextOutlineField name={'MEAS_NAME'} label={'MEAS_NAME'} value={formData.MEAS_NAME} onChange={handleChange} ></TextOutlineField>
                                <TextOutlineField name={'MEAS_RULE_DESC'} label={'MEAS_RULE_DESC'} value={formData.MEAS_RULE_DESC} onChange={handleChange} ></TextOutlineField>
                                <TextOutlineField name={'MEAS_RULE_SQL'} label={'MEAS_RULE_SQL'} value={formData.MEAS_RULE_SQL} onChange={handleChange} ></TextOutlineField>
                                <TextOutlineField name={'IS_ACTIVE_FLG'} label={'IS_ACTIVE_FLG'} value={formData.IS_ACTIVE_FLG} onChange={handleChange} ></TextOutlineField>
                                <TextOutlineField name={'IS_CRITICAL_FLG'} label={'IS_CRITICAL_FLG'} value={formData.IS_CRITICAL_FLG} onChange={handleChange} ></TextOutlineField>


                            </fieldset>
                        </Col>
                        <Col xl={3} style={{ display: additionalFieldsVisible ? "block" : "none" }} >
                            <fieldset style={{ display: additionalFieldsVisible ? "block" : "none" }} >
                                <TextOutlineField name={'RULE_PRFL_SCHD_TS'} label={'RULE_PRFL_SCHD_TS'} value={formData.RULE_PRFL_SCHD_TS} onChange={handleChange} ></TextOutlineField>

                                <TextOutlineField name={'RULE_MIN_THRSD'} label={'RULE_MIN_THRSD'} value={formData.RULE_MIN_THRSD} onChange={handleChange} ></TextOutlineField>
                                <TextOutlineField name={'RULE_MAX_THRSD'} label={'RULE_MAX_THRSD'} value={formData.RULE_MAX_THRSD} onChange={handleChange} ></TextOutlineField>
                                <TextOutlineField name={'mail_sub'} label={'mail_sub'} value={formData.mail_sub} onChange={handleChange} ></TextOutlineField>
                                <TextOutlineField name={'email_distro'} label={'email_distro'} value={formData.email_distro} onChange={handleChange} ></TextOutlineField>
                                <TextOutlineField name={'invalid_rec_flg'} label={'invalid_rec_flg'} value={formData.invalid_rec_flg} onChange={handleChange} ></TextOutlineField>
                                <TextOutlineField name={'invalid_rec_sql'} label={'invalid_rec_sql'} value={formData.invalid_rec_sql} onChange={handleChange} ></TextOutlineField>
                                <TextOutlineField name={'PRODUCT_NAME'} label={'PRODUCT_NAME'} value={formData.PRODUCT_NAME} onChange={handleChange} ></TextOutlineField>
                                <TextOutlineField name={'PRODUCT_TYPE'} label={'PRODUCT_TYPE'} value={formData.PRODUCT_TYPE} onChange={handleChange} ></TextOutlineField>
                                <TextOutlineField name={'PRODUCT_AREA'} label={'PRODUCT_AREA'} value={formData.PRODUCT_AREA} onChange={handleChange} ></TextOutlineField>
                                <TextOutlineField name={'BUSINESS_PROGRAM'} label={'BUSINESS_PROGRAM'} value={formData.BUSINESS_PROGRAM} onChange={handleChange} ></TextOutlineField>

                            </fieldset>
                        </Col>
                        <div className="d-flex justify-content-center mb-2">
                            <Button
                                variant="dark"
                                style={{ display: additionalFieldsVisible ? "block" : "none" }}
                                disabled={loading}
                                className="mx-2"
                                onClick={resetHandler}
                            >
                                Reset
                            </Button>
                            <Button
                                variant="dark"
                                type="submit"
                                disabled={loading}
                                style={{ display: additionalFieldsVisible ? "block" : "none" }}
                                className="mx-2"
                            >
                                {loading ? "loading..." : "Submit Profile"}
                            </Button>
                        </div>
                    </Row>
                </Form>
            </Container>

            <Modal show={show} onHide={() => handleClose()}>
                <Modal.Header closeButton>
                    <Modal.Title>Connectivity/Access does not exist.</Modal.Title>
                </Modal.Header>
                <Modal.Body>{body}</Modal.Body>
                <Modal.Footer>
                    <Button
                        variant="secondary"
                        onClick={() => {
                            handleClose();
                            window.open(
                                "https://marketplace.verizon.com/#/subscriptionReqForm",
                                "_blank"
                            );
                        }}
                    >
                        Close
                    </Button>
                </Modal.Footer>
            </Modal>

            <Modal show={showModal} onHide={() => handleClose()}>
                <Modal.Header closeButton>
                    <Modal.Title>Connectivity/Access available.</Modal.Title>
                </Modal.Header>
                <Modal.Body>{body}</Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleClose}>
                        Close
                    </Button>
                </Modal.Footer>
            </Modal>

            <Modal
                show={profileSuccess}
                onHide={() => handleClose()}
                backdrop="static"
                keyboard={false}
            >
                <Modal.Header closeButton>
                    <Modal.Title>Data Profiler Triggered.</Modal.Title>
                </Modal.Header>
                <Modal.Body>{body}</Modal.Body>
                <Modal.Footer>
                    <Button
                        variant="secondary"
                        onClick={() => {
                            handleClose();
                            window.open(
                                "https://tdcldizcva002.ebiz.verizon.com:8446/dataQuality/mlProfileReports",
                                "_self"
                            );
                        }}
                    >
                        Close
                    </Button>
                </Modal.Footer>
            </Modal>
        </Container>
    );
}

const TextOutlineField = ({ label, value, name, onChange }) => {
    return (
        <>
            <Form.Group className="mb-2" controlId="ControlInput7">

                <TextField required label={label} variant="outlined" value={value}
                    name={name}
                    onChange={onChange}
                    size="small"
                    fullWidth />
            </Form.Group>
        </>
    );
};

export default SingleRowRantDT;

