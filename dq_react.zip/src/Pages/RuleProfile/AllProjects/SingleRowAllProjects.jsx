// import React, { useState, useEffect } from "react";
// import axios from "axios";
// import { Container, Row, Col, Form, Button, Breadcrumb, Modal } from "react-bootstrap";
// import URLSearchParams from "url-search-params";
// import InputLabel from '@mui/material/InputLabel';
// import MenuItem from '@mui/material/MenuItem';
// import FormControl from '@mui/material/FormControl';
// import Select from '@mui/material/Select';
// import TextField from '@mui/material/TextField';
// import Autocomplete from '@mui/material/Autocomplete';


// function SingleRowAllProjects() {
//     const [formData, setFormData] = useState({
//         data_source: "",
//         project_name: "",
//         dbname: "",
//         table_name: "",
//         Data_LOB: "",
//         DATA_DMN: "",
//         DATA_SUB_DMN: "",
//         DATA_BUS_ELEM: "",
//         DB_NAME: "",
//         SRC_TBL: "",
//         SRC_COL: "",
//         DQ_PILLAR: "",
//         MEAS_NAME: "",
//         MEAS_RULE_DESC: "",
//         MEAS_RULE_SQL: "",
//         IS_ACTIVE_FLG: "",
//         IS_CRITICAL_FLG: "",
//         RULE_PRFL_SCHD_TS: "",
//         DATA_SRC: "",
//         RULE_MIN_THRSD: "",
//         RULE_MAX_THRSD: "",
//         mail_sub: "",
//         email_distro: "",
//         invalid_rec_flg: "",
//         invalid_rec_sql: "",
//         PRODUCT_NAME: "",
//         PRODUCT_TYPE: "",
//         PRODUCT_AREA: "",
//         BUSINESS_PROGRAM: ""
//     });
//     const [loading, setLoading] = useState(false);
//     const [additionalFieldsVisible, setAdditionalFieldsVisible] = useState(false);
//     const [show, setShow] = useState(false);
//     const [body, setBody] = useState("");
//     const [showModal, setShowModal] = useState(false);
//     const [profileSuccess, setProfileSuccess] = useState(false);
//     const [projectOptions, setProjectOptions] = useState([])
//     const [dbOptions, setDbOptions] = useState([])
//     const [tableOptions, setTableOptions] = useState([])


//     const handleClose = () => {
//         setShow(false);
//         setShowModal(false);
//         setProfileSuccess(false);
//     };

//     const handleChange = (e) => {
//         const { name, value } = e.target;
//         setFormData((prevState) => ({
//             ...prevState,
//             [name]: value,
//         }));
//     };

//     useEffect(() => {
//         axios.get(`${process.env.REACT_APP_BASE_URL}self_serve2/SingleTableLoad/`)
//             .then(response => {
//                 setProjectOptions(response.data.project_ids)
//             })
//             .catch(error => {
//                 console.error('Error fetching project ids:', error)
//             })
//     }, [])

//     useEffect(() => {
//         if (formData.project_name) {
//             axios.post(`${process.env.REACT_APP_BASE_URL}self_serve2/SingleTableLoad/`, {
//                 project_id: formData.project_name,
//                 dataset: formData.dbname

//             }, {
//                 headers: {
//                     "Content-Type": "application/x-www-form-urlencoded",
//                 },

//             })
//                 .then(response => {
//                     if ('datasets' in response.data) {
//                         setDbOptions(response.data.datasets)
//                     }
//                     else if ('table_names' in response.data) {
//                         setTableOptions(response.data.table_names)
//                     }
//                 })
//                 .catch(error => {
//                     console.error('Error fetching project ids:', error)
//                 })
//         }

//     }, [formData.project_name, formData.dbname])

//     const handleConnectivityCheck = () => {
//         setLoading(true);
//         const formDataUrlEncoded = new URLSearchParams();
//         for (const [key, value] of Object.entries(formData)) {
//             formDataUrlEncoded.append(key, value);
//         }

//         axios
//             .post(
//                 `${process.env.REACT_APP_BASE_URL}ml_profiler_config_form/ui_fetch/`,
//                 formDataUrlEncoded,
//                 {
//                     headers: {
//                         "Content-Type": "application/x-www-form-urlencoded",
//                     },
//                 }
//             )
//             .then((response) => {
//                 setLoading(false);
//                 console.log(response.data.combination_exists);
//                 if (response.data.combination_exists) {
//                     setShow(true);
//                     setBody(
//                         "Click on close button to redirect to marketplace to raise a request"
//                     );
//                 } else {
//                     setBody("Please fill the remaining fields for profiling");
//                     setAdditionalFieldsVisible(true);
//                     setShowModal(true);
//                 }
//             })
//             .catch((error) => {
//                 setLoading(false);
//                 console.error("Error checking connectivity:", error);
//                 alert("error in handling data");
//             });
//     };

//     const handleSubmit = (e) => {
//         e.preventDefault();
//         setLoading(true);

//         const formDataUrlEncoded = new URLSearchParams();
//         for (const [key, value] of Object.entries(formData)) {
//             formDataUrlEncoded.append(key, value);
//         }

//         axios
//             .post(
//                 `${process.env.REACT_APP_BASE_URL}self_serve2/SingleTableLoad/`,
//                 formDataUrlEncoded,
//                 {
//                     headers: {
//                         "Content-Type": "application/x-www-form-urlencoded",
//                     },
//                 }
//             )
//             .then((response) => {
//                 setLoading(false);
//                 setBody("Table loaded successfully");
//                 setProfileSuccess(true);
//             })
//             .catch((error) => {
//                 setLoading(false);
//                 console.error("Error:", error);
//                 alert("Error:", error);
//             });
//     };

//     const resetHandler = () => {
//         setFormData((prevState) => ({
//             ...prevState,
//             data_source: "",
//             project_name: "",
//             dbname: "",
//             table_name: "",
//             Data_LOB: "",
//             DATA_DMN: "",
//             DATA_SUB_DMN: "",
//             DATA_BUS_ELEM: "",
//             DB_NAME: "",
//             SRC_TBL: "",
//             SRC_COL: "",
//             DQ_PILLAR: "",
//             MEAS_NAME: "",
//             MEAS_RULE_DESC: "",
//             MEAS_RULE_SQL: "",
//             IS_ACTIVE_FLG: "",
//             IS_CRITICAL_FLG: "",
//             RULE_PRFL_SCHD_TS: "",
//             DATA_SRC: "",
//             RULE_MIN_THRSD: "",
//             RULE_MAX_THRSD: "",
//             mail_sub: "",
//             email_distro: "",
//             invalid_rec_flg: "",
//             invalid_rec_sql: "",
//             PRODUCT_NAME: "",
//             PRODUCT_TYPE: "",
//             PRODUCT_AREA: "",
//             BUSINESS_PROGRAM: ""
//         }));
//         setAdditionalFieldsVisible(false);
//     };

//     return (
//         <Container fluid className="">


//             <Container fluid className="mx-8 px-8 mb-2">
//                 <Form onSubmit={handleSubmit}>
//                     <h2 className="mb-2 text-center" style={{ color: "#EE0000" }}>
//                         SingleRow AllProjects
//                     </h2>
//                     <Row className="justify-content-center align-items-center">
//                         <Col xl={3}>
//                             <fieldset disabled={additionalFieldsVisible || loading}>
//                                 <Form.Group className="mb-2" controlId="ControlInput1">

//                                     <FormControl fullWidth>
//                                         <InputLabel id="select-label">Environment</InputLabel>
//                                         <Select
//                                             labelId="select-label"
//                                             id="select"
//                                             value={formData.data_source}
//                                             label="Environment"
//                                             onChange={handleChange}
//                                             name="data_source"

//                                             size="small"
//                                             disabled={additionalFieldsVisible || loading}
//                                         >
//                                             <MenuItem value="TD">TeraData</MenuItem>
//                                             <MenuItem value="GCP">GCP</MenuItem>
//                                         </Select>
//                                     </FormControl>


//                                 </Form.Group>

//                                 <Form.Group
//                                     className="mb-2"
//                                     controlId="ControlInput2"
//                                     style={{
//                                         display: formData.data_source === "GCP" ? "block" : "none",
//                                     }}
//                                 >

//                                     <Autocomplete
//                                         // id="combo-box"
//                                         options={projectOptions}
//                                         autoHighlight

//                                         fullWidth
//                                         size="small"
//                                         name="project_name"
//                                         value={formData.project_name}
//                                         onChange={(_, value) => setFormData((prev) => ({ ...prev, project_name: value }))}
//                                         renderInput={(params) => <TextField {...params} label="Project" variant="outlined" />}
//                                     />
//                                 </Form.Group>

//                                 <Form.Group className="mb-2" controlId="ControlInput3">
//                                     <TextField required label="Database" variant="outlined" value={formData.dbname}
//                                         name="dbname"
//                                         onChange={handleChange}
//                                         style={{ display: (formData.data_source === "TD" || formData.data_source === "") || "" ? "block" : "none" }}
//                                         size="small" fullWidth />
//                                     <Autocomplete
//                                         // id="combo-box"
//                                         style={{ display: formData.data_source === "GCP" ? "block" : "none" }}
//                                         options={dbOptions || []}

//                                         autoHighlight
//                                         fullWidth
//                                         size="small"
//                                         name="dbname"
//                                         value={formData.dbname}
//                                         onChange={(_, value) => setFormData((prev) => ({ ...prev, dbname: value }))}
//                                         renderInput={(params) => <TextField {...params} label="DB Name" variant="outlined" />}
//                                     />
//                                 </Form.Group>

//                                 <Form.Group className="" controlId="ControlInput4">
//                                     <TextField required label="Table" variant="outlined" value={formData.table_name}
//                                         style={{ display: (formData.data_source === "TD" || formData.data_source === "") ? "block" : "none" }}
//                                         name="table_name"
//                                         onChange={handleChange}
//                                         size="small"
//                                         fullWidth />
//                                     <Autocomplete
//                                         // id="combo-box"
//                                         options={tableOptions || []}
//                                         style={{ display: formData.data_source === "GCP" ? "block" : "none" }}
//                                         autoHighlight
//                                         fullWidth
//                                         size="small"
//                                         name="table_name"
//                                         value={formData.table_name}
//                                         onChange={(_, value) => setFormData((prev) => ({ ...prev, table_name: value }))}
//                                         renderInput={(params) => <TextField {...params} label="Table Name" variant="outlined" />}
//                                     />
//                                 </Form.Group>

//                                 <div className="d-flex justify-content-center my-2">
//                                     <Button
//                                         variant="dark"
//                                         type="button"
//                                         onClick={handleConnectivityCheck}
//                                         disabled={loading}
//                                         style={{
//                                             display: additionalFieldsVisible ? "none" : "block",
//                                             borderRadius: "25px",
//                                         }}
//                                     >
//                                         {loading ? "Checking..." : "Check For Connectivity"}
//                                     </Button>
//                                 </div>
//                             </fieldset>
//                             <fieldset style={{ display: additionalFieldsVisible ? "block" : "none" }} >

//                             </fieldset>
//                         </Col>
//                         <Col xl={3} style={{ display: additionalFieldsVisible ? "block" : "none" }} >
//                             <fieldset style={{ display: additionalFieldsVisible ? "block" : "none" }} >
//                                 <TextOutlineField name={'Data_LOB'} label={'Data_LOB'} value={formData.Data_LOB} onChange={handleChange} ></TextOutlineField>
//                                 <TextOutlineField name={'DATA_DMN'} label={'DATA_DMN'} value={formData.DATA_DMN} onChange={handleChange} ></TextOutlineField>
//                                 <TextOutlineField name={'DATA_SUB_DMN'} label={'DATA_SUB_DMN'} value={formData.DATA_SUB_DMN} onChange={handleChange} ></TextOutlineField>
//                                 <TextOutlineField name={'DATA_BUS_ELEM'} label={'DATA_BUS_ELEM'} value={formData.DATA_BUS_ELEM} onChange={handleChange} ></TextOutlineField>
//                                 <TextOutlineField name={'DB_NAME'} label={'DB_NAME'} value={formData.DB_NAME} onChange={handleChange} ></TextOutlineField>
//                                 <TextOutlineField name={'SRC_TBL'} label={'SRC_TBL'} value={formData.SRC_TBL} onChange={handleChange} ></TextOutlineField>
//                                 <TextOutlineField name={'SRC_COL'} label={'SRC_COL'} value={formData.INCR_DT_COND} onChange={handleChange} ></TextOutlineField>
//                                 <TextOutlineField name={'DQ_PILLAR'} label={'DQ_PILLAR'} value={formData.DQ_PILLAR} onChange={handleChange} ></TextOutlineField>
//                                 <TextOutlineField name={'MEAS_NAME'} label={'MEAS_NAME'} value={formData.MEAS_NAME} onChange={handleChange} ></TextOutlineField>
//                                 <TextOutlineField name={'MEAS_RULE_DESC'} label={'MEAS_RULE_DESC'} value={formData.MEAS_RULE_DESC} onChange={handleChange} ></TextOutlineField>
//                                 <TextOutlineField name={'MEAS_RULE_SQL'} label={'MEAS_RULE_SQL'} value={formData.MEAS_RULE_SQL} onChange={handleChange} ></TextOutlineField>
//                                 <TextOutlineField name={'IS_ACTIVE_FLG'} label={'IS_ACTIVE_FLG'} value={formData.IS_ACTIVE_FLG} onChange={handleChange} ></TextOutlineField>


//                             </fieldset>
//                         </Col>
//                         <Col xl={3} style={{ display: additionalFieldsVisible ? "block" : "none" }} >
//                             <fieldset style={{ display: additionalFieldsVisible ? "block" : "none" }} >
//                                 <TextOutlineField name={'IS_CRITICAL_FLG'} label={'IS_CRITICAL_FLG'} value={formData.IS_CRITICAL_FLG} onChange={handleChange} ></TextOutlineField>
//                                 <TextOutlineField name={'RULE_PRFL_SCHD_TS'} label={'RULE_PRFL_SCHD_TS'} value={formData.RULE_PRFL_SCHD_TS} onChange={handleChange} ></TextOutlineField>
//                                 <TextOutlineField name={'DATA_SRC'} label={'DATA_SRC'} value={formData.DATA_SRC} onChange={handleChange} ></TextOutlineField>
//                                 <TextOutlineField name={'RULE_MIN_THRSD'} label={'RULE_MIN_THRSD'} value={formData.RULE_MIN_THRSD} onChange={handleChange} ></TextOutlineField>
//                                 <TextOutlineField name={'RULE_MAX_THRSD'} label={'RULE_MAX_THRSD'} value={formData.RULE_MAX_THRSD} onChange={handleChange} ></TextOutlineField>
//                                 <TextOutlineField name={'mail_sub'} label={'mail_sub'} value={formData.mail_sub} onChange={handleChange} ></TextOutlineField>
//                                 <TextOutlineField name={'email_distro'} label={'email_distro'} value={formData.email_distro} onChange={handleChange} ></TextOutlineField>
//                                 <TextOutlineField name={'invalid_rec_flg'} label={'invalid_rec_flg'} value={formData.invalid_rec_flg} onChange={handleChange} ></TextOutlineField>
//                                 <TextOutlineField name={'invalid_rec_sql'} label={'invalid_rec_sql'} value={formData.invalid_rec_sql} onChange={handleChange} ></TextOutlineField>
//                                 <TextOutlineField name={'PRODUCT_NAME'} label={'PRODUCT_NAME'} value={formData.PRODUCT_NAME} onChange={handleChange} ></TextOutlineField>
//                                 <TextOutlineField name={'PRODUCT_TYPE'} label={'PRODUCT_TYPE'} value={formData.PRODUCT_TYPE} onChange={handleChange} ></TextOutlineField>
//                                 <TextOutlineField name={'PRODUCT_AREA'} label={'PRODUCT_AREA'} value={formData.PRODUCT_AREA} onChange={handleChange} ></TextOutlineField>
//                                 <TextOutlineField name={'BUSINESS_PROGRAM'} label={'BUSINESS_PROGRAM'} value={formData.BUSINESS_PROGRAM} onChange={handleChange} ></TextOutlineField>

//                             </fieldset>
//                         </Col>
//                         <div className="d-flex justify-content-center mb-2">
//                             <Button
//                                 variant="danger"
//                                 style={{ display: additionalFieldsVisible ? "block" : "none" }}
//                                 disabled={loading}
//                                 className="mx-2"
//                                 onClick={resetHandler}
//                             >
//                                 Reset
//                             </Button>
//                             <Button
//                                 variant="danger"
//                                 type="submit"
//                                 disabled={loading}
//                                 style={{ display: additionalFieldsVisible ? "block" : "none" }}
//                                 className="mx-2"
//                             >
//                                 {loading ? "loading..." : "Submit Profile"}
//                             </Button>
//                         </div>
//                     </Row>
//                 </Form>
//             </Container>

//             <Modal show={show} onHide={() => handleClose()}>
//                 <Modal.Header closeButton>
//                     <Modal.Title>Connectivity/Access does not exist.</Modal.Title>
//                 </Modal.Header>
//                 <Modal.Body>{body}</Modal.Body>
//                 <Modal.Footer>
//                     <Button
//                         variant="secondary"
//                         onClick={() => {
//                             handleClose();
//                             window.open(
//                                 "https://marketplace.verizon.com/#/subscriptionReqForm",
//                                 "_blank"
//                             );
//                         }}
//                     >
//                         Close
//                     </Button>
//                 </Modal.Footer>
//             </Modal>

//             <Modal show={showModal} onHide={() => handleClose()}>
//                 <Modal.Header closeButton>
//                     <Modal.Title>Connectivity/Access available.</Modal.Title>
//                 </Modal.Header>
//                 <Modal.Body>{body}</Modal.Body>
//                 <Modal.Footer>
//                     <Button variant="secondary" onClick={handleClose}>
//                         Close
//                     </Button>
//                 </Modal.Footer>
//             </Modal>

//             <Modal
//                 show={profileSuccess}
//                 onHide={() => handleClose()}
//                 backdrop="static"
//                 keyboard={false}
//             >
//                 <Modal.Header closeButton>
//                     <Modal.Title>Data Profiler Triggered.</Modal.Title>
//                 </Modal.Header>
//                 <Modal.Body>{body}</Modal.Body>
//                 <Modal.Footer>
//                     <Button
//                         variant="secondary"
//                         onClick={() => {
//                             handleClose();
//                             window.open(
//                                 "https://tdcldizcva002.ebiz.verizon.com:8446/dataQuality/mlProfileReports",
//                                 "_self"
//                             );
//                         }}
//                     >
//                         Close
//                     </Button>
//                 </Modal.Footer>
//             </Modal>
//         </Container>
//     );
// }

// const TextOutlineField = ({ label, value, name, onChange }) => {
//     return (
//         <>
//             <Form.Group className="mb-2" controlId="ControlInput7">

//                 <TextField required label={label} variant="outlined" value={value}
//                     name={name}
//                     onChange={onChange}
//                     size="small"
//                     fullWidth />
//             </Form.Group>
//         </>
//     );
// };

// export default SingleRowAllProjects;

import React, { useState, useEffect } from "react";
import axios from "axios";
import { Container, Row, Col, Form, Button, Breadcrumb, Modal } from "react-bootstrap";
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import TextField from '@mui/material/TextField';
import Autocomplete from '@mui/material/Autocomplete';
import Checkbox from '@mui/material/Checkbox';
import ListItemText from '@mui/material/ListItemText';
import Chip from '@mui/material/Chip';
import { CircularProgress } from "@mui/material";
import { useSelector } from "react-redux";


function SingleRowAllProjects() {
    const [formData, setFormData] = useState({
        data_source: "TD",
        project_name: "",
        dbname: "",
        table_name: "",
    });
    const [loading, setLoading] = useState(false);
    const [additionalFieldsVisible, setAdditionalFieldsVisible] = useState(false);
    const [show, setShow] = useState(false);
    const [body, setBody] = useState("");
    const [showModal, setShowModal] = useState(false);
    const [profileSuccess, setProfileSuccess] = useState(false);
    const [projectOptions, setProjectOptions] = useState([])
    const [dbOptions, setDbOptions] = useState([])
    const [tableOptions, setTableOptions] = useState([])
    const [dbOptionsTD, setDbOptionsTD] = useState([])
    const [tableOptionsTD, setTableOptionsTD] = useState([])
    const [projectLoading, setProjectLoading] = useState(false);
    const [dbLoading, setDBLoading] = useState(false);
    const [tableLoading, setTableLoading] = useState(false);
    const fieldNames = [
        'DATA_SRC', 'DB_NAME', 'SRC_TBL', 'SRC_COL',
        'Data_LOB', 'DATA_DMN', 'DATA_SUB_DMN', 'DATA_BUS_ELEM',
        'DQ_PILLAR', 'MEAS_NAME', 'MEAS_RULE_DESC', 'MEAS_RULE_SQL',
        'IS_ACTIVE_FLG', 'IS_CRITICAL_FLG', 'RULE_PRFL_SCHD_TS', 'RULE_MIN_THRSD',
        'RULE_MAX_THRSD', 'mail_sub', 'email_distro', 'invalid_rec_flg', 'invalid_rec_sql',
        'PRODUCT_NAME', 'PRODUCT_TYPE', 'PRODUCT_AREA', 'BUSINESS_PROGRAM'
    ];

    const user = useSelector((store) => store.userAuthorization.user);
    const userRole = user?.roles?.[0]?.name;

    const handleClose = () => {
        setShow(false);
        setShowModal(false);
        setProfileSuccess(false);
        if (body.includes('Connectivity/Access not available for')) {
            window.open("https://marketplace.verizon.com/#/subscriptionReqForm", "_blank");
        }
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prevState) => ({
            ...prevState,
            [name]: value,
        }));
    };

    // To fetch Project (GCP)
    useEffect(() => {
        // setProjectLoading(true);
        axios.get(`${process.env.REACT_APP_BASE_URL}self_serve2/SingleTableLoad/`)
            .then(response => {
                setProjectOptions(response.data.project_ids)
                setProjectLoading(false);
            })
            .catch(error => {
                console.error('Error fetching project ids:', error)
                setProjectLoading(false);
                alert('Error fetching project ids')
            })
    }, [])

    // To fetch DB Name(TD)
    useEffect(() => {
        axios.get(`${process.env.REACT_APP_BASE_URL}self_serve2/SingleTableLoadTD/`)
            .then(response => {
                setDbOptionsTD(response.data.DatabaseName.map(dbname => dbname.trim()))
            })
            .catch(error => {
                console.error('Error fetching Database Names:', error)
                alert('Error fetching Database Names')
            })
    }, [])

    // To fetch DB Name based on Project Name (GCP)
    useEffect(() => {
        if (formData.project_name) {
            axios.post(`${process.env.REACT_APP_BASE_URL}self_serve2/SingleTableLoad/`, {
                project_id: formData.project_name,
                dataset: formData.dbname

            }, {
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded",
                },
            })
                .then(response => {
                    if ('datasets' in response.data) {
                        setDbOptions(response.data.datasets)
                        setDBLoading(false);
                    }
                    else if ('table_names' in response.data) {
                        setTableOptions(response.data.table_names)
                        setTableLoading(false);
                    }
                })
                .catch(error => {
                    console.error('Error fetching project ids:', error)
                    setDBLoading(false);
                    setTableLoading(false);
                })
        }

    }, [formData.project_name, formData.dbname])

    // To fetch Table Name based on DB Name (TD)
    const fetchTableNames = (dbname) => {
        // setTableLoading(true);
        axios.post(`${process.env.REACT_APP_BASE_URL}self_serve2/SingleTableLoadTD/`, {
            DatabaseName: dbname
        }, {
            headers: {
                "Content-Type": "application/json",
            },
        })
            .then(response => {
                setTableOptionsTD(response.data.TableName.map(value => value.trim()))
                setTableLoading(false);
            })
            .catch(error => {
                console.error('Error fetching project ids:', error)
                setTableLoading(false);
            })
    }

    useEffect(() => {
        if (formData.dbname) {
            fetchTableNames(formData.dbname);
        }
    }, [formData.dbname]);

    const [tableWithAccess, setTableWithAccess] = useState([])
    const [formDataArray, setFormDataArray] = useState([])
    useEffect(() => {
        setFormDataArray(tableWithAccess.map((tableName) => ({
            DATA_SRC: formData.data_source,
            DB_NAME: formData.dbname,
            SRC_TBL: tableName,
            project_name: "",
            Data_LOB: "",
            DATA_DMN: "",
            DATA_SUB_DMN: "",
            DATA_BUS_ELEM: "",
            SRC_COL: "",
            DQ_PILLAR: "",
            MEAS_NAME: "",
            MEAS_RULE_DESC: "",
            MEAS_RULE_SQL: "",
            IS_ACTIVE_FLG: "",
            IS_CRITICAL_FLG: "",
            RULE_PRFL_SCHD_TS: "",
            RULE_MIN_THRSD: "",
            RULE_MAX_THRSD: "",
            mail_sub: "",
            email_distro: "",
            invalid_rec_flg: "",
            invalid_rec_sql: "",
            PRODUCT_NAME: "",
            PRODUCT_TYPE: "",
            PRODUCT_AREA: "",
            BUSINESS_PROGRAM: ""
        })));
    }, [tableWithAccess, formData]);
    const handleConnectivityCheck = () => {
        setLoading(true);
        console.log(formData);

        let data = {};

        if (formData.data_source === 'TD' && formData.dbname) {
            data = {
                "teradata_info": {
                    "dbname": formData.dbname,
                    "tables": selectedTables
                }
            };
        }
        else if (formData.data_source === 'GCP' && formData.dbname) {
            data = {
                "gcp_info": {
                    "project_id": formData.project_name,
                    "dataset": formData.dbname,
                    "tables": selectedTables
                }
            };
        }


        axios.post(`${process.env.REACT_APP_BASE_URL}self_serve2/ConnectionCheck/`,
            data,
            {
                headers: {
                    "Content-Type": "application/json",
                },
            }
        )
            .then((response) => {
                setLoading(false);
                console.log(response.data);

                let tablesWithAccess = '';
                let tablesWithoutAccess = '';

                if (response.data.GCP) {
                    tablesWithAccess = response.data.GCP.tables_with_access.map(table => table.trim()).join(', ');
                    tablesWithoutAccess = response.data.GCP.tables_without_access.map(table => table.trim()).join(', ');
                }

                if (response.data.TD) {
                    tablesWithAccess = response.data.TD.tables_with_access.map(table => table.trim()).join(', ');
                    tablesWithoutAccess = response.data.TD.tables_without_access.map(table => table.trim()).join(', ');
                }

                let body = '';

                if (tablesWithAccess) {
                    body += `Connectivity/Access available for ${tablesWithAccess}`;
                    setAdditionalFieldsVisible(true);
                    if (response.data.GCP) {
                        setTableWithAccess(response.data.GCP.tables_with_access);
                    }
                    else if (response.data.TD) {
                        setTableWithAccess(response.data.TD.tables_with_access);
                    }
                }

                if (tablesWithoutAccess) {
                    if (body.length > 0) {
                        body += ' and ';
                    }
                    body += `Connectivity/Access not available for ${tablesWithoutAccess}`;
                }

                setBody(body);
                setShowModal(true);
            })
            .catch((error) => {
                setLoading(false);
                console.error("Error checking connectivity:", error);
                alert("error in handling data");
            });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
    };

    const resetHandler = () => {
        setFormData((prevState) => ({
            ...prevState,
            data_source: "",
            project_name: "",
            dbname: "",
            table_name: "",
            Data_LOB: "",
            DATA_DMN: "",
            DATA_SUB_DMN: "",
            DATA_BUS_ELEM: "",
            DB_NAME: "",
            SRC_TBL: "",
            SRC_COL: "",
            DQ_PILLAR: "",
            MEAS_NAME: "",
            MEAS_RULE_DESC: "",
            MEAS_RULE_SQL: "",
            IS_ACTIVE_FLG: "",
            IS_CRITICAL_FLG: "",
            RULE_PRFL_SCHD_TS: "",
            DATA_SRC: "",
            RULE_MIN_THRSD: "",
            RULE_MAX_THRSD: "",
            mail_sub: "",
            email_distro: "",
            invalid_rec_flg: "",
            invalid_rec_sql: "",
            PRODUCT_NAME: "",
            PRODUCT_TYPE: "",
            PRODUCT_AREA: "",
            BUSINESS_PROGRAM: ""

        }));
        setAdditionalFieldsVisible(false);
    };

    const [selectedTables, setSelectedTables] = useState([])
    const handleTableChange = (event, newValue) => {
        newValue = newValue.map(value => value.trim())
        setSelectedTables(newValue);
    };

    return (
        <Container fluid className="">
            <Container fluid className="my-2 pt-3">
                <Breadcrumb>
                    <Breadcrumb.Item active>Profiling Services</Breadcrumb.Item>
                    <Breadcrumb.Item active>Auto Profile</Breadcrumb.Item>
                    <Breadcrumb.Item active>
                        <span className="fw-bold">Submit Auto Profile</span>
                    </Breadcrumb.Item>
                </Breadcrumb>
            </Container>

            <Container fluid className="mx-8 px-8 mb-2" >
                <h2 className="mb-2 text-center" style={{ color: "#EE0000" }}>
                    Submit Rule Profile
                </h2>
                <Form onSubmit={handleSubmit} style={{ display: additionalFieldsVisible ? "none" : "block" }}>
                    <Row className="justify-content-center align-items-center">
                        <Col xl={3}>
                            <fieldset disabled={additionalFieldsVisible || loading} >
                                <Form.Group className="mb-2" controlId="ControlInput1">

                                    <FormControl fullWidth>
                                        <InputLabel id="select-label">Environment</InputLabel>
                                        <Select
                                            labelId="select-label"
                                            id="select"
                                            value={formData.data_source}
                                            label="Environment"
                                            onChange={handleChange}
                                            name="data_source"

                                            size="small"
                                            disabled={additionalFieldsVisible || loading}
                                        >
                                            <MenuItem value="TD">TeraData</MenuItem>
                                            <MenuItem value="GCP">GCP</MenuItem>
                                        </Select>
                                    </FormControl>
                                </Form.Group>

                                <Form.Group
                                    className="mb-2"
                                    controlId="ControlInput2"
                                    style={{ display: formData.data_source === "GCP" ? "block" : "none" }}
                                >
                                    <Autocomplete
                                        options={projectOptions || []}
                                        autoHighlight
                                        fullWidth
                                        size="small"
                                        name="project_name"
                                        value={formData.project_name}
                                        required
                                        onChange={(_, value) => setFormData((prev) => ({ ...prev, project_name: value }))}
                                        renderInput={(params) => <TextField {...params} label="Project" variant="outlined" />}
                                    />
                                </Form.Group>

                                <Form.Group className="mb-2" controlId="ControlInput3">
                                    <Autocomplete
                                        style={{ display: (formData.data_source === "TD" || formData.data_source === "") || "" ? "block" : "none" }}
                                        options={dbOptionsTD || []}
                                        autoHighlight
                                        fullWidth
                                        size="small"
                                        name="dbname"
                                        // onChange={handleChange}
                                        value={formData.dbname}
                                        isOptionEqualToValue={(option, value) => option.id === value.id}
                                        required
                                        onChange={(_, value) => setFormData((prev) => ({ ...prev, dbname: value }))}
                                        renderInput={(params) => <TextField {...params} label="DB Name" variant="outlined" />}
                                    />
                                    <Autocomplete
                                        // id="combo-box"
                                        style={{ display: formData.data_source === "GCP" ? "block" : "none" }}
                                        options={dbOptions || []}
                                        autoHighlight
                                        fullWidth
                                        size="small"
                                        name="dbname"
                                        value={formData.dbname}
                                        required
                                        onChange={(_, value) => setFormData((prev) => ({ ...prev, dbname: value }))}
                                        renderInput={(params) => <TextField {...params} label="DB Name" variant="outlined" />}
                                    />
                                </Form.Group>

                                <Form.Group className="" controlId="ControlInput4">
                                    <Autocomplete
                                        style={{ display: (formData.data_source === "TD" || formData.data_source === "") ? "block" : "none" }}
                                        multiple
                                        // options={["Select All", ...tableOptionsTD] || []}
                                        options={tableOptionsTD || []}
                                        disableCloseOnSelect
                                        getOptionLabel={(option) => option}
                                        value={selectedTables}
                                        onChange={handleTableChange}
                                        required
                                        renderOption={(props, option, { selected }) => (
                                            <li {...props}>
                                                <Checkbox
                                                    checked={selected}
                                                />
                                                <ListItemText primary={option} />
                                            </li>
                                        )}
                                        renderInput={(params) => (
                                            <TextField {...params} variant="outlined" label="Table Name" placeholder={selectedTables.length === 0 ? "Select Table Name(s)" : ''}
                                                InputProps={{
                                                    ...params.InputProps,
                                                    style: { borderRadius: 0 },
                                                    endAdornment: (
                                                        <>
                                                            {tableLoading ? <CircularProgress color="inherit" size={20} /> : null}
                                                            {params.InputProps.endAdornment}
                                                        </>
                                                    ),
                                                }}
                                            />
                                        )}
                                        renderTags={(value, getTagProps) =>
                                            value.length > 2
                                                ? value.slice(0, 2).map((option, index) => (
                                                    <Chip key={option.id || index} variant="secondary" label={option} {...getTagProps({ index })} />
                                                )).concat(<Chip key='more' variant="outlined" label="..." />)
                                                : value.map((option, index) => (
                                                    <Chip key={option.id || index} variant="secondary" label={option} {...getTagProps({ index })} />
                                                ))
                                        }

                                        autoHighlight
                                        fullWidth
                                        size="small"
                                    />
                                    <Autocomplete
                                        multiple
                                        id="checkboxes-tags"
                                        // options={["Select All", ...tableOptions] || []}
                                        options={tableOptions || []}
                                        disableCloseOnSelect
                                        getOptionLabel={(option) => option}
                                        value={selectedTables}
                                        onChange={handleTableChange}
                                        autoHighlight
                                        fullWidth
                                        required
                                        size="small"
                                        style={{ display: (formData.data_source === "GCP") ? "block" : "none" }}
                                        renderOption={(props, option, { selected }) => (
                                            <li {...props}>
                                                <Checkbox
                                                    checked={selected}
                                                />
                                                <ListItemText primary={option} />
                                            </li>
                                        )}
                                        renderInput={(params) => (
                                            <TextField {...params} variant="outlined" label="Table Name" placeholder={selectedTables.length === 0 ? "Select Table Name(s)" : ''}
                                                InputProps={{
                                                    ...params.InputProps,
                                                    style: { borderRadius: 0 },
                                                    endAdornment: (
                                                        <>
                                                            {tableLoading ? <CircularProgress color="inherit" size={20} /> : null}
                                                            {params.InputProps.endAdornment}
                                                        </>
                                                    ),
                                                }}
                                            />
                                        )}
                                        renderTags={(value, getTagProps) =>
                                            value.length > 2
                                                ? value.slice(0, 2).map((option, index) => (
                                                    <Chip key={option.id || index} variant="secondary" label={option} {...getTagProps({ index })} />
                                                )).concat(<Chip key='more' variant="outlined" label="..." />)
                                                : value.map((option, index) => (
                                                    <Chip key={option.id || index} variant="secondary" label={option} {...getTagProps({ index })} />
                                                ))
                                        }


                                    />

                                </Form.Group>

                                {userRole === 'Executive' ? (<>
                                    <div className="d-flex justify-content-center my-2">
                                        <Button
                                            variant="dark"
                                            type="button"
                                            style={{
                                                display: additionalFieldsVisible ? "none" : "block",
                                                borderRadius: "25px",
                                            }}
                                        >
                                            Check For Connectivity
                                        </Button>
                                    </div></>) : (<>
                                        <div className="d-flex justify-content-center my-2">
                                            <Button
                                                variant="dark"
                                                type="button"
                                                onClick={handleConnectivityCheck}
                                                disabled={loading}
                                                style={{
                                                    display: additionalFieldsVisible ? "none" : "block",
                                                    borderRadius: "25px",
                                                }}
                                            >
                                                {loading ? "Checking..." : "Check For Connectivity"}
                                            </Button>
                                        </div></>)}

                            </fieldset>

                        </Col>

                    </Row>
                </Form>
                <Form style={{ display: additionalFieldsVisible ? "block" : "none" }}>


                    <Container fluid={tableWithAccess.length >= 2}>
                        <Row>


                            {formDataArray.map((form, index) => (
                                <Col key={index}>
                                    {fieldNames.map(fieldName => (
                                        // <Form.Group className="mb-2" key={fieldName}>
                                        <TextField
                                            className="mb-2"
                                            key={fieldName}
                                            required
                                            label={fieldName}
                                            variant="outlined"
                                            value={form[fieldName]}
                                            name={fieldName}
                                            onChange={e => {
                                                const newFormData = [...formDataArray];
                                                newFormData[index] = { ...newFormData[index], [fieldName]: e.target.value };
                                                setFormDataArray(newFormData);
                                            }}
                                            size="small"
                                            fullWidth
                                            style={fieldName === 'SRC_TBL' ? { position: 'sticky', top: '0', zIndex: 1000, backgroundColor: 'white' } : {}}
                                        />
                                        // </Form.Group>
                                    ))}
                                </Col>
                            ))}

                        </Row>
                    </Container>
                    <div className="d-flex justify-content-center mb-2">
                        <Button
                            variant="dark"
                            style={{ display: additionalFieldsVisible ? "block" : "none", borderRadius: '25px' }}
                            disabled={loading}
                            className="mx-2"
                            onClick={resetHandler}
                        >
                            Reset
                        </Button>
                        <Button
                            variant="dark"
                            type="submit"
                            disabled={loading}
                            style={{ display: additionalFieldsVisible ? "block" : "none", borderRadius: '25px' }}
                            className="mx-2"
                            onClick={handleSubmit}
                        >
                            {loading ? "loading..." : "Submit Profile"}
                        </Button>
                    </div>
                </Form>

            </Container>

            <></>

            <Modal show={show} onHide={() => handleClose()}>
                <Modal.Header closeButton>
                    <Modal.Title>Connectivity/Access does not exist.</Modal.Title>
                </Modal.Header>
                <Modal.Body>{body}</Modal.Body>
                <Modal.Footer>
                    <Button
                        variant="secondary"
                        onClick={() => {
                            handleClose();
                            window.open(
                                "https://marketplace.verizon.com/#/subscriptionReqForm",
                                "_blank"
                            );
                        }}
                    >
                        Close
                    </Button>
                </Modal.Footer>
            </Modal>

            <Modal show={showModal} onHide={() => handleClose()}>
                <Modal.Header closeButton>
                    <Modal.Title>Connectivity/Access available.</Modal.Title>
                </Modal.Header>
                <Modal.Body>{body}</Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleClose}>
                        Close
                    </Button>
                </Modal.Footer>
            </Modal>

            <Modal
                show={profileSuccess}
                onHide={() => handleClose()}
                backdrop="static"
                keyboard={false}
            >
                <Modal.Header closeButton>
                    <Modal.Title>Data Profiler Triggered.</Modal.Title>
                </Modal.Header>
                <Modal.Body>{body}</Modal.Body>
                <Modal.Footer>
                    <Button
                        variant="secondary"
                        onClick={() => {
                            handleClose();
                        }}
                    >
                        Close
                    </Button>
                </Modal.Footer>
            </Modal>
        </Container >
    );
}




export default SingleRowAllProjects;


