import { Tabs, Tab } from "@vds/tabs"
import { Title } from "@vds/typography"
import { Breadcrumbs,BreadcrumbItem } from "@vds/breadcrumbs"
import OneCorpMultiRequest from "./OneCorpMultiRequest"
import OneCorpRestart from './OneCorpRestart'
import OneCorpViewEdit from './OneCorpViewEdit'
import styles from './OneCorp.module.css'

const OneCorp= () => {
  return (
    <>
      <div className={styles.section}>
        <div className={styles.subHeading}>
          <Title
            size="medium"
            bold={true}
            color="#000">
            OneCorp Rule Profile
          </Title>
          <Breadcrumbs surface="light">
            <BreadcrumbItem>Profiling</BreadcrumbItem>
            <BreadcrumbItem>Rule Profile</BreadcrumbItem>
            <BreadcrumbItem>OneCorp</BreadcrumbItem>
          </Breadcrumbs>
        </div>
        <div className={styles.content}>
          <Tabs orientation="horizontal" indicatorPosition="bottom" size="medium">
            <Tab label="Submit Multiple Requests">
              <OneCorpMultiRequest />
            </Tab>
            <Tab label="OneCorp Restart">
              <OneCorpRestart />
            </Tab>
            <Tab label="View/Edit Request">
              <OneCorpViewEdit />
            </Tab>
          </Tabs>
        </div>
      </div>
    </>
  )
}
export default OneCorp