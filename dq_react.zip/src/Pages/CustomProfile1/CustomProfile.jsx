import { useState, useRef } from "react";
import { Container, Row, Col, Form } from "react-bootstrap";
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import TextField from '@mui/material/TextField';
import Select from '@mui/material/Select';
import ModalComponent from "../../Components/LayoutComponents/ModalComponent";
import dqaas_custom_prfl_mtd from "../../assets/CSV Files/dqaas_custom_prfl_mtd.csv";
import { usePostCustomProfileMutation } from '../../features/api/djangoapiSlice'
import { Loader, Breadcrumbs, BreadcrumbItem, Title, Button } from '@vds/core'
import styles from './CustomProfile.module.css'

const CustomProfile = () => {
    const [show, setShow] = useState(false);
    const [modalTitle, setModalTitle] = useState("");
    const [modalBody, setModalBody] = useState("");
    const [profileType, setProfileType] = useState('');
    const [email, setEmail] = useState('');

    const [postCustomProfile, { isLoading: ispostL2DataLoading }] = usePostCustomProfileMutation();

    const fileInputRef = useRef(null);

    const handleClose = () => {
        setShow(false);
        resetHandler();
    };

    const handleProfileTypeChange = (event) => {
        setProfileType(event.target.value);
    };

    const handleCustomProfileSubmit = (e) => {
        e.preventDefault();
        const file = fileInputRef.current.files[0];
        if (!file) {
            setModalTitle("");
            setModalBody("Please select a file");
            setShow(true);
            return;
        }
        if (profileType === '') {
            setModalTitle("");
            setModalBody("Please select a profile type");
            setShow(true);
            return;
        }
        if (email === '') {
            setModalTitle("");
            setModalBody("Please enter a valid email");
            setShow(true);
            return;
        }
        const formData = new FormData();
        formData.append("profileType", profileType);
        formData.append("requestorEmail", email);
        formData.append("fileName", file);
        postCustomProfile(formData).unwrap()
            .then((response) => {
                console.log(response.message);
                const [title, ...bodyParts] = response.message.split("File Path:");
                setModalTitle(title.trim());
                setModalBody(bodyParts.join("File Path:").trim());
                setShow(true);
            })
            .catch((response) => {
                console.log(response);
                const [title, ...bodyParts] = response.error.split("File Path:");
                setModalTitle(title.trim());
                setModalBody(bodyParts.join("File Path:").trim());
                setShow(true);
            });
    };
    const resetHandler = () => {
        fileInputRef.current.value = "";
        setProfileType('');
        setEmail('');
    };
    return (<>
        <div className={styles.section}>
            <div className={styles.subHeading}>
                <Title
                    size="medium"
                    bold={true}
                    color="#000">
                    Custom Profile
                </Title>
                <Breadcrumbs surface="light">
                    <BreadcrumbItem>Profiling</BreadcrumbItem>
                    <BreadcrumbItem>Custom Profile</BreadcrumbItem>
                </Breadcrumbs>
            </div>
            <div className={styles.content}>
                <div className={styles.mainContent}>
                    <Container fluid className="mx-8 px-8 mb-2">
                        <Row className="justify-content-center align-items-center my-5">
                            <Col xl={7} lg={12} md={12} sm={12} xs={12}>
                                <Container fluid className="px-5 py-3">
                                    <div style={{ display: 'flex', gap: '0.5em' }}>
                                        <div style={{ width: '50%' }}>
                                            <FormControl fullWidth>
                                                <InputLabel id="simple-select-label">Profile Type</InputLabel>
                                                <Select
                                                    labelId="select-label"
                                                    id="simple-select"
                                                    value={profileType}
                                                    label="Profile Type"
                                                    // size="small"
                                                    onChange={handleProfileTypeChange}
                                                >
                                                    <MenuItem value={"CUSTOM"}>update custom profile metadata</MenuItem>
                                                    <MenuItem value={"MICRO"}>update microsegment metadata</MenuItem>
                                                    <MenuItem value={"PRODUCT"}>update product metadata</MenuItem>
                                                    <MenuItem value={"MAIL"}>update mail distro</MenuItem>
                                                </Select>
                                            </FormControl>
                                        </div>
                                        <div style={{ width: '50%' }}>
                                            <TextField fullWidth id="outlined" label="Email" variant="outlined"
                                                value={email}
                                                onChange={(e) => setEmail(e.target.value)}
                                            />
                                        </div>
                                    </div>

                                    <Form.Group controlId="file1" className="my-3">
                                        <Form.Control type="file" accept=".csv" ref={fileInputRef} />
                                    </Form.Group>

                                    <a
                                        href={dqaas_custom_prfl_mtd}
                                        download
                                        className="text-decoration-none text-danger"
                                    >
                                        <span style={{ color: "#EE0000" }}>
                                            Download sample Template(CSV)
                                        </span>
                                    </a>
                                    <div className="d-flex justify-content-center gap-2 my-4">
                                        <Button onClick={resetHandler}>
                                            Reset
                                        </Button>
                                        <Button onClick={handleCustomProfileSubmit}>
                                            Submit
                                        </Button>
                                    </div>
                                </Container>
                            </Col>
                        </Row>
                    </Container >
                </div>
            </div>
        </div>

        <ModalComponent
            show={show}
            handleClose={handleClose}
            modalTitle={modalTitle}
            modalBody={modalBody}
        />
        <Loader
            fullscreen={true}
            active={ispostL2DataLoading}
            surface="dark"
        />
    </>)
}

export default CustomProfile;