import { useRef, useCallback, useEffect, useState, useMemo } from 'react';
import PropTypes from 'prop-types';
import Chart from 'chart.js/auto';
import { Title } from '@vds/typography';
import truncateDecimal from '../../utils/truncateDecimal';
import styles from './Home.module.css';
import {
    strokeColorHigh,
    strokeColorMedium,
    strokeColorLow,
    vdsColorHigh,
    vdsColorMedium,
    vdsColorLow,
} from '../../utils/colors';

const DQReportBarChart = ({ dqScore }) => {
    const [sortedTables, setSortedTables] = useState([]);
    const barChartRef = useRef(null);

    const getColor = useCallback((value) => {
        if (value > 90) return { bg: vdsColorHigh, border: strokeColorHigh };
        if (value > 80) return { bg: vdsColorMedium, border: strokeColorMedium };
        return { bg: vdsColorLow, border: strokeColorLow };
    }, []);

    const axisConfig = useMemo(() => ({
        x: {
            display: true,
            grid: { display: false },
            ticks: { display: true, color: '#000' },
            border: { color: '#000' },
        },
        y: {
            display: true,
            grid: { display: false },
            ticks: {
                display: true,
                color: '#000',
                callback: (value) => (value === 0 ? '0' : `${value}%`),
            },
            border: { color: '#000' },
            beginAtZero: true,
        },
    }), []);

    useEffect(() => {
        if (dqScore.length > 0) {
            const dqScoreObj = dqScore[0];
            const dqScorePG = ["Overall DQ Score", dqScoreObj["OVERALL_AVG_DQ_SCORE_PG"]];
            const sortedArray = Object.entries(dqScoreObj)
                .sort((a, b) => parseFloat(a[1]) - parseFloat(b[1]))
                .filter(([key]) => key !== 'OVERALL_AVG_integrity_PG' && key !== 'OVERALL_AVG_DQ_SCORE_PG')
                .map(([key, value]) => {
                    let newKey = key.replace('OVERALL_AVG_', '').replace('_PG', '').toLowerCase();
                    newKey = newKey.charAt(0).toUpperCase() + newKey.slice(1);
                    return [newKey, value];
                });
            sortedArray.push(dqScorePG);
            const sortedObject = Object.fromEntries(sortedArray);
            setSortedTables([sortedObject]);
        }
    }, [dqScore]);

    const chartConfig = useMemo(() => ({
        type: 'bar',
        data: {
            labels: sortedTables.length > 0 ? Object.keys(sortedTables[0]) : [],
            datasets: [{
                label: 'DQ Score',
                data: sortedTables.length > 0 ? Object.values(sortedTables[0]).map((value) => truncateDecimal(Number(value), 2)) : [],
                backgroundColor: (context) => getColor(context.raw).bg,
                borderColor: (context) => getColor(context.raw).border,
                borderWidth: 1.5,
            }],
        },
        options: {
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
            },
            scales: {
                x: { ...axisConfig.x },
                y: { ...axisConfig.y },
            },
        },
        plugins: [{
            id: 'datalabels',
            afterDatasetsDraw: (chart) => {
                const ctx = chart.ctx;
                chart.data.datasets.forEach((dataset, i) => {
                    const meta = chart.getDatasetMeta(i);
                    meta.data.forEach((point, index) => {
                        const value = dataset.data[index];
                        ctx.fillStyle = '#000';
                        ctx.fillText(`${value}%`, point.x - 20, point.y + (point.height / 10));
                    });
                });
            },
        }],
    }), [sortedTables, axisConfig, getColor]);

    useEffect(() => {
        const createChart = (ref, config) => {
            if (!ref.current) return;
            const ctx = ref.current.getContext('2d');
            const chart = new Chart(ctx, config);
            return () => chart.destroy();
        };

        const cleanupMainChart = createChart(barChartRef, chartConfig);

        return () => {
            cleanupMainChart();
        };
    }, [chartConfig]);

    return (
        <div className={styles.barChart}>
            <div className={styles.barChartHeader}>
                <Title size="small" bold color="#000">
                    DQ Report
                </Title>
            </div>
            <div className={styles.barChartBody}>
                <canvas ref={barChartRef}></canvas>
            </div>
        </div>
    );
};

DQReportBarChart.propTypes = {
    dqScore: PropTypes.arrayOf(PropTypes.object).isRequired,
};

export default DQReportBarChart;