import { useState, useEffect, useCallback } from "react";
import { Autocomplete, Checkbox, ListItemText, TextField, CircularProgress, Chip } from '@mui/material';
import parse from 'autosuggest-highlight/parse';
import match from 'autosuggest-highlight/match';
import { Button } from "@vds/buttons";
import { Title } from "@vds/typography";
import _ from 'lodash';
import { useGetDQTrendQuery } from '../../features/api/djangoapiSlice';
// import { useGetProjectListQuery, usePostSSUIReportDataMutation, useGetDQTrendQuery } from '../../features/api/djangoapiSlice';
import { useGetSSUIReportDataQuery, usePostSSUIReportDataMutation } from '../../features/api/nodeapiSlice';
import DQReportBarChart from "./DQReportBarChart";
import DQReportLineChart from "./DQReportLineChart";
import GraphLoader from '../../Components/LayoutComponents/GraphLoader';
import styles from './Home.module.css';

const Home = () => {
  const [state, setState] = useState({
    allProjects: [],
    selectedProjects: [],
    alternativeText: "",
    dqScore: []
  });

  const { data: dqTrendData, isLoading: isDqTrendDataLoading } = useGetDQTrendQuery();
  const { data: projectData, isLoading: projectLoading } = useGetSSUIReportDataQuery();
  const [fetchDQReport, { isLoading: isReportLoading }] = usePostSSUIReportDataMutation();


  const fetchDQReportHandler = useCallback((projects) => {
    const debouncedFetch = _.debounce(async () => {
      if (!projects?.length) {
        setState(prev => ({ ...prev, alternativeText: "Please select a project" }));
        return;
      }

      try {
        const response = await fetchDQReport({ BUSINESS_PROGRAM: projects }).unwrap();
        setState(prev => ({
          ...prev,
          dqScore: response,
          alternativeText: !response.length || !response[0]?.OVERALL_AVG_DQ_SCORE_PG
            ? "No DQ Report found"
            : ""
        }));
      } catch (error) {
        console.error("Error:", error);
        setState(prev => ({ ...prev, alternativeText: "Error loading report" }));
      }
    }, 500);

    debouncedFetch();
  }, [fetchDQReport, setState]);


  const handleProjectChange = (_, selectedOption) => {
    if (!selectedOption) return;

    const newSelection = selectedOption.includes("Select All")
      ? state.selectedProjects.length === state.allProjects.length
        ? []
        : [...state.allProjects]
      : selectedOption;

    setState(prev => ({ ...prev, selectedProjects: newSelection }));
  };
  useEffect(() => {
    if (projectData?.business_programs) {
      const uniquePrograms = [...new Set(projectData.business_programs)];
      setState(prev => ({
        ...prev,
        allProjects: uniquePrograms,
        selectedProjects: prev.selectedProjects.length ? prev.selectedProjects : uniquePrograms
      }));
      fetchDQReportHandler(uniquePrograms);
    }
  }, [projectData, fetchDQReportHandler]);

  return (
    <div className={styles.section}>
      <header className={styles.subHeading}>
        <Title size="large" bold color="#000">Home</Title>
      </header>

      <main className={styles.content}>
        <div className={styles.searchbar}>
          <Autocomplete
            multiple
            options={["Select All", ...state.allProjects]}
            value={state.selectedProjects}
            onChange={handleProjectChange}
            disableCloseOnSelect
            renderOption={(props, option, { selected, inputValue }) => {
              const matches = match(option, inputValue, { insideWords: true });
              const parts = parse(option, matches);

              return (
                <li {...props}>
                  <Checkbox checked={option === "Select All"
                    ? state.selectedProjects.length === state.allProjects.length
                    : selected}
                  />
                  <ListItemText>
                    {parts.map((part, index) => (
                      <span
                        key={index}
                        style={{
                          fontWeight: part.highlight ? 700 : 400,
                        }}
                      >
                        {part.text}
                      </span>
                    ))}
                  </ListItemText>
                </li>
              );
            }}

            style={{ minWidth: 650 }}
            size="small"
            renderInput={(params) => (
              <TextField
                {...params}
                variant="outlined"
                label="Projects"
                placeholder={!state.selectedProjects.length ? "Select Projects" : ''}
                slotProps={{
                  input: {
                    ...params.InputProps,
                    style: { borderRadius: 0 },
                    endAdornment: (
                      <>
                        {projectLoading && <CircularProgress size={20} />}
                        {params.InputProps.endAdornment}
                      </>
                    ),
                  }
                }}
              />
            )}

            renderTags={(value, getTagProps) =>
              value.length > 2
                ? [
                  ...value.slice(0, 2).map((option, index) => (
                    <Chip
                      key={`chip-${option}-${index}`}
                      variant="secondary"
                      label={option}
                      {...getTagProps({ index })}
                    />
                  )),
                  <Chip
                    key="more-chip"
                    variant="outlined"
                    label="..."
                  />
                ]
                : value.map((option, index) => (
                  <Chip
                    key={`chip-${option}-${index}`}
                    variant="secondary"
                    label={option}
                    {...getTagProps({ index })}
                  />
                ))
            }

          />
          <Button
            size="small"
            use="primary"
            style={{
              width: '9.1rem',
              borderRadius: 0,
              height: state.selectedProjects.length ? '3rem' : '2.5rem'
            }}
            onClick={() => fetchDQReportHandler(state.selectedProjects)}
            disabled={isReportLoading}
          >
            Fetch DQ Report
          </Button>
        </div>

        <div className={styles.card}>
          <div className={styles.barchartCard}>
            {isReportLoading || projectLoading || !state.dqScore.length ? (
              <div className={styles.loader}><GraphLoader /></div>
            ) : state.alternativeText ? (
              <div className={styles.message}>{state.alternativeText}</div>
            ) : (
              <DQReportBarChart dqScore={state.dqScore} />
            )}
          </div>
          <div className={styles.linechartCard}>
            <DQReportLineChart
              dqTrendData={dqTrendData}
              isDqTrendDataLoading={isDqTrendDataLoading}
            />
          </div>
        </div>
      </main>
    </div>
  );
};

export default Home;
