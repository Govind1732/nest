import React from 'react';
import { Autocomplete, Checkbox, ListItemText, TextField, CircularProgress, Chip } from '@mui/material';

const ProjectSelector = ({ 
  allProjects, 
  selectedProjects, 
  isLoading, 
  onChange 
}) => (
  <Autocomplete
    multiple
    options={["Select All", ...allProjects]}
    value={selectedProjects}
    onChange={onChange}
    disableCloseOnSelect
    renderOption={(props, option, { selected }) => (
      <li {...props}>
        <Checkbox checked={option === "Select All" 
          ? selectedProjects.length === allProjects.length 
          : selected} 
        />
        <ListItemText primary={option} />
      </li>
    )}
    renderInput={(params) => (
      <TextField 
        {...params} 
        variant="outlined" 
        label="Projects"
        placeholder={!selectedProjects.length ? "Select your Projects" : ''}
        InputProps={{
          ...params.InputProps,
          className: 'project-selector-input',
          endAdornment: (
            <>
              {isLoading && <CircularProgress size={20} />}
              {params.InputProps.endAdornment}
            </>
          ),
        }}
      />
    )}
    renderTags={(value, getTagProps) =>
      value.length > 2
        ? [...value.slice(0, 2).map((option, index) => (
            <Chip 
              key={option} 
              variant="secondary" 
              label={option} 
              {...getTagProps({ index })} 
            />
          )), <Chip key="more" variant="outlined" label="..." />]
        : value.map((option, index) => (
            <Chip 
              key={option} 
              variant="secondary" 
              label={option} 
              {...getTagProps({ index })} 
            />
          ))
    }
  />
);

export default ProjectSelector;
