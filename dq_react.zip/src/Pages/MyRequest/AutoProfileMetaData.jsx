import { useEffect, useState } from 'react';
import { Container, Row, Col, Form, Button, Modal } from 'react-bootstrap';
import Backdrop from '@mui/material/Backdrop';
import { GridLoader } from 'react-spinners';
import { TableContainer, Table, TableHead, TableBody, TableRow, TableCell, Paper, IconButton, TablePagination } from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import SaveIcon from '@mui/icons-material/Save';
import LoadingButton from '@mui/lab/LoadingButton';
import { Textarea } from '@mui/joy';
import TextField from '@mui/material/TextField';
import Autocomplete from '@mui/material/Autocomplete';
import {
    useGetAutoPrflMyRequestDataQuery,
    useGetDropdownDbAutoMLEMtdDataQuery,
    usePostDropdownDbAutoMLEMtdMutation,
    usePostViewEditAutoMLEMtdMutation,
    usePostSaveAutoMLEMtdMutation,
} from '../../features/api/djangoapiSlice';

const AutoProfileMetaData = () => {
    const { data: autoPrflData } = useGetAutoPrflMyRequestDataQuery();
    const { data: dbNamesData } = useGetDropdownDbAutoMLEMtdDataQuery();
    const [fetchTableNames] = usePostDropdownDbAutoMLEMtdMutation();
    const [fetchViewEditData] = usePostViewEditAutoMLEMtdMutation();
    const [postSaveAutoMLEMtd] = usePostSaveAutoMLEMtdMutation();
    const [formData, setFormData] = useState({
        db_name: null,
        table_name: null,
    });
    const [submitToggle, setSubmitToggle] = useState(false);
    const [editingRow, setEditingRow] = useState(null);
    const [tableData, setTableData] = useState([]);
    const [loading, setLoading] = useState(false);
    const [dataNotFound, setDataNotFound] = useState('');
    const [dbOptions, setDbOptions] = useState([]);
    const [tableOptions, setTableOptions] = useState([]);
    const [alert, setAlert] = useState(false);
    const [editedRow, setEditedRow] = useState({});
    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const [entireData, setEntireData] = useState([]);
    const [filteredDataVisible, setFilteredDataVisible] = useState(false);
    const [status, setStatus] = useState('');
    const [message, setMessage] = useState('');

    useEffect(() => {
        if (autoPrflData) {
            setEntireData(autoPrflData);
            setLoading(false);
        }
    }, [autoPrflData]);

    useEffect(() => {
        if (dbNamesData) {
            const dbOptions = Array.isArray(dbNamesData?.distinct_db)
                ? dbNamesData?.distinct_db.map(option => option?.db_name || '')
                : [];
            setDbOptions(dbOptions);
        }
    }, [dbNamesData]);
    useEffect(() => {
        const getTableNames = async () => {
            if (formData.db_name) {
                try {
                    console.log('Fetching table names for DB:', formData.db_name);
                    const response = await fetchTableNames({ DB_NAME: formData.db_name }).unwrap();
                    console.log('Fetching table names:', response);
                    setTableOptions(Array.isArray(response) ? response : []);
                } catch (error) {
                    console.error('Error:', error);
                }
            } else {
                setTableOptions([]);
            }
        };
        getTableNames();
    }, [formData.db_name, fetchTableNames]);

    const handleEdit = (index) => {
        setEditingRow(index);
        setEditedRow(tableData[index]);
    };

    const handleSave = async (index) => {
        try {
            setLoading(true);
            const response = await postSaveAutoMLEMtd({
                'prfl_tbl_id': editedRow.PRFL_TBL_ID ?? '',
                'data_lob': editedRow.DATA_Lob ?? '',
                "data_bus_elem": editedRow.DATA_BUS_ELEM ?? '',
                "data_dmn": editedRow.DATA_DMN ?? '',
                "data_sub_dmn": editedRow.DATA_SUB_DMN ?? '',
                "data_src": editedRow.DATA_SRC ?? '',
                "db_name": editedRow.DB_NAME ?? '',
                "src_tbl": editedRow.SRC_TBL ?? '',
                "incr_dt_col": editedRow.INCR_DT_COL ?? '',
                "incr_dt_cond": editedRow.INCR_DT_COND ?? 0,
                "unq_index_cols": editedRow.UNQ_INDEX_COLS ?? '',
                "auto_prfl_freq": editedRow.AUTO_PRFL_FREQ ?? '',
                "auto_prfl_schd_ts": editedRow.AUTO_PRFL_SCHD_TS ?? '',
                "email_dist": editedRow.EMAIL_DIST ?? '',
                "is_active_flg": editedRow.IS_ACTIVE_FLG ?? '',
                "is_complete_flg": editedRow.IS_COMPLETE_FLG ?? '',
                "is_critical_flg": editedRow.IS_CRITICAL_FLG ?? '',
                "tbl_cde": editedRow.TBL_CDE ?? ''
            }).unwrap();
            setEditingRow(null);
            setEditedRow({});
            setAlert(true);
            setStatus(response.status);
            setMessage(response.message);
        } catch (error) {
            console.error('Error saving edited row:', error);
            setAlert(true);
            setStatus('Error');
            setMessage('Error saving edited row :' + error);
        } finally {
            setLoading(false);
        }
    };

    const handleSubmit = async (e) => {
        if (e) e.preventDefault();
        setLoading(true);
        try {
            const response = await fetchViewEditData(formData).unwrap();
            setFilteredDataVisible(true);
            if (response.length === 0) {
                setDataNotFound('No such combination or files exist');
                setTableData([]);
            } else {
                setDataNotFound('');
                setTableData(response);
                setSubmitToggle(true);
            }
        } catch (error) {
            console.error('Error:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(+event.target.value);
        setPage(0);
    };

    const override = {
        display: 'block',
        margin: '0 auto',
        borderColor: 'red',
    };

    return (
        <Container fluid>
            <Container fluid className="my-2">
                <Form onSubmit={handleSubmit}>
                    <Row>
                        <Col xs={3}>
                            <Autocomplete
                                placeholder="Select your Option"
                                options={dbOptions}
                                autoHighlight
                                required
                                name="db_name"
                                size="small"
                                value={formData.db_name || null}
                                onChange={(_, value) => setFormData((prev) => ({ ...prev, db_name: value }))}
                                isOptionEqualToValue={(option, value) => option.toLowerCase() === value.toLowerCase()}
                                renderInput={(params) => <TextField {...params} variant="outlined" label="DB Name" />}
                            />
                        </Col>
                        <Col xs={3}>
                            <Autocomplete
                                placeholder="Select your Option"
                                options={tableOptions}
                                autoHighlight
                                required
                                name="table_name"
                                size="small"
                                value={formData.table_name || null}
                                onChange={(_, value) => setFormData((prev) => ({ ...prev, table_name: value }))}
                                isOptionEqualToValue={(option, value) => option.toLowerCase() === value.toLowerCase()}
                                renderInput={(params) => <TextField {...params} variant="outlined" label="Table Name" />}
                            />
                        </Col>
                        <Col xs={2}>
                            <Button variant="dark" type="submit" className="w-50">
                                Filter
                            </Button>
                        </Col>
                    </Row>
                </Form>
            </Container>

            {tableData.length > 0 ? (
                <Container fluid className='mt-3'>
                    <Paper sx={{ width: '100%', overflow: 'hidden' }}>
                        <TableContainer sx={{ maxHeight: 500 }}>
                            <Table stickyHeader aria-label="sticky table">
                                <TableHead>
                                    <TableRow>
                                        {tableData[0] &&
                                            Object.keys(tableData[0])
                                                .filter(key => key !== 'update_made_ts' && key !== 'entry_made_ts')
                                                .map((key) => (
                                                    <TableCell
                                                        key={key}
                                                        style={{ backgroundColor: 'black', color: 'white', border: '1px solid white', fontWeight: 'bold' }}
                                                    >
                                                        {key}
                                                    </TableCell>
                                                ))}
                                        <TableCell
                                            key="action"
                                            style={{ backgroundColor: 'black', color: 'white', border: '1px solid white', fontWeight: 'bold' }}
                                        >
                                            Action
                                        </TableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {tableData.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row, index) => (
                                        <TableRow key={index} hover role="checkbox" tabIndex={-1}>
                                            {Object.entries(row)
                                                .filter(([key]) => key !== 'update_made_ts' && key !== 'entry_made_ts')
                                                .map(([key, value], valueIndex) => (
                                                    <TableCell key={valueIndex}>
                                                        {editingRow === index && !['PRFL_TBL_ID', 'DB_NAME', 'SRC_TBL', 'DATA_SUB_DMN'].includes(key) ? (
                                                            <Textarea
                                                                aria-label="empty textarea"
                                                                defaultValue={value}
                                                                onChange={(e) =>
                                                                    setEditedRow((prevRow) => ({
                                                                        ...prevRow,
                                                                        [key]: e.target.value,
                                                                    }))
                                                                }
                                                            />
                                                        ) : (
                                                            value
                                                        )}
                                                    </TableCell>
                                                ))}
                                            <TableCell key={`action-${index}`}>
                                                {editingRow === index ? (
                                                    <LoadingButton loading={false} loadingPosition="start" startIcon={<SaveIcon />} onClick={() => handleSave(index)}>
                                                        Save
                                                    </LoadingButton>
                                                ) : (
                                                    <IconButton onClick={() => handleEdit(index)}>
                                                        <EditIcon /> Edit
                                                    </IconButton>
                                                )}
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </TableContainer>
                        <TablePagination
                            rowsPerPageOptions={[10, 20, 30, 40, 50, 100]}
                            component="div"
                            count={tableData.length}
                            rowsPerPage={rowsPerPage}
                            page={page}
                            onPageChange={handleChangePage}
                            onRowsPerPageChange={handleChangeRowsPerPage}
                        />
                    </Paper>
                </Container>
            ) : (
                <>
                    <Container className="d-flex justify-content-center m-2 blink">
                        <h5>{dataNotFound}</h5>
                    </Container>
                    {entireData.length > 0 && (
                        <Container fluid className='mt-3'>
                            <Paper sx={{ width: '100%', overflow: 'hidden' }}>
                                <TableContainer sx={{ maxHeight: 500 }}>
                                    <Table stickyHeader aria-label="sticky table">
                                        <TableHead>
                                            <TableRow>
                                                {entireData[0] &&
                                                    Object.keys(entireData[0])
                                                        .filter(key => key !== 'update_made_ts' && key !== 'entry_made_ts')
                                                        .map((key) => (
                                                            <TableCell
                                                                key={key}
                                                                style={{ backgroundColor: 'black', color: 'white', border: '1px solid white', fontWeight: 'bold' }}
                                                            >
                                                                {key}
                                                            </TableCell>
                                                        ))}
                                                <TableCell
                                                    key="action"
                                                    style={{ backgroundColor: 'black', color: 'white', border: '1px solid white', fontWeight: 'bold' }}
                                                >
                                                    Action
                                                </TableCell>
                                            </TableRow>
                                        </TableHead>
                                        <TableBody>
                                            {entireData.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row, index) => (
                                                <TableRow key={index} hover role="checkbox" tabIndex={-1}>
                                                    {Object.entries(row)
                                                        .filter(([key]) => key !== 'update_made_ts' && key !== 'entry_made_ts')
                                                        .map(([key, value], valueIndex) => (
                                                            <TableCell key={valueIndex}>
                                                                {editingRow === index && !['PRFL_TBL_ID', 'DB_NAME', 'SRC_TBL', 'DATA_SUB_DMN'].includes(key) ? (
                                                                    <Textarea
                                                                        aria-label="empty textarea"
                                                                        defaultValue={value}
                                                                        onChange={(e) =>
                                                                            setEditedRow((prevRow) => ({
                                                                                ...prevRow,
                                                                                [key]: e.target.value,
                                                                            }))
                                                                        }
                                                                    />
                                                                ) : (
                                                                    value
                                                                )}
                                                            </TableCell>
                                                        ))}
                                                    <TableCell key={`action-${index}`}>
                                                        {editingRow === index ? (
                                                            <LoadingButton loading={false} loadingPosition="start" startIcon={<SaveIcon />} onClick={() => handleSave(index)}>
                                                                Save
                                                            </LoadingButton>
                                                        ) : (
                                                            <IconButton onClick={() => handleEdit(index)}>
                                                                <EditIcon /> Edit
                                                            </IconButton>
                                                        )}
                                                    </TableCell>
                                                </TableRow>
                                            ))}
                                        </TableBody>
                                    </Table>
                                </TableContainer>
                                <TablePagination
                                    rowsPerPageOptions={[10, 20, 30, 40, 50, 100]}
                                    component="div"
                                    count={entireData.length}
                                    rowsPerPage={rowsPerPage}
                                    page={page}
                                    onPageChange={handleChangePage}
                                    onRowsPerPageChange={handleChangeRowsPerPage}
                                />
                            </Paper>
                        </Container>
                    )}
                </>
            )}

            <Backdrop sx={{ color: '#fff', zIndex: (theme) => theme.zIndex.drawer + 1 }} open={loading}>
                <Container className="loading-overlay">
                    <GridLoader color="#ff0000" loading={loading} cssOverride={override} size={20} aria-label="Loading Spinner" data-testid="loader" />
                </Container>
            </Backdrop>

            <Modal show={alert} onHide={() => {
                setAlert(false);
                handleSubmit();
            }}>
                <Modal.Header closeButton>
                    <Modal.Title>{status}</Modal.Title>
                </Modal.Header>
                <Modal.Body>{message}</Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={() => {
                        setAlert(false)
                        handleSubmit();
                    }}>
                        Close
                    </Button>
                </Modal.Footer>
            </Modal>
        </Container>
    );
};

export default AutoProfileMetaData;