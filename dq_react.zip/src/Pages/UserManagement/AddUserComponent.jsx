import React from 'react';
import { Container, Form, Button } from 'react-bootstrap'
import { TextField, FormControl, InputLabel, Select, MenuItem } from '@mui/material'
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';

const AddUserComponent = () => {

    return (
        <Container className='my-5'>
            {/* <h4 className='text-center ' style={{ color: '#EE0000' }}>Add User</h4> */}
            {/* <Container > */}
            <Form>
                <Box sx={{ flexGrow: 1 }}>
                    <Grid container spacing={3}>
                        <Grid item xs={6} md={6}>
                            <TextField
                                required
                                id="outlined-required"
                                label="First Name"
                                fullWidth
                            />

                        </Grid>
                        <Grid item xs={6} md={6}>
                            <TextField
                                required
                                id="outlined-required"
                                label="Last Name"
                                fullWidth
                            />

                        </Grid>
                        <Grid item xs={8} md={8}>
                            <TextField
                                required
                                id="outlined-required"
                                label="EMail ID"
                                fullWidth
                            />
                        </Grid>
                        <Grid item xs={4} md={4}>
                            <TextField
                                required
                                id="outlined-required"
                                label="Vzid"
                                fullWidth
                            />
                        </Grid>

                        <Grid item xs={6} md={6}>
                            <FormControl fullWidth>
                                <InputLabel id="demo-simple-select-label">Role</InputLabel>
                                <Select
                                    labelId="demo-simple-select-label"
                                    id="demo-simple-select"
                                    label="role"
                                // onChange={handleChange}
                                >
                                    <MenuItem value='OneCorp'>DQ Aanalyst</MenuItem>
                                    <MenuItem value='DTRan'>DQ Admin</MenuItem>
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item xs={6} md={6}>
                            <FormControl fullWidth>
                                <InputLabel id="demo-simple-select-label">Project(s)</InputLabel>
                                <Select
                                    labelId="demo-simple-select-label"
                                    id="demo-simple-select"
                                    // value={project}
                                    label="project"
                                // onChange={handleChange}
                                >
                                    <MenuItem value='OneCorp'>OneCorp</MenuItem>
                                    <MenuItem value='DTRan'>DTRan</MenuItem>
                                    <MenuItem value='MLE'>MLE</MenuItem>
                                </Select>
                            </FormControl>
                        </Grid>
                    </Grid>
                </Box>

                <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                    <Button variant="dark" type="submit" className='text-align-center my-3'>
                        Submit
                    </Button>
                </div>
            </Form>
            {/* </Container> */}
        </Container >
    )
}
export default AddUserComponent;