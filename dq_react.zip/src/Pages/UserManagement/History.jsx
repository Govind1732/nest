import React from 'react';
import { Container } from 'react-bootstrap';
const History = () => {
    return (<Container fluid>
        <h4 className='text-center' style={{ color: '#EE0000' }}>History</h4>
    </Container>)
}

export default History;