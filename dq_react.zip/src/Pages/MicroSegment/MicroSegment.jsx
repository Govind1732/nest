const MicroSegment=()=>{
    return(
        <div>
            <h1>MicroSegment</h1>
        </div>
    )
}
export default MicroSegment;