import { Container, Table, Image, Breadcrumb } from 'react-bootstrap'
import EmailIcon from '@mui/icons-material/Email';
import { Link } from 'react-router-dom'
// import styles from './Help.module.css'
import VideoFileIcon from '@mui/icons-material/VideoFile';
import VideoFileOutlinedIcon from '@mui/icons-material/VideoFileOutlined';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import PictureAsPdfOutlinedIcon from '@mui/icons-material/PictureAsPdfOutlined';
import slackImg from '../../assets/images/slack.jpg'
import { Breadcrumbs, BreadcrumbItem, Title } from "@vds/core"
import styles from './Help.module.css'
// src\assets\images\slack.jpg
const Help = () => {
    return (
        <>
            <div className={styles.section}>
                <div className={styles.subHeading}>
                    <Title
                        size="medium"
                        bold={true}
                        color="#000">
                        Knowledge Articles
                    </Title>
                    {/* <Breadcrumbs surface="light">
                        <BreadcrumbItem>API Integration</BreadcrumbItem>
                        <BreadcrumbItem>Help</BreadcrumbItem>
                    </Breadcrumbs> */}
                </div>
                <div className={styles.content}>
                    <div className={styles.mainContent}>
                        <Container fluid className=''>
                            <Container fluid className="">

                                {/* <div className='d-flex justify-content-center my-2'><h2 className='m-2 text-danger fw-bold'>Knowledge Articles</h2></div> */}

                                <Table hover responsive striped className='d-flex justify-content-center my-2'>
                                    <tbody>

                                        <tr>
                                            <td className='fw-bold'>What is Data Quality?</td>
                                            <td className='fw-bold'><Link to='#' className="text-decoration-none text-black"><span className="text-decoration mx-4"><PictureAsPdfIcon />PDF</span></Link> |
                                                {/* <Link to='/dataQuality/assets/DQ Knowledge Base/Overview of Data Quality Framework-20240201 0933-1' className="text-decoration-none text-black"><span className="text-decoration mx-4"><VideoFileIcon />VIDEO</span></Link> */}
                                                <Link to='https://drive.google.com/file/d/1Vo46sWyW9SG2xXnyB2KzwCTduwA6f9sz/view?usp=drive_link' target='blank' className="text-decoration-none text-black"><span className="text-decoration mx-4"><VideoFileIcon />VIDEO</span></Link>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td className='fw-bold'>How to onboard to Data Quality</td>
                                            <td className='fw-bold'><Link to='#' className="text-decoration-none text-black"><span className="text-decoration mx-4"><PictureAsPdfOutlinedIcon />PDF</span></Link> |
                                                {/* <Link to='#' className="text-decoration-none text-black"><span className="text-decoration mx-4"><VideoFileOutlinedIcon />VIDEO</span></Link> */}
                                                <Link to='https://drive.google.com/file/d/1G72Tcu7EnmjLbefaAHYgmdX-DhQSK01T/view?usp=drive_link' target='blank' className="text-decoration-none text-black"><span className="text-decoration mx-4"><VideoFileOutlinedIcon />VIDEO</span></Link>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td className='fw-bold'>How can I perform Auto Profiling</td>
                                            <td className='fw-bold'><Link to='https://drive.google.com/file/d/14g9qWp8G8OhooH87W1VvzaKm8x4p7Iq7/view?usp=drive_link' target="_blank" className="text-decoration-none text-black"><span className="text-decoration mx-4"><PictureAsPdfIcon />PDF</span></Link> |
                                                {/* <Link to='https://files.slack.com/files-tmb/T011UM83BV0-F06UYCLQ39P-119beef111/auto_prfl_walkthrough.mp4' className="text-decoration-none text-black" target="_blank"><span className="text-decoration mx-4"><VideoFileIcon />VIDEO</span></Link> */}
                                                <Link to='https://drive.google.com/file/d/1TbiM6ZpWjii_ZK4fo_7DmcU1KKlLHnb1/view?usp=drive_link' target='blank' className="text-decoration-none text-black"><span className="text-decoration mx-4"><VideoFileIcon />VIDEO</span></Link>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td className='fw-bold'>How can I perform Rule based Profiling</td>
                                            <td className='fw-bold'><Link to='https://drive.google.com/file/d/1-Vv-vsL_uyR6L0MNNuLkLg2tjkF6vTve/view?usp=drive_link' target="_blank" className="text-decoration-none text-black"><span className="text-decoration mx-4"><PictureAsPdfOutlinedIcon />PDF</span></Link> |
                                                {/* <Link to='https://files.slack.com/files-tmb/T011UM83BV0-F06UD3XCBQE-8e4a1e2a52/rule_prfl_walkthrough.mp4' className="text-decoration-none text-black" target="_blank"><span className="text-decoration mx-4"><VideoFileOutlinedIcon />VIDEO</span></Link> */}
                                                <Link to='https://drive.google.com/file/d/15w9Eic4AiHKl8CBdAhyr417zunTmC9UF/view?usp=drive_link' target='blank' className="text-decoration-none text-black"><span className="text-decoration mx-4"><VideoFileOutlinedIcon />VIDEO</span></Link>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td className='fw-bold'>How can I perform Auto ML Profiling</td>
                                            <td className='fw-bold'><Link to='https://drive.google.com/file/d/1JRfQUqa1oY4-nO7U9zny2BOIaVjNPOyP/view?usp=drive_link' target="_blank" className="text-decoration-none text-black"><span className="text-decoration mx-4"><PictureAsPdfIcon />PDF</span></Link> |
                                                <Link to='https://verizon.webex.com/verizon/ldr.php?RCID=e3794828b0b0b74d309ea27f36c9b7ce' className="text-decoration-none text-black" target="_blank"><span className="text-decoration mx-4"><VideoFileIcon />VIDEO</span></Link>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td className='fw-bold'>How to read Data Quality Email Alert?</td>
                                            <td className='fw-bold'><Link to='#' className="text-decoration-none text-black"><span className="text-decoration mx-4"><PictureAsPdfOutlinedIcon />PDF</span></Link> |
                                                {/* <Link to='#' className="text-decoration-none text-black"><span className="text-decoration mx-4"><VideoFileOutlinedIcon />VIDEO</span></Link> */}
                                                <Link to='https://drive.google.com/file/d/1IcjkcqfUTJbLCqdGvdne7CBgtFl5gA_Z/view?usp=drive_link' target='blank' className="text-decoration-none text-black"><span className="text-decoration mx-4"><VideoFileOutlinedIcon />VIDEO</span></Link>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td className='fw-bold'>How to read Data Quality Dashboard?</td>
                                            <td className='fw-bold'><Link to='#' className="text-decoration-none text-black"><span className="text-decoration mx-4"><PictureAsPdfIcon />PDF</span></Link> |
                                                {/* <Link to='#' className="text-decoration-none text-black"><span className="text-decoration mx-4"><VideoFileIcon />VIDEO</span></Link> */}
                                                <Link to='https://drive.google.com/file/d/1IcjkcqfUTJbLCqdGvdne7CBgtFl5gA_Z/view?usp=drive_link' target='blank' className="text-decoration-none text-black"><span className="text-decoration mx-4"><VideoFileOutlinedIcon />VIDEO</span></Link>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td className='fw-bold'>How to Subscribe to API  for ETL Pipeline?</td>
                                            <td className='fw-bold'><Link to='https://drive.google.com/file/d/1C62mZnHfd8labn2u4YEtBLsgF3rz_Gmo/view?usp=drive_link' target="_blank" className="text-decoration-none text-black"><span className="text-decoration mx-4"><PictureAsPdfOutlinedIcon />PDF</span></Link> | <Link to='https://verizon.webex.com/recordingservice/sites/verizon/recording/58b8ee5ade1d103c9fab02b99e1f5e90/playback' target="_blank" className="text-decoration-none text-black"><span className="text-decoration mx-4"><VideoFileOutlinedIcon />VIDEO</span></Link></td>
                                        </tr>
                                        <tr>
                                            <td className='fw-bold'>Whom to reach out for any issues in DQ Framework ?</td>
                                            <td className='fw-bold' >
                                                <Link
                                                    to="mailto:DQ-DEV-Team@verizon.com"
                                                    className="text-decoration-none text-black"
                                                >
                                                    <EmailIcon />
                                                    <span className="text-decoration">DQ-DEV-Team@verizon.com</span>

                                                </Link>
                                                <br />
                                                <Link
                                                    to="https://join.slack.com/share/enQtNzE5OTE0NDQwMTIwNS1iNWI5YTgxNDQxYWI0NWUxMjBlMjA1Y2VlNjA1YTEyMGU2YmIxMjEyMjY4N2EzMmNmMzhhOGU5YmViODRhZGQy"
                                                    className="text-decoration-none text-black"
                                                >
                                                    <Image src={slackImg} alt='slack Icon' style={{ width: 20, margin: 2 }} />
                                                    <span className="text-decoration">Slack Channel</span>

                                                </Link>
                                            </td>
                                        </tr>

                                    </tbody>
                                </Table>


                            </Container>
                        </Container>
                    </div>
                </div>
            </div>

        </>)
}
export default Help