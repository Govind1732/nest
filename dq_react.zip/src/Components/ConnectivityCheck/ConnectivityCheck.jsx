import { useState, useEffect, useCallback } from "react";
import { Modal } from "react-bootstrap";
import {Button} from "@vds/core"
import URLSearchParams from "url-search-params";
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import TextField from '@mui/material/TextField';
import Autocomplete from '@mui/material/Autocomplete';
import Backdrop from '@mui/material/Backdrop';
import CircularProgress from '@mui/material/CircularProgress';
import { useGetSingleTableLoadQuery, useGetSingleTableLoadTDQuery, usePostUiFetchMutation, usePostSingleTableLoadMutation, usePostSingleTableLoadTDMutation } from '../../features/api/djangoapiSlice';


function ConnectivityCheck({ additionalFieldsVisible, setAdditionalFieldsVisible, formData, setFormData }) {
    // const [formData, setFormData] = useState({
    //     data_source: "TD",
    //     project_name: "",
    //     dbname: "",
    //     table_name: "",
    // });
    // const [loading, setLoading] = useState(false);
    // const [additionalFieldsVisible, setAdditionalFieldsVisible] = useState(false);
    const [show, setShow] = useState(false);
    const [body, setBody] = useState("");
    const [showModal, setShowModal] = useState(false);
    const [projectOptions, setProjectOptions] = useState([])
    const [dbOptions, setDbOptions] = useState([])
    const [tableOptions, setTableOptions] = useState([])
    // const [dbOptionsTD, setDbOptionsTD] = useState([])
    // const [tableOptionsTD, setTableOptionsTD] = useState([])

    //TD
    const { data: getSingleTableLoadTD, isLoading: isgetSingleTableLoadTDLoading, isError: isgetSingleTableLoadTDError } = useGetSingleTableLoadTDQuery();
    const [postSingleTableLoadTD, { isLoading: ispostSingleTableLoadTDLoading, isError: postpostSingleTableLoadTDError }] = usePostSingleTableLoadTDMutation();
    //GCP
    const { data: getSingleTableLoadGCP, isLoading: isgetSingleTableLoadGCPLoading, isError: isgetSingleTableLoadGCPGCPError } = useGetSingleTableLoadQuery();
    const [postSingleTableLoadGCP, { isLoading: ispostSingleTableLoadGCPLoading, isError: postSingleTableLoadGCPError }] = usePostSingleTableLoadMutation();
    //Connectivity Check submit button
    const [postUiFetch, { isLoading: ispostUiFetchLoading, isError: ispostUiFetchError }] = usePostUiFetchMutation();

    useEffect(() => {
        if (getSingleTableLoadTD && formData.data_source === 'TD') {
            setDbOptions(getSingleTableLoadTD?.DatabaseName.map(dbname => dbname.trim()));
        }
        if (getSingleTableLoadGCP) {
            setProjectOptions(getSingleTableLoadGCP.project_ids);
        }
        if (formData.data_source === 'GCP') {
            setDbOptions([]);
            setProjectOptions(getSingleTableLoadGCP.project_ids);
        }

    }, [getSingleTableLoadTD, getSingleTableLoadGCP, formData.data_source]);

    // useEffect(() => {
    //     if (isgetSingleTableLoadTDError) {
    //     }
    //     if (postpostSingleTableLoadTDError) {
    //     }
    //     if (isgetSingleTableLoadGCPGCPError) {
    //     }
    //     if (postSingleTableLoadGCPError) {
    //     }
    //     if (ispostUiFetchError) {
    //     }
    // }, [isgetSingleTableLoadTDError, postpostSingleTableLoadTDError, isgetSingleTableLoadGCPGCPError, postSingleTableLoadGCPError, ispostUiFetchError]);

    const handleClose = () => {
        setShow(false);
        setShowModal(false);
        if (body.includes('Connectivity/Access not available for')) {
            window.open("https://marketplace.verizon.com/#/subscriptionReqForm", "_blank");
        }
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prevState) => ({
            ...prevState,
            [name]: value,
        }));
    };

    const fetchTableNames = useCallback(async (dbname) => {

        try {
            const response = await postSingleTableLoadTD({
                DatabaseName: dbname
            });
            setTableOptions(response.data.TableName.map(value => value.trim()));
        } catch (error) {
            console.error('Error fetching Table Names:', error);
            alert('Error fetching Table Names');
        }
    }, [postSingleTableLoadTD]);
    // To fetch Table Name based on DB Name (TD)
    useEffect(() => {
        console.log("fetchTableNames")
        if (formData.data_source === 'TD' && formData.dbname) {
            fetchTableNames(formData.dbname);
        }
        if (formData.data_source === 'TD') {
            if (getSingleTableLoadTD) {
                setDbOptions(getSingleTableLoadTD?.DatabaseName.map(dbname => dbname.trim()));
            }
        }
    }, [formData.dbname, formData.data_source, fetchTableNames, getSingleTableLoadTD]);

    const fetchGCPDBNames = useCallback(async (projectName) => {
        try {
            const response = await postSingleTableLoadGCP({
                project_id: projectName,
            });
            setDbOptions(response.data.datasets.map(value => value.trim()));
        } catch (error) {
            console.error('Error fetching Table Names:', error);
            alert('Error fetching Table Names');
        }
    }, [postSingleTableLoadGCP]);
    // To fetch DB Name based on Project Name (GCP)
    useEffect(() => {
        if (formData.data_source === 'GCP' && formData.project_name) {
            fetchGCPDBNames(formData.project_name);
        }
    }, [formData.data_source, formData.project_name, fetchGCPDBNames]);
    const fetchGCPTableNames = useCallback(async (dbname, projectName) => {
        try {
            const response = await postSingleTableLoadGCP({
                project_id: projectName,
                dataset: dbname
            });
            setTableOptions(response.data.table_names.map(value => value.trim()));
        } catch (error) {
            console.error('Error fetching Table Names:', error);
            alert('Error fetching Table Names');
        }
    }, [postSingleTableLoadGCP]);
    // To fetch Table Name based on DB Name and project ID (GCP)
    useEffect(() => {
        if (formData.data_source === 'GCP' && formData.dbname && formData.project_name) {
            fetchGCPTableNames(formData.dbname, formData.project_name);
        }
    }, [formData.dbname, formData.data_source, formData.project_name, fetchGCPTableNames]);


    const validateForm = () => {
        if (!formData.table_name) {
            alert("Table Name is required");
            return false;
        }
        return true;
    };

    const handleConnectivityCheck = async (e) => {
        const formDataUrlEncoded = new URLSearchParams();
        for (const [key, value] of Object.entries(formData)) {
            formDataUrlEncoded.append(key, value);
        }
        e.preventDefault();
        // setLoading(true)
        if (!validateForm()) {
            return;
        }
        try {
            const res = await postUiFetch(formDataUrlEncoded);
            console.log(res);
            if (res.data.combination_exists) {
                // setLoading(false)
                setShow(true);
                setBody("Click on close button to redirect to marketplace to raise a request");
            } else {
                // setLoading(false)
                setBody("Please fill the remaining fields for profiling");
                setShowModal(true);
                setAdditionalFieldsVisible(true);
            }
        } catch (error) {
            // setLoading(false)
            console.error("Error checking connectivity:", error);
        }
    };
    const resetHandler = () => {
        setFormData((prevState) => ({
            ...prevState,
            data_source: "TD",
            project_name: "",
            dbname: "",
            table_name: "",
        }));
        // setAdditionalFieldsVisible(false);
    };

    return (<>
        <form onSubmit={handleConnectivityCheck} style={{ display: "flex", flexDirection: 'column', justifyContent: 'center', alignItems: 'center', gap: '1em', disabled: 'true' }}>
            <FormControl fullWidth >
                <InputLabel id="select-label">Environment</InputLabel>
                <Select
                    labelId="select-label"
                    id="select"
                    value={formData.data_source}
                    label="Environment"
                    onChange={handleChange}
                    name="data_source"
                    size="small"
                    required
                    sx={{ width: '25vw' }}
                    disabled={additionalFieldsVisible}
                >
                    <MenuItem value="TD">TeraData</MenuItem>
                    <MenuItem value="GCP">GCP</MenuItem>
                </Select>
            </FormControl>

            {formData.data_source === "GCP" && (
                <Autocomplete
                    options={projectOptions || []}
                    autoHighlight
                    fullWidth
                    size="small"
                    name="project_name"
                    value={formData.project_name || null}
                    required
                    loading={isgetSingleTableLoadGCPLoading}
                    sx={{ width: '25vw' }}
                    disabled={additionalFieldsVisible}
                    onChange={(event, value) => handleChange({ target: { name: 'project_name', value } })}
                    isOptionEqualToValue={(option, value) => option === value || value === ""}
                    renderInput={(params) => <TextField {...params} label="Project" variant="outlined"
                        required={true}
                        InputProps={{
                            ...params.InputProps,
                            endAdornment: (
                                <>
                                    {(isgetSingleTableLoadGCPLoading) && <CircularProgress color="inherit" size={20} />}
                                    {params.InputProps.endAdornment}
                                </>
                            ),
                        }}
                    />}
                />
            )}
            <Autocomplete
                options={dbOptions || []}
                autoHighlight
                fullWidth
                size="small"
                name="dbname"
                value={formData.dbname || null}
                required
                sx={{ width: '25vw' }}
                disabled={additionalFieldsVisible}
                loading={isgetSingleTableLoadTDLoading || ispostSingleTableLoadGCPLoading}
                onChange={(event, value) => handleChange({ target: { name: 'dbname', value } })}
                isOptionEqualToValue={(option, value) => option === value || value === ""}
                renderInput={(params) => <TextField {...params} label="DB Name" variant="outlined"
                    required={true}
                    InputProps={{
                        ...params.InputProps,
                        endAdornment: (
                            <>
                                {((formData.data_source === 'TD' && isgetSingleTableLoadTDLoading) || ((formData.data_source === 'GCP' && formData.dbname === '') && ispostSingleTableLoadGCPLoading)) && <CircularProgress color="inherit" size={20} />}
                                {params.InputProps.endAdornment}
                            </>
                        ),
                    }}
                />}
            />
            <Autocomplete
                options={tableOptions || []}
                value={formData.table_name || null}
                required
                name='table_name'
                autoHighlight
                fullWidth
                size="small"
                sx={{ width: '25vw' }}
                disabled={additionalFieldsVisible}
                loading={ispostSingleTableLoadTDLoading || ispostSingleTableLoadGCPLoading}
                onChange={(event, value) => handleChange({ target: { name: 'table_name', value } })}
                isOptionEqualToValue={(option, value) => option === value || value === ""}
                renderInput={(params) => (
                    <TextField
                        {...params}
                        label="Table Name"
                        variant="outlined"
                        required={true}
                        InputProps={{
                            ...params.InputProps,
                            endAdornment: (
                                <>
                                    {((formData.data_source === 'TD' && ispostSingleTableLoadTDLoading) || ((formData.data_source === 'GCP' && formData.dbname !== '') && ispostSingleTableLoadGCPLoading)) && <CircularProgress color="inherit" size={20} />}
                                    {params.InputProps.endAdornment}
                                </>
                            ),
                        }}
                    />
                )}
            />
            <div style={{ display: additionalFieldsVisible? 'none':'flex', gap: '1em', justifyContent: 'center', alignItems: 'center' }}>
                <Button
                    use='secondary'
                    onClick={resetHandler}
                >
                    Reset
                </Button>
                <Button onClick={handleConnectivityCheck}>
                    {ispostUiFetchLoading ? "Checking..." : "Check For Connectivity"}
                </Button>
            </div>


        </form>

        <ModalComponent
            show={show}
            title="Connectivity/Access does not exist."
            body={body}
            onClose={handleClose}
            redirectUrl="https://marketplace.verizon.com/#/subscriptionReqForm"
        />

        <ModalComponent
            show={showModal}
            title="Connectivity/Access available."
            body={body}
            onClose={handleClose}
        />

        {(ispostUiFetchLoading) && (
            <Backdrop
                sx={{ color: '#ddd', zIndex: (theme) => theme.zIndex.drawer + 1 }}
                open={ispostUiFetchLoading}
            >
                <CircularProgress color="inherit" />
            </Backdrop>
        )}
    </>);
}

const ModalComponent = ({ show, title, body, onClose, redirectUrl }) => (
    <Modal show={show} onHide={onClose}>
        <Modal.Header closeButton>
            <Modal.Title>{title}</Modal.Title>
        </Modal.Header>
        <Modal.Body>{body}</Modal.Body>
        <Modal.Footer>
            <Button
                onClick={() => {
                    onClose();
                    if (redirectUrl) window.open(redirectUrl, "_blank");
                }}
            >
                Close
            </Button>
        </Modal.Footer>
    </Modal>
);

export default ConnectivityCheck
