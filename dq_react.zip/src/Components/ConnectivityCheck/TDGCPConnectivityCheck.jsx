import React, { useState, useEffect, useCallback } from "react";
import { Modal } from "react-bootstrap";
import { Button } from '@vds/core';
import URLSearchParams from "url-search-params";
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import TextField from '@mui/material/TextField';
import Autocomplete from '@mui/material/Autocomplete';
import Backdrop from '@mui/material/Backdrop';
import CircularProgress from '@mui/material/CircularProgress';
import _ from 'lodash';
import { useGetSingleTableLoadQuery, useGetSingleTableLoadTDQuery, usePostUiFetchMutation, usePostSingleTableLoadMutation, usePostSingleTableLoadTDMutation } from '../../features/api/djangoapiSlice';


function TDGCPConnectivityCheck({ handleConnectivityStatus, handleGCPData, handleTDData, onEmailChange }) {
    // const [formData, setFormData] = useState({
    //     data_source: "TD",
    //     project_name: "",
    //     dbname: "",
    //     table_name: "",
    // });
    const [TDformData, setTDFormData] = useState({
        data_source: "TD",
        dbname: "",
        table_name: "",
    });
    const [GCPformData, setGCPFormData] = useState({
        data_source: "GCP",
        project_name: "",
        dbname: "",
        table_name: "",
    });
    const [email, setEmail] = useState("");
    // const [loading, setLoading] = useState(false);
    const [additionalFieldsVisible, setAdditionalFieldsVisible] = useState(false);
    const [show, setShow] = useState(false);
    const [title, setTitle] = useState("")
    const [body, setBody] = useState("");
    const [showModal, setShowModal] = useState(false);
    const [projectOptionsGCP, setProjectOptionsGCP] = useState([])
    const [dbOptionsGCP, setDbOptionsGCP] = useState([])
    const [tableOptionsGCP, setTableOptionsGCP] = useState([])
    const [dbOptionsTD, setDbOptionsTD] = useState([])
    const [tableOptionsTD, setTableOptionsTD] = useState([])

    //TD
    const { data: getSingleTableLoadTD, isLoading: isgetSingleTableLoadTDLoading, isError: isgetSingleTableLoadTDError } = useGetSingleTableLoadTDQuery();
    const [postSingleTableLoadTD, { isLoading: ispostSingleTableLoadTDLoading, isError: postpostSingleTableLoadTDError }] = usePostSingleTableLoadTDMutation();
    //GCP
    const { data: getSingleTableLoadGCP, isLoading: isgetSingleTableLoadGCPLoading, isError: isgetSingleTableLoadGCPGCPError } = useGetSingleTableLoadQuery();
    const [postSingleTableLoadGCP, { isLoading: ispostSingleTableLoadGCPLoading, isError: postSingleTableLoadGCPError }] = usePostSingleTableLoadMutation();
    //Connectivity Check submit button
    const [postUiFetch, { isLoading: ispostUiFetchLoading, isError: ispostUiFetchError }] = usePostUiFetchMutation();

    useEffect(() => {
        if (getSingleTableLoadTD) {
            setDbOptionsTD(getSingleTableLoadTD?.DatabaseName.map(dbname => dbname.trim()));
        }
        if (getSingleTableLoadGCP) {
            setProjectOptionsGCP(getSingleTableLoadGCP.project_ids);
        }
    }, [getSingleTableLoadTD, getSingleTableLoadGCP]);

    useEffect(() => {
        if (isgetSingleTableLoadTDError) {
        }
        if (postpostSingleTableLoadTDError) {
        }
        if (isgetSingleTableLoadGCPGCPError) {
        }
        if (postSingleTableLoadGCPError) {
        }
        if (ispostUiFetchError) {
        }
    }, [isgetSingleTableLoadTDError, postpostSingleTableLoadTDError, isgetSingleTableLoadGCPGCPError, postSingleTableLoadGCPError, ispostUiFetchError]);

    const handleClose = () => {
        setShow(false);
        setShowModal(false);
        if (body.includes('Connectivity/Access not available for')) {
            window.open("https://marketplace.verizon.com/#/subscriptionReqForm", "_blank");
        }
    };

    const handleTDChange = (e) => {
        const { name, value } = e.target;
        setTDFormData((prevState) => ({
            ...prevState,
            [name]: value,
        }));
    };
    const handleGCPChange = (e) => {
        const { name, value } = e.target;
        setGCPFormData((prevState) => ({
            ...prevState,
            [name]: value,
        }));
    };
    const handleEmail = (e) => {
        setEmail(e.target.value);
        onEmailChange(e.target.value);
    };
    const fetchTableNames = useCallback(async (dbname) => {

        try {
            const response = await postSingleTableLoadTD({
                DatabaseName: dbname
            });
            setTableOptionsTD(response.data.TableName.map(value => value.trim()));
        } catch (error) {
            console.error('Error fetching Table Names:', error);
            alert('Error fetching Table Names');
        }
    }, [postSingleTableLoadTD]);
    // To fetch Table Name based on DB Name (TD)
    useEffect(() => {
        // console.log("fetchTableNames")
        if (TDformData.data_source === 'TD' && TDformData.dbname) {
            fetchTableNames(TDformData.dbname);
        }
        // if (formData.data_source === 'TD') {
        //     if (getSingleTableLoadTD) {
        //         setDbOptions(getSingleTableLoadTD?.DatabaseName.map(dbname => dbname.trim()));
        //     }
        // }
    }, [TDformData.dbname, TDformData.data_source, fetchTableNames]);

    const fetchGCPDBNames = useCallback(async (projectName) => {
        try {
            const response = await postSingleTableLoadGCP({
                project_id: projectName,
            });
            setDbOptionsGCP(response.data.datasets.map(value => value.trim()));
        } catch (error) {
            console.error('Error fetching Table Names:', error);
            alert('Error fetching Table Names');
        }
    }, [postSingleTableLoadGCP]);
    // To fetch DB Name based on Project Name (GCP)
    useEffect(() => {
        if (GCPformData.data_source === 'GCP' && GCPformData.project_name) {
            fetchGCPDBNames(GCPformData.project_name);
        }
    }, [GCPformData.data_source, GCPformData.project_name, fetchGCPDBNames]);
    const fetchGCPTableNames = useCallback(async (dbname, projectName) => {
        try {
            const response = await postSingleTableLoadGCP({
                project_id: projectName,
                dataset: dbname
            });
            setTableOptionsGCP(response.data.table_names.map(value => value.trim()));
        } catch (error) {
            console.error('Error fetching Table Names:', error);
            alert('Error fetching Table Names');
        }
    }, [postSingleTableLoadGCP]);
    // To fetch Table Name based on DB Name and project ID (GCP)
    useEffect(() => {
        if (GCPformData.data_source === 'GCP' && GCPformData.dbname && GCPformData.project_name) {
            fetchGCPTableNames(GCPformData.dbname, GCPformData.project_name);
        }
    }, [GCPformData.dbname, GCPformData.data_source, GCPformData.project_name, fetchGCPTableNames]);


    const validateForm = () => {
        if (!TDformData.table_name && !GCPformData.table_name) {
            alert("Table Name is required");
            return false;
        }
        return true;
    };

    const handleConnectivityCheck = async (e) => {
        const TDformDataUrlEncoded = new URLSearchParams();
        const GCPformDataUrlEncoded = new URLSearchParams();
        for (const [key, value] of Object.entries(TDformData)) {
            TDformDataUrlEncoded.append(key, value);
        }
        for (const [key, value] of Object.entries(GCPformData)) {
            GCPformDataUrlEncoded.append(key, value);
        }
        e.preventDefault();
        if (!validateForm()) {
            return;
        }
        try {
            const [TDResponse, GCPResponse] = await Promise.all([
                postUiFetch(TDformDataUrlEncoded),
                postUiFetch(GCPformDataUrlEncoded)
            ]);

            if (TDResponse.data.combination_exists && GCPResponse.data.combination_exists) {
                setShow(true);
                setTitle('Connectivity/Access does not exist for both TD and GCP');
                setBody("Click on close button to redirect to marketplace to raise a request");
            }
            else if (TDResponse.data.combination_exists && !GCPResponse.data.combination_exists) {
                setShow(true);
                setTitle('Connectivity/Access does not exist for TD');
                setBody("Click on close button to redirect to marketplace to raise a request");
            }
            else if (!TDResponse.data && GCPResponse.data) {
                setShow(true);
                setTitle('Connectivity/Access does not exist for GCP');
                setBody("Click on close button to redirect to marketplace to raise a request");
            }
            else {
                setBody("Please fill the remaining fields for profiling");
                setShowModal(true);
                setAdditionalFieldsVisible(true);
                handleConnectivityStatus(true);
                handleGCPData(GCPformData)
                handleTDData(TDformData);
            }
        } catch (error) {
            console.error("Error checking connectivity:", error);
        }
    };
    const resetHandler = () => {
        setTDFormData((prevState) => ({
            ...prevState,
            data_source: "TD",
            dbname: "",
            table_name: "",
        }));
        setGCPFormData((prevState) => ({
            ...prevState,
            data_source: "GCP",
            project_name: "",
            dbname: "",
            table_name: "",
        }));
        // setAdditionalFieldsVisible(false);
    };

    return (<>
        <form onSubmit={handleConnectivityCheck} style={{ display: "flex", flexDirection: 'column', justifyContent: 'center', alignItems: 'center', gap: '1em', disabled: 'true' }}>
            <div style={{ display: 'flex', gap: '1rem' }}>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                    <TextField label="Environment" variant="outlined" size='small' sx={{ width: '25vw' }} disabled={additionalFieldsVisible} value={GCPformData.data_source} />
                    <Autocomplete
                        options={projectOptionsGCP || []}
                        autoHighlight
                        fullWidth
                        size="small"
                        name="project_name"
                        value={GCPformData.project_name || null}
                        required
                        loading={isgetSingleTableLoadGCPLoading}
                        sx={{ width: '25vw' }}
                        disabled={additionalFieldsVisible}
                        onChange={(event, value) => handleGCPChange({ target: { name: 'project_name', value } })}
                        isOptionEqualToValue={(option, value) => option === value || value === ""}
                        renderInput={(params) => <TextField {...params} label="Project" variant="outlined"
                            required={true}
                            InputProps={{
                                ...params.InputProps,
                                endAdornment: (
                                    <>
                                        {(isgetSingleTableLoadGCPLoading) && <CircularProgress color="inherit" size={20} />}
                                        {params.InputProps.endAdornment}
                                    </>
                                ),
                            }}
                        />}
                    />
                    <Autocomplete
                        options={dbOptionsGCP || []}
                        autoHighlight
                        fullWidth
                        size="small"
                        name="dbname"
                        value={GCPformData.dbname || null}
                        required
                        sx={{ width: '25vw' }}
                        disabled={additionalFieldsVisible}
                        loading={ispostSingleTableLoadGCPLoading}
                        onChange={(event, value) => handleGCPChange({ target: { name: 'dbname', value } })}
                        isOptionEqualToValue={(option, value) => option === value || value === ""}
                        renderInput={(params) => <TextField {...params} label="DB Name" variant="outlined"
                            required={true}
                            InputProps={{
                                ...params.InputProps,
                                endAdornment: (
                                    <>
                                        {ispostSingleTableLoadGCPLoading && <CircularProgress color="inherit" size={20} />}
                                        {params.InputProps.endAdornment}
                                    </>
                                ),
                            }}
                        />}
                    />
                    <Autocomplete
                        options={tableOptionsGCP || []}
                        value={GCPformData.table_name || null}
                        required
                        name='table_name'
                        autoHighlight
                        fullWidth
                        size="small"
                        sx={{ width: '25vw' }}
                        disabled={additionalFieldsVisible}
                        loading={ispostSingleTableLoadGCPLoading}
                        onChange={(event, value) => handleGCPChange({ target: { name: 'table_name', value } })}
                        isOptionEqualToValue={(option, value) => option === value || value === ""}
                        renderInput={(params) => (
                            <TextField
                                {...params}
                                label="Table Name"
                                variant="outlined"
                                required={true}
                                InputProps={{
                                    ...params.InputProps,
                                    endAdornment: (
                                        <>
                                            {ispostSingleTableLoadGCPLoading && <CircularProgress color="inherit" size={20} />}
                                            {params.InputProps.endAdornment}
                                        </>
                                    ),
                                }}
                            />
                        )}
                    />

                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                    <TextField label="Environment" variant="outlined" size='small' sx={{ width: '25vw' }} disabled={additionalFieldsVisible} value={TDformData.data_source} />
                    <Autocomplete
                        options={dbOptionsTD || []}
                        autoHighlight
                        fullWidth
                        size="small"
                        name="dbname"
                        value={TDformData.dbname || null}
                        required
                        sx={{ width: '25vw' }}
                        disabled={additionalFieldsVisible}
                        loading={isgetSingleTableLoadTDLoading}
                        onChange={(event, value) => handleTDChange({ target: { name: 'dbname', value } })}
                        isOptionEqualToValue={(option, value) => option === value || value === ""}
                        renderInput={(params) => <TextField {...params} label="DB Name" variant="outlined"
                            required={true}
                            InputProps={{
                                ...params.InputProps,
                                endAdornment: (
                                    <>
                                        {isgetSingleTableLoadTDLoading && <CircularProgress color="inherit" size={20} />}
                                        {params.InputProps.endAdornment}
                                    </>
                                ),
                            }}
                        />}
                    />
                    <Autocomplete
                        options={tableOptionsTD || []}
                        value={TDformData.table_name || null}
                        required
                        name='table_name'
                        autoHighlight
                        fullWidth
                        size="small"
                        sx={{ width: '25vw' }}
                        disabled={additionalFieldsVisible}
                        loading={ispostSingleTableLoadTDLoading}
                        onChange={(event, value) => handleTDChange({ target: { name: 'table_name', value } })}
                        isOptionEqualToValue={(option, value) => option === value || value === ""}
                        renderInput={(params) => (
                            <TextField
                                {...params}
                                label="Table Name"
                                variant="outlined"
                                required={true}
                                InputProps={{
                                    ...params.InputProps,
                                    endAdornment: (
                                        <>
                                            {ispostSingleTableLoadTDLoading && <CircularProgress color="inherit" size={20} />}
                                            {params.InputProps.endAdornment}
                                        </>
                                    ),
                                }}
                            />
                        )}
                    />
                    {additionalFieldsVisible && (<TextField label="EMail" variant="outlined" size='small' sx={{ width: '25vw' }} onChange={handleEmail} value={email} />
                    )}
                </div>
            </div>
            <div style={{ display: additionalFieldsVisible?'none':'flex', gap: '1em', justifyContent: 'center', alignItems: 'center' }}>
                <Button
                    onClick={resetHandler}
                    style={{
                        display: additionalFieldsVisible ? "none" : "block",
                    }}
                    use="secondary"
                >
                    Reset
                </Button>
                <Button
                    onClick={handleConnectivityCheck}
                    style={{
                        display: additionalFieldsVisible ? "none" : "block",
                    }}
                >
                    {ispostUiFetchLoading ? "Checking..." : "Check For Connectivity"}
                </Button>
            </div>


        </form>

        <ModalComponent
            show={show}
            title={title}
            body={body}
            onClose={handleClose}
            redirectUrl="https://marketplace.verizon.com/#/subscriptionReqForm"
        />

        <ModalComponent
            show={showModal}
            title="Connectivity/Access available."
            body={body}
            onClose={handleClose}
        />

        {(ispostUiFetchLoading) && (
            <Backdrop
                sx={{ color: '#ddd', zIndex: (theme) => theme.zIndex.drawer + 1 }}
                open={ispostUiFetchLoading}
            >
                <CircularProgress color="inherit" />
            </Backdrop>
        )}
    </>);
}

const ModalComponent = ({ show, title, body, onClose, redirectUrl }) => (
    <Modal show={show} onHide={onClose}>
        <Modal.Header closeButton>
            <Modal.Title>{title}</Modal.Title>
        </Modal.Header>
        <Modal.Body>{body}</Modal.Body>
        <Modal.Footer>
            <Button
                use="secondary"
                onClick={() => {
                    onClose();
                    if (redirectUrl) window.open(redirectUrl, "_blank");
                }}
            >
                Close
            </Button>
        </Modal.Footer>
    </Modal>
);

export default TDGCPConnectivityCheck
