import PropTypes from 'prop-types';
// import Chatbot from "../Chatbot/Chatbot";
// import "./Layout.css";
import Header from "../Header/Header";
import Sidebar from "../Sidebar/Sidebar";
// import { Title } from "@vds/typography"
import { useLocation } from 'react-router-dom';
import styles from './Layout.module.css';

const Layout = ({ children }) => {
  const location = useLocation();
  const isIframePage = location.pathname.includes('/iframes/');
  return (
    <div className={styles.layout}>
      {!isIframePage && (
        <header className={styles.header}>
          <Header />
        </header>
      )}

      <div className={styles.mainContent}>
        <aside className={styles.sidebar}>
          <Sidebar />
        </aside>

        {/* <div className="content"> */}
        {/* <div className="sub-heading">
            <Title
              size="large"
              bold={true}
              color="#000000">
              Home
            </Title>
          </div> */}
        <main className={styles.main}>
          {children}
        </main>
      </div>
      {/* </div> */}

      {/* <Chatbot /> */}
    </div>
  );
};

Layout.propTypes = {
  children: PropTypes.node.isRequired,
};

export default Layout;