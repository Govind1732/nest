import React, { useState, useEffect, useRef } from "react";
import "./Chatbot.css";
import Chip from '@mui/material/Chip';
import SendIcon from '@mui/icons-material/Send';
import CloseIcon from '@mui/icons-material/Close';
import chatbotIcon from "../../assets/images/chatbotIcon.png";
import chatbotSmallIcon from "../../assets/images/chatbotSmallIcon.png";
import RestartAltRoundedIcon from '@mui/icons-material/RestartAltRounded';
import Tooltip from '@mui/material/Tooltip';
import axios from "axios";


const Options = ({ onIntentChange }) => {
    // const [intent, setIntent] = useState("")
    // const handleOptionClick = async (option) => {
    //     // Simulate calling an API to recognize the intent
    //     const result = await axios.post(`${process.env.REACT_APP_BASE_URL}chatbot/HomeChatBot/`, {
    //         message: option
    //     }, {
    //         headers: {
    //             'Content-Type': 'application/json'
    //         }
    //     });
    //     if (result.data.response.includes("Intent recognized")) {
    //         const intent = result.data.response.split(": ")[1].split(".")[0];
    //         onIntentChange(intent);
    //     }
    // };
    const handleIntentClick = (intent) => {
        onIntentChange(intent);
    };
    return (<>
        <span className="ms-3"> Select one of the option</span>
        <Chip label='get Data' className="m-2" onClick={() => handleIntentClick('get Data')} />
        <Chip label='Provide Link' className="m-2" onClick={() => handleIntentClick('Provide Link')} />
        <Chip label='get metrics' className="m-2" onClick={() => handleIntentClick('get metrics')} />
        <Chip label='Data Quality help' className="m-2" onClick={() => handleIntentClick('Data Quality help')} />
    </>)
}

const GetDataForm = ({ onSubmit }) => {
    const [formData, setFormData] = useState({ tableName: "", date: "" });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prevState => ({ ...prevState, [name]: value }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
    };
    return (
        <form onSubmit={handleSubmit}>
            <input
                type="text"
                name="tableName"
                placeholder="Table Name"
                value={formData.tableName}
                onChange={handleChange}
                className="my-2 w-100"
            />
            <input
                type="date"
                name="date"
                value={formData.date}
                onChange={handleChange}
                className="w-100"
            />
            <br />
            <div className="d-flex justify-content-center align-items-center">
                <button type="submit" className="m-2 py-1 px-2" style={{ borderRadius: '25px' }}>Submit</button>
            </div>
        </form>
    )
}

const ChatBot = () => {
    const [showChatbot, setShowChatbot] = useState(false);
    const [userMessage, setUserMessage] = useState("");
    const [showFooter, setShowFooter] = useState(false);
    const [intent, setIntent] = useState("");

    const handleIntentChange = (newIntent) => {
        setIntent(newIntent);
        setChatMessages(prevMessages => [...prevMessages, { message: `${newIntent}`, className: "outgoing" }]);
    }

    const [chatMessages, setChatMessages] = useState([
        { message: "Hi there 👋", className: "incoming" },
        { message: <Options onIntentChange={handleIntentChange} />, className: "incoming" }
    ]);
    const chatboxRef = useRef(null);
    useEffect(() => {
        if (chatboxRef.current) {
            chatboxRef.current.scrollTo(0, chatboxRef.current.scrollHeight);
        }
    }, [chatMessages]);

    const handleSubmit = () => {
        console.log("Submit")
    }

    const [userInput, setUserInput] = useState({});

    useEffect(() => {
        if (intent === "get Data") {
            setChatMessages(prevMessages => [...prevMessages, { message: <GetDataForm />, className: "incoming" }]);

        } else if (intent === "Provide Link") {
            setChatMessages(prevMessages => [...prevMessages, { message: "Please provide the link", className: "incoming" }]);
        } else if (intent === "get metrics") {
            setChatMessages(prevMessages => [...prevMessages, { message: "Please provide the metrics", className: "incoming" }]);
        } else if (intent === "Data Quality help") {
            setShowFooter(true);
        }
    }, [intent]);

    const handleChat = async (e) => {
        e.preventDefault()
        if (userMessage) {
            setChatMessages(prevMessages => [...prevMessages, { message: userMessage, className: "outgoing" }]);
            setUserMessage("");
            try {
                const res = await axios.post("https://lens-chatbot.herokuapp.com/chat", { message: userMessage });
                setChatMessages(prevMessages => [...prevMessages, { message: res.data, className: "incoming" }]);
            } catch (err) {
                setChatMessages(prevMessages => [...prevMessages, { message: "Sorry, I am not able to process your request at the moment.", className: "incoming" }]);
            }
        }
    };

    const resetHandler = () => {
        setChatMessages([
            { message: "Hi there 👋 \n", className: "incoming" },
            { message: <Options onIntentChange={handleIntentChange} />, className: "incoming" }]);
        setIntent("");
        setShowFooter(false)
        setUserInput({ tableName: "", date: "" })
    };

    return (<>
        <div className="show-chatbot">
            {showChatbot
                ? <span className="chatbot-close" onClick={() => setShowChatbot(!showChatbot)}><CloseIcon></CloseIcon></span>
                : <img src={chatbotIcon} alt="ChatBot Icon" className="chatbot-icon" onClick={() => setShowChatbot(!showChatbot)} />
            }

            {showChatbot && (
                <div className="chatbot">
                    <header>
                        <h2>LENS</h2>
                        <Tooltip title="Reset">
                            <RestartAltRoundedIcon onClick={resetHandler} className="resetIcon" />
                        </Tooltip>
                        <span className="" onClick={() => setShowChatbot(false)}><CloseIcon /></span>
                    </header>

                    <ul className="chatbox" ref={chatboxRef}>
                        {chatMessages.map((msg, index) => (
                            <li key={index} className={`chat ${msg.className}`}>
                                {msg.className === "incoming" && (<>
                                    <img src={chatbotSmallIcon} alt="ChatBot Icon" className="chatbot-toy" />
                                </>)}
                                <p>{msg.message}</p>
                            </li>
                        ))}
                    </ul>

                    {/* {
                        (intent === "get Data") && (
                            setChatMessages(prevMessages => [...prevMessages, {
                                message:
                                    <div>
                                        <input
                                            type="text"
                                            placeholder="Table Name"
                                            value={userInput.tableName}
                                            onChange={(e) => setUserInput({ ...userInput, tableName: e.target.value })}
                                        />
                                        <input
                                            type="date"
                                            placeholder="Date"
                                            value={userInput.date}
                                            onChange={(e) => setUserInput({ ...userInput, date: e.target.value })}
                                        />
                                        <button onClick={handleSubmit}>Submit</button>
                                    </div>, className: "incoming"
                            }])
                        )
                    } */}


                    {/* <Button variant="primary" onClick={resetHandler}>Reset</Button> */}
                    {/* <div className="chip-container">
                            <Chip onClick={resetHandler} label="Reset" />
                        </div> */}
                    {showFooter && (
                        <footer className="chat-form-container">
                            <form onSubmit={handleChat} className="chat-input">
                                <textarea
                                    placeholder="Enter a message..."
                                    required
                                    value={userMessage}
                                    onChange={(e) => setUserMessage(e.target.value)}
                                    onKeyDown={(e) => {
                                        if (e.key === 'Enter' && !e.shiftKey) {
                                            e.preventDefault();
                                            handleChat(e);
                                        }
                                    }}
                                >
                                </textarea>
                                {userMessage && (
                                    <button type='submit' className="bg-white border-0">
                                        <SendIcon />
                                    </button>
                                )}
                            </form>
                        </footer>
                    )}
                </div>
            )}
        </div>
    </>)
}

export default ChatBot
