// import React from 'react';
import styled, { keyframes } from 'styled-components';

const l5_1 = keyframes`
  0%   {left:-16px;transform:translateY(-8px)}
  100% {left:calc(100% + 8px);transform:translateY(22px)}
`;

const l5_2 = keyframes`
  100% {top:-0.1px}
`;

const Loader = styled.div`
  width: 40px;
  height: 30px;
  --c: no-repeat linear-gradient(#000 0 0);
  background:
    var(--c) 0    100%/8px 30px,
    var(--c) 50%  100%/8px 20px,
    var(--c) 100% 100%/8px 10px;
  position: relative;
  clip-path: inset(-100% 0);

  &:before {
    content: "";
    position: absolute;
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: #000;
    left: -16px;
    top: 0;
    animation: ${l5_1} 2s linear infinite, ${l5_2} 0.5s cubic-bezier(0,200,.8,200) infinite;
  }
`;

const GraphLoader = () => {
  return (
    <Loader />
  );
};

export default GraphLoader;