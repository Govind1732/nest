import React from 'react'
import Autocomplete from '@mui/material/Autocomplete';
import TextField from '@mui/material/TextField';
import Checkbox from '@mui/material/Checkbox';
import ListItemText from '@mui/material/ListItemText';
import Chip from '@mui/material/Chip';
import CircularProgress from '@mui/material/CircularProgress';

const AutoComplete = ({ options, selectedOptions, loading, handleChange }) => {

    return (
        <div>
            <Autocomplete
                multiple
                id="checkboxes-tags"
                options={["Select All", ...options]}
                // options={project}
                disableCloseOnSelect
                getOptionLabel={(option) => option}
                value={selectedOptions}
                onChange={handleChange}
                renderOption={(props, option, { selected }) => (
                    <li {...props}>
                        <Checkbox
                            checked={option === "Select All" ? selectedOptions.length === options.length : selected}
                        />
                        <ListItemText primary={option} />
                    </li>
                )}
                size="small"
                renderInput={(params) => (
                    <TextField {...params} variant="outlined" label="Projects" placeholder={selectedOptions.length === 0 ? "Select your Data" : ''}
                        InputProps={{
                            ...params.InputProps,
                            style: { borderRadius: 0 },
                            endAdornment: (
                                <>
                                    {loading ? <CircularProgress color="inherit" size={20} /> : null}
                                    {params.InputProps.endAdornment}
                                </>
                            ),
                        }}
                    />
                )}
                renderTags={(value, getTagProps) =>
                    value.length > 2
                        ? value.slice(0, 2).map((option, index) => (
                            <Chip variant="secondary" label={option} {...getTagProps({ index })} />
                        )).concat(<Chip variant="outlined" label="..." />)
                        : value.map((option, index) => (
                            <Chip variant="secondary" label={option} {...getTagProps({ index })} />
                        ))
                }
            />
        </div>
    )
}

export default AutoComplete
