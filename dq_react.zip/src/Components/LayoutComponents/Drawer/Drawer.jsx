import React from 'react';
import './Drawer.css';

const Drawer = ({ isOpen, onClose, children }) => {
    if (!isOpen) return null;

    return (
        <div className="drawer-overlay">
            <div className="drawer">
                <button className="close-button" onClick={onClose}>X</button>
                {children}
            </div>
        </div>
    );
};

export default Drawer;