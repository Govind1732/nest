import React from 'react';
import styles from './Modal.module.css';
import { Icon } from "@vds/icons"
const ModalComponent = ({ show, handleClose, modalTitle, modalBody }) => {
    if (!show) {
        return null;
    }

    return (
        <div className={styles.modalOverlay}>
            <div className={styles.modalContent}>
                <div className={styles.modalHeader}>
                    <h2>{modalTitle}</h2>
                    <button className={styles.closeButton} onClick={handleClose}>
                        <Icon name="close" size="large" />
                    </button>
                </div>
                <div className={styles.modalBody}>
                    {modalBody}
                </div>
            </div>
        </div>
    );
};

export default ModalComponent;