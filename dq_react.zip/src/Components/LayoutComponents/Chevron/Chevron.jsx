import PropTypes from 'prop-types';
import { Icon } from "@vds/icons"
import styles from './Chevron.module.css';

const Chevron = ({ direction }) => {
    const iconName = direction === 'top' ? 'up-caret' : 
                    direction === 'bottom' ? 'down-caret' : 
                    direction === 'left' ? 'left-caret' : 'right-caret';
                    
    return (
        <div className={styles.chevronWrapper}>
            <Icon
                name={iconName}
                size="small"
            />
        </div>
    );
};

Chevron.propTypes = {
    direction: PropTypes.oneOf(['top', 'right', 'bottom', 'left']).isRequired,
};

export default Chevron;
