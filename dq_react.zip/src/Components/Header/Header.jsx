// import React, { useState, useEffect } from 'react';
// import { useDispatch, useSelector } from 'react-redux';
// import { fetchUserAuthorization } from '../../features/users/userAuthorizationSlice';
// import axios from 'axios';
import { Link, useNavigate } from "react-router-dom";
// import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
// import { faBars, faTimes } from "@fortawesome/free-solid-svg-icons";
import lens_x_final from '../../assets/images/lens_x_final.svg';
import { Icon } from "@vds/icons";
import { TextLink } from "@vds/buttons";
import { ButtonIcon } from "@vds/button-icons"
import styles from './Header.module.css';
import { Body } from "@vds/core";
// import axios from 'axios';

const Header = () => {
    // const [isOpen, setIsOpen] = useState(false);

    // const toggleMenu = () => {
    //     setIsOpen(!isOpen);
    // };
    // const [loading, setLoading] = useState(false);
    // const dispatch = useDispatch();

    // Local Storage
    // const storedUserHeaders = localStorage.getItem('userHeaders') ? JSON.parse(localStorage.getItem('userHeaders')) : null;
    // const storedDQUser = localStorage.getItem('DQ_user') ? JSON.parse(localStorage.getItem('DQ_user')) : null;

    // const user = useSelector((store) => store.userAuthorization.user);
    // const [userHeaders, setUserHeaders] = useState({});
    // const userRole = storedDQUser?.roles?.[0]?.name || user?.roles?.[0]?.name;
    // const userName = storedDQUser?.first_name || userHeaders?.firstname;
    // useEffect(() => {
    //     dispatch(fetchUserAuthorization("raodago"));
    //     if (!storedDQUser) {
    //         const fetchData = async () => {
    //             setLoading(true);
    //             try {
    //                 if (storedUserHeaders) {
    //                     dispatch(fetchUserAuthorization(storedUserHeaders.vzid.toString().toLowerCase()));
    //                     setUserHeaders(storedUserHeaders);
    //                     setLoading(false);
    //                 } else {
    //                     const response = await axios.get(`${import.meta.env.VITE_REACT_APP_USER_HEADERS}dqapi/`);
    //                     dispatch(fetchUserAuthorization(response.data.headers.vzid.toString().toLowerCase()));
    //                     setUserHeaders(response.data.headers);
    //                     localStorage.setItem('userHeaders', JSON.stringify(response.data.headers));
    //                     setLoading(false);
    //                 }
    //             } catch (error) {
    //                 console.error('Error while fetching user headers', error);
    //                 setLoading(false);
    //             }
    //         };
    //         fetchData();
    //     } else {
    //         setUserHeaders(storedUserHeaders);
    //     }
    // }, []);

    const navigate = useNavigate();
    const handleNavigation = (path) => {
        navigate(path);
    };

    return (
        <nav className={styles.navbar}>
            <div className={styles.logoContainer}>
                <a href='/dataQuality'><img src={lens_x_final} alt='logo' className={styles.logo} /></a>
            </div>
            {/* <div className={styles.menuIcon} onClick={toggleMenu}>
                <FontAwesomeIcon icon={isOpen ? faTimes : faBars} />
            </div> */}
            <div className={styles.navLinksContainer}>
                <ul>
                    {/* <li>
                        {userRole === "DQ Admin" && (
                            <TextLink type="standAlone" onClick={() => handleNavigation("/dataQuality/UserManagement")}>
                                User Management
                            </TextLink>
                        )}
                    </li> */}
                    <li>
                        <Link to={"/dataQuality/dataquality-validation"} className={styles.hoverUnderline}>
                            <Body bold={true} size="large">DataQuality Validation</Body>
                        </Link>
                    </li>
                    <li>
                        <Link to={"/dataQuality/dq-domainlevelreport"} className={styles.hoverUnderline}>
                            <Body bold={true} size="large">DQ Domain Level Report</Body>
                        </Link>
                    </li>
                    <li>
                        <Link to={"/dataQuality/dq-reports"} className={styles.hoverUnderline}>
                            <Body bold={true} size="large">DQ Report</Body>
                        </Link>
                    </li>
                    <li>
                        <Link to={"/dataQuality/myrequest"} className={styles.hoverUnderline}>
                            <Body bold={true} size="large">My Request</Body>
                        </Link>
                    </li>
                    {/* <li>
                        <TextLink type="standAlone" onClick={() => handleNavigation("/dataQuality/openissues")}>
                            My Issues
                        </TextLink>
                    </li> */}
                    <li className='d-flex align-items-center'>
                        <ButtonIcon
                            kind="ghost"
                            size="medium"
                            surface="light"
                            surfaceType="colorFill"
                            disabled={false}
                            hideBorder={true}
                            floating={false}
                            focusBorderPosition="outside"
                            iconOffset={{
                                x: 0,
                                y: 0
                            }}
                            fitToIcon={false}
                            renderIcon={(props) => <Icon name="question" {...props} />}
                            onClick={() => handleNavigation("/dataQuality/help")}
                        />
                        <Link to={"/dataQuality/help"} className={styles.hoverUnderline}>
                            <Body bold={true} size="large">Help</Body>
                        </Link>
                    </li>
                    {/* <li>
                        <ButtonIcon
                            kind="ghost"
                            size="large"
                            surface="light"
                            surfaceType="colorFill"
                            disabled={false}
                            hideBorder={true}
                            floating={false}
                            focusBorderPosition="outside"
                            iconOffset={{
                                x: 0,
                                y: 0
                            }}
                            fitToIcon={false}
                            renderIcon={(props) => <Icon name="my-account" {...props} />}
                            onClick={() => handleNavigation("/dataQuality/userprofile")}
                        />
                        <TextLink type="standAlone" onClick={() => handleNavigation("/dataQuality/userprofile")}>
                            <div>
                                <div>Welcome {userName}</div>
                                <div>{userRole}</div>
                            </div>
                        </TextLink>
                    </li> */}
                </ul>
            </div>
        </nav>
    );
};

export default Header;