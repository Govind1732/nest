import { createContext, useState } from 'react';
import PropTypes from 'prop-types';

export const DQDomainLevelReportContext = createContext();

export const DQDomainLevelReportProvider = ({ children }) => {
    const [activeProduct, setActiveProduct] = useState({ productId: "", L2_productId: "", tableName: "" });
    const [last7days, setLast7days] = useState([]);
    const [showAllTables, setShowAllTables] = useState(false);
    const [showAllColumns, setShowAllColumns] = useState(false);
    const [dashboardView, setDashboardView] = useState(true);
    const [selectedTable, setSelectedTable] = useState('');
    const [columnsData, setColumnsData] = useState([]);

    return (
        <DQDomainLevelReportContext.Provider value={{
            activeProduct, setActiveProduct,
            last7days, setLast7days,
            showAllTables, setShowAllTables,
            showAllColumns, setShowAllColumns,
            dashboardView, setDashboardView,
            selectedTable,setSelectedTable,
            columnsData, setColumnsData
        }}>
            {children}
        </DQDomainLevelReportContext.Provider>
    );
};

DQDomainLevelReportProvider.propTypes = {
    children: PropTypes.node.isRequired,
};
