"use client"

import { ScoreCard } from "../src/components/charts/ScoreCard"

export default function SyntheticV0PageForDeployment() {
  return <ScoreCard />
}