// RuleProfileMLE slice for Redux
import { createSlice, type PayloadAction } from "@reduxjs/toolkit"

interface RuleProfileMLEState {
  file: File | null
  isUploading: boolean
  isLoading: boolean
  error: string | null
  tableData: any[]
}

const initialState: RuleProfileMLEState = {
  file: null,
  isUploading: false,
  isLoading: false,
  error: null,
  tableData: [],
}

const ruleProfileMLESlice = createSlice({
  name: "ruleProfileMLE",
  initialState,
  reducers: {
    setFile: (state, action: PayloadAction<File | null>) => {
      state.file = action.payload
    },
    setIsUploading: (state, action: PayloadAction<boolean>) => {
      state.isUploading = action.payload
    },
    clearState: (state) => {
      state.file = null
      state.isUploading = false
      state.isLoading = false
      state.error = null
      state.tableData = []
    },
    setTableData: (state, action: PayloadAction<any[]>) => {
      state.tableData = action.payload
    },
    setLoading: (state, action: PayloadAction<boolean>) => {
      state.isLoading = action.payload
    },
    setError: (state, action: PayloadAction<string | null>) => {
      state.error = action.payload
    },
  },
})

export const { setFile, setIsUploading, clearState, setTableData, setLoading, setError } = ruleProfileMLESlice.actions

export default ruleProfileMLESlice.reducer

