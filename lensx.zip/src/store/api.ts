// RTK Query base API setup
import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react"
import { API_BASE_URL } from "@/config/constants"

export const api = createApi({
  reducerPath: "api",
  baseQuery: fetchBaseQuery({
    baseUrl: API_BASE_URL,
    prepareHeaders: (headers) => {
      // Add any common headers here
      return headers
    },
  }),
  tagTypes: [
    "User",
    "Profile",
    "Report",
    "DomainReport",
    "Request",
    "AutoProfile",
    "RuleProfile",
    "DataProfile",
    "CustomProfile",
  ],
  endpoints: () => ({}),
})

