import { renderHook, act } from "@testing-library/react-hooks"
import { useGuidedTour } from "@/hooks/useGuidedTour"
import { describe, beforeEach, test, expect, jest } from "@jest/globals"

// Mock localStorage
const localStorageMock = (() => {
  let store: Record<string, string> = {}
  return {
    getItem: (key: string) => store[key] || null,
    setItem: (key: string, value: string) => {
      store[key] = value.toString()
    },
    removeItem: (key: string) => {
      delete store[key]
    },
    clear: () => {
      store = {}
    },
  }
})()

Object.defineProperty(window, "localStorage", {
  value: localStorageMock,
})

describe("useGuidedTour", () => {
  beforeEach(() => {
    localStorage.clear()
  })

  const mockSteps = [
    {
      target: ".mock-target-1",
      title: "Step 1",
      content: "This is step 1",
      placement: "bottom" as const,
    },
    {
      target: ".mock-target-2",
      title: "Step 2",
      content: "This is step 2",
      placement: "right" as const,
    },
  ]

  test("initializes with correct default values", () => {
    const { result } = renderHook(() =>
      useGuidedTour({
        tourId: "test-tour",
        steps: mockSteps,
      }),
    )

    expect(result.current.isOpen).toBe(false)
    expect(result.current.currentStep).toBe(0)
    expect(result.current.hasCompletedTour).toBe(false)
  })

  test("starts tour automatically if autoStart is true and tour not completed", () => {
    const { result } = renderHook(() =>
      useGuidedTour({
        tourId: "test-tour",
        steps: mockSteps,
        autoStart: true,
      }),
    )

    expect(result.current.isOpen).toBe(true)
  })

  test("does not start tour automatically if tour was completed before", () => {
    // Set tour as completed
    localStorage.setItem("completedTours", JSON.stringify({ "test-tour": true }))

    const { result } = renderHook(() =>
      useGuidedTour({
        tourId: "test-tour",
        steps: mockSteps,
        autoStart: true,
      }),
    )

    expect(result.current.isOpen).toBe(false)
    expect(result.current.hasCompletedTour).toBe(true)
  })

  test("startTour opens the tour and resets to first step", () => {
    const { result } = renderHook(() =>
      useGuidedTour({
        tourId: "test-tour",
        steps: mockSteps,
      }),
    )

    act(() => {
      result.current.setCurrentStep(1)
      result.current.startTour()
    })

    expect(result.current.isOpen).toBe(true)
    expect(result.current.currentStep).toBe(0)
  })

  test("closeTour closes the tour", () => {
    const { result } = renderHook(() =>
      useGuidedTour({
        tourId: "test-tour",
        steps: mockSteps,
        autoStart: true,
      }),
    )

    act(() => {
      result.current.closeTour()
    })

    expect(result.current.isOpen).toBe(false)
  })

  test("completeTour closes the tour and marks it as completed", () => {
    const mockOnComplete = jest.fn()
    const { result } = renderHook(() =>
      useGuidedTour({
        tourId: "test-tour",
        steps: mockSteps,
        onComplete: mockOnComplete,
      }),
    )

    act(() => {
      result.current.startTour()
      result.current.completeTour()
    })

    expect(result.current.isOpen).toBe(false)
    expect(result.current.hasCompletedTour).toBe(true)
    expect(mockOnComplete).toHaveBeenCalled()

    // Check localStorage
    const completedTours = JSON.parse(localStorage.getItem("completedTours") || "{}")
    expect(completedTours["test-tour"]).toBe(true)
  })

  test("resetTourCompletion resets the completion status", () => {
    // Set tour as completed
    localStorage.setItem("completedTours", JSON.stringify({ "test-tour": true }))

    const { result } = renderHook(() =>
      useGuidedTour({
        tourId: "test-tour",
        steps: mockSteps,
      }),
    )

    expect(result.current.hasCompletedTour).toBe(true)

    act(() => {
      result.current.resetTourCompletion()
    })

    expect(result.current.hasCompletedTour).toBe(false)

    // Check localStorage
    const completedTours = JSON.parse(localStorage.getItem("completedTours") || "{}")
    expect(completedTours["test-tour"]).toBeUndefined()
  })

  test("setCurrentStep updates the current step", () => {
    const { result } = renderHook(() =>
      useGuidedTour({
        tourId: "test-tour",
        steps: mockSteps,
      }),
    )

    act(() => {
      result.current.setCurrentStep(1)
    })

    expect(result.current.currentStep).toBe(1)
  })
})

