import { render, screen } from "@testing-library/react"
import { CircleProgress } from "@/components/charts/CircleProgress"

describe("CircleProgress", () => {
  test("renders with default props", () => {
    render(<CircleProgress value={75} />)

    // Check that the SVG exists
    const svg = screen.getByRole("img", { hidden: true })
    expect(svg).toBeInTheDocument()

    // Check that the percentage is displayed
    expect(screen.getByText("75.0%")).toBeInTheDocument()
  })

  test("renders with custom size", () => {
    render(<CircleProgress value={75} size={200} />)

    const svg = screen.getByRole("img", { hidden: true })
    expect(svg).toHaveAttribute("width", "200")
    expect(svg).toHaveAttribute("height", "200")
  })

  test("renders with label and sublabel", () => {
    render(<CircleProgress value={75} label="Test Label" sublabel="Test Sublabel" />)

    expect(screen.getByText("75.0%")).toBeInTheDocument()
    expect(screen.getByText("Test Label")).toBeInTheDocument()
    expect(screen.getByText("Test Sublabel")).toBeInTheDocument()
  })

  test("applies success color for high value", () => {
    render(<CircleProgress value={95} />)

    const circle = screen.getAllByRole("presentation")[1] // The second circle is the progress circle
    expect(circle).toHaveAttribute("stroke", "var(--stroke-color-success)")
  })

  test("applies warning color for medium value", () => {
    render(<CircleProgress value={85} />)

    const circle = screen.getAllByRole("presentation")[1]
    expect(circle).toHaveAttribute("stroke", "var(--stroke-color-medium)")
  })

  test("applies error color for low value", () => {
    render(<CircleProgress value={75} />)

    const circle = screen.getAllByRole("presentation")[1]
    expect(circle).toHaveAttribute("stroke", "var(--stroke-color-low)")
  })
})

