import { render, screen, fireEvent, waitFor } from "@testing-library/react"
import { Provider } from "react-redux"
import { configureStore } from "@reduxjs/toolkit"
import { DQReportFilters } from "@/modules/reports/components/DQReport/DQReportFilters"
import dqReportReducer from "@/store/slices/dqReportSlice"

// Create a mock store
const createMockStore = (initialState = {}) => {
  return configureStore({
    reducer: {
      dqReport: dqReportReducer,
    },
    preloadedState: {
      dqReport: {
        filterOptions: {
          platforms: ["GCP", "TeraData"],
          lobs: ["Network Performance", "Customer Experience"],
          productTypes: ["5G Home", "Wireless"],
          productAreas: ["East", "West"],
          productNames: ["Product A", "Product B"],
          businessPrograms: ["Program 1", "Program 2"],
        },
        isLoading: false,
        filterValues: {},
        ...initialState,
      },
    },
  })
}

describe("DQReportFilters", () => {
  test("renders filter components", () => {
    const mockOnApplyFilters = jest.fn()
    const store = createMockStore()

    render(
      <Provider store={store}>
        <DQReportFilters onApplyFilters={mockOnApplyFilters} />
      </Provider>,
    )

    expect(screen.getByText("Filters")).toBeInTheDocument()
    expect(screen.getByText("Date Range")).toBeInTheDocument()
    expect(screen.getByText("Platform")).toBeInTheDocument()
    expect(screen.getByText("LOB")).toBeInTheDocument()
    expect(screen.getByText("Product Type")).toBeInTheDocument()
    expect(screen.getByText("Product Area")).toBeInTheDocument()
    expect(screen.getByText("Product Name")).toBeInTheDocument()
    expect(screen.getByText("Business Program")).toBeInTheDocument()
    expect(screen.getByRole("button", { name: /apply filters/i })).toBeInTheDocument()
  })

  test("handles filter changes", async () => {
    const mockOnApplyFilters = jest.fn()
    const store = createMockStore()

    render(
      <Provider store={store}>
        <DQReportFilters onApplyFilters={mockOnApplyFilters} />
      </Provider>,
    )

    // Open platform dropdown
    const platformTrigger = screen.getByRole("combobox", { name: /platform/i })
    fireEvent.click(platformTrigger)

    // Wait for dropdown to open
    await waitFor(() => {
      expect(screen.getByText("GCP")).toBeInTheDocument()
    })

    // Select a platform
    fireEvent.click(screen.getByText("GCP"))

    // Click apply filters
    fireEvent.click(screen.getByRole("button", { name: /apply filters/i }))

    // Check if onApplyFilters was called
    expect(mockOnApplyFilters).toHaveBeenCalled()
  })

  test("handles reset filters", async () => {
    const mockOnApplyFilters = jest.fn()
    const store = createMockStore({
      filterValues: {
        platform: "GCP",
        lob: "Network Performance",
      },
    })

    render(
      <Provider store={store}>
        <DQReportFilters onApplyFilters={mockOnApplyFilters} />
      </Provider>,
    )

    // Clear All button should be visible when filters are applied
    expect(screen.getByText("Clear All")).toBeInTheDocument()

    // Click Clear All
    fireEvent.click(screen.getByText("Clear All"))

    // Check if filters were reset in the store
    await waitFor(() => {
      expect(store.getState().dqReport.filterValues).toEqual({})
    })
  })

  test("disables filters when loading", () => {
    const mockOnApplyFilters = jest.fn()
    const store = createMockStore({
      isLoading: true,
    })

    render(
      <Provider store={store}>
        <DQReportFilters onApplyFilters={mockOnApplyFilters} />
      </Provider>,
    )

    // Apply Filters button should be disabled
    expect(screen.getByRole("button", { name: /loading/i })).toBeDisabled()
  })
})

