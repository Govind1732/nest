"use client"

import { render, screen, fireEvent, waitFor } from "@testing-library/react"
import { Provider } from "react-redux"
import { configureStore } from "@reduxjs/toolkit"
import { DQReportPage } from "@/modules/reports/pages/DQReportPage"
import dqReportReducer from "@/store/slices/dqReportSlice"

// Mock html2canvas and jsPDF
jest.mock("html2canvas", () => ({
  __esModule: true,
  default: jest.fn().mockResolvedValue({
    toDataURL: jest.fn().mockReturnValue("data:image/png;base64,mockImageData"),
  }),
}))

jest.mock("jspdf", () => {
  const mockJsPDF = {
    addImage: jest.fn(),
    save: jest.fn(),
    internal: {
      pageSize: {
        getWidth: jest.fn().mockReturnValue(210),
        getHeight: jest.fn().mockReturnValue(297),
      },
    },
    getImageProperties: jest.fn().mockReturnValue({ width: 100, height: 100 }),
  }
  return {
    __esModule: true,
    default: jest.fn(() => mockJsPDF),
  }
})

// Mock the useToast hook
jest.mock("@/hooks/use-toast", () => ({
  useToast: () => ({
    toast: jest.fn(),
  }),
}))

// Mock the LiveDataChart component
jest.mock("@/modules/reports/components/LiveDataChart", () => ({
  LiveDataChart: () => <div data-testid="live-data-chart">Live Data Chart</div>,
}))

// Mock the AdvancedBarChart component
jest.mock("@/components/charts/AdvancedBarChart", () => ({
  AdvancedBarChart: ({ onClick, data }) => (
    <div data-testid="bar-chart" onClick={() => onClick && onClick(data[0])}>
      Bar Chart
    </div>
  ),
}))

// Mock the AdvancedLineChart component
jest.mock("@/components/charts/AdvancedLineChart", () => ({
  AdvancedLineChart: () => <div data-testid="line-chart">Line Chart</div>,
}))

// Create a mock store
const createMockStore = (initialState = {}) => {
  return configureStore({
    reducer: {
      dqReport: dqReportReducer,
    },
    preloadedState: {
      dqReport: {
        dashboardView: true,
        dataProductsView: false,
        tableLevelAssetsView: false,
        selectedLabel: null,
        enterpriseData: [
          {
            no_of_assets: 1043,
            TBL_COMPLETENESS: 91.5,
            TBL_TIMELINESS: 100.0,
            TBL_UNIQUENESS: 90.8,
            tbl_conformity: 95.3,
            tbl_validity: 91.6,
            tbl_consistency: 98.8,
            OVERALL_DQ_SCORE: 94.7,
          },
        ],
        dqTrendData: {
          trend_line: [
            { run_date: "2023-01-01", trend_score: 90 },
            { run_date: "2023-01-02", trend_score: 92 },
          ],
        },
        productTypeWiseData: [
          {
            product_type: "5G Home",
            no_of_assets: 412,
            TBL_COMPLETENESS: 92.5,
            TBL_TIMELINESS: 98.7,
            TBL_UNIQUENESS: 91.2,
            tbl_conformity: 94.8,
            tbl_validity: 90.3,
            tbl_consistency: 97.1,
            OVERALL_DQ_SCORE: 94.1,
          },
        ],
        lobWiseData: [],
        isLoading: false,
        error: null,
        startDate: "2023-01-01",
        endDate: "2023-01-07",
        filterOptions: {
          platforms: ["GCP", "TeraData"],
          lobs: ["Network Performance", "Customer Experience"],
          productTypes: ["5G Home", "Wireless"],
          productAreas: ["East", "West"],
          productNames: ["Product A", "Product B"],
          businessPrograms: ["Program 1", "Program 2"],
        },
        filterValues: {},
        ...initialState,
      },
    },
  })
}

describe("DQReportPage", () => {
  test("renders the DQ Report page", () => {
    const store = createMockStore()
    render(
      <Provider store={store}>
        <DQReportPage />
      </Provider>,
    )

    expect(screen.getByText("DQ Report")).toBeInTheDocument()
    expect(screen.getByText("Overview of data quality metrics across the organization")).toBeInTheDocument()
  })

  test("displays enterprise score and metrics", () => {
    const store = createMockStore()
    render(
      <Provider store={store}>
        <DQReportPage />
      </Provider>,
    )

    expect(screen.getByText("Enterprise")).toBeInTheDocument()
    expect(screen.getByText("Completeness")).toBeInTheDocument()
    expect(screen.getByText("Timeliness")).toBeInTheDocument()
    expect(screen.getByText("Uniqueness")).toBeInTheDocument()
    expect(screen.getByText("Conformity")).toBeInTheDocument()
    expect(screen.getByText("Validity")).toBeInTheDocument()
    expect(screen.getByText("Consistency")).toBeInTheDocument()
  })

  test("displays charts", () => {
    const store = createMockStore()
    render(
      <Provider store={store}>
        <DQReportPage />
      </Provider>,
    )

    expect(screen.getByText("DQ Score Tables")).toBeInTheDocument()
    expect(screen.getByText("DQ Score Trend")).toBeInTheDocument()
    expect(screen.getByTestId("bar-chart")).toBeInTheDocument()
    expect(screen.getByTestId("line-chart")).toBeInTheDocument()
  })

  test("handles refresh button click", async () => {
    const store = createMockStore()
    render(
      <Provider store={store}>
        <DQReportPage />
      </Provider>,
    )

    const refreshButton = screen.getByRole("button", { name: /refresh/i })
    fireEvent.click(refreshButton)

    // Wait for the refresh to complete
    await waitFor(() => {
      expect(store.getState().dqReport.isLoading).toBe(false)
    })
  })

  test("handles PDF download", async () => {
    const store = createMockStore()
    render(
      <Provider store={store}>
        <DQReportPage />
      </Provider>,
    )

    const downloadButton = screen.getByRole("button", { name: /download pdf/i })
    fireEvent.click(downloadButton)

    // Wait for the download to complete
    await waitFor(() => {
      expect(require("jspdf").default).toHaveBeenCalled()
    })
  })

  test("displays filters", () => {
    const store = createMockStore()
    render(
      <Provider store={store}>
        <DQReportPage />
      </Provider>,
    )

    expect(screen.getByText("Filters")).toBeInTheDocument()
    expect(screen.getByText("Date Range")).toBeInTheDocument()
    expect(screen.getByText("Platform")).toBeInTheDocument()
    expect(screen.getByText("LOB")).toBeInTheDocument()
  })

  test("handles view switching", async () => {
    const store = createMockStore()
    render(
      <Provider store={store}>
        <DQReportPage />
      </Provider>,
    )

    // Click on "All Data Products" to switch view
    const allDataProductsButton = screen.getByRole("button", { name: /all data products/i })
    fireEvent.click(allDataProductsButton)

    // Wait for the view to change
    await waitFor(() => {
      expect(store.getState().dqReport.dashboardView).toBe(false)
      expect(store.getState().dqReport.dataProductsView).toBe(true)
    })

    // Click on "DQ Reports" to switch back
    const dqReportsLink = screen.getByText("DQ Reports")
    fireEvent.click(dqReportsLink)

    // Wait for the view to change back
    await waitFor(() => {
      expect(store.getState().dqReport.dashboardView).toBe(true)
      expect(store.getState().dqReport.dataProductsView).toBe(false)
    })
  })
})

