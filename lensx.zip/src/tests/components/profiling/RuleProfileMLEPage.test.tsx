import { render, screen, fireEvent, waitFor } from "@testing-library/react"
import { Provider } from "react-redux"
import { store } from "@/store/store"
import { BrowserRouter } from "react-router-dom"
import RuleProfileMLEPage from "@/modules/profiling/pages/RuleProfileMLEPage"

describe("RuleProfileMLEPage", () => {
  const setup = () => {
    return render(
      <Provider store={store}>
        <BrowserRouter>
          <RuleProfileMLEPage />
        </BrowserRouter>
      </Provider>,
    )
  }

  test("renders Rule Profile - MLE page", () => {
    setup()
    expect(screen.getByText(/Rule Profile - MLE/i)).toBeInTheDocument()
    expect(screen.getByText(/Submit Multiple Requests/i)).toBeInTheDocument()
    expect(screen.getByText(/View\/Edit Request/i)).toBeInTheDocument()
  })

  test("allows file selection in Submit Multiple Requests tab", () => {
    setup()
    const fileInput = screen.getByLabelText(/Choose File/i)
    expect(fileInput).toBeInTheDocument()
  })

  test("shows file name after selection", () => {
    setup()
    const fileInput = screen.getByLabelText(/Choose File/i)
    const file = new File(["dummy content"], "test.csv", { type: "text/csv" })
    fireEvent.change(fileInput, { target: { files: [file] } })
    expect(screen.getByText(/test.csv/i)).toBeInTheDocument()
  })

  test("submits file upload request", async () => {
    setup()
    const fileInput = screen.getByLabelText(/Choose File/i)
    const file = new File(["dummy content"], "test.csv", { type: "text/csv" })
    fireEvent.change(fileInput, { target: { files: [file] } })
    const submitButton = screen.getByRole("button", { name: /Submit/i })
    fireEvent.click(submitButton)
    await waitFor(() => {
      expect(screen.getByText(/Uploading.../i)).toBeInTheDocument()
    })
  })

  test("allows database and table name input in View/Edit Request tab", () => {
    setup()
    fireEvent.click(screen.getByText(/View\/Edit Request/i))
    const databaseInput = screen.getByPlaceholderText(/Enter database name/i)
    const tableNameInput = screen.getByPlaceholderText(/Enter table name/i)
    expect(databaseInput).toBeInTheDocument()
    expect(tableNameInput).toBeInTheDocument()
  })

  test("submits database and table name request", async () => {
    setup()
    fireEvent.click(screen.getByText(/View\/Edit Request/i))
    const databaseInput = screen.getByPlaceholderText(/Enter database name/i)
    const tableNameInput = screen.getByPlaceholderText(/Enter table name/i)
    fireEvent.change(databaseInput, {
      target: { value: "test_database" },
    })
    fireEvent.change(tableNameInput, { target: { value: "test_table" } })
    const submitButton = screen.getByRole("button", { name: /Submit/i })
    fireEvent.click(submitButton)
  })
})

