import { render, screen, fireEvent } from "@testing-library/react"
import { FeatureTour } from "@/components/tours/FeatureTour"
import { useLocation } from "react-router-dom"
import { useGuidedTour } from "@/hooks/useGuidedTour"
import { ROUTES } from "@/config/constants"

// Mock the hooks
jest.mock("react-router-dom", () => ({
  useLocation: jest.fn(),
}))

jest.mock("@/hooks/useGuidedTour", () => ({
  useGuidedTour: jest.fn(),
}))

// Mock translations
jest.mock("react-i18next", () => ({
  useTranslation: () => {
    return {
      t: (str: string) => str,
      i18n: {
        changeLanguage: () => new Promise(() => {}),
      },
    }
  },
}))

describe("FeatureTour", () => {
  // Setup default mocks
  beforeEach(() => {
    // Mock useLocation
    ;(useLocation as jest.Mock).mockReturnValue({
      pathname: ROUTES.HOME,
    })

    // Mock useGuidedTour
    ;(useGuidedTour as jest.Mock).mockReturnValue({
      isOpen: false,
      startTour: jest.fn(),
      closeTour: jest.fn(),
      completeTour: jest.fn(),
      currentStep: 0,
      setCurrentStep: jest.fn(),
      hasCompletedTour: false,
      resetTourCompletion: jest.fn(),
    })

    // Add mock elements for tour targets
    const mockElements = `
      <div class="dq-dashboard-header"></div>
      <div class="dq-overall-score"></div>
      <div class="dq-metrics-cards"></div>
      <div class="dq-charts-container"></div>
      <div class="dq-filters-section"></div>
    `
    document.body.innerHTML = mockElements
  })

  afterEach(() => {
    jest.clearAllMocks()
    document.body.innerHTML = ""
  })

  test("renders tour button on supported pages", () => {
    render(<FeatureTour />)

    const tourButton = screen.getByRole("button", { name: /guidedTour.startTour/i })
    expect(tourButton).toBeInTheDocument()
  })

  test("does not render on unsupported pages", () => {
    // Mock an unsupported page
    ;(useLocation as jest.Mock).mockReturnValue({
      pathname: "/unsupported-page",
    })

    render(<FeatureTour />)

    const tourButton = screen.queryByRole("button", { name: /guidedTour.startTour/i })
    expect(tourButton).not.toBeInTheDocument()
  })

  test("starts tour when button is clicked", () => {
    const mockStartTour = jest.fn()
    ;(useGuidedTour as jest.Mock).mockReturnValue({
      isOpen: false,
      startTour: mockStartTour,
      closeTour: jest.fn(),
      completeTour: jest.fn(),
      currentStep: 0,
      setCurrentStep: jest.fn(),
      hasCompletedTour: false,
      resetTourCompletion: jest.fn(),
    })

    render(<FeatureTour />)

    const tourButton = screen.getByRole("button", { name: /guidedTour.startTour/i })
    fireEvent.click(tourButton)

    expect(mockStartTour).toHaveBeenCalled()
  })

  test("resets tour completion when button is clicked for completed tours", () => {
    const mockResetTourCompletion = jest.fn()
    ;(useGuidedTour as jest.Mock).mockReturnValue({
      isOpen: false,
      startTour: jest.fn(),
      closeTour: jest.fn(),
      completeTour: jest.fn(),
      currentStep: 0,
      setCurrentStep: jest.fn(),
      hasCompletedTour: true,
      resetTourCompletion: mockResetTourCompletion,
    })

    render(<FeatureTour />)

    const tourButton = screen.getByRole("button", { name: /guidedTour.restartTour/i })
    fireEvent.click(tourButton)

    expect(mockResetTourCompletion).toHaveBeenCalled()
  })

  test("loads different tour steps based on current route", () => {
    // Test home tour
    ;(useLocation as jest.Mock).mockReturnValue({
      pathname: ROUTES.HOME,
    })

    const { rerender } = render(<FeatureTour />)

    // Check that home tour is used
    expect(useGuidedTour).toHaveBeenCalledWith(
      expect.objectContaining({
        tourId: "home-tour",
        steps: expect.arrayContaining([
          expect.objectContaining({
            target: ".dq-dashboard-header",
          }),
        ]),
      }),
    )

    // Test profiling tour
    ;(useLocation as jest.Mock).mockReturnValue({
      pathname: ROUTES.AUTO_PROFILE,
    })

    rerender(<FeatureTour />)

    // Check that profiling tour is used
    expect(useGuidedTour).toHaveBeenCalledWith(
      expect.objectContaining({
        tourId: "profiling-tour",
      }),
    )

    // Test validation tour
    ;(useLocation as jest.Mock).mockReturnValue({
      pathname: ROUTES.DATA_QUALITY_VALIDATION,
    })

    rerender(<FeatureTour />)

    // Check that validation tour is used
    expect(useGuidedTour).toHaveBeenCalledWith(
      expect.objectContaining({
        tourId: "validation-tour",
      }),
    )
  })

  test("renders GuidedTour component when tour is open", () => {
    // Mock tour as open
    ;(useGuidedTour as jest.Mock).mockReturnValue({
      isOpen: true,
      startTour: jest.fn(),
      closeTour: jest.fn(),
      completeTour: jest.fn(),
      currentStep: 0,
      setCurrentStep: jest.fn(),
      hasCompletedTour: false,
      resetTourCompletion: jest.fn(),
    })

    render(<FeatureTour />)

    // GuidedTour should be rendered with props
    expect(screen.getByTestId("guided-tour")).toBeInTheDocument()
  })
})

