import { render, screen, fireEvent, waitFor } from "@testing-library/react"
import { BrowserRouter } from "react-router-dom"
import { Provider } from "react-redux"
import { store } from "@/store/store"
import LoginPage from "@/modules/auth/pages/LoginPage"
import { AuthProvider } from "@/modules/auth/context/AuthContext"

describe("LoginPage", () => {
  const setup = () => {
    return render(
      <Provider store={store}>
        <BrowserRouter>
          <AuthProvider>
            <LoginPage />
          </AuthProvider>
        </BrowserRouter>
      </Provider>,
    )
  }

  test("renders login form", () => {
    setup()

    expect(screen.getByText(/LensX/i)).toBeInTheDocument()
    expect(screen.getByLabelText(/Email/i)).toBeInTheDocument()
    expect(screen.getByLabelText(/Password/i)).toBeInTheDocument()
    expect(screen.getByRole("button", { name: /Sign in/i })).toBeInTheDocument()
  })

  test("validates empty form submission", async () => {
    setup()

    const signInButton = screen.getByRole("button", { name: /Sign in/i })
    fireEvent.click(signInButton)

    await waitFor(() => {
      expect(screen.getByText(/email is required/i)).toBeInTheDocument()
      expect(screen.getByText(/password is required/i)).toBeInTheDocument()
    })
  })

  test("validates email format", async () => {
    setup()

    const emailInput = screen.getByLabelText(/Email/i)
    const signInButton = screen.getByRole("button", { name: /Sign in/i })

    fireEvent.change(emailInput, { target: { value: "invalidemail" } })
    fireEvent.click(signInButton)

    await waitFor(() => {
      expect(screen.getByText(/please enter a valid email address/i)).toBeInTheDocument()
    })
  })

  test("validates password minimum length", async () => {
    setup()

    const emailInput = screen.getByLabelText(/Email/i)
    const passwordInput = screen.getByLabelText(/Password/i)
    const signInButton = screen.getByRole("button", { name: /Sign in/i })

    fireEvent.change(emailInput, { target: { value: "test@example.com" } })
    fireEvent.change(passwordInput, { target: { value: "12345" } })
    fireEvent.click(signInButton)

    await waitFor(() => {
      expect(screen.getByText(/password must be at least 6 characters/i)).toBeInTheDocument()
    })
  })

  test("submits valid form data", async () => {
    setup()

    const emailInput = screen.getByLabelText(/Email/i)
    const passwordInput = screen.getByLabelText(/Password/i)
    const signInButton = screen.getByRole("button", { name: /Sign in/i })

    fireEvent.change(emailInput, { target: { value: "john.doe@verizon.com" } })
    fireEvent.change(passwordInput, { target: { value: "password123" } })
    fireEvent.click(signInButton)

    // Check that the button changes to loading state
    await waitFor(() => {
      expect(screen.getByRole("button", { name: /Signing in/i })).toBeInTheDocument()
    })

    // Since we're using MSW to mock the API, we don't need to wait for the actual API call
    // to complete. We can just check that the form was submitted correctly.
  })
})

