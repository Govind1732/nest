import type { Metadata } from "next"
import { PageContainer } from "@/components/layout/PageContainer"
import { DataQualityValidationPage } from "@/modules/profiling/pages/DataQualityValidationPage"

export const metadata: Metadata = {
  title: "Data Quality Validation - LensX",
  description: "Data Quality Validation",
}

export default function DataQualityValidation() {
  return (
    <PageContainer>
      <DataQualityValidationPage />
    </PageContainer>
  )
}

