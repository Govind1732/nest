import type { Metadata } from "next"
import LoginPage from "@/modules/auth/pages/login-page"

export const metadata: Metadata = {
  title: "Login - LensX",
  description: "Sign in to LensX Data Quality & Validation",
}

export default function Login() {
  return <LoginPage />
}

