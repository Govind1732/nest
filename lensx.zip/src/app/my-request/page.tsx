import type { Metadata } from "next"
import { PageContainer } from "@/components/layout/PageContainer"
import { MyRequestPage } from "@/modules/myRequests/pages/MyRequestPage"

export const metadata: Metadata = {
  title: "My Request - LensX",
  description: "My Data Quality Requests",
}

export default function MyRequest() {
  return (
    <PageContainer>
      <MyRequestPage />
    </PageContainer>
  )
}

