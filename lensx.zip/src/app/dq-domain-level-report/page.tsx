import type { Metadata } from "next"
import { PageContainer } from "@/components/layout/PageContainer"
import { DQDomainLevelReportPage } from "@/modules/reports/pages/DQDomainLevelReportPage"

export const metadata: Metadata = {
  title: "DQ Domain Level Report - LensX",
  description: "Domain Level Data Quality Reports",
}

export default function DQDomainLevelReport() {
  return (
    <PageContainer>
      <DQDomainLevelReportPage />
    </PageContainer>
  )
}

