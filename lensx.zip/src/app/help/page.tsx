import type { Metadata } from "next"
import { PageContainer } from "@/components/layout/PageContainer"
import { HelpPage } from "@/modules/help/pages/HelpPage"

export const metadata: Metadata = {
  title: "Help - LensX",
  description: "Help and Knowledge Articles",
}

export default function Help() {
  return (
    <PageContainer>
      <HelpPage />
    </PageContainer>
  )
}

