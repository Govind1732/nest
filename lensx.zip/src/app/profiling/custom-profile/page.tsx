import type { Metadata } from "next"
import { PageContainer } from "@/components/layout/PageContainer"
import { CustomProfilePage } from "@/modules/profiling/pages/CustomProfilePage"

export const metadata: Metadata = {
  title: "Custom Profile - LensX",
  description: "Custom Profile for Data Quality",
}

export default function CustomProfile() {
  return (
    <PageContainer>
      <CustomProfilePage />
    </PageContainer>
  )
}

