import type { Metadata } from "next"
import { PageContainer } from "@/components/layout/PageContainer"
import { AutoProfilePage } from "@/modules/profiling/pages/AutoProfilePage"

export const metadata: Metadata = {
  title: "Auto Profile - LensX",
  description: "Auto Profile for Data Quality",
}

export default function AutoProfile() {
  return (
    <PageContainer>
      <AutoProfilePage />
    </PageContainer>
  )
}

