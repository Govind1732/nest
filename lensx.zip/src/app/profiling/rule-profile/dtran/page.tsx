import type { Metadata } from "next"
import { PageContainer } from "@/components/layout/PageContainer"
import { RuleProfileDTRanPage } from "@/modules/profiling/pages/RuleProfileDTRanPage"

export const metadata: Metadata = {
 title: "DTRan Rule Profile - LensX",
 description: "DTRan Rule Profile for Data Quality",
}

export default function RuleProfileDTRan() {
 return (
   <PageContainer>
     <RuleProfileDTRanPage />
   </PageContainer>
 )
}

