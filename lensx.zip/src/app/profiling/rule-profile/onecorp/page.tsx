import type { Metadata } from "next"
import { PageContainer } from "@/components/layout/PageContainer"
import { RuleProfileOneCorpPage } from "@/modules/profiling/pages/RuleProfileOneCorpPage"

export const metadata: Metadata = {
  title: "OneCorp Rule Profile - LensX",
  description: "OneCorp Rule Profile for Data Quality",
}

export default function RuleProfileOneCorp() {
  return (
    <PageContainer>
      <RuleProfileOneCorpPage />
    </PageContainer>
  )
}

