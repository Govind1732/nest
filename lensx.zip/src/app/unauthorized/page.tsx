import type { Metadata } from "next"
import UnauthorizedPage from "@/modules/auth/pages/unauthorized-page"

export const metadata: Metadata = {
  title: "Unauthorized - LensX",
  description: "Access Denied",
}

export default function Unauthorized() {
  return <UnauthorizedPage />
}

