"use client"

import { DQDomainLevelReportPage } from "@/modules/reports/pages/DQDomainLevelReportPage"

export default function DQDomainLevelReportRoute() {
  return <DQDomainLevelReportPage />
}

