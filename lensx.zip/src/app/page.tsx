import { redirect } from "next/navigation"

export default function Home() {
  // Redirect to the DQ Reports page as the default landing page
  redirect("/dq-report")
}

