"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { usePathname } from "next/navigation"
import { Navbar } from "./navbar"
import { Sidebar } from "./sidebar"
import { motion } from "framer-motion"
import { useMediaQuery } from "@/hooks/use-media-query"
import { cn } from "@/lib/utils"
import { useAuth } from "@/hooks/use-auth"
import { PageLoadingIndicator } from "@/components/ui/page-loading-indicator"

interface AppLayoutProps {
  children: React.ReactNode
}

export function AppLayout({ children }: AppLayoutProps) {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false)
  const [isSidebarOpen, setIsSidebarOpen] = useState(false)
  const [isPageLoading, setIsPageLoading] = useState(false)
  const pathname = usePathname()
  const isMobile = useMediaQuery("(max-width: 768px)")
  const { isLoading: authLoading } = useAuth()

  // Close sidebar on mobile when route changes
  useEffect(() => {
    if (isMobile) {
      setIsSidebarOpen(false)
    }
  }, [pathname, isMobile])

  // Load sidebar collapsed state from localStorage
  useEffect(() => {
    const savedState = localStorage.getItem("sidebar-collapsed")
    if (savedState !== null) {
      setIsSidebarCollapsed(JSON.parse(savedState))
    }
  }, [])

  // Save sidebar collapsed state to localStorage when it changes
  useEffect(() => {
    localStorage.setItem("sidebar-collapsed", JSON.stringify(isSidebarCollapsed))
  }, [isSidebarCollapsed])

  // Show loading state when changing routes
  useEffect(() => {
    const handleStart = () => setIsPageLoading(true)
    const handleComplete = () => setIsPageLoading(false)

    // Add event listeners for route changes
    window.addEventListener("routeChangeStart", handleStart)
    window.addEventListener("routeChangeComplete", handleComplete)
    window.addEventListener("routeChangeError", handleComplete)

    return () => {
      window.removeEventListener("routeChangeStart", handleStart)
      window.removeEventListener("routeChangeComplete", handleComplete)
      window.removeEventListener("routeChangeError", handleComplete)
    }
  }, [])

  const toggleSidebar = () => {
    if (isMobile) {
      setIsSidebarOpen(!isSidebarOpen)
    } else {
      setIsSidebarCollapsed(!isSidebarCollapsed)
    }
  }

  if (authLoading) {
    return <PageLoadingIndicator />
  }

  return (
    <div className="relative flex h-screen overflow-hidden bg-background">
      {/* Sidebar */}
      <Sidebar isCollapsed={isSidebarCollapsed} isMobile={isMobile} isOpen={isSidebarOpen} onToggle={toggleSidebar} />

      {/* Mobile sidebar overlay */}
      {isMobile && isSidebarOpen && (
        <div className="fixed inset-0 z-40 bg-black/50" onClick={() => setIsSidebarOpen(false)} />
      )}

      {/* Main content area */}
      <motion.div
        className="relative flex flex-col flex-1 w-full overflow-hidden"
        initial={false}
        animate={{
          marginLeft: isMobile ? 0 : isSidebarCollapsed ? 80 : 280,
          width: isMobile ? "100%" : isSidebarCollapsed ? "calc(100% - 80px)" : "calc(100% - 280px)",
        }}
        transition={{ duration: 0.3, ease: "easeInOut" }}
      >
        {/* Navbar */}
        <Navbar isSidebarCollapsed={isSidebarCollapsed} onToggleSidebar={toggleSidebar} />

        {/* Page content */}
        <div
          className={cn(
            "flex-1 overflow-auto p-4 lg:p-6",
            isPageLoading && "opacity-50 transition-opacity duration-300",
          )}
        >
          {isPageLoading ? <PageLoadingIndicator /> : children}
        </div>
      </motion.div>
    </div>
  )
}

