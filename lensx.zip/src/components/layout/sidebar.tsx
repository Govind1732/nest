"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { motion, AnimatePresence } from "framer-motion"
import {
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  Home,
  Database,
  CheckCircle,
  Webhook,
  BarChart,
  FileText,
  ShieldCheck,
  type LucideIcon,
} from "lucide-react"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { SIDEBAR_ITEMS } from "@/config/constants"
import { useAuth } from "@/hooks/use-auth"

interface SidebarProps {
  isCollapsed: boolean
  isMobile: boolean
  isOpen: boolean
  onToggle: () => void
}

export function Sidebar({ isCollapsed, isMobile, isOpen, onToggle }: SidebarProps) {
  const pathname = usePathname()
  const [openMenus, setOpenMenus] = useState<Record<string, boolean>>({})
  const { user, hasPermission } = useAuth()

  // Initialize open state based on current path
  useEffect(() => {
    const newOpenMenus: Record<string, boolean> = {}

    SIDEBAR_ITEMS.forEach((item) => {
      if (item.submenu) {
        const isSubmenuActive = item.submenu.some(
          (subItem) => pathname === subItem.href || pathname.startsWith(subItem.href + "/"),
        )
        if (isSubmenuActive) {
          newOpenMenus[item.title] = true
        }
      }
    })

    setOpenMenus(newOpenMenus)
  }, [pathname])

  const toggleMenu = (title: string) => {
    setOpenMenus((prev) => ({
      ...prev,
      [title]: !prev[title],
    }))
  }

  // Get icon component from icon name string
  const getIconComponent = (iconName?: string): LucideIcon | null => {
    switch (iconName) {
      case "Home":
        return Home
      case "Database":
        return Database
      case "CheckCircle":
        return CheckCircle
      case "Webhook":
        return Webhook
      case "BarChart":
        return BarChart
      case "FileText":
        return FileText
      case "ShieldCheck":
        return ShieldCheck
      default:
        return null
    }
  }

  // Filter items based on user permissions
  const filteredItems = SIDEBAR_ITEMS.filter((item) => {
    // If no requiredRole is specified, show the item
    if (!item.requiredRole) return true

    // If item has a requiredRole, check permission
    return hasPermission(item.requiredRole, item.requiredProject)
  })

  // Styles based on collapsed state
  const sidebarWidth = isCollapsed ? "w-20" : "w-72"
  const sidebarClass = isMobile
    ? `fixed inset-y-0 left-0 z-50 transform ${isOpen ? "translate-x-0" : "-translate-x-full"} transition-transform duration-300 ease-in-out ${sidebarWidth}`
    : `relative ${sidebarWidth} transition-all duration-300 ease-in-out`

  return (
    <>
      <aside className={cn("flex h-screen flex-col border-r bg-background", sidebarClass)}>
        {/* Sidebar header with toggle button */}
        <div className="flex h-16 items-center justify-between border-b px-4">
          <div className="flex items-center">
            {!isCollapsed && <span className="text-lg font-semibold">Data Quality</span>}
          </div>
          {!isMobile && (
            <Button
              variant="ghost"
              size="icon"
              onClick={onToggle}
              className="h-8 w-8"
              aria-label={isCollapsed ? "Expand sidebar" : "Collapse sidebar"}
            >
              {isCollapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
            </Button>
          )}
        </div>

        {/* Sidebar content with scroll area */}
        <ScrollArea className="flex-1 py-2">
          <nav className="space-y-1 px-2">
            {filteredItems.map((item) => {
              const IconComponent = item.icon ? getIconComponent(item.icon) : null
              const isActive =
                pathname === item.href ||
                (item.submenu && item.submenu.some((subItem) => pathname.startsWith(subItem.href)))

              // Skip rendering if item requires a role and user doesn't have permission
              if (item.requiredRole && !hasPermission(item.requiredRole, item.requiredProject)) {
                return null
              }

              return (
                <div key={item.title} className="py-0.5">
                  {item.submenu ? (
                    <div>
                      <Button
                        variant="ghost"
                        size={isCollapsed ? "icon" : "default"}
                        className={cn("w-full justify-start", isActive && "bg-muted", isCollapsed && "h-10 w-10 p-0")}
                        onClick={() => !isCollapsed && toggleMenu(item.title)}
                      >
                        {IconComponent && <IconComponent className="h-4 w-4 mr-2" />}
                        {!isCollapsed && (
                          <>
                            <span className="flex-1 text-left">{item.title}</span>
                            <ChevronDown
                              className={cn("h-4 w-4 transition-transform", openMenus[item.title] && "rotate-180")}
                            />
                          </>
                        )}
                      </Button>

                      {/* Submenu items - only show when not collapsed */}
                      {!isCollapsed && (
                        <AnimatePresence initial={false}>
                          {openMenus[item.title] && (
                            <motion.div
                              initial={{ height: 0, opacity: 0 }}
                              animate={{ height: "auto", opacity: 1 }}
                              exit={{ height: 0, opacity: 0 }}
                              transition={{ duration: 0.2 }}
                              className="overflow-hidden"
                            >
                              <div className="pl-6 pt-1">
                                {item.submenu.map((subItem) => {
                                  // Skip rendering if subitem requires a role and user doesn't have permission
                                  if (
                                    subItem.requiredRole &&
                                    !hasPermission(subItem.requiredRole, subItem.requiredProject)
                                  ) {
                                    return null
                                  }

                                  return (
                                    <Link
                                      key={subItem.href}
                                      href={subItem.href}
                                      className={cn(
                                        "flex items-center py-2 px-3 text-sm rounded-md transition-colors",
                                        pathname === subItem.href
                                          ? "bg-primary/10 text-primary font-medium"
                                          : "text-muted-foreground hover:bg-muted",
                                      )}
                                    >
                                      {subItem.title}
                                    </Link>
                                  )
                                })}
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      )}

                      {/* Collapsed state: Show tooltip on hover for submenus */}
                      {isCollapsed && item.submenu && (
                        <div className="mt-1 space-y-1 pl-3">
                          {item.submenu.map((subItem) => {
                            // Skip rendering if subitem requires a role and user doesn't have permission
                            if (subItem.requiredRole && !hasPermission(subItem.requiredRole, subItem.requiredProject)) {
                              return null
                            }

                            return (
                              <div key={subItem.href} className="group relative">
                                <Link
                                  href={subItem.href}
                                  className={cn(
                                    "flex h-8 w-8 items-center justify-center rounded-md",
                                    pathname === subItem.href
                                      ? "bg-primary/10 text-primary"
                                      : "text-muted-foreground hover:bg-muted hover:text-foreground",
                                  )}
                                >
                                  <span className="h-1.5 w-1.5 rounded-full bg-current" />
                                </Link>
                                <div className="absolute left-full top-0 ml-1.5 hidden group-hover:block">
                                  <div className="rounded bg-popover px-2 py-1 text-xs font-medium text-popover-foreground shadow-md">
                                    {subItem.title}
                                  </div>
                                </div>
                              </div>
                            )
                          })}
                        </div>
                      )}
                    </div>
                  ) : (
                    <Link href={item.href}>
                      <Button
                        variant="ghost"
                        size={isCollapsed ? "icon" : "default"}
                        className={cn(
                          "w-full justify-start",
                          pathname === item.href && "bg-muted",
                          isCollapsed && "h-10 w-10 p-0",
                        )}
                      >
                        {IconComponent && <IconComponent className={cn("h-4 w-4", !isCollapsed && "mr-2")} />}
                        {!isCollapsed && <span>{item.title}</span>}
                      </Button>
                    </Link>
                  )}
                </div>
              )
            })}
          </nav>
        </ScrollArea>

        {/* Sidebar footer */}
        {!isCollapsed && (
          <div className="border-t p-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-medium">{user?.role || "Guest"}</p>
                <p className="text-xs text-muted-foreground">Role-based access</p>
              </div>
              {user?.role !== "Admin" && (
                <Button variant="outline" size="sm" asChild>
                  <Link href="/request-access">Upgrade</Link>
                </Button>
              )}
            </div>
          </div>
        )}
      </aside>
    </>
  )
}

