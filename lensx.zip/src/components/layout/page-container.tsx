"use client"

import type { ReactNode } from "react"
import { usePathname } from "next/navigation"
import Link from "next/link"
import { cva } from "class-variance-authority"
import { ChevronRight, Home } from "lucide-react"

const containerVariants = cva("flex flex-col space-y-4", {
  variants: {
    variant: {
      default: "",
      dashboard: "space-y-6",
    },
  },
  defaultVariants: {
    variant: "default",
  },
})

interface Breadcrumb {
  label: string
  href?: string
}

interface PageContainerProps {
  children: ReactNode
  title?: string
  description?: string
  breadcrumbs?: Breadcrumb[]
  actions?: ReactNode
  variant?: "default" | "dashboard"
  className?: string
}

export function PageHeader({
  title,
  description,
  actions,
  breadcrumbs,
}: Pick<PageContainerProps, "title" | "description" | "actions" | "breadcrumbs">) {
  const pathname = usePathname();
  
  // Generate breadcrumbs from pathname if not provided
  const generatedBreadcrumbs = !breadcrumbs && pathname !== "/" 
    ? pathname
        .split("/")
        .filter(Boolean)
        .map((segment, index, segments) => {
          const href = `/${segments.slice(0, index + 1).join("/")}`;
          return {
            label: segment
              .split("-")
              .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
              .join(" "),
            href,
          };
        })
    : [];

  const breadcrumbItems = breadcrumbs || generatedBreadcrumbs;

  return (
    <div className="flex flex-col space-y-2 md:flex-row md:items-center md:justify-between md:space-y-0">
      <div className="space-y-1">
        {breadcrumbItems.length > 0 && (
          <nav className="flex items-center text-sm text-muted-foreground">
            <Link
              href="/"
              className="inline-flex items-center gap-1 hover:text-foreground"
            >
              <Home className="h-3.5 w-3.5" />
              <span>Home</span>
            </Link>
            {breadcrumbItems.map((crumb, i) => (
              <span key={i} className="flex items-center">
                <ChevronRight className="h-3.5 w-3.5 mx-1" />
                {crumb.href ? (
                  <Link
                    href={crumb.href}
                    className="hover:text-foreground"
                  >
                    {crumb.label}
                  </Link>
                ) : (
                  <span>{crumb.label}</span>
                )}
              </span>
            ))}
          </nav>
        )}
        {title && (
          <h1 className="text-2


\

