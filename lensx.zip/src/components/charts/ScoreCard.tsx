"use client"

import type React from "react"

import { cn } from "@/lib/utils"
import { formatPercentage } from "@/lib/formatters"
import { Card, CardContent } from "@/components/ui/card"

interface ScoreCardProps {
  title: string
  value: number
  icon: React.ReactNode
  className?: string
  variant?: "default" | "success" | "warning" | "error"
}

export function ScoreCard({ title, value, icon, className, variant = "default" }: ScoreCardProps) {
  const getVariantClass = () => {
    switch (variant) {
      case "success":
        return "bg-[var(--vds-color-feedback-success)] text-[var(--stroke-color-success)]"
      case "warning":
        return "bg-[var(--vds-color-feedback-warning)] text-[var(--stroke-color-medium)]"
      case "error":
        return "bg-[var(--vds-color-feedback-error)] text-[var(--stroke-color-low)]"
      default:
        return "bg-muted"
    }
  }

  const getVariantByValue = () => {
    if (value >= 90) return "success"
    if (value >= 80) return "warning"
    return "error"
  }

  const dynamicVariant = variant === "default" ? getVariantByValue() : variant

  return (
    <Card className={cn("overflow-hidden", className)}>
      <CardContent className="p-6">
        <div className="flex flex-col items-center text-center">
          <div className={cn("flex items-center justify-center rounded-full p-3 mb-4", getVariantClass())}>{icon}</div>
          <h3 className="text-xl font-semibold">{title}</h3>
          <p
            className={cn(
              "text-3xl font-bold mt-2",
              dynamicVariant === "success" && "text-[var(--stroke-color-success)]",
              dynamicVariant === "warning" && "text-[var(--stroke-color-medium)]",
              dynamicVariant === "error" && "text-[var(--stroke-color-low)]",
            )}
          >
            {formatPercentage(value)}
          </p>
        </div>
      </CardContent>
    </Card>
  )
}

