"use client"

import { useRef, useEffect } from "react"
import { Chart, type ChartConfiguration, registerables } from "chart.js"
import { cn } from "@/lib/utils"
import { formatPercentage } from "@/lib/formatters"

Chart.register(...registerables)

interface BarChartProps {
  data: {
    labels: string[]
    values: number[]
  }
  height?: number
  className?: string
  horizontal?: boolean
  showValues?: boolean
}

export function BarChart({ data, height = 300, className, horizontal = false, showValues = true }: BarChartProps) {
  const chartRef = useRef<HTMLCanvasElement>(null)
  const chartInstance = useRef<Chart | null>(null)

  useEffect(() => {
    if (!chartRef.current) return

    // Destroy existing chart
    if (chartInstance.current) {
      chartInstance.current.destroy()
    }

    const ctx = chartRef.current.getContext("2d")
    if (!ctx) return

    const getBarColor = (value: number) => {
      if (value >= 90) return "rgba(0, 131, 49, 0.7)"
      if (value >= 80) return "rgba(188, 159, 10, 0.7)"
      return "rgba(185, 83, 25, 0.7)"
    }

    const getBarBorderColor = (value: number) => {
      if (value >= 90) return "rgb(0, 131, 49)"
      if (value >= 80) return "rgb(188, 159, 10)"
      return "rgb(185, 83, 25)"
    }

    const barColors = data.values.map(getBarColor)
    const barBorderColors = data.values.map(getBarBorderColor)

    const config: ChartConfiguration = {
      type: horizontal ? "horizontalBar" : "bar",
      data: {
        labels: data.labels,
        datasets: [
          {
            data: data.values,
            backgroundColor: barColors,
            borderColor: barBorderColors,
            borderWidth: 1,
            borderRadius: 4,
            barPercentage: 0.6,
            categoryPercentage: 0.8,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false,
          },
          tooltip: {
            callbacks: {
              label: (context) => {
                return formatPercentage(context.parsed.y || context.parsed.x || 0)
              },
            },
          },
        },
        scales: {
          x: {
            grid: {
              display: false,
            },
            ticks: {
              font: {
                size: 11,
              },
            },
          },
          y: {
            beginAtZero: true,
            max: 100,
            grid: {
              display: true,
              drawBorder: false,
            },
            ticks: {
              font: {
                size: 11,
              },
              callback: (value) => {
                return showValues ? `${value}%` : value
              },
            },
          },
        },
      },
    }

    chartInstance.current = new Chart(ctx, config)

    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy()
      }
    }
  }, [data, horizontal, showValues])

  return (
    <div className={cn("w-full", className)} style={{ height }}>
      <canvas ref={chartRef} />
    </div>
  )
}

