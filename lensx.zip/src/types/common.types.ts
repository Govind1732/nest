import type React from "react"
// Common types used across the application

export type NavItem = {
  title: string
  href: string
  icon?: React.ComponentType<{ className?: string }>
  disabled?: boolean
  external?: boolean
  submenu?: NavItem[]
}

export type SidebarNavItem = {
  title: string
  href: string
  icon?: React.ComponentType<{ className?: string }>
  disabled?: boolean
  external?: boolean
  submenu?: SidebarNavItem[]
}

export type DQScore = {
  name: string
  value: number
  color?: string
}

export type DQScoreCard = {
  title: string
  value: number
  icon: React.ComponentType<{ className?: string }>
  color?: string
}

export type TableData = {
  id: string | number
  [key: string]: any
}

export type ProfileType =
  | "Auto Profile"
  | "Rule Profile - DTRan"
  | "Rule Profile - OneCorp"
  | "Rule Profile - MLE"
  | "Data Profile"
  | "Custom Profile"

export type UserRole = "Admin" | "DQ User" | "Executive"

export type User = {
  id: string
  name: string
  email: string
  role: UserRole
  projects: string[]
}

export type ChartData = {
  name: string
  value: number
}

export type LineChartData = {
  date: string
  value: number
}

export type DQReport = {
  id: string
  name: string
  score: number
  completeness: number
  timeliness: number
  uniqueness: number
  conformity: number
  validity: number
  consistency?: number
}

export type DQDomainReport = {
  id: string
  name: string
  score: number
  subdomains: {
    name: string
    score: number
  }[]
  metrics: {
    completeness: number
    timeliness: number
    uniqueness: number
    conformity: number
    validity: number
    consistency?: number
  }
  trend: LineChartData[]
}

