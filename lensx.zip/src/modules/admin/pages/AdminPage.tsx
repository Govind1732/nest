"use client"

import { useState, useEffect } from "react"
import { useTranslation } from "react-i18next"
import { motion } from "framer-motion"
import { PageContainer, PageHeader, PageSection } from "@/components/layout/PageContainer"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { DataTable } from "@/components/ui/data-table"
import { Badge } from "@/components/ui/badge"
import { RoleGuard } from "@/modules/auth/components/RoleGuard"
import { useToast } from "@/hooks/use-toast"
import { Check, X, UserPlus, User, Users, ShieldCheck, Eye } from "lucide-react"

export default function AdminPage() {
  const { t } = useTranslation()
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("role-requests")
  const [isLoading, setIsLoading] = useState(true)
  const [requests, setRequests] = useState([])
  const [users, setUsers] = useState([])

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true)
      try {
        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 1000))

        // Mock data
        setRequests([
          {
            id: "req-1",
            userId: "user-2",
            userName: "Jane Smith",
            email: "jane.smith@verizon.com",
            currentRole: "Executive",
            requestedRole: "DQ User",
            projectId: "DTRan",
            reason: "Need to submit and manage DTRan profiles for the Q2 data quality audit",
            status: "pending",
            createdAt: "2025-03-25T14:32:00Z",
          },
          {
            id: "req-2",
            userId: "user-3",
            userName: "Michael Johnson",
            email: "michael.johnson@verizon.com",
            currentRole: "Executive",
            requestedRole: "DQ User",
            projectId: "OneCorp",
            reason: "Working on the OneCorp migration project and need to validate data quality",
            status: "pending",
            createdAt: "2025-03-28T09:15:00Z",
          },
        ])

        setUsers([
          {
            id: "user-1",
            name: "John Doe",
            email: "john.doe@verizon.com",
            role: "Admin",
            department: "IT",
            projects: ["DTRan", "OneCorp", "MLE"],
            lastActive: "2025-04-01T15:23:00Z",
          },
          {
            id: "user-2",
            name: "Jane Smith",
            email: "jane.smith@verizon.com",
            role: "Executive",
            department: "Data Analytics",
            projects: [],
            lastActive: "2025-03-30T11:45:00Z",
          },
          {
            id: "user-3",
            name: "Michael Johnson",
            email: "michael.johnson@verizon.com",
            role: "Executive",
            department: "Business Intelligence",
            projects: [],
            lastActive: "2025-03-29T16:10:00Z",
          },
          {
            id: "user-4",
            name: "Sarah Williams",
            email: "sarah.williams@verizon.com",
            role: "DQ User",
            department: "Data Governance",
            projects: ["DTRan"],
            lastActive: "2025-03-31T14:05:00Z",
          },
        ])
      } catch (error) {
        console.error("Failed to fetch admin data:", error)
        toast({
          variant: "destructive",
          title: t("common.status.error"),
          description: t("admin.fetchError"),
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchData()
  }, [toast, t])

  const handleApproveRequest = (requestId) => {
    // Update local state
    setRequests(requests.map((req) => (req.id === requestId ? { ...req, status: "approved" } : req)))

    // Update user role in users list
    const request = requests.find((req) => req.id === requestId)
    if (request) {
      setUsers(
        users.map((user) =>
          user.id === request.userId
            ? {
                ...user,
                role: request.requestedRole,
                projects: [...user.projects, request.projectId],
              }
            : user,
        ),
      )
    }

    toast({
      title: t("admin.requestApproved"),
      description: t("admin.userRoleUpdated"),
    })
  }

  const handleRejectRequest = (requestId) => {
    setRequests(requests.map((req) => (req.id === requestId ? { ...req, status: "rejected" } : req)))

    toast({
      title: t("admin.requestRejected"),
      description: t("admin.userNotified"),
    })
  }

  const requestColumns = [
    {
      accessorKey: "userName",
      header: t("admin.userName"),
    },
    {
      accessorKey: "email",
      header: t("admin.email"),
    },
    {
      accessorKey: "currentRole",
      header: t("admin.currentRole"),
      cell: ({ row }) => (
        <Badge variant="outline" className="font-normal">
          {row.original.currentRole}
        </Badge>
      ),
    },
    {
      accessorKey: "requestedRole",
      header: t("admin.requestedRole"),
      cell: ({ row }) => (
        <Badge variant="outline" className="font-normal">
          {row.original.requestedRole}
        </Badge>
      ),
    },
    {
      accessorKey: "projectId",
      header: t("admin.project"),
    },
    {
      accessorKey: "reason",
      header: t("admin.reason"),
      cell: ({ row }) => (
        <div className="max-w-[200px] truncate" title={row.original.reason}>
          {row.original.reason}
        </div>
      ),
    },
    {
      accessorKey: "status",
      header: t("admin.status"),
      cell: ({ row }) => {
        const status = row.original.status
        return (
          <Badge variant={status === "approved" ? "success" : status === "rejected" ? "destructive" : "secondary"}>
            {status === "pending"
              ? t("admin.pending")
              : status === "approved"
                ? t("admin.approved")
                : t("admin.rejected")}
          </Badge>
        )
      },
    },
    {
      id: "actions",
      header: t("admin.actions"),
      cell: ({ row }) => {
        const { id, status } = row.original
        const isPending = status === "pending"

        return (
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleApproveRequest(id)}
              disabled={!isPending}
              className="h-8 w-8 p-0"
              aria-label={t("admin.approve")}
            >
              <Check className="h-4 w-4 text-green-500" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleRejectRequest(id)}
              disabled={!isPending}
              className="h-8 w-8 p-0"
              aria-label={t("admin.reject")}
            >
              <X className="h-4 w-4 text-red-500" />
            </Button>
          </div>
        )
      },
    },
  ]

  const userColumns = [
    {
      accessorKey: "name",
      header: t("admin.name"),
    },
    {
      accessorKey: "email",
      header: t("admin.email"),
    },
    {
      accessorKey: "department",
      header: t("admin.department"),
    },
    {
      accessorKey: "role",
      header: t("admin.role"),
      cell: ({ row }) => (
        <Badge variant="outline" className="font-normal">
          {row.original.role}
        </Badge>
      ),
    },
    {
      accessorKey: "projects",
      header: t("admin.projects"),
      cell: ({ row }) => {
        const projects = row.original.projects
        return projects.length > 0 ? (
          <div className="flex flex-wrap gap-1">
            {projects.map((project) => (
              <Badge key={project} variant="secondary" className="text-xs">
                {project}
              </Badge>
            ))}
          </div>
        ) : (
          <span className="text-muted-foreground text-sm">-</span>
        )
      },
    },
    {
      accessorKey: "lastActive",
      header: t("admin.lastActive"),
      cell: ({ row }) => <span>{new Date(row.original.lastActive).toLocaleString()}</span>,
    },
    {
      id: "actions",
      header: t("admin.actions"),
      cell: ({ row }) => (
        <div className="flex gap-2">
          <Button variant="ghost" size="sm" className="h-8 w-8 p-0" aria-label={t("admin.viewUser")}>
            <Eye className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" className="h-8 w-8 p-0" aria-label={t("admin.editUser")}>
            <User className="h-4 w-4" />
          </Button>
        </div>
      ),
    },
  ]

  const statsData = [
    { title: t("admin.totalUsers"), value: users.length, icon: <Users className="h-5 w-5" /> },
    {
      title: t("admin.pendingRequests"),
      value: requests.filter((r) => r.status === "pending").length,
      icon: <UserPlus className="h-5 w-5" />,
    },
    {
      title: t("admin.adminUsers"),
      value: users.filter((u) => u.role === "Admin").length,
      icon: <ShieldCheck className="h-5 w-5" />,
    },
  ]

  return (
    <PageContainer>
      <PageHeader title={t("admin.title")} description={t("admin.description")} />

      <RoleGuard requiredRole="Admin">
        <PageSection>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            {statsData.map((stat, i) => (
              <Card key={i}>
                <CardContent className="flex items-center p-6">
                  <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center text-primary mr-4">
                    {stat.icon}
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">{stat.title}</p>
                    <p className="text-2xl font-bold">{stat.value}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <Tabs defaultValue="role-requests" onValueChange={setActiveTab}>
            <TabsList className="mb-6">
              <TabsTrigger value="role-requests">{t("admin.roleRequests")}</TabsTrigger>
              <TabsTrigger value="user-management">{t("admin.userManagement")}</TabsTrigger>
              <TabsTrigger value="permissions">{t("admin.permissions")}</TabsTrigger>
            </TabsList>

            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              <Card>
                <TabsContent value="role-requests" className="m-0">
                  <CardHeader>
                    <CardTitle>{t("admin.roleUpgradeRequests")}</CardTitle>
                    <CardDescription>{t("admin.roleRequestsDescription")}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {isLoading ? (
                      <div className="flex items-center justify-center h-64">
                        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                      </div>
                    ) : requests.length > 0 ? (
                      <DataTable columns={requestColumns} data={requests} />
                    ) : (
                      <div className="flex items-center justify-center h-64">
                        <p className="text-muted-foreground">{t("admin.noRequests")}</p>
                      </div>
                    )}
                  </CardContent>
                </TabsContent>

                <TabsContent value="user-management" className="m-0">
                  <CardHeader>
                    <CardTitle>{t("admin.users")}</CardTitle>
                    <CardDescription>{t("admin.userManagementDescription")}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {isLoading ? (
                      <div className="flex items-center justify-center h-64">
                        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                      </div>
                    ) : (
                      <DataTable columns={userColumns} data={users} />
                    )}
                  </CardContent>
                </TabsContent>

                <TabsContent value="permissions" className="m-0">
                  <CardHeader>
                    <CardTitle>{t("admin.rolePermissions")}</CardTitle>
                    <CardDescription>{t("admin.permissionsDescription")}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      <div className="space-y-4">
                        <h3 className="text-lg font-medium">{t("admin.adminRole")}</h3>
                        <ul className="list-disc pl-5 space-y-1">
                          <li>{t("admin.adminPermission1")}</li>
                          <li>{t("admin.adminPermission2")}</li>
                          <li>{t("admin.adminPermission3")}</li>
                          <li>{t("admin.adminPermission4")}</li>
                        </ul>
                      </div>

                      <div className="space-y-4">
                        <h3 className="text-lg font-medium">{t("admin.dqUserRole")}</h3>
                        <ul className="list-disc pl-5 space-y-1">
                          <li>{t("admin.dqUserPermission1")}</li>
                          <li>{t("admin.dqUserPermission2")}</li>
                          <li>{t("admin.dqUserPermission3")}</li>
                        </ul>
                      </div>

                      <div className="space-y-4">
                        <h3 className="text-lg font-medium">{t("admin.executiveRole")}</h3>
                        <ul className="list-disc pl-5 space-y-1">
                          <li>{t("admin.executivePermission1")}</li>
                          <li>{t("admin.executivePermission2")}</li>
                          <li>{t("admin.executivePermission3")}</li>
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </TabsContent>
              </Card>
            </motion.div>
          </Tabs>
        </PageSection>
      </RoleGuard>
    </PageContainer>
  )
}

