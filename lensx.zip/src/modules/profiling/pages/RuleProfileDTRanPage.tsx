"use client"

import type React from "react"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import type { z } from "zod"
import { motion } from "framer-motion"
import { Pencil, Trash, Upload } from 'lucide-react'
import { PageContainer, PageHeader } from "@/components/layout/PageContainer"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DataTable } from "@/components/ui/data-table"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { useToast } from "@/hooks/use-toast"
import { ruleProfileDTRanSchema } from "@/lib/schema"
import { RoleGuard } from "@/modules/auth/components/RoleGuard"
import {
 useDispatch,
 useSelector,
} from "react-redux"
import {
 addTableData,
 deleteTableData,
 setEndDate,
 setError,
 setLoading,
 setSourceTable,
 setStartDate,
 setTableData,
 updateTableData,
} from "@/store/slices/ruleProfileDTRanSlice"

type FormValues = z.infer<typeof ruleProfileDTRanSchema>

export default function RuleProfileDTRanPage() {
 const { toast } = useToast()
 const [activeTab, setActiveTab] = useState("submit")
 const [file, setFile] = useState<File | null>(null)
 const [isUploading, setIsUploading] = useState(false)
 const dispatch = useDispatch()
 const { sourceTable, startDate, endDate, tableData, isLoading, error } = useSelector(
   (state: any) => state.ruleProfileDTRan,
 )

 const form = useForm<FormValues>({
   resolver: zodResolver(ruleProfileDTRanSchema),
   defaultValues: {
     sourceTable: "",
     startDate: "",
     endDate: "",
   },
 })

 const columns = [
   { accessorKey: "id", header: "#" },
   { accessorKey: "sourceTable", header: "Source Table" },
   { accessorKey: "startDate", header: "Start Date" },
   { accessorKey: "endDate", header: "End Date" },
   {
     id: "actions",
     header: "Actions",
     cell: ({ row }: any) => (
       <div className="flex items-center gap-2">
         <Button variant="ghost" size="icon" onClick={() => handleEdit(row.original)}>
           <Pencil className="h-4 w-4" />
         </Button>
         <Button variant="ghost" size="icon" onClick={() => handleDelete(row.original.id)}>
           <Trash className="h-4 w-4" />
         </Button>
       </div>
     ),
   },
 ]

 const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
   if (e.target.files && e.target.files.length > 0) {
     setFile(e.target.files[0])
   }
 }

 const handleSubmitFile = async () => {
   if (!file) return

   try {
     setIsUploading(true)
     dispatch(setLoading(true))

     // Simulate API call
     await new Promise((resolve) => setTimeout(resolve, 1500))

     toast({
       title: "Upload successful",
       description: "Your file has been uploaded successfully",
     })

     setFile(null)
     dispatch(setLoading(false))
   } catch (e: any) {
     console.error("Upload failed:", e)
     toast({
       variant: "destructive",
       title: "Upload failed",
       description: "There was an error uploading your file",
     })
     dispatch(setError(e.message))
     dispatch(setLoading(false))
   } finally {
     setIsUploading(false)
   }
 }

 const onSubmit = async (values: FormValues) => {
   try {
     // Add new entry to table
     const newEntry = {
       id: (tableData.length + 1).toString(),
       sourceTable: values.sourceTable,
       startDate: values.startDate,
       endDate: values.endDate,
     }

     dispatch(addTableData(newEntry))

     toast({
       title: "Entry added",
       description: "Your entry has been added successfully",
     })

     form.reset()
   } catch (e: any) {
     console.error("Add failed:", e)
     toast({
       variant: "destructive",
       title: "Add failed",
       description: "There was an error adding your entry",
     })
     dispatch(setError(e.message))
   }
 }

 const handleEdit = (row: any) => {
   dispatch(setSourceTable(row.sourceTable))
   dispatch(setStartDate(row.startDate))
   dispatch(setEndDate(row.endDate))

   // Remove the entry from the table
   dispatch(setTableData(tableData.filter((item) => item.id !== row.id)))
 }

 const handleDelete = (id: string) => {
   dispatch(deleteTableData(id))

   toast({
     title: "Entry deleted",
     description: "Your entry has been deleted successfully",
   })
 }

 const handleDeleteAll = () => {
   dispatch(setTableData([]))

   toast({
     title: "All entries deleted",
     description: "All entries have been deleted successfully",
   })
 }

 const handleSubmitAll = () => {
   if (tableData.length === 0) {
     toast({
       variant: "destructive",
       title: "No entries",
       description: "There are no entries to submit",
     })
     return
   }

   toast({
     title: "All entries submitted",
     description: `${tableData.length} entries have been submitted successfully`,
   })
 }

 return (
   <PageContainer>
     <PageHeader
       title="RanDT Rule Profile"
       breadcrumbs={[
         { label: "Profiling", href: "/profiling" },
         { label: "Rule Profile", href: "/profiling/rule-profile" },
         { label: "Ran DT" },
       ]}
     />

     <RoleGuard requiredRole="DQ User" projectId="DTRan">
       <Tabs defaultValue="submit" onValueChange={setActiveTab}>
         <TabsList className="mb-6">
           <TabsTrigger value="submit">Submit Multiple Requests</TabsTrigger>
           <TabsTrigger value="rerun">DQ Rerun</TabsTrigger>
         </TabsList>

         <motion.div
           key={activeTab}
           initial={{ opacity: 0, y: 20 }}
           animate={{ opacity: 1, y: 0 }}
           exit={{ opacity: 0, y: -20 }}
           transition={{ duration: 0.3 }}
         >
           <Card>
             <CardContent className="p-6">
               {activeTab === "submit" && (
                 <div>
                   <div className="flex flex-col items-center justify-center p-8 border-2 border-dashed rounded-lg">
                     <Upload className="h-12 w-12 text-muted-foreground mb-4" />
                     <p className="text-center mb-4">Upload Excel file for multiple requests</p>

                     <Input
                       type="file"
                       className="hidden"
                       id="file-upload"
                       accept=".csv,.xlsx,.xls"
                       onChange={handleFileChange}
                     />

                     {file ? (
                       <div className="flex items-center gap-2 p-2 border rounded-md w-full max-w-md">
                         <div className="flex-1 truncate">{file.name}</div>
                       </div>
                     ) : (
                       <Button asChild>
                         <label htmlFor="file-upload">Choose File</label>
                       </Button>
                     )}
                   </div>

                   <div className="flex justify-center gap-4 mt-6">
                     <Button variant="outline" onClick={() => setFile(null)}>
                       Reset
                     </Button>
                     <Button onClick={handleSubmitFile} disabled={!file || isUploading}>
                       {isUploading ? "Uploading..." : "Submit"}
                     </Button>
                   </div>
                 </div>
               )}

               {activeTab === "rerun" && (
                 <div>
                   <Form {...form}>
                     <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                       <FormField
                         control={form.control}
                         name="sourceTable"
                         render={({ field }) => (
                           <FormItem>
                             <FormLabel>
                               Source Table <span className="text-red-500">*</span>
                             </FormLabel>
                             <FormControl>
                               <Input placeholder="Please enter text" {...field} onChange={(e) => dispatch(setSourceTable(e.target.value))} />
                             </FormControl>
                             <FormMessage />
                           </FormItem>
                         )}
                       />

                       <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                         <FormField
                           control={form.control}
                           name="startDate"
                           render={({ field }) => (
                             <FormItem>
                               <FormLabel>
                                 Start Date <span className="text-red-500">*</span>
                               </FormLabel>
                               <FormControl>
                                 <Input type="date" {...field} onChange={(e) => dispatch(setStartDate(e.target.value))} />
                               </FormControl>
                               <FormMessage />
                             </FormItem>
                           )}
                         />

                         <FormField
                           control={form.control}
                           name="endDate"
                           render={({ field }) => (
                             <FormItem>
                               <FormLabel>
                                 End Date <span className="text-red-500">*</span>
                               </FormLabel>
                               <FormControl>
                                 <Input type="date" {...field} onChange={(e) => dispatch(setEndDate(e.target.value))} />
                               </FormControl>
                               <FormMessage />
                             </FormItem>
                           )}
                         />
                       </div>

                       <div className="flex justify-end gap-4">
                         <Button type="button" variant="outline" onClick={() => form.reset()}>
                           Reset
                         </Button>
                         <Button type="submit">Add</Button>
                       </div>
                     </form>
                   </Form>

                   <div className="mt-6">
                     <DataTable columns={columns} data={tableData} />
                   </div>

                   <div className="flex justify-end gap-4 mt-6">
                     <Button variant="outline" onClick={handleDeleteAll} disabled={tableData.length === 0}>
                       Delete All
                     </Button>
                     <Button onClick={handleSubmitAll} disabled={tableData.length === 0}>
                       Submit All
                     </Button>
                   </div>
                 </div>
               )}
             </CardContent>
           </Card>
         </motion.div>
       </Tabs>
     </RoleGuard>
   </PageContainer>
 )
}

