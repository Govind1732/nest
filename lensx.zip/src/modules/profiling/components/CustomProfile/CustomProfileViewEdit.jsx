"use client"

import { useState, useEffect } from "react"
import {
  Card,
  CardContent,
  Typography,
  Grid,
  TextField,
  Button,
  CircularProgress,
  MenuItem,
  FormControl,
  InputLabel,
  Select,
} from "@mui/material"
import { useParams, useNavigate } from "react-router-dom"
import { useSnackbar } from "notistack"
import { useTheme } from "@mui/material/styles"
import useMediaQuery from "@mui/material/useMediaQuery"

import { getCustomProfile, updateCustomProfile } from "../../../../services/customProfileService"
import { getAllProfileFields } from "../../../../services/profileFieldService"

const CustomProfileViewEdit = () => {
  const { id } = useParams()
  const navigate = useNavigate()
  const { enqueueSnackbar } = useSnackbar()
  const theme = useTheme()
  const isXs = useMediaQuery(theme.breakpoints.down("xs"))
  const isSm = useMediaQuery(theme.breakpoints.down("sm"))

  const [profile, setProfile] = useState({ name: "", description: "", fields: [] })
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [availableFields, setAvailableFields] = useState([])
  const [selectedFields, setSelectedFields] = useState([])

  useEffect(() => {
    const fetchData = async () => {
      try {
        const profileData = await getCustomProfile(id)
        setProfile(profileData)
        setSelectedFields(profileData.fields.map((field) => field.id))

        const allFields = await getAllProfileFields()
        setAvailableFields(allFields)
        setLoading(false)
      } catch (error) {
        console.error("Error fetching data:", error)
        enqueueSnackbar("Failed to load profile data", { variant: "error" })
        setLoading(false)
      }
    }

    fetchData()
  }, [id, enqueueSnackbar])

  const handleChange = (e) => {
    setProfile({ ...profile, [e.target.name]: e.target.value })
  }

  const handleFieldChange = (e) => {
    setSelectedFields(e.target.value)
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setSaving(true)

    try {
      const updatedProfile = {
        ...profile,
        fields: selectedFields.map((fieldId) => ({ id: fieldId })),
      }
      await updateCustomProfile(id, updatedProfile)
      enqueueSnackbar("Profile updated successfully", { variant: "success" })
      navigate("/profiling/custom-profiles")
    } catch (error) {
      console.error("Error updating profile:", error)
      enqueueSnackbar("Failed to update profile", { variant: "error" })
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <div style={{ display: "flex", justifyContent: "center", alignItems: "center", height: "200px" }}>
        <CircularProgress />
      </div>
    )
  }

  return (
    <Card>
      <CardContent>
        <Typography variant="h5" component="div" gutterBottom>
          Edit Custom Profile
        </Typography>
        <form onSubmit={handleSubmit}>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Name"
                name="name"
                value={profile.name}
                onChange={handleChange}
                required
                variant="outlined"
                size={isXs ? "small" : "medium"}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Description"
                name="description"
                value={profile.description}
                onChange={handleChange}
                variant="outlined"
                size={isXs ? "small" : "medium"}
              />
            </Grid>
            <Grid item xs={12}>
              <FormControl fullWidth variant="outlined" size={isXs ? "small" : "medium"}>
                <InputLabel id="fields-label">Fields</InputLabel>
                <Select
                  labelId="fields-label"
                  multiple
                  value={selectedFields}
                  onChange={handleFieldChange}
                  label="Fields"
                  renderValue={(selected) =>
                    selected.map((id) => availableFields.find((field) => field.id === id)?.name).join(", ")
                  }
                >
                  {availableFields.map((field) => (
                    <MenuItem key={field.id} value={field.id}>
                      {field.name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12}>
              <Button type="submit" variant="contained" color="primary" disabled={saving}>
                {saving ? <CircularProgress size={24} color="inherit" /> : "Update"}
              </Button>
              <Button
                onClick={() => navigate("/profiling/custom-profiles")}
                variant="text"
                style={{ marginLeft: "10px" }}
              >
                Cancel
              </Button>
            </Grid>
          </Grid>
        </form>
      </CardContent>
    </Card>
  )
}

export default CustomProfileViewEdit

