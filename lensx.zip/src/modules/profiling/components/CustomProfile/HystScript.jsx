"use client"

```jsx file="src/modules/profiling/components/CustomProfile/CustomProfileBulkUpload.jsx"
[v0-no-op-code-block-prefix]import React, { useState } from 'react';
import { Button, Modal, Upload, message } from 'antd';
import { InboxOutlined } from '@ant-design/icons';
import * as XLSX from 'xlsx';

const { Dragger } = Upload;

const CustomProfileBulkUpload = ({ visible, onCancel, onUploadSuccess }) => {
 const [fileList, setFileList] = useState([]);
 const [uploading, setUploading] = useState(false);

 const props = {
   name: 'file',
   multiple: false,
   accept: '.xlsx, .xls',
   beforeUpload: (file) => {
     const isXLSX = file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || file.type === 'application/vnd.ms-excel';
     if (!isXLSX) {
       message.error('You can only upload XLSX/XLS file!');
     }
     const isLt2M = file.size / 1024 / 1024 < 2;
     if (!isLt2M) {
       message.error('File must smaller than 2MB!');
     }
     return isXLSX && isLt2M;
   },
   onChange: (info) => {
     setFileList(info.fileList.slice(-1));
   },
   onRemove: () => {
     setFileList([]);
   },
   fileList: fileList,
 };

 const handleUpload = async () => {
   setUploading(true);

   try {
     if (fileList.length === 0) {
       message.error('Please select a file to upload.');
       setUploading(false);
       return;
     }

     const file = fileList[0].originFileObj;

     const reader = new FileReader();
     reader.onload = (e) => {
       const data = new Uint8Array(e.target.result);
       const workbook = XLSX.read(data, { type: 'array' });

       const sheetName = workbook.SheetNames[0];
       const worksheet = workbook.Sheets[sheetName];
       const jsonData = XLSX.utils.sheet_to_json(worksheet);

       onUploadSuccess(jsonData);
       message.success('Upload successful.');
       setFileList([]);
       onCancel();
     };
     reader.onerror = () => {
       message.error('Error reading the file.');
       setUploading(false);
     };
     reader.readAsArrayBuffer(file);
   } catch (error) {
     console.error('Upload failed:', error);
     message.error('Upload failed.');
   } finally {
     setUploading(false);
   }
 };

 return (
   <Modal
     title="Bulk Upload Custom Profiles"
     visible={visible}
     onCancel={onCancel}
     footer={[
       <Button key="cancel" onClick={onCancel}>
         Cancel
       </Button>,
       <Button key="upload" type="primary" onClick={handleUpload} disabled={fileList.length === 0} loading={uploading}>
         {uploading ? 'Uploading' : 'Start Upload'}
       </Button>,
     ]}
   >
     <Dragger {...props}>
       <p className="ant-upload-drag-icon">
         <InboxOutlined />
       </p>
       <p className="ant-upload-text">Click or drag file to this area to upload</p>
       <p className="ant-upload-hint">Support for a single XLSX/XLS file upload.</p>
     </Dragger>
   </Modal>
 );
};

export default CustomProfileBulkUpload;

