"use client"

import { useState } from "react"
import { PageHeader } from "@/components/layout/PageContainer"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export function MyRequestPage() {
  const [activeTab, setActiveTab] = useState("auto")
  const [dbName, setDbName] = useState("")
  const [tableName, setTableName] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = () => {
    setIsLoading(true)
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false)
      console.log("Submitted:", { dbName, tableName })
    }, 1500)
  }

  const handleReset = () => {
    setDbName("")
    setTableName("")
  }

  return (
    <div>
      <PageHeader
        title="MyRequest"
        breadcrumbs={[{ label: "API Integration", href: "/api-integration" }, { label: "My Request" }]}
      />

      <Tabs defaultValue="auto" onValueChange={setActiveTab}>
        <TabsList className="mb-6">
          <TabsTrigger value="auto">Auto Profile</TabsTrigger>
          <TabsTrigger value="onecorp">OneCorp Rule Profile</TabsTrigger>
          <TabsTrigger value="dtran">DTRan Rule Profile</TabsTrigger>
          <TabsTrigger value="mle">MLE Rule Profile</TabsTrigger>
        </TabsList>

        <TabsContent value="auto">
          <Card>
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div>
                  <label htmlFor="dbName" className="block text-sm font-medium mb-1">
                    DB Name
                  </label>
                  <Select value={dbName} onValueChange={setDbName}>
                    <SelectTrigger id="dbName">
                      <SelectValue placeholder="DB Name" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="db1">Database 1</SelectItem>
                      <SelectItem value="db2">Database 2</SelectItem>
                      <SelectItem value="db3">Database 3</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label htmlFor="tableName" className="block text-sm font-medium mb-1">
                    Table Name
                  </label>
                  <Select value={tableName} onValueChange={setTableName}>
                    <SelectTrigger id="tableName">
                      <SelectValue placeholder="Table Name" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="table1">Table 1</SelectItem>
                      <SelectItem value="table2">Table 2</SelectItem>
                      <SelectItem value="table3">Table 3</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex justify-center gap-4">
                <Button variant="outline" onClick={handleReset}>
                  Reset
                </Button>
                <Button onClick={handleSubmit} disabled={isLoading}>
                  {isLoading ? "Loading data..." : "Submit"}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="onecorp">
          <Card>
            <CardContent className="p-6">
              <p className="text-center text-muted-foreground mb-4">OneCorp Rule Profile requests</p>

              <div className="flex justify-center">
                <p className="text-sm text-muted-foreground">
                  Select a database and table to view OneCorp Rule Profile requests
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="dtran">
          <Card>
            <CardContent className="p-6">
              <p className="text-center text-muted-foreground mb-4">DTRan Rule Profile requests</p>

              <div className="flex justify-center">
                <p className="text-sm text-muted-foreground">
                  Select a database and table to view DTRan Rule Profile requests
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="mle">
          <Card>
            <CardContent className="p-6">
              <p className="text-center text-muted-foreground mb-4">MLE Rule Profile requests</p>

              <div className="flex justify-center">
                <p className="text-sm text-muted-foreground">
                  Select a database and table to view MLE Rule Profile requests
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

