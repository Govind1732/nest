"use client"

import { PageHeader } from "@/components/layout/PageContainer"
import { Card, CardContent } from "@/components/ui/card"
import { FileText, Video, Mail, MessageSquare } from "lucide-react"

export function HelpPage() {
  const helpArticles = [
    {
      title: "What is Data Quality?",
      pdfLink: "#",
      videoLink: "#",
    },
    {
      title: "How to onboard to Data Quality",
      pdfLink: "#",
      videoLink: "#",
    },
    {
      title: "How can I perform Auto Profiling",
      pdfLink: "#",
      videoLink: "#",
    },
    {
      title: "How can I perform Rule based Profiling",
      pdfLink: "#",
      videoLink: "#",
    },
    {
      title: "How can I perform Auto ML Profiling",
      pdfLink: "#",
      videoLink: "#",
    },
    {
      title: "How to read Data Quality Email Alert?",
      pdfLink: "#",
      videoLink: "#",
    },
    {
      title: "How to read Data Quality Dashboard?",
      pdfLink: "#",
      videoLink: "#",
    },
    {
      title: "How to Subscribe to API for ETL Pipeline?",
      pdfLink: "#",
      videoLink: "#",
    },
  ]

  return (
    <div>
      <PageHeader title="Knowledge Articles" />

      <Card>
        <CardContent className="p-6">
          <div className="space-y-4">
            {helpArticles.map((article, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-muted/50 rounded-md">
                <div className="text-base font-medium">{article.title}</div>
                <div className="flex items-center gap-4">
                  <a href={article.pdfLink} className="flex items-center gap-1 text-sm hover:text-primary">
                    <FileText className="h-4 w-4" />
                    <span>PDF</span>
                  </a>
                  <span className="text-muted-foreground">|</span>
                  <a href={article.videoLink} className="flex items-center gap-1 text-sm hover:text-primary">
                    <Video className="h-4 w-4" />
                    <span>VIDEO</span>
                  </a>
                </div>
              </div>
            ))}

            <div className="flex items-center justify-between p-4 bg-muted/50 rounded-md">
              <div className="text-base font-medium">Whom to reach out for any issues in DQ Framework ?</div>
              <div className="flex items-center gap-4">
                <a href="mailto:DQ-DEV-Team@verizon.com" className="flex items-center gap-1 text-sm hover:text-primary">
                  <Mail className="h-4 w-4" />
                  <span>DQ-DEV-Team@verizon.com</span>
                </a>
                <span className="text-muted-foreground">|</span>
                <a href="#" className="flex items-center gap-1 text-sm hover:text-primary">
                  <MessageSquare className="h-4 w-4" />
                  <span>Slack Channel</span>
                </a>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

