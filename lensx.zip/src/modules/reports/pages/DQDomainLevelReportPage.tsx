import { DQDomainLevelReport } from "../components/DQDomainLevelReport/DQDomainLevelReport"

export function DQDomainLevelReportPage() {
  return (
    <div className="h-screen">
      <DQDomainLevelReport />
    </div>
  )
}

