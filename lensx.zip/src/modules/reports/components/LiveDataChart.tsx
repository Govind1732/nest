"use client"

import { useState, useEffect } from "react"
import { AdvancedLineChart } from "@/components/charts/AdvancedLineChart"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import { Clock } from "lucide-react"

interface LiveDataChartProps {
  title: string
  endpoint: string
  dataSets: string[]
  colors?: string[]
  className?: string
}

export function LiveDataChart({
  title,
  endpoint,
  dataSets,
  colors = ["#008331", "#bc9f0a", "#b95319"],
  className,
}: LiveDataChartProps) {
  const [chartData, setChartData] = useState<any[]>([])
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date())
  const [isLive, setIsLive] = useState(true)
  const [isLoading, setIsLoading] = useState(true)

  // Simulate WebSocket connection for live data
  useEffect(() => {
    if (!isLive) return

    // Initial data fetch
    const fetchInitialData = async () => {
      setIsLoading(true)
      try {
        // In a real app, this would be an API call
        // For demo purposes, we'll generate random data
        const initialData = Array(20)
          .fill(0)
          .map((_, i) => {
            const timestamp = new Date(Date.now() - (19 - i) * 30000) // Every 30 seconds
            const dataPoint: any = {
              timestamp: timestamp.toISOString(),
              name: timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }),
            }

            dataSets.forEach((metric) => {
              dataPoint[metric] = Math.floor(Math.random() * 20) + 80 // Random value between 80-100
            })

            return dataPoint
          })

        setChartData(initialData)
      } catch (error) {
        console.error("Failed to fetch initial data:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchInitialData()

    // Simulate live data updates
    const interval = setInterval(() => {
      const timestamp = new Date()
      const newDataPoint: any = {
        timestamp: timestamp.toISOString(),
        name: timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }),
      }

      dataSets.forEach((metric) => {
        newDataPoint[metric] = Math.floor(Math.random() * 20) + 80 // Random value between 80-100
      })

      setChartData((prev) => [...prev.slice(1), newDataPoint]) // Keep only the last 20 points
      setLastUpdated(timestamp)
    }, 3000) // Update every 3 seconds

    return () => clearInterval(interval)
  }, [isLive, dataSets])

  // Format data for the chart
  const formattedDataSets = dataSets.map((dataSet, index) => ({
    name: dataSet.charAt(0).toUpperCase() + dataSet.slice(1), // Capitalize first letter
    data: chartData.map((item) => item[dataSet]),
    color: colors ? colors[index % colors.length] : undefined,
  }))

  if (isLoading) {
    return <Skeleton className="h-[250px] w-full" />
  }

  return (
    <div className={className}>
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-medium">{title}</h3>
        <div className="flex items-center gap-2">
          <Badge variant={isLive ? "default" : "destructive"} className="px-2 py-0 h-5">
            {isLive ? "Live" : "Offline"}
          </Badge>
          <div className="text-xs text-muted-foreground flex items-center gap-1">
            <Clock className="h-3 w-3" />
            {lastUpdated.toLocaleTimeString()}
          </div>
        </div>
      </div>

      <AdvancedLineChart
        data={chartData}
        dataSets={formattedDataSets}
        xKey="name"
        height={250}
        showArea={true}
        dotSize={2}
        activeDotSize={4}
        strokeWidth={2}
        animationDuration={300}
      />
    </div>
  )
}

