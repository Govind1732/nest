"use client"

import type React from "react"

import { useRef, useCallback, useEffect, useState, useMemo } from "react"
import { useDispatch, useSelector } from "react-redux"
import Chart from "chart.js/auto"
import { truncateDecimal, colors } from "@/lib/utils"
import {
  setSelectedTable,
  setShowAllColumns,
  setDashboardView,
  setColumnsData,
  setActiveProduct,
} from "@/store/slices/dqDomainLevelReportSlice"

interface BarGraphItem {
  tableName: string
  overall_DQ_Score: number
  columns?: any[]
}

interface DQBarchartProps {
  bargraphData: BarGraphItem[]
}

export function DQBarchart({ bargraphData }: DQBarchartProps) {
  const [sortedTables, setSortedTables] = useState<BarGraphItem[]>([])
  const [labelLength, setLabelLength] = useState(0)

  const dispatch = useDispatch()
  const activeProduct = useSelector((state) => state.dqDomainLevelReport.activeProduct)

  const barChartRef = useRef<HTMLCanvasElement>(null)
  const staticBarChartRef = useRef<HTMLCanvasElement>(null)

  const wrapLabel = useCallback((label?: string) => {
    const maxLength = 10
    if (label) {
      const wrappedLabel = label.length > maxLength ? label.match(new RegExp(".{1," + maxLength + "}", "g")) : label
      if (wrappedLabel && Array.isArray(wrappedLabel)) {
        setLabelLength((prev) => Math.max(prev, wrappedLabel.length))
      }
      return wrappedLabel
    }
    return label
  }, [])

  const handleChartClick = useCallback(
    (event: any, elements: any[], chart: any) => {
      if (elements.length > 0) {
        const newSelectedTable = chart.data.labels[elements[0].index]
        dispatch(setSelectedTable(newSelectedTable))
        dispatch(
          setActiveProduct({
            productId: activeProduct.productId,
            L2_productId: activeProduct.L2_productId,
            tableName: newSelectedTable,
          }),
        )
        dispatch(setDashboardView(false))
        dispatch(setShowAllColumns(true))

        const selectedTableData = bargraphData.find((item) => item.tableName === newSelectedTable)?.columns || []
        dispatch(setColumnsData(selectedTableData))
      }
    },
    [dispatch, bargraphData, activeProduct.productId, activeProduct.L2_productId],
  )

  const handleChartHover = useCallback((event: any, elements: any[]) => {
    if (event.native && event.native.target) {
      event.native.target.style.cursor = elements.length > 0 ? "pointer" : "default"
    }
  }, [])

  const getColor = useCallback((value: number) => {
    if (value > 90) return { bg: colors.vdsColorHigh, border: colors.strokeColorHigh }
    if (value > 80) return { bg: colors.vdsColorMedium, border: colors.strokeColorMedium }
    return { bg: colors.vdsColorLow, border: colors.strokeColorLow }
  }, [])

  const axisConfig = useMemo(
    () => ({
      x: {
        display: false,
        grid: { display: false, drawTricks: false, drawBorder: false },
        ticks: { display: false },
      },
      y: {
        display: true,
        grid: { display: false },
        ticks: {
          color: "#6F7171",
          callback: (index: number) => wrapLabel(sortedTables[index]?.tableName),
          font: (context: any) => {
            const label = sortedTables[context.index]?.tableName || ""
            return { size: Math.max(9, 20 - label.length) }
          },
        },
        beginAtZero: true,
        border: { color: "#000" },
      },
      xBarStatic: {
        display: true,
        grid: { display: false },
        ticks: {
          font: { size: 14 },
          color: "#6F7171",
          stepSize: 10,
          min: 0,
          max: 100,
          callback: (value: number) => `${value}%`,
        },
        border: { color: "#000" },
      },
      yBarStatic: {
        display: false,
        grid: { display: false },
      },
    }),
    [sortedTables, wrapLabel],
  )

  useEffect(() => {
    if (bargraphData && bargraphData.length > 0) {
      setSortedTables(
        [...bargraphData].sort(
          (a, b) => Number.parseFloat(a.overall_DQ_Score.toString()) - Number.parseFloat(b.overall_DQ_Score.toString()),
        ),
      )
    } else {
      setSortedTables([])
    }
  }, [bargraphData])

  const chartConfig = useMemo(
    () => ({
      type: "bar",
      data: {
        labels: sortedTables.map((table) => table?.tableName),
        datasets: [
          {
            label: "DQ Score",
            data: sortedTables.map((table) => table.overall_DQ_Score),
            backgroundColor: (context: any) => getColor(context.raw).bg,
            borderColor: (context: any) => getColor(context.raw).border,
            borderWidth: { top: 1, right: 1, bottom: 1, left: 0 },
            barThickness: 30,
            borderRadius: { topRight: 5, bottomRight: 5 },
          },
        ],
      },
      options: {
        maintainAspectRatio: false,
        indexAxis: "y",
        plugins: {
          legend: { display: false },
          tooltip: {
            bodyFont: { size: 14 },
            padding: 10,
            boxPadding: 10,
          },
        },
        layout: { padding: { right: 11 } },
        scales: {
          x: { ...axisConfig.x },
          y: axisConfig.y,
        },
        onClick: handleChartClick,
        onHover: handleChartHover,
      },
      plugins: [
        {
          id: "datalabels",
          afterDatasetsDraw: (chart: any) => {
            const ctx = chart.ctx
            chart.data.datasets.forEach((_dataset: any, i: number) => {
              const meta = chart.getDatasetMeta(i)
              meta.data.forEach((point: any, index: number) => {
                const value = truncateDecimal(chart.data.datasets[i].data[index], 1)
                ctx.fillStyle = "#000"
                ctx.font = "14px Arial"
                ctx.fillText(value + "%", point.x - 60, point.y + point.height / 10)
              })
            })
          },
        },
      ],
    }),
    [sortedTables, axisConfig, getColor, handleChartClick, handleChartHover],
  )

  useEffect(() => {
    const createChart = (ref: React.RefObject<HTMLCanvasElement>, config: any) => {
      if (!ref.current) return
      const ctx = ref.current.getContext("2d")
      if (!ctx) return

      const chart = new Chart(ctx, config)
      return () => chart.destroy()
    }

    const cleanupMainChart = createChart(barChartRef, chartConfig)
    const cleanupStaticChart = createChart(staticBarChartRef, {
      type: "bar",
      data: {
        labels: [],
        datasets: [
          {
            label: "DQ Score",
            data: sortedTables.map((table) => table.overall_DQ_Score),
          },
        ],
      },
      options: {
        maintainAspectRatio: false,
        responsive: true,
        indexAxis: "y",
        plugins: { legend: { display: false } },
        layout: { padding: { left: 75, top: -30 } },
        scales: { x: axisConfig.xBarStatic, y: axisConfig.yBarStatic },
      },
    })

    return () => {
      if (cleanupMainChart) cleanupMainChart()
      if (cleanupStaticChart) cleanupStaticChart()
    }
  }, [chartConfig, sortedTables, axisConfig, labelLength])

  return (
    <div className="w-full h-full">
      <div className="h-[90%] overflow-y-auto">
        <div className="min-h-[50px]" style={{ minHeight: `${bargraphData.length * 50}px` }}>
          <canvas ref={barChartRef}></canvas>
        </div>
      </div>
      <div className="h-[10%]">
        <canvas ref={staticBarChartRef}></canvas>
      </div>
    </div>
  )
}

