import { useSelector } from "react-redux"
import { truncateDecimal } from "@/lib/utils"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { CheckCircle, Medal, Clock, Grid, Shield, ThumbsUp } from "lucide-react"

export function DQDomainLevelColumns() {
  const columnsData = useSelector((state) => state.dqDomainLevelReport.columnsData)

  const calculateColumnAverage = (obj) => {
    const values = Object.values(obj).map((value) => {
      const parsed = Number.parseFloat(value)
      return isNaN(parsed) ? value : parsed
    })

    const numericValues = values.filter((value) => typeof value === "number")
    const sum = numericValues.reduce((acc, value) => acc + value, 0)
    const average = sum / numericValues.length

    return average
  }

  const metricIcons = {
    completeness: <CheckCircle className="h-5 w-5" />,
    uniqueness: <Medal className="h-5 w-5" />,
    timeliness: <Clock className="h-5 w-5" />,
    consistency: <Grid className="h-5 w-5" />,
    validity: <Shield className="h-5 w-5" />,
    conformity: <ThumbsUp className="h-5 w-5" />,
  }

  const getScoreColor = (score) => {
    if (score > 90) return "text-green-600"
    if (score > 80) return "text-orange-600"
    return "text-red-600"
  }

  if (!columnsData || columnsData.length === 0) {
    return <div className="text-center p-4">No column data available</div>
  }

  return (
    <div className="w-full overflow-auto">
      <Table className="border-collapse">
        <TableHeader className="sticky top-0 bg-gray-100 z-10">
          <TableRow>
            {Object.keys(columnsData[0]).map((columnName, index) =>
              columnName === "columnName" ? (
                <TableHead key={`column-${index}`} className="p-0"></TableHead>
              ) : (
                <TableHead key={index} className="text-center p-2 border border-gray-200 bg-white rounded-t-md">
                  <div className="flex flex-col items-center justify-center gap-2 h-24">
                    <div className="bg-gray-100 p-2 rounded-full">{metricIcons[columnName.toLowerCase()]}</div>
                    <div className="font-medium text-gray-700">{columnName}</div>
                  </div>
                </TableHead>
              ),
            )}
            <TableHead className="text-center p-2 border border-gray-200 bg-blue-50 text-blue-700 rounded-t-md">
              <div className="h-24 flex items-center justify-center">
                <span>
                  Overall
                  <br />
                  Score
                </span>
              </div>
            </TableHead>
          </TableRow>
        </TableHeader>

        <TableBody>
          {columnsData.map((column, index) => (
            <TableRow key={index} className={index % 2 === 0 ? "bg-white" : "bg-gray-50"}>
              {Object.entries(column).map(([key, value], idx) => {
                const parsedValue = isNaN(value) ? value : Number.parseInt(value)

                return (
                  <TableCell key={idx} className="border border-gray-200 p-2">
                    {parsedValue === null ? (
                      <span className="flex justify-center">-</span>
                    ) : typeof parsedValue === "number" ? (
                      <span className={`flex justify-center ${getScoreColor(parsedValue)}`}>
                        {truncateDecimal(parsedValue, 1)}%
                      </span>
                    ) : (
                      <span className="text-left font-normal">{parsedValue}</span>
                    )}
                  </TableCell>
                )
              })}

              <TableCell
                className={`border border-gray-200 p-2 text-center ${index % 2 === 0 ? "bg-white" : "bg-blue-50"}`}
              >
                {calculateColumnAverage(column) !== null ? (
                  <span className={getScoreColor(calculateColumnAverage(column))}>
                    {truncateDecimal(calculateColumnAverage(column), 1)}%
                  </span>
                ) : (
                  "-"
                )}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

