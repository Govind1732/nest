export function Legend() {
  return (
    <div className="flex items-center">
      <div className="flex items-center">
        {[
          { label: "90 - 100%", bgColor: "bg-green-100", dotColor: "bg-green-600" },
          { label: "80% - 89%", bgColor: "bg-orange-100", dotColor: "bg-orange-600" },
          { label: "0% - 79%", bgColor: "bg-red-100", dotColor: "bg-red-600" },
        ].map((item, index) => (
          <div key={index} className="flex items-center mx-4">
            <span className={`w-6 h-6 rounded flex items-center justify-center ${item.bgColor} mr-2`}>
              <span className={`w-3 h-3 rounded-full ${item.dotColor}`}></span>
            </span>
            <span className="text-sm">{item.label}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

