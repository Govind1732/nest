"use client"

import { useState, useEffect } from "react"
import { useDispatch, useSelector } from "react-redux"
import { setActiveProduct, setShowAllColumns, setDashboardView } from "@/store/slices/dqDomainLevelReportSlice"
import { ChevronDown, ChevronUp } from "lucide-react"
import { Skeleton } from "@/components/ui/skeleton"
import { useGetProductDataQuery, useGetL2ProductDataQuery } from "@/services/api"
import { truncateDecimal } from "@/lib/utils"

export function DQDomainLevelReportSidebar() {
  const dispatch = useDispatch()
  const [openSections, setOpenSections] = useState({})
  const { data: productData = [], isLoading: productIdDataLoading } = useGetProductDataQuery()
  const { data: l2Data = [], isLoading: l2DataLoading } = useGetL2ProductDataQuery()
  const [productIdData, setProductIdData] = useState([])
  const activeProduct = useSelector((state) => state.dqDomainLevelReport.activeProduct)

  useEffect(() => {
    if (productData?.length > 0) {
      const journeyDataIndex = productData.findIndex((product) => product.product_id === "Journey Data Product")

      const sortedData =
        journeyDataIndex > 0
          ? [
              productData[journeyDataIndex],
              ...productData.slice(0, journeyDataIndex),
              ...productData.slice(journeyDataIndex + 1),
            ]
          : productData

      setProductIdData(sortedData)
    }
  }, [productData])

  const L2Handler = (productId, L2_productId) => {
    if (l2Data.length > 0) {
      dispatch(setActiveProduct({ productId, L2_productId, tableName: "" }))
      dispatch(setShowAllColumns(false))
      dispatch(setDashboardView(true))
    } else {
      alert("No Level 2 data found for this product")
    }
  }

  const handleToggle = (section) => {
    setOpenSections((prevState) => ({
      ...prevState,
      [section]: !prevState[section],
    }))
  }

  const getScoreColor = (score) => {
    if (score > 90) {
      return {
        bg: "bg-green-100",
        text: "text-green-700",
      }
    } else if (score > 80) {
      return {
        bg: "bg-orange-100",
        text: "text-orange-700",
      }
    } else {
      return {
        bg: "bg-red-100",
        text: "text-red-700",
      }
    }
  }

  return (
    <div className="h-full overflow-y-auto">
      {productIdDataLoading || l2DataLoading ? (
        <div className="flex flex-col gap-1 m-1">
          {[...Array(4)].map((_, index) => (
            <Skeleton key={index} className="w-full h-10" />
          ))}
        </div>
      ) : (
        productIdData?.length > 0 &&
        productIdData.map((section) => {
          const overallDqScore = truncateDecimal(
            Object.values(section?.dq_score).reduce((a, b) => Number.parseFloat(a) + Number.parseFloat(b), 0) /
              Object.keys(section?.dq_score).length,
            1,
          )

          const { bg, text } = getScoreColor(overallDqScore)

          return (
            <div key={section?.product_id} className="mb-1">
              <div className="flex justify-between items-center bg-gray-100 m-1 p-2 rounded">
                <div
                  className={`cursor-${overallDqScore > 0 ? "pointer" : "default"}`}
                  style={{
                    color: activeProduct.productId === section?.product_id ? "#EE0000" : "#000",
                    fontWeight: activeProduct.productId === section?.product_id ? "bold" : "normal",
                  }}
                  onClick={
                    overallDqScore > 0
                      ? () => {
                          dispatch(
                            setActiveProduct({
                              productId: section?.product_id,
                              L2_productId: "",
                              tableName: "",
                            }),
                          )
                          dispatch(setShowAllColumns(false))
                          dispatch(setDashboardView(true))
                        }
                      : null
                  }
                >
                  {section?.product_id}
                </div>
                <div className="flex items-center gap-2">
                  {overallDqScore > 0 && (
                    <div className={`${bg} ${text} px-2 py-1 rounded-full text-sm`}>
                      {truncateDecimal(overallDqScore, 1)}%
                    </div>
                  )}
                  <button onClick={() => handleToggle(section?.product_id)} className="cursor-pointer">
                    {openSections[section?.product_id] ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                  </button>
                </div>
              </div>

              {openSections[section?.product_id] && (
                <div className="pl-8 pr-2 py-2 flex flex-col gap-2">
                  {l2Data &&
                    l2Data
                      .filter((session) => session.product_id === section.product_id)[0]
                      ?.level2_data.map((obj, index) => {
                        const overallL2DqScore = truncateDecimal(
                          Object.values(obj?.dq_score).reduce(
                            (a, b) => Number.parseFloat(a) + Number.parseFloat(b),
                            0,
                          ) / Object.keys(obj?.dq_score).length,
                          1,
                        )

                        const { bg, text } = getScoreColor(overallL2DqScore)

                        return (
                          <div key={index} className="flex justify-between items-center">
                            <div
                              onClick={
                                overallL2DqScore > 0 ? () => L2Handler(section?.product_id, obj.level2_name) : null
                              }
                              className={`cursor-${overallL2DqScore > 0 ? "pointer" : "default"}`}
                              style={{
                                color:
                                  activeProduct.productId === section.product_id &&
                                  activeProduct.L2_productId === obj.level2_name
                                    ? "#EE0000"
                                    : "#000",
                                fontWeight:
                                  activeProduct.productId === section.product_id &&
                                  activeProduct.L2_productId === obj.level2_name
                                    ? "bold"
                                    : "normal",
                              }}
                            >
                              {obj.level2_name}
                            </div>
                            {overallL2DqScore > 0 && (
                              <div className={`${bg} ${text} px-2 py-1 rounded-full text-sm`}>
                                {truncateDecimal(overallL2DqScore, 1)}%
                              </div>
                            )}
                          </div>
                        )
                      })}
                </div>
              )}
            </div>
          )
        })
      )}
    </div>
  )
}

