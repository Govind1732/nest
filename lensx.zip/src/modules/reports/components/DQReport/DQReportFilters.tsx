"use client"

import { useState, useEffect } from "react"
import { useDispatch, useSelector } from "react-redux"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { DatePicker } from "@/components/ui/date-picker"
import { Skeleton } from "@/components/ui/skeleton"
import { resetFilters } from "@/store/slices/dqReportSlice"
import type { RootState } from "@/store/store"

interface DQReportFiltersProps {
  onApplyFilters: (filters: any) => void
}

export function DQReportFilters({ onApplyFilters }: DQReportFiltersProps) {
  const dispatch = useDispatch()
  const { filterOptions, isLoading, filterValues } = useSelector((state: RootState) => state.dqReport)

  const [filters, setFilters] = useState({
    platform: "",
    lob: "",
    productType: "",
    productArea: "",
    productName: "",
    businessProgram: "",
    startDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), // 7 days ago
    endDate: new Date(),
  })

  // Initialize filters from Redux state
  useEffect(() => {
    if (filterValues) {
      setFilters((prev) => ({
        ...prev,
        ...filterValues,
      }))
    }
  }, [filterValues])

  // Update dependent dropdowns when a filter changes
  useEffect(() => {
    // This would typically call an API to get updated options based on current selections
    // For now, we'll just use the static options from Redux
  }, [filters.platform, filters.lob, filters.productType, filters.productArea])

  const handleFilterChange = (name: string, value: string) => {
    setFilters((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleDateChange = (name: string, date: Date | undefined) => {
    if (date) {
      setFilters((prev) => ({
        ...prev,
        [name]: date,
      }))
    }
  }

  const handleApplyFilters = () => {
    onApplyFilters(filters)
  }

  const handleResetFilters = () => {
    dispatch(resetFilters())
    setFilters({
      platform: "",
      lob: "",
      productType: "",
      productArea: "",
      productName: "",
      businessProgram: "",
      startDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
      endDate: new Date(),
    })
  }

  // Check if any filter is applied
  const hasFilters = Object.entries(filters).some(([key, value]) => {
    if (key === "startDate" || key === "endDate") return false
    return value !== ""
  })

  return (
    <Card className="h-full">
      <CardHeader className="pb-3">
        <div className="flex justify-between items-center">
          <CardTitle className="text-lg">Filters</CardTitle>
          {hasFilters && (
            <Button variant="link" onClick={handleResetFilters} className="p-0 h-auto text-sm">
              Clear All
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Date Range */}
        <div className="space-y-2">
          <Label>Date Range</Label>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <DatePicker
                date={filters.startDate}
                onSelect={(date) => handleDateChange("startDate", date)}
                disabled={isLoading}
              />
            </div>
            <div>
              <DatePicker
                date={filters.endDate}
                onSelect={(date) => handleDateChange("endDate", date)}
                disabled={isLoading}
              />
            </div>
          </div>
        </div>

        {/* Platform */}
        <div className="space-y-2">
          <Label htmlFor="platform">Platform</Label>
          {isLoading ? (
            <Skeleton className="h-10 w-full" />
          ) : (
            <Select
              value={filters.platform}
              onValueChange={(value) => handleFilterChange("platform", value)}
              disabled={isLoading}
            >
              <SelectTrigger id="platform">
                <SelectValue placeholder="Select platform" />
              </SelectTrigger>
              <SelectContent>
                {filterOptions.platforms?.map((platform) => (
                  <SelectItem key={platform} value={platform}>
                    {platform}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        </div>

        {/* LOB */}
        <div className="space-y-2">
          <Label htmlFor="lob">LOB</Label>
          {isLoading ? (
            <Skeleton className="h-10 w-full" />
          ) : (
            <Select
              value={filters.lob}
              onValueChange={(value) => handleFilterChange("lob", value)}
              disabled={isLoading || !filters.platform}
            >
              <SelectTrigger id="lob">
                <SelectValue placeholder="Select LOB" />
              </SelectTrigger>
              <SelectContent>
                {filterOptions.lobs?.map((lob) => (
                  <SelectItem key={lob} value={lob}>
                    {lob}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        </div>

        {/* Product Type */}
        <div className="space-y-2">
          <Label htmlFor="productType">Product Type</Label>
          {isLoading ? (
            <Skeleton className="h-10 w-full" />
          ) : (
            <Select
              value={filters.productType}
              onValueChange={(value) => handleFilterChange("productType", value)}
              disabled={isLoading || !filters.lob}
            >
              <SelectTrigger id="productType">
                <SelectValue placeholder="Select product type" />
              </SelectTrigger>
              <SelectContent>
                {filterOptions.productTypes?.map((type) => (
                  <SelectItem key={type} value={type}>
                    {type}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        </div>

        {/* Product Area */}
        <div className="space-y-2">
          <Label htmlFor="productArea">Product Area</Label>
          {isLoading ? (
            <Skeleton className="h-10 w-full" />
          ) : (
            <Select
              value={filters.productArea}
              onValueChange={(value) => handleFilterChange("productArea", value)}
              disabled={isLoading || !filters.productType}
            >
              <SelectTrigger id="productArea">
                <SelectValue placeholder="Select product area" />
              </SelectTrigger>
              <SelectContent>
                {filterOptions.productAreas?.map((area) => (
                  <SelectItem key={area} value={area}>
                    {area}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        </div>

        {/* Product Name */}
        <div className="space-y-2">
          <Label htmlFor="productName">Product Name</Label>
          {isLoading ? (
            <Skeleton className="h-10 w-full" />
          ) : (
            <Select
              value={filters.productName}
              onValueChange={(value) => handleFilterChange("productName", value)}
              disabled={isLoading || !filters.productArea}
            >
              <SelectTrigger id="productName">
                <SelectValue placeholder="Select product name" />
              </SelectTrigger>
              <SelectContent>
                {filterOptions.productNames?.map((name) => (
                  <SelectItem key={name} value={name}>
                    {name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        </div>

        {/* Business Program */}
        <div className="space-y-2">
          <Label htmlFor="businessProgram">Business Program</Label>
          {isLoading ? (
            <Skeleton className="h-10 w-full" />
          ) : (
            <Select
              value={filters.businessProgram}
              onValueChange={(value) => handleFilterChange("businessProgram", value)}
              disabled={isLoading}
            >
              <SelectTrigger id="businessProgram">
                <SelectValue placeholder="Select business program" />
              </SelectTrigger>
              <SelectContent>
                {filterOptions.businessPrograms?.map((program) => (
                  <SelectItem key={program} value={program}>
                    {program}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        </div>

        {/* Apply Button */}
        <Button className="w-full" onClick={handleApplyFilters} disabled={isLoading}>
          {isLoading ? "Loading..." : "Apply Filters"}
        </Button>
      </CardContent>
    </Card>
  )
}

