"use client"

import { useState } from "react"
import { useDispatch } from "react-redux"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { setDashboardView, setDataProductsView, setTableLevelAssetsView } from "@/store/slices/dq-report-slice"
import { formatPercentage } from "@/lib/formatters"

interface FilteredReportTableProps {
  productTypeWiseData: any[]
  label: string
  startDate: string
  endDate: string
}

export function FilteredReportTable({ productTypeWiseData, label, startDate, endDate }: FilteredReportTableProps) {
  const dispatch = useDispatch()
  const [isLoading, setIsLoading] = useState(false)
  const [tableWiseData, setTableWiseData] = useState<any[]>([])
  const [selectedProductType, setSelectedProductType] = useState("")

  // Metrics to display in the table
  const metrics = [
    { key: "TBL_COMPLETENESS", label: "Completeness" },
    { key: "TBL_TIMELINESS", label: "Timeliness" },
    { key: "TBL_UNIQUENESS", label: "Uniqueness" },
    { key: "tbl_conformity", label: "Conformity" },
    { key: "tbl_validity", label: "Validity" },
    { key: "tbl_consistency", label: "Consistency" },
    { key: "OVERALL_DQ_SCORE", label: "Overall DQ" },
  ]

  // Function to fetch table-level data
  const fetchTableWiseData = async (productType: string) => {
    setIsLoading(true)
    try {
      // In a real implementation, this would be an API call
      // For demo purposes, we'll simulate a response
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Mock data for table-level assets
      const mockData = Array(5)
        .fill(0)
        .map((_, i) => ({
          SRC_TBL: `${productType}_Table_${i + 1}`,
          max_run_date: new Date().toISOString().split("T")[0],
          TBL_COMPLETENESS: Math.floor(Math.random() * 20) + 80,
          TBL_TIMELINESS: Math.floor(Math.random() * 20) + 80,
          TBL_UNIQUENESS: Math.floor(Math.random() * 20) + 80,
          tbl_conformity: Math.floor(Math.random() * 20) + 80,
          tbl_validity: Math.floor(Math.random() * 20) + 80,
          tbl_consistency: Math.floor(Math.random() * 20) + 80,
          OVERALL_DQ_SCORE: Math.floor(Math.random() * 20) + 80,
        }))

      setTableWiseData(mockData)
      setSelectedProductType(productType)

      // Switch to table level view
      dispatch(setDashboardView(false))
      dispatch(setDataProductsView(false))
      dispatch(setTableLevelAssetsView(true))
    } catch (error) {
      console.error("Failed to fetch table data:", error)
    } finally {
      setIsLoading(false)
    }
  }

  // Get color based on score
  const getScoreColor = (score: number) => {
    if (score > 90) return "text-green-600"
    if (score > 80) return "text-orange-500"
    return "text-red-500"
  }

  // Filter data for the selected label
  const filteredData = productTypeWiseData.filter((item) => item.product_type === label)

  if (isLoading) {
    return <Skeleton className="h-[300px] w-full" />
  }

  if (filteredData.length === 0) {
    return (
      <div className="flex justify-center items-center h-[100px]">
        <p className="text-muted-foreground">No data available for {label}</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Product Type</TableHead>
              <TableHead className="text-center">Assets</TableHead>
              {metrics.map(({ key, label }) => (
                <TableHead key={key} className="text-center">
                  {label}
                </TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredData.map((row, index) => (
              <TableRow key={index}>
                <TableCell>{row.product_type}</TableCell>
                <TableCell className="text-center">
                  <Button variant="link" onClick={() => fetchTableWiseData(row.product_type)} className="p-0 h-auto">
                    {row.no_of_assets}
                  </Button>
                </TableCell>
                {metrics.map(({ key }) => {
                  const value = Number.parseFloat(row[key])
                  const colorClass = getScoreColor(value)
                  return (
                    <TableCell key={key} className={`text-center ${colorClass}`}>
                      {formatPercentage(value)}
                    </TableCell>
                  )
                })}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {tableWiseData.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-lg font-medium">
            Table Level Assets for {selectedProductType} ({startDate} to {endDate})
          </h3>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Table Name</TableHead>
                  <TableHead>Last Updated</TableHead>
                  {metrics.map(({ key, label }) => (
                    <TableHead key={key} className="text-center">
                      {label}
                    </TableHead>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody>
                {tableWiseData.map((row, index) => (
                  <TableRow key={index}>
                    <TableCell>{row.SRC_TBL}</TableCell>
                    <TableCell>{row.max_run_date}</TableCell>
                    {metrics.map(({ key }) => {
                      const value = Number.parseFloat(row[key])
                      const colorClass = getScoreColor(value)
                      return (
                        <TableCell key={key} className={`text-center ${colorClass}`}>
                          {formatPercentage(value)}
                        </TableCell>
                      )
                    })}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        \

