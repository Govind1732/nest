"use client"

import type React from "react"

import { Navigate } from "react-router-dom"
import { useAuth } from "@/modules/auth/context/AuthContext"

interface RoleGuardProps {
  requiredRole: "Admin" | "DQ User" | "Executive"
  projectId?: string
  children: React.ReactNode
  fallback?: React.ReactNode
}

export function RoleGuard({
  requiredRole,
  projectId,
  children,
  fallback = <Navigate to="/unauthorized" replace />,
}: RoleGuardProps) {
  const { user, hasPermission, hasProjectAccess } = useAuth()

  // If not authenticated, redirect to login
  if (!user) {
    return <Navigate to="/login" replace />
  }

  // Check role permission
  const hasRolePermission = hasPermission(requiredRole)

  // Check project access if projectId is provided
  const hasAccess = projectId ? hasRolePermission && hasProjectAccess(projectId) : hasRolePermission

  // If user doesn't have permission, show fallback
  if (!hasAccess) {
    return <>{fallback}</>
  }

  // User has permission, render children
  return <>{children}</>
}

