"use client"

// Custom hook for auth functionality
import { useCallback } from "react"
import { useDispatch, useSelector } from "react-redux"
import type { RootState } from "@/store/store"
import { loginStart, loginSuccess, loginFailure, logout } from "@/modules/auth/slice"
import { useLoginMutation, useLogoutMutation } from "@/modules/auth/services/auth.service"

export function useAuth() {
  const dispatch = useDispatch()
  const { user, isAuthenticated, isLoading, error } = useSelector((state: RootState) => state.auth)

  const [loginApi] = useLoginMutation()
  const [logoutApi] = useLogoutMutation()

  const login = useCallback(
    async (email: string, password: string) => {
      try {
        dispatch(loginStart())
        const result = await loginApi({ email, password }).unwrap()
        dispatch(loginSuccess(result.user))
        return result
      } catch (error) {
        dispatch(loginFailure((error as Error).message))
        throw error
      }
    },
    [dispatch, loginApi],
  )

  const logoutUser = useCallback(async () => {
    try {
      await logoutApi().unwrap()
      dispatch(logout())
    } catch (error) {
      console.error("Logout failed:", error)
    }
  }, [dispatch, logoutApi])

  const hasPermission = useCallback(
    (requiredRole: string) => {
      if (!user) return false

      const roles = ["Executive", "DQ User", "Admin"]
      const userRoleIndex = roles.indexOf(user.role)
      const requiredRoleIndex = roles.indexOf(requiredRole)

      return userRoleIndex >= requiredRoleIndex
    },
    [user],
  )

  const hasProjectAccess = useCallback(
    (projectId: string) => {
      if (!user) return false
      if (user.role === "Admin") return true

      return user.projects.includes(projectId)
    },
    [user],
  )

  return {
    user,
    isAuthenticated,
    isLoading,
    error,
    login,
    logout: logoutUser,
    hasPermission,
    hasProjectAccess,
  }
}

