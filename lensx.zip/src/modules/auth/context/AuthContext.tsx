"use client"

import type React from "react"
import { createContext, useContext, useEffect, useState } from "react"
import { useNavigate } from "react-router-dom"
import { userSchema, type User, userRoleSchema } from "@/lib/schema"

interface AuthContextType {
  user: User | null
  isLoading: boolean
  error: string | null
  login: (email: string, password: string) => Promise<void>
  logout: () => Promise<void>
  hasPermission: (requiredRole: string) => boolean
  hasProjectAccess: (projectId: string) => boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const navigate = useNavigate()

  // Fetch current user on mount
  useEffect(() => {
    const fetchCurrentUser = async () => {
      try {
        setIsLoading(true)
        // In a real app, this would be an API call
        // For demo purposes, we'll simulate a user
        const mockUser = {
          id: "user-1",
          name: "John Doe",
          email: "john.doe@verizon.com",
          role: "Admin" as const,
          projects: ["DTRan", "OneCorp", "MLE"],
        }

        // Validate user data with Zod
        const validatedUser = userSchema.parse(mockUser)
        setUser(validatedUser)
        setError(null)
      } catch (err) {
        console.error("Failed to fetch user:", err)
        setError("Failed to authenticate user")
        setUser(null)
      } finally {
        setIsLoading(false)
      }
    }

    fetchCurrentUser()
  }, [])

  const login = async (email: string, password: string) => {
    try {
      setIsLoading(true)
      setError(null)

      // In a real app, this would be an API call
      // For demo purposes, we'll simulate a successful login
      const mockUser = {
        id: "user-1",
        name: "John Doe",
        email,
        role: "Admin" as const,
        projects: ["DTRan", "OneCorp", "MLE"],
      }

      // Validate user data with Zod
      const validatedUser = userSchema.parse(mockUser)
      setUser(validatedUser)

      // Redirect to home page
      navigate("/")
    } catch (err) {
      console.error("Login failed:", err)
      setError("Invalid email or password")
      throw err
    } finally {
      setIsLoading(false)
    }
  }

  const logout = async () => {
    try {
      setIsLoading(true)

      // In a real app, this would be an API call
      // For demo purposes, we'll just clear the user
      setUser(null)

      // Redirect to login page
      navigate("/login")
    } catch (err) {
      console.error("Logout failed:", err)
      setError("Failed to logout")
    } finally {
      setIsLoading(false)
    }
  }

  const hasPermission = (requiredRole: string) => {
    if (!user) return false

    try {
      // Validate the required role
      userRoleSchema.parse(requiredRole)

      const roles = ["Executive", "DQ User", "Admin"]
      const userRoleIndex = roles.indexOf(user.role)
      const requiredRoleIndex = roles.indexOf(requiredRole)

      return userRoleIndex >= requiredRoleIndex
    } catch (err) {
      console.error("Invalid role:", err)
      return false
    }
  }

  const hasProjectAccess = (projectId: string) => {
    if (!user) return false
    if (user.role === "Admin") return true

    return user.projects.includes(projectId)
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        error,
        login,
        logout,
        hasPermission,
        hasProjectAccess,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

