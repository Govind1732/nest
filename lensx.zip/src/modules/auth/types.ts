// Auth module types
import type { User, UserRole } from "@/types/common.types"

export interface LoginCredentials {
  email: string
  password: string
}

export interface LoginResponse {
  user: User
  token: string
}

export interface RoleUpgradeRequest {
  id: string
  userId: string
  userName: string
  currentRole: UserRole
  requestedRole: UserRole
  projectId: string
  reason: string
  status: "pending" | "approved" | "rejected"
  createdAt: string
  updatedAt: string
}

