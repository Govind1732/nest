"use client"

import { useState, useCallback } from "react"
import { useTranslation } from "react-i18next"
import { ROUTES } from "@/config/constants"

interface Message {
  id: string
  content: string
  role: "user" | "assistant"
  timestamp: Date
  attachments?: string[]
  contextInfo?: {
    page?: string
    action?: string
    userRole?: string
  }
}

interface ProcessMessageContext {
  currentPath: string
  userRole?: string
  attachments?: string[]
}

interface ProcessMessageResponse {
  text: string
  intent?: string
  confidence?: number
}

export function useAIChat() {
  const { t } = useTranslation()
  const [isProcessing, setIsProcessing] = useState(false)

  // Process user message with NLU and context awareness
  const processMessage = useCallback(
    async (
      message: string,
      conversationHistory: Message[],
      context: ProcessMessageContext,
    ): Promise<ProcessMessageResponse> => {
      setIsProcessing(true)

      try {
        // In a real implementation, this would call an AI service API
        // For this demo, we'll simulate NLU processing with a delay
        await new Promise((resolve) => setTimeout(resolve, 1000))

        // Extract intent and entities from the message
        const intent = extractIntent(message)
        const entities = extractEntities(message)

        // Generate response based on intent, entities, conversation history, and context
        const response = generateResponse(intent, entities, conversationHistory, context)

        return {
          text: response,
          intent,
          confidence: 0.85, // Simulated confidence score
        }
      } catch (error) {
        console.error("Error processing message:", error)
        throw error
      } finally {
        setIsProcessing(false)
      }
    },
    [],
  )

  // Generate suggested questions based on current context
  const generateSuggestedQuestions = useCallback(
    async (currentPath: string, userRole?: string, conversationHistory?: Message[]): Promise<string[]> => {
      // In a real implementation, this would use the conversation history and context
      // to generate relevant questions using an AI service

      // For this demo, we'll return predefined questions based on the current path
      const routeKey = Object.entries(ROUTES).find(([_, path]) => path === currentPath)?.[0]

      if (!routeKey) {
        return getDefaultSuggestions()
      }

      switch (routeKey) {
        case "DQ_DOMAIN_LEVEL_REPORT":
          return [
            t("chatbot.suggestions.domainReport1"),
            t("chatbot.suggestions.domainReport2"),
            t("chatbot.suggestions.domainReport3"),
          ]
        case "DQ_REPORT":
          return [
            t("chatbot.suggestions.dqReport1"),
            t("chatbot.suggestions.dqReport2"),
            t("chatbot.suggestions.dqReport3"),
          ]
        case "AUTO_PROFILE":
        case "RULE_PROFILE_DTRAN":
        case "RULE_PROFILE_ONECORP":
        case "RULE_PROFILE_MLE":
        case "DATA_PROFILE":
        case "CUSTOM_PROFILE":
          return [
            t("chatbot.suggestions.profile1"),
            t("chatbot.suggestions.profile2"),
            t("chatbot.suggestions.profile3"),
          ]
        case "DATA_QUALITY_VALIDATION":
          return [
            t("chatbot.suggestions.validation1"),
            t("chatbot.suggestions.validation2"),
            t("chatbot.suggestions.validation3"),
          ]
        case "ADMIN":
          return userRole === "Admin"
            ? [t("chatbot.suggestions.admin1"), t("chatbot.suggestions.admin2"), t("chatbot.suggestions.admin3")]
            : getDefaultSuggestions()
        default:
          return getDefaultSuggestions()
      }
    },
    [t],
  )

  // Helper function to get default suggested questions
  const getDefaultSuggestions = useCallback(() => {
    return [t("chatbot.suggestions.default1"), t("chatbot.suggestions.default2"), t("chatbot.suggestions.default3")]
  }, [t])

  // Extract intent from message (simplified NLU)
  const extractIntent = (message: string): string => {
    const lowerMessage = message.toLowerCase()

    if (lowerMessage.includes("what is") || lowerMessage.includes("definition") || lowerMessage.includes("explain")) {
      return "definition"
    }

    if (lowerMessage.includes("how to") || lowerMessage.includes("how do i")) {
      return "howto"
    }

    if (lowerMessage.includes("where") || lowerMessage.includes("find") || lowerMessage.includes("locate")) {
      return "location"
    }

    if (lowerMessage.includes("why") || lowerMessage.includes("reason")) {
      return "reason"
    }

    if (lowerMessage.includes("when") || lowerMessage.includes("time")) {
      return "time"
    }

    if (lowerMessage.includes("who") || lowerMessage.includes("contact")) {
      return "person"
    }

    if (lowerMessage.includes("thank") || lowerMessage.includes("thanks")) {
      return "gratitude"
    }

    if (lowerMessage.includes("hello") || lowerMessage.includes("hi ") || lowerMessage === "hi") {
      return "greeting"
    }

    return "general"
  }

  // Extract entities from message (simplified NLU)
  const extractEntities = (message: string): Record<string, string> => {
    const entities: Record<string, string> = {}
    const lowerMessage = message.toLowerCase()

    // Data quality metrics
    if (lowerMessage.includes("completeness")) entities.metric = "completeness"
    if (lowerMessage.includes("timeliness")) entities.metric = "timeliness"
    if (lowerMessage.includes("uniqueness")) entities.metric = "uniqueness"
    if (lowerMessage.includes("conformity")) entities.metric = "conformity"
    if (lowerMessage.includes("validity")) entities.metric = "validity"
    if (lowerMessage.includes("consistency")) entities.metric = "consistency"

    // Features
    if (lowerMessage.includes("profile") || lowerMessage.includes("profiling")) entities.feature = "profile"
    if (lowerMessage.includes("report")) entities.feature = "report"
    if (lowerMessage.includes("validation")) entities.feature = "validation"
    if (lowerMessage.includes("api") || lowerMessage.includes("integration")) entities.feature = "api"

    // Projects
    if (lowerMessage.includes("dtran")) entities.project = "dtran"
    if (lowerMessage.includes("onecorp")) entities.project = "onecorp"
    if (lowerMessage.includes("mle")) entities.project = "mle"

    return entities
  }

  // Generate response based on intent, entities, and context
  const generateResponse = (
    intent: string,
    entities: Record<string, string>,
    conversationHistory: Message[],
    context: ProcessMessageContext,
  ): string => {
    // In a real implementation, this would use a more sophisticated approach
    // possibly with a large language model API

    // For this demo, we'll use a simple rule-based approach
    switch (intent) {
      case "greeting":
        return t("chatbot.responses.greeting")

      case "gratitude":
        return t("chatbot.responses.gratitude")

      case "definition":
        if (entities.metric) {
          return t(`chatbot.responses.definition.${entities.metric}`)
        }
        if (entities.feature) {
          return t(`chatbot.responses.definition.${entities.feature}`)
        }
        return t("chatbot.responses.definition.dataQuality")

      case "howto":
        if (entities.feature === "profile") {
          return t("chatbot.responses.howto.profile")
        }
        if (entities.feature === "report") {
          return t("chatbot.responses.howto.report")
        }
        if (entities.feature === "validation") {
          return t("chatbot.responses.howto.validation")
        }
        if (entities.feature === "api") {
          return t("chatbot.responses.howto.api")
        }
        return t("chatbot.responses.howto.general")

      case "location":
        if (entities.feature === "profile") {
          return t("chatbot.responses.location.profile")
        }
        if (entities.feature === "report") {
          return t("chatbot.responses.location.report")
        }
        if (entities.feature === "validation") {
          return t("chatbot.responses.location.validation")
        }
        if (entities.feature === "api") {
          return t("chatbot.responses.location.api")
        }
        return t("chatbot.responses.location.general")

      case "reason":
        if (entities.metric) {
          return t(`chatbot.responses.reason.${entities.metric}`)
        }
        return t("chatbot.responses.reason.dataQuality")

      case "time":
        return t("chatbot.responses.time")

      case "person":
        return t("chatbot.responses.person")

      default:
        // Check if we have context about the current page
        if (context.currentPath) {
          const routeKey = Object.entries(ROUTES).find(([_, path]) => path === context.currentPath)?.[0]
          if (routeKey) {
            return t(`chatbot.responses.contextual.${routeKey.toLowerCase()}`)
          }
        }

        // Check if there are attachments
        if (context.attachments && context.attachments.length > 0) {
          return t("chatbot.responses.attachments", { count: context.attachments.length })
        }

        return t("chatbot.responses.default")
    }
  }

  return {
    processMessage,
    isProcessing,
    generateSuggestedQuestions,
  }
}

