// Helper functions

import { DQ_SCORE_RANGES } from "@/config/constants"

/**
 * Format a number as a percentage
 */
export function formatPercentage(value: number): string {
  return `${value.toFixed(1)}%`
}

/**
 * Get the color for a DQ score based on the defined ranges
 */
export function getDQScoreColor(score: number): string {
  if (score >= DQ_SCORE_RANGES.HIGH.min) {
    return DQ_SCORE_RANGES.HIGH.color
  } else if (score >= DQ_SCORE_RANGES.MEDIUM.min) {
    return DQ_SCORE_RANGES.MEDIUM.color
  } else {
    return DQ_SCORE_RANGES.LOW.color
  }
}

/**
 * Format a date to a readable string
 */
export function formatDate(date: Date | string): string {
  const d = typeof date === "string" ? new Date(date) : date
  return d.toLocaleDateString("en-US", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  })
}

/**
 * Check if the user has permission for a specific action
 */
export function hasPermission(userRole: string, requiredRole: string): boolean {
  const roles = ["Executive", "DQ User", "Admin"]
  const userRoleIndex = roles.indexOf(userRole)
  const requiredRoleIndex = roles.indexOf(requiredRole)

  return userRoleIndex >= requiredRoleIndex
}

/**
 * Truncate a string if it exceeds the maximum length
 */
export function truncateString(str: string, maxLength: number): string {
  if (str.length <= maxLength) return str
  return `${str.slice(0, maxLength)}...`
}

/**
 * Generate a random ID
 */
export function generateId(): string {
  return Math.random().toString(36).substring(2, 9)
}

/**
 * Delay function for simulating API calls
 */
export function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

