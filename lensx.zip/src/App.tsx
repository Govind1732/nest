"use client"

import { lazy, Suspense, useEffect } from "react"
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom"
import { Provider } from "react-redux"
import { store } from "./store/store"
import { AuthProvider } from "./modules/auth/context/AuthContext"
import { Toaster } from "./components/ui/toaster"
import { SkeletonPage } from "./components/ui/skeleton-page"
import { ChatbotWidget } from "./components/chatbot/ChatbotWidget"
import { ThemeProvider } from "./components/theme-provider"

// Import i18n instance
import "./i18n/i18n"

// Core components (always loaded)
import Layout from "./components/layout/Layout"
import LoginPage from "./modules/auth/pages/LoginPage"
import UnauthorizedPage from "./modules/auth/pages/UnauthorizedPage"

// Lazy loaded pages
const DQReportPage = lazy(() =>
  import("./modules/reports/pages/DQReportPage").then((module) => ({ default: module.DQReportPage })),
)
const DQDomainLevelReportPage = lazy(() => import("./modules/reports/pages/DQDomainLevelReportPage"))
const AutoProfilePage = lazy(() => import("./modules/profiling/pages/AutoProfilePage"))
const RuleProfileDTRanPage = lazy(() => import("./modules/profiling/pages/RuleProfileDTRanPage"))
const RuleProfileOneCorpPage = lazy(() => import("./modules/profiling/pages/RuleProfileOneCorpPage"))
const RuleProfileMLEPage = lazy(() => import("./modules/profiling/pages/RuleProfileMLEPage"))
const DataProfilePage = lazy(() => import("./modules/profiling/pages/DataProfilePage"))
const CustomProfilePage = lazy(() => import("./modules/profiling/pages/CustomProfilePage"))
const DataQualityValidationPage = lazy(() => import("./modules/profiling/pages/DataQualityValidationPage"))
const MyRequestPage = lazy(() => import("./modules/myRequests/pages/MyRequestPage"))
const HelpPage = lazy(() => import("./modules/help/pages/HelpPage"))
const DQMetricsAPIPage = lazy(() => import("./modules/apiIntegration/pages/DQMetricsAPIPage"))
const ETLPipelineIntegrationPage = lazy(() => import("./modules/apiIntegration/pages/ETLPipelineIntegrationPage"))
const DQFalloutSubscriptionPage = lazy(() => import("./modules/apiIntegration/pages/DQFalloutSubscriptionPage"))
const DQDataRemediationPage = lazy(() => import("./modules/apiIntegration/pages/DQDataRemediationPage"))
const DataDriftPage = lazy(() => import("./modules/apiIntegration/pages/DataDriftPage"))
const SchemaDriftPage = lazy(() => import("./modules/apiIntegration/pages/SchemaDriftPage"))
const MetadataGeneratorPage = lazy(() => import("./modules/apiIntegration/pages/MetadataGeneratorPage"))
const AdminPage = lazy(() => import("./modules/admin/pages/AdminPage"))

const App = () => {
  // Register service worker for PWA support
  useEffect(() => {
    if ("serviceWorker" in navigator) {
      window.addEventListener("load", () => {
        navigator.serviceWorker.register("/service-worker.js").then(
          (registration) => {
            console.log("ServiceWorker registration successful with scope: ", registration.scope)
          },
          (err) => {
            console.log("ServiceWorker registration failed: ", err)
          },
        )
      })
    }
  }, [])

  return (
    <Provider store={store}>
      <ThemeProvider defaultTheme="light" storageKey="lensx-theme">
        <AuthProvider>
          <Router basename="/dataQuality">
            <Routes>
              <Route path="/login" element={<LoginPage />} />
              <Route path="/unauthorized" element={<UnauthorizedPage />} />
              <Route path="/" element={<Layout />}>
                <Route
                  index
                  element={
                    <Suspense fallback={<SkeletonPage />}>
                      <DQReportPage />
                    </Suspense>
                  }
                />
                <Route
                  path="dq-domain-level-report"
                  element={
                    <Suspense fallback={<SkeletonPage />}>
                      <DQDomainLevelReportPage />
                    </Suspense>
                  }
                />
                <Route
                  path="dq-report"
                  element={
                    <Suspense fallback={<SkeletonPage />}>
                      <DQReportPage />
                    </Suspense>
                  }
                />
                <Route
                  path="profiling/auto-profile"
                  element={
                    <Suspense fallback={<SkeletonPage />}>
                      <AutoProfilePage />
                    </Suspense>
                  }
                />
                <Route
                  path="profiling/rule-profile/dtran"
                  element={
                    <Suspense fallback={<SkeletonPage />}>
                      <RuleProfileDTRanPage />
                    </Suspense>
                  }
                />
                <Route
                  path="profiling/rule-profile/onecorp"
                  element={
                    <Suspense fallback={<SkeletonPage />}>
                      <RuleProfileOneCorpPage />
                    </Suspense>
                  }
                />
                <Route
                  path="profiling/rule-profile/mle"
                  element={
                    <Suspense fallback={<SkeletonPage />}>
                      <RuleProfileMLEPage />
                    </Suspense>
                  }
                />
                <Route
                  path="profiling/data-profile"
                  element={
                    <Suspense fallback={<SkeletonPage />}>
                      <DataProfilePage />
                    </Suspense>
                  }
                />
                <Route
                  path="profiling/custom-profile"
                  element={
                    <Suspense fallback={<SkeletonPage />}>
                      <CustomProfilePage />
                    </Suspense>
                  }
                />
                <Route
                  path="data-quality-validation"
                  element={
                    <Suspense fallback={<SkeletonPage />}>
                      <DataQualityValidationPage />
                    </Suspense>
                  }
                />
                <Route
                  path="my-request"
                  element={
                    <Suspense fallback={<SkeletonPage />}>
                      <MyRequestPage />
                    </Suspense>
                  }
                />
                <Route
                  path="help"
                  element={
                    <Suspense fallback={<SkeletonPage />}>
                      <HelpPage />
                    </Suspense>
                  }
                />
                <Route
                  path="api-integration/dq-metrics-api"
                  element={
                    <Suspense fallback={<SkeletonPage />}>
                      <DQMetricsAPIPage />
                    </Suspense>
                  }
                />
                <Route
                  path="api-integration/etl-pipeline-integration-api"
                  element={
                    <Suspense fallback={<SkeletonPage />}>
                      <ETLPipelineIntegrationPage />
                    </Suspense>
                  }
                />
                <Route
                  path="api-integration/dq-fallout-subscription"
                  element={
                    <Suspense fallback={<SkeletonPage />}>
                      <DQFalloutSubscriptionPage />
                    </Suspense>
                  }
                />
                <Route
                  path="api-integration/dq-data-remediation"
                  element={
                    <Suspense fallback={<SkeletonPage />}>
                      <DQDataRemediationPage />
                    </Suspense>
                  }
                />
                <Route
                  path="api-integration/data-drift"
                  element={
                    <Suspense fallback={<SkeletonPage />}>
                      <DataDriftPage />
                    </Suspense>
                  }
                />
                <Route
                  path="api-integration/schema-drift"
                  element={
                    <Suspense fallback={<SkeletonPage />}>
                      <SchemaDriftPage />
                    </Suspense>
                  }
                />
                <Route
                  path="api-integration/metadata-generator"
                  element={
                    <Suspense fallback={<SkeletonPage />}>
                      <MetadataGeneratorPage />
                    </Suspense>
                  }
                />
                <Route
                  path="admin"
                  element={
                    <Suspense fallback={<SkeletonPage />}>
                      <AdminPage />
                    </Suspense>
                  }
                />
                <Route path="*" element={<Navigate to="/" replace />} />
              </Route>
            </Routes>
            <Toaster />
            <ChatbotWidget />
          </Router>
        </AuthProvider>
      </ThemeProvider>
    </Provider>
  )
}

export default App

