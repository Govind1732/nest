// Route path definitions
import { ROUTES } from "./constants"

export const routes = [
  {
    path: ROUTES.HOME,
    component: "Home",
  },
  {
    path: ROUTES.DQ_DOMAIN_LEVEL_REPORT,
    component: "DQDomainLevelReport",
  },
  {
    path: ROUTES.DQ_REPORT,
    component: "DQReport",
  },
  {
    path: ROUTES.MY_REQUEST,
    component: "MyRequest",
  },
  {
    path: ROUTES.HELP,
    component: "Help",
  },
  {
    path: ROUTES.AUTO_PROFILE,
    component: "AutoProfile",
  },
  {
    path: ROUTES.RULE_PROFILE_DTRAN,
    component: "RuleProfileDTRan",
  },
  {
    path: ROUTES.RULE_PROFILE_ONECORP,
    component: "RuleProfileOneCorp",
  },
  {
    path: ROUTES.RULE_PROFILE_MLE,
    component: "RuleProfileMLE",
  },
  {
    path: ROUTES.DATA_PROFILE,
    component: "DataProfile",
  },
  {
    path: ROUTES.CUSTOM_PROFILE,
    component: "CustomProfile",
  },
  {
    path: ROUTES.DATA_QUALITY_VALIDATION,
    component: "DataQualityValidation",
  },
  {
    path: ROUTES.ADMIN,
    component: "Admin",
  },
]

