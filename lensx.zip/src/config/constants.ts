// Application-wide constants

export const APP_NAME = "LensX - Data Quality & Validation"
export const API_BASE_URL = "/api"

export const DQ_SCORE_RANGES = {
  HIGH: { min: 90, max: 100, color: "success" },
  MEDIUM: { min: 80, max: 89, color: "warning" },
  LOW: { min: 0, max: 79, color: "error" },
}

export const PROFILE_TYPES = [
  "Auto Profile",
  "Rule Profile - DTRan",
  "Rule Profile - OneCorp",
  "Rule Profile - MLE",
  "Data Profile",
  "Custom Profile",
]

export const USER_ROLES = {
  ADMIN: "Admin",
  DQ_USER: "DQ User",
  EXECUTIVE: "Executive",
}

export const ROUTES = {
  HOME: "/",
  DQ_DOMAIN_LEVEL_REPORT: "/dq-domain-level-report",
  DQ_REPORT: "/dq-report",
  MY_REQUEST: "/my-request",
  HELP: "/help",
  AUTO_PROFILE: "/profiling/auto-profile",
  RULE_PROFILE_DTRAN: "/profiling/rule-profile/dtran",
  RULE_PROFILE_ONECORP: "/profiling/rule-profile/onecorp",
  RULE_PROFILE_MLE: "/profiling/rule-profile/mle",
  DATA_PROFILE: "/profiling/data-profile",
  CUSTOM_PROFILE: "/profiling/custom-profile",
  DATA_QUALITY_VALIDATION: "/data-quality-validation",
  ADMIN: "/admin",
}

export const SIDEBAR_ITEMS = [
  {
    title: "Home",
    href: ROUTES.HOME,
    icon: "Home",
  },
  {
    title: "Profiling",
    href: "#",
    icon: "Database",
    submenu: [
      {
        title: "Auto Profile",
        href: ROUTES.AUTO_PROFILE,
      },
      {
        title: "Rule Profile - DTRan",
        href: ROUTES.RULE_PROFILE_DTRAN,
      },
      {
        title: "Rule Profile - OneCorp",
        href: ROUTES.RULE_PROFILE_ONECORP,
      },
      {
        title: "Rule Profile - MLE",
        href: ROUTES.RULE_PROFILE_MLE,
      },
      {
        title: "Data Profile",
        href: ROUTES.DATA_PROFILE,
      },
      {
        title: "Custom Profile",
        href: ROUTES.CUSTOM_PROFILE,
      },
    ],
  },
  {
    title: "Data Quality Validation",
    href: ROUTES.DATA_QUALITY_VALIDATION,
    icon: "CheckCircle",
  },
  {
    title: "API Integration",
    href: "#",
    icon: "Webhook",
    submenu: [
      {
        title: "DQ Metrics API",
        href: "/api-integration/dq-metrics-api",
      },
      {
        title: "ETL Pipeline Integration API",
        href: "/api-integration/etl-pipeline-integration-api",
      },
      {
        title: "DQ Fallout Subscription",
        href: "/api-integration/dq-fallout-subscription",
      },
      {
        title: "DQ Data Remediation",
        href: "/api-integration/dq-data-remediation",
      },
      {
        title: "Data Drift",
        href: "/api-integration/data-drift",
      },
      {
        title: "Schema Drift",
        href: "/api-integration/schema-drift",
      },
      {
        title: "Metadata Generator",
        href: "/api-integration/metadata-generator",
      },
    ],
  },
  {
    title: "Reports",
    href: "#",
    icon: "BarChart",
    submenu: [
      {
        title: "DQ Reports",
        href: ROUTES.DQ_REPORT,
      },
      {
        title: "DQ Domain Level Report",
        href: ROUTES.DQ_DOMAIN_LEVEL_REPORT,
      },
    ],
  },
  {
    title: "My Requests",
    href: ROUTES.MY_REQUEST,
    icon: "FileText",
  },
  {
    title: "Admin",
    href: ROUTES.ADMIN,
    icon: "ShieldCheck",
  },
]

export const NAVBAR_ITEMS = [
  {
    title: "DQ Domain Level Report",
    href: ROUTES.DQ_DOMAIN_LEVEL_REPORT,
  },
  {
    title: "DQ Report",
    href: ROUTES.DQ_REPORT,
  },
  {
    title: "My Request",
    href: ROUTES.MY_REQUEST,
  },
  {
    title: "Help",
    href: ROUTES.HELP,
  },
]

