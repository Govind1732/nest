// Theme configuration for the application

import type { Config } from "tailwindcss"

export const colors = {
  primary: "#CD040B", // Verizon Red
  secondary: "#000000", // Black
  background: "#FFFFFF", // White
  sidebar: "#F5F5F5", // Light Gray
  success: "#008331", // Green
  warning: "#bc9f0a", // Yellow
  error: "#b95319", // Orange
  text: {
    primary: "#000000", // Black
    secondary: "#666666", // Dark Gray
    muted: "#999999", // Medium Gray
  },
}

export const theme: Partial<Config> = {
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
        sidebar: {
          DEFAULT: "hsl(var(--sidebar))",
          foreground: "hsl(var(--sidebar-foreground))",
          border: "hsl(var(--sidebar-border))",
          accent: "hsl(var(--sidebar-accent))",
          "accent-foreground": "hsl(var(--sidebar-accent-foreground))",
        },
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      fontFamily: {
        sans: ["verizon", "sans-serif"],
        bold: ["verizon-bold", "sans-serif"],
        light: ["verizon-light", "sans-serif"],
        tx: ["verizon-tx", "sans-serif"],
        "tx-bold": ["verizon-tx-bold", "sans-serif"],
      },
    },
  },
}

